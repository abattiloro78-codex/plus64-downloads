# Authored materials for composite dense sprites

This addendum specifies the opt-in dense-material format identified by snapshot
capability **82**. It extends the existing 70-byte dense MCM record without adding
sprite slots, a texture store or guest RAM. Bindings, column directories and
material recipes are authored by software and stored in the same shared 16 KiB.
The renderer has no game, character, body-part or fixed-address recognition.

The canonical byte contract is in
[`FORMAT.md`](../../emulator/experimental/sprite-formats/FORMAT.md), under
“Authored composite dense materials”. Capability 82 is a snapshot-header field,
not a 6502 register. Protocol 05 alone does not identify support for this format;
use the corresponding emulator and its packed-cache/mixed-sprite options.

## Dense record

Mode 1 keeps its previous bitmap, tag, ink and marker semantics exactly. With
capability 82 enabled, mode 2 or hexadecimal `$82` uses this interpretation:

| Record offset | Meaning |
| --- | --- |
| `$00` | Binding pointer low byte |
| `$01..$3F` | Existing inverse two-bit bitmap, unchanged |
| `$40` | Existing dense head height |
| `$41` | 2, or `$82` for reflected recipe coordinates |
| `$42..$44` | Original source inks for pairs 3, 2 and 1 |
| `$45` | `$80 | (binding_pointer >> 8)`; its top two bits must be `10` |

The resulting binding pointer is a full 14-bit offset in the existing 16 KiB
view. The ordinary descriptor still uses the dense pointer tag and packed-slot
selection. A 63-row column still occupies three consecutive 70-byte records;
each part has its own binding, origin and valid metadata. The format does not
add an expanded copy of the bitmap.

## Binding and column directory

Each binding occupies eight bytes and must fit without wrapping:

| Binding offset | Meaning |
| --- | --- |
| 0..1 | Recipe pointer, little-endian, in the shared 16 KiB |
| 2..3 | Column-directory pointer, little-endian |
| 4 | Composite width in columns: 1, 2 or 3 |
| 5 | This part's X origin in physical pixels: a multiple of 24 |
| 6 | This part's Y origin: a multiple of 21 |
| 7 | Composite height: 1..63 source pixels |

The directory holds one little-endian column-head address per column, in
actual left-to-right source order. Each column contains `ceil(height/21)`
consecutive dense parts. Column heads can be unaligned and noncontiguous.
Directories contain addresses, not other directories, so they cannot recurse.

The selected column head plus `originY/21 * 70` must equal the current record
address. Origins and displayed rows must lie inside the composite dimensions.
All referenced parts must have valid metadata, including parts outside the
visible screen. This explicit topology lets a material follow a composite
sprite across columns and 21-row boundaries without assuming its memory layout.

## Recipe encoding

A recipe begins with `$80 | count`, where count is 0..63 and the header's top
two bits are `10`. It is followed by `count` four-byte little-endian rectangles:

| Bits | Meaning |
| --- | --- |
| 0..5 | Inclusive x0 in two-pixel MCM units |
| 6..11 | Inclusive y0 in source pixels |
| 12..17 | Inclusive x1 in two-pixel MCM units |
| 18..23 | Inclusive y1 in source pixels |
| 24..25 | Source pair: 0 for any nonzero pair, or 1..3 |
| 26..28 | Material profile: 0..5; 6 and 7 are invalid |
| 29..31 | Component: 0..7 |

Equivalent packing is
`x0 | y0<<6 | x1<<12 | y1<<18 | pair<<24 | profile<<26 | component<<29`.
Coordinates must fit the declared composite. The last matching rectangle wins.
An unmatched pixel, profile 0 or a zero-rectangle recipe retains the original
ink. Pair 0 remains transparent: a recipe cannot create occupied pixels. Inks
above 120 retain their ordinary non-visible behaviour.

For frontal profiles, component 0 means that rectangle alone. Components 1..7
join winning rectangles with the same profile and pair selector into one row
span, including across dense columns and 21-row parts. The first and last
matching opaque source pixels determine its extrema. Holes and retained dark
details do not create additional light centres. Different component values keep
adjacent shapes independent. Software authors these groups; the renderer does
not infer anatomy.

## Profiles

| Profile | Output |
| --- | --- |
| 0 | Original source ink |
| 1 | Original hue; luminance 0..6 from distance to original opaque black |
| 2 | Original hue; soft frontal luminance 5..7 |
| 3 | Original hue; pale frontal luminance 6..7 |
| 4 | Neutral hue 1; dark frontal curve, luminance 0..3 |
| 5 | Neutral hue 1; lower-gain dark frontal curve, luminance 0..2 |

Profiles 1..3 preserve opaque black. Recolouring an original black region
therefore requires an explicit profile 4 or 5 rectangle. A later profile-0
rectangle can protect a detail that should keep its original ink.

Profile 1 uses nearest squared distance to opaque original black pixels.
Thresholds 2, 4, 5, 8, 9 and 10 select successive levels; distances at least 10
saturate at 6. Sampling needs only a radius-3 source neighbourhood across the
authored composite. It reads original masks and inks, never shaded output.

For profiles 2 and 3, let `width` be the winning row span and `edge` the distance
to its nearer extremum. Profile 2 uses depth 1 at widths 3/4 and depth 2 above
4; widths 1/2 stay at 7. Profile 3 keeps widths 1..4 at 7 and otherwise uses
depth 1. Other pixels use
`min(7, 7-depth+ceil(2*depth*edge/(width-1)))`.

For profiles 4 and 5, with span extrema `lo` and `hi`, use
`t=abs(2*x-lo-hi)/(width+1)` and `floor(gain*(1-t*t))`.
Gain is 16/5 for profile 4 and 72/25 for profile 5. Computations use bounded
integer arithmetic. A recipe can select different profiles on authored rows
without putting source-specific row numbers in the renderer.

## Reflection, validation and compatibility

Mode `$82` reflects recipe lookup X across the complete composite width. It
does not reverse bitmap bytes: software already owns their orientation.
Distance sampling uses actual source space; symmetric frontal curves use the
reflected recipe/group coordinates. Expansion, clipping, display priority and
collision processing still follow the colour calculation.

Mode 2/82 bypasses the older whole-record tag, radial and diagonal material
selectors. Mode 1 is unchanged when capability 82 is enabled. Bad pointers,
bindings, directories, recipes, rectangles, part metadata or complete-chain
bounds reject the entire displayed chain. Pointers never wrap.

Enable mixed formats and packed cache while output is disabled, before
publishing these records. Snapshot header 82 is boolean and requires dense
capability 80, mixed formats and packed cache. Bytes 83..127 remain reserved
zero; the existing serialized payload remains 144,776 bytes. Old snapshots
with header 82 zero leave modes 2/82 invalid. Older readers reject the nonzero
reserved field instead of interpreting the new record incorrectly.

Bindings, directories and recipes must be counted in the application's
**65,536 + 16,384 = 81,920-byte** budget. This format defines no additional
bitmap, material or history pool. Application build and test reports must
identify their data, addresses, matching emulator and validation scope.
