# Usagi RAM80 — materiali composti, candidato 018

Il controllo indipendente ricostruisce esattamente i 65.536 byte dell’immagine finale, applicando **400 patch con guardie** nell’ordine dichiarato e **19 componenti** disgiunti per **5.096 byte** nella RAM principale esistente. Esegue inoltre uploader e ripristino basso su una CPU 6502 privata con un modello delle porte. Questo controllo statico/CPU non sostituisce le prove del disco e dell’emulatore. I rapporti dei candidati precedenti restano storici.

## Artefatti esatti

| Artefatto | Byte | SHA256 |
| --- | ---: | --- |
| Immagine principale | 65,536 | `6bc77415e438f6d14d751b1f363e1d4c98b7f67a6cb184da2c13ec60ccd0858d` |
| Banchi originali D/F | 8,192 | `d07595210b1beb05a25c918e4b9eebb49a8ae7043e6797fa265b0afbdc1d9546` |
| Materiali | 4,608 | `0931967d3efe26c0f6e9abb47882f0d5301852621501134e8fdf8ae130f0978b` |
| PRG | 60,673 | `8fc5981990ce5f0e9dae3345fbe54e7c1664f55bcab1df3fd78bab38e25cab69` |
| D64 | 174,848 | `a5a8040a61e41beb8f202645d8d438f98718538e924df6246e736016ea851843` |


La macchina emulata dispone sempre di **65.536 + 16.384 = 81.920 byte**. Non sono previsti altri pool per bitmap, sprite, cache, modem o decompressione.

| RAM interna, inizio incluso/fine esclusa | Byte | Uso a regime |
| --- | ---: | --- |
| `$0000..$0C94` | 3.220 | 46 record densi da 70 byte |
| `$0C94..$0E00` | 364 | Non assegnati; possono contenere residui dell’avvio |
| `$0E00..$2000` | 4.608 | Lookup, collegamenti, cache, directory e ricette dei materiali |
| `$2000..$3000` | 4.096 | Banco D originale |
| `$3000..$4000` | 4.096 | Banco F originale |
| **Totale** | **16.384** | |

Il payload dei materiali comprende due piani da 256 byte di puntatori alle ricette (`$0E00/$0F00`), una riserva di 46 collegamenti da 8 byte (`$1000..$1170`), 24 byte di directory delle colonne (`$1170..$1188`) e ricette deduplicate a partire da `$1190`. I 24 collegamenti degli attori occupano `$1000..$10BF`; una cache di 16 byte riusa collegamenti non selezionati del ritratto, a `$10C0..$10CF`. Il ritratto usa il modo originale 1 e non interpreta tali byte come collegamenti. Il margine tra directory e ricette resta compreso nel payload di 4.608 byte.

Le ricette sono dati del gioco generati da `materials/characters.json`, non riconoscimenti del personaggio nel renderer. Le 207 pose canoniche hanno assegnazioni esplicite. Si conservano bitmap RLE, tabelle delle pose, inchiostri nei record e banchi compressi originali. Le ricette possono modificare luminanze e, per regioni scure esplicite, selezionare una tinta neutra; non aggiungono pixel occupati.

Gli helper usano soltanto intervalli già disponibili nella RAM principale: `$0C90`, `$2CB0`, `$2EA8` e `$DF40`, più campi temporanei nello stato sprite già riservato. Il controllo sull’immagine finale verifica le dimensioni e l’assenza di sovrapposizioni. Gli otto slot video e i 46 record non aumentano.

Il caricatore carica materiali e banchi originali con decompressione all’avvio, riusando memoria principale e interna già esistenti. La sorgente dei riferimenti LZ è l’output già prodotto, senza una cronologia residente separata. L’avvio temporaneo sotto `$0E00` e il payload materiali da `$0E00` sono distinti e appartengono agli stessi 16 KiB.

Il nuovo formato richiede la capacità snapshot 82. I modi 2/82 usano puntatori a collegamenti espliciti, mantenendo il record da 70 byte; il modo 1 del ritratto e delle versioni precedenti resta invariato. Vedere `ADDENDUM_DENSE_MATERIALS_IT.md` per il contratto generico. Sono necessarie prove del nuovo eseguibile e del nuovo disco: le prove storiche del decoder precedente non vengono trasferite al produttore modificato.

Windows tramite Wine, Windows nativo e hardware fisico sono ambiti distinti. Non si dichiara una campagna completa o una prova su hardware.

## Payload e componenti finali

Il payload usa **4.577 byte** dei 4.608 riservati, lasciando **31 byte di padding** interni alla riserva. Le 107 definizioni di template diventano 85 ricette deduplicate; i dati delle ricette occupano 3.665 byte a partire da `$1190`. La selezione copre tutte le 207 pose canoniche: 171 hanno cambiamenti di colore effettivi e 36 pose di effetti o vuote conservano esplicitamente i colori originali. Sono comprese le 48 pose NPC con regioni chiare dei pantaloni definite esplicitamente. I byte dei banchi originali, dei bitmap RLE e delle tabelle delle pose restano invariati.

Il produttore denso conserva i byte di collegamento mentre aggiorna i 63 byte visibili del frammento. La vecchia matrice di 5.508 casi del produttore mode1 conserva valore storico per quel codice; non viene presentata come qualifica automatica del produttore modificato. Le prove CPU dei nuovi helper e i confronti del renderer sono rapporti separati, legati ai propri hash.

I materiali compressi occupano 2.349 byte di trasporto e i banchi originali compressi 6.212 byte. Queste dimensioni riguardano il caricamento: a regime restano un solo payload di 4.608 byte e gli originali 8 KiB di banchi nella medesima RAM interna. Il controllo dell’uploader verifica i materiali esatti; inizializzazione e ripristino basso li conservano.

| Componente | Inizio | Fine esclusa | Byte |
| --- | --- | --- | ---: |
| `ui_marks` | `$0A00` | `$0AAB` | 171 |
| `ui_data` | `$0B40` | `$0B80` | 64 |
| `bridge_stub` | `$0B80` | `$0BD5` | 85 |
| `ui_rows` | `$0C00` | `$0C89` | 137 |
| `material_finish` | `$0C90` | `$0D7F` | 239 |
| `bridge` | `$2800` | `$2A4E` | 590 |
| `video` | `$2A80` | `$2CA5` | 549 |
| `material_entries` | `$2CB0` | `$2CD3` | 35 |
| `timers` | `$2D00` | `$2EA6` | 422 |
| `material_cache` | `$2EA8` | `$2EFF` | 87 |
| `input` | `$2F00` | `$2FBA` | 186 |
| `direct_colour` | `$40B4` | `$41CA` | 278 |
| `direct_column` | `$43F1` | `$444A` | 89 |
| `memory` | `$DC00` | `$DD8F` | 399 |
| `menu` | `$DD90` | `$DE1F` | 143 |
| `keyboard` | `$DE40` | `$DEEC` | 172 |
| `bootstrap` | `$DF00` | `$DF40` | 64 |
| `material_record` | `$DF40` | `$DFDB` | 155 |
| `sprites` | `$F800` | `$FCCF` | 1231 |
