# Final revision3/game015 GUI receipt

Exact stage: `/workspace/work/usagi-port-004/delivery-rev3/runtime`.
Windows PE: `ed5048964eaee623d27657b096083b7f9598da1859e0d3a55a9512341b9f613a`.
D64: `5f0448a5d3f8885085d696bc51d14497c9566d0ab0e86ef110d1729d650a59ee`.
No provisional/c776 executable was used. Stage files were not edited by this
QA task. Final hashes for game, PE, map and both launchers are recorded in
`wine-final15-two-messages/PROOF.json`; the tested disk is preserved beside it.

The exact production SDL Windows executable was cold-autostarted under Wine.
Actual host F1/F3/F7, arrows and Space drove the original game. There was no
observer hook, debug joystick device, guest RAM/PC/health/progress assignment
or loaded running snapshot. F1 selectedGAME; F3 toggled and restored input;
F7 paused/resumed original code, with no world movement during65,536 paused
instructions despite Right held. Up alone animated jumping. The ordinary
route eventually reached the original atonement/end path38A8; health remained9
and player flags became0, as that original script specifies.

Two distinct messages were reached through ordinary play in one GAME:

1. Bowed early at worldX324 before the farmer's automatic acknowledgement
   range. He replied “THANKYOU NOBLE RONIN”, E8=81/E9=2. Two stationary
   captures8source boundaries apart matched every displayed source/native
   character and standard ink across physical rows0,1,2,3 and lowerHUD24.
   This includes the blank partial tail row3. Natural expiry returned65/0;
   physical rows0,1 and24 were exact.
2. Approached, drew the sword and attacked. The original repentance message
   “MY SOUL IS EMPTY…ATONE FOR MY SHAME” appeared, E8=89/E9=3. All displayed
   codes and standard inks across rows0,1,2,3,4 and24 were exact in three
   captures, including the blank partial tail row4. Its natural expiry
   returned65/0 with physical rows0,1 and24 exact.

All seven lifecycle captures had clear dirty flags. Every latent row0..6,
source/native differences,BE and0B0C/0D0E pointers are retained in
`NATURAL_TWO_MESSAGE_UI15.json`, also embedded into the finalPROOF.json.
The physical mask is `ceil((E8-51)/8)`, correcting the older whole-row-only
checks documented in `COVERAGE_ERRATUM.md`.

This natural sequence is **short-to-long**, not a claimed natural
long-to-short reproduction. The UI owner's independent controlled
long-to-short/clear/interrupt proofs remain separate. OriginalPRACTICE was
also tested on014 without F1; its bounded1253tick combat-arena route produced
no6052message calls, so no repeated tutorial texts are claimed.

The unchanged64ms launcher setting was recognized: a continuous unwarped
menu window ignored500SID-update hits in10.104s, with no internal monitor
stops. Diagnostics confirm48kHz,128-sample fragments and64.00ms buffer. The
file sink was used because the host has no working physical Windows WMM
output; this is not proof that the user's audible crackling is cured.

Cold C16/Plus4 and closed-border pixel/cadence tests are owned by the
independent distribution agent. These GUI tests are Wine qualification,
not native Windows, physical hardware, a complete campaign or a victory.
