# Usagi RAM80 — controllo memoria e patch del candidato finale 016

Il candidato usa **65.536 + 16.384 = 81.920 byte della macchina emulata (80 KiB)**. Non esistono pool aggiuntivi per sprite, modem, cache o decompressione. Questo controllo ricostruisce in modo indipendente l'immagine principale finale ed esegue il ripristino della memoria bassa con un modello privato di CPU 6502 e porte. Avvio nell'emulatore, comandi e gioco costituiscono prove separate.

## Artefatti esatti

| Artefatto | Byte | SHA256 |
| --- | ---: | --- |
| Immagine principale nativa | 65.536 | `cdd88c268c9b3c78d901549bb24db9c7b5740c7ffbf44bfecd983544fd170ccb` |
| Banchi originali D/F conservati | 8.192 | `d07595210b1beb05a25c918e4b9eebb49a8ae7043e6797fa265b0afbdc1d9546` |
| D64 per avvio a freddo | 174.848 | `8a60ec6ba4c2121e24a3f7d7cc67271291467962e35e8989b8ecebf831b23472` |

L'immagine principale viene ricostruita byte per byte dall'immagine sorgente senza trainer, applicando tutte le **393 patch con guardie**, la copia di 2 KiB di tabelle, 15 componenti compilati e gli intervalli di inizializzazione dichiarati. Le 393 patch comprendono le 14 guardie per la rilocazione delle tabelle. Ogni sequenza attesa prima della patch coincide nell'ordine di applicazione. Non sono emerse differenze non dichiarate, troncamenti o sovrapposizioni tra componenti compilati. Codice e dati dei componenti occupano 4.580 byte nella RAM principale esistente: non si sommano ai 64 KiB.

## Uso della RAM principale

Gli intervalli seguenti hanno **inizio incluso e fine esclusa**. Descrivono l'assegnazione della memoria fisica sottostante, compresi i byte coperti da I/O: non tutti gli indirizzi sono direttamente utilizzabili dalla CPU mentre I/O o ROM sono visibili.

| Intervallo | Byte | Assegnazione |
| --- | ---: | --- |
| `$0000..$0200` | 512 | Zero page e stack CPU |
| `$0200..$0A00` | 2.048 | Tabelle originali spostate da `$1800..$1FFF` |
| `$0A00..$0D80` | 896 | Helper nativi bassi, area temporanea e dati UI |
| `$0D80..$0F00` | 384 | Copie dei registri VIC/CIA, stato adattatori e vettori originali |
| `$0F00..$1800` | 2.304 | Animazioni e dati originali |
| `$1800..$2000` | 2.048 | Coppia TED UI indipendente: attributi/codici `$1800/$1C00` |
| `$2000..$2800` | 2.048 | Font, matrice sorgente e stato HUD originali |
| `$2800..$3000` | 2.048 | Bridge, video, timer e input nativi |
| `$3000..$3800` | 2.048 | Font originale dell'area di gioco |
| `$3800..$8000` | 18.432 | Codice e dati originali con adattatori verificati e intervalli di codice riusati dichiarati |
| `$8000..$D000` | 20.480 | Asset compressi e intestazioni originali |
| `$D000..$D800` | 2.048 | Coppia TED fondale A: attributi `$D000`, codici `$D400` |
| `$D800..$DC00` | 1.024 | Copia della RAM colori C64 originale |
| `$DC00..$E000` | 1.024 | Memoria, menu, tastiera e ingresso nativi |
| `$E000..$F000` | 4.096 | Area SID/musica originale con modifiche dichiarate agli operandi delle periferiche |
| `$F000..$F800` | 2.048 | Coppia TED fondale B: attributi `$F000`, codici `$F400` |
| `$F800..$FD00` | 1.280 | Publisher sprite densi e spazio riservato restante |
| `$FD00..$10000` | 768 | I/O nativo, memoria sottostante non assegnata e vettori CPU reali |
| **Totale** | **65.536** | |

La disposizione bassa separa codice UI `$0A00`, area RLE temporanea da 64 byte `$0B00..$0B3F`, tabelle/scratch UI `$0B40..$0B7F`, stub del bridge `$0B80` e codice di pubblicazione delle righe `$0C00`. Le copie VIC/CIA restano a `$0D80/$0DC0/$0DD0`; lo stato denso occupa `$0DE0..$0E44`, i timer `$0E50..$0E5F`, lo scratch input `$0E60`, lo stato del bridge `$0E61..$0E6B` e la copia dei vettori originali `$0E70..$0E75`.

## RAM interna condivisa

| Intervallo durante il gioco | Byte | Assegnazione |
| --- | ---: | --- |
| `$0000..$0C94` | 3.220 | 46 record MCM densi × 70 byte |
| `$0C94..$2000` | 4.972 | Non assegnati dal runtime; possono contenere residui del caricamento |
| `$2000..$3000` | 4.096 | Banco originale di asset principali `$D000..$DFFF` |
| `$3000..$4000` | 4.096 | Banco originale `$F000..$FFFF`, compresi i byte dei vettori precedenti all'inizializzazione |
| **Totale** | **16.384** | |

Ogni byte dei due banchi originali è conservato esattamente. Gli scambi e le letture indirette durante il gioco vi accedono attraverso la porta della RAM interna condivisa: non sono asset conservati dall'host fuori dal budget. Anche gli intervalli principali originali `$2000..$27FF`, `$3000..$37FF` e `$8000..$CFFF` coincidono byte per byte con il sorgente pulito.

Quattro personaggi usano otto colonne dense di 63 righe. Le teste sono i record fisici `0,3,6,9,12,15,18,21`, ciascuno seguito da due blocchi da 21 righe. I record HUD `24..29` hanno altezza ordinaria da 21 righe. Le altre 16 posizioni conservano la propria mappatura, ma non sono selezionate come colonne dei personaggi. Formato denso e altezza concatenata richiedono le capacità correnti abilitate esplicitamente, rappresentate dai byte 80 e 81 dell'intestazione snapshot PLUS64. Si usano gli slot esistenti e gli stessi 16 KiB interni.

Durante l'avvio a freddo, la RAM interna `$0000..$0CFF` contiene temporaneamente i futuri byte principali `$0200..$0EFF`, mentre `$0D00..$0DFF` contiene la pagina del finalizzatore. I due banchi interni `$2000..$3FFF` rimangono presenti. Questi byte temporanei occupano la stessa memoria che diventerà record densi o resterà non assegnata: non costituiscono altri 3,5 KiB.

Il trasporto compresso del disco risiede nella RAM principale esistente. La coda di ingresso `$F500..$FCFF` viene protetta temporaneamente nella RAM principale `$0700..$0EFF`, usata per questo soltanto durante il caricamento; l'uscita stessa fornisce la cronologia LZ. Il finalizzatore ripristina `$0200..$09FF` e `$0B00..$0EFF`, preservando la propria pagina in esecuzione `$0A00`. L'ingresso `$DF00` ripristina `$0A00..$0AFF` dalla RAM interna `$0800..$08FF` prima di installare il bridge e inizializzare i record densi. L'inizializzazione sovrascrive poi soltanto la RAM interna `$0000..$0C93` con 46 record. Tabelle rilocate, codice basso ripristinato e banchi originali D/F rimangono intatti.

## Ritiro della cache, riuso di codice e automodifica

La vecchia cache sprite principale di 46 record `$0200..$0D7F` non conserva più i pixel. Quattro caricamenti del decoder, modificati con guardie, selezionano l'area temporanea `$0B00`; le due chiamate originali al bridge selezionano lo stub da 85 byte a `$0B80`. Gli indici logici della cache rimangono disponibili al gioco. Una matrice di **5.508 casi**, rieseguita in modo indipendente, confronta le chiamate originali complete `$45A9/$45B0` con questo percorso nella posizione finale `$F800/$0DE0/$0B00` e con la palette effettiva. I binari di publisher e stub coincidono esattamente con il candidato. Vengono confrontati stato CPU finale, tutta la zero page, RAM non ritirata, 30 maschere effettive degli sprite e byte interni estranei all'operazione. È una prova CPU circoscritta, non una partita completa.

I 14 riferimenti alle tabelle, l'helper copiato dei tasselli e il banco partner dello scambio glifi usano le tabelle rilocate. `$1800/$1C00` diventa così una coppia UI realmente indipendente, senza sovrapporsi ai dati originali.

Gli helper tipizzati dei colori riusano gli intervalli dei vecchi callback CIA e di avvio `$40B4..$41D0` e `$43F1..$444E`. Tra i 4.340 inizi di istruzione originali identificati non compaiono operandi assoluti diretti rivolti a questi intervalli. Il dispatcher nativo IRQ/NMI non entra nei callback ritirati. Le automodifiche note del dispatcher originale puntano a `$4082..$40AE`, fuori dagli intervalli riusati. La conclusione dipende dalla sostituzione del dispatcher nativo e non dimostra compatibilità con ingressi esterni arbitrari.

La scrittura dei record originariamente a `$3DAE` viene spostata intenzionalmente a `$418C`, mantenendo la forma `STA $FFFF,Y`. Tutte le sette letture/scritture originali del suo operando automodificante sono controllate e rivolte ai nuovi byte `$418D/$418E`. Non viene confusa con una scrittura ai vettori CPU. Le 16 scritture assolute identificate ai vettori originali vengono indirizzate separatamente a `$0E70..$0E75`; i vettori CPU nativi reali rimangono sotto il controllo del bridge.

## Revisione 2: scorrimento grossolano differito

La patch precedente sostituiva con NOP il `CLI` originale a `$43E7`, lasciando la lunga routine di scorrimento grossolano `$5E56` dentro un IRQ nativo con gli interrupt mascherati. Al cambio di blocco dello scorrimento questo ritardava i successivi eventi dell'area di gioco. La patch corrente di quattro byte è `JMP ub_frame_done` seguito da NOP. Termina il prefisso originale del frame con le esatte estrazioni Y/X/A e RTI, consentendo al dispatcher nativo di armare prima il successivo evento raster. L'IRQ esterno esegue poi con CLI la routine sorgente `$5E56` invariata e ripristina lo stato mascherato al ritorno.

I byte pending/running del frame sono `$0E6A/$0E6B`, subito dopo i byte pending/running già presenti per il ritratto `$0E68/$0E69`, nello stesso blocco principale riservato `$0D80..$0EFF`. La guardia running impedisce di rientrare ricorsivamente nello stesso worker; un completamento di frame accodato durante il lavoro rimane pendente. IRQ raster nativi annidati e worker del ritratto possono procedere mentre continua lo scorrimento grossolano. Il vecchio corpo delle strisce dei personaggi è sostituito dal suo ingresso ABI conservato con RTS: le colonne dense usano una sola banda dei timer. Il bridge occupa ora **590 byte** a `$2800..$2A4D`; tutti i componenti compilati restano disgiunti. Non si aggiungono memoria principale/interna, record sprite o slot visualizzati.

`frame-worker-proof015/PROOF.json` verifica indipendentemente 2.048 casi di stato/stack nell'epilogo, sette esecuzioni del vero prefisso originale del frame attraverso il chiamante sintetico del timer, 256 casi di IRQ/registri/coda/puntatore e quattro casi di IRQ annidati. In un campione valido catturato al cambio di blocco dello scorrimento, l'esecuzione diretta di `$5E56` e il percorso IRQ differito lasciano uguali tutti i byte principali estranei all'harness e tutti i 16 KiB interni. A/X/Y/P/SP e `$FD97/$FD98` vengono ripristinati per il chiamante interrotto. Sono prove CPU circoscritte: la cadenza video effettiva e le interazioni prolungate richiedono il proprio rapporto nativo.

Il launcher usa un **buffer audio dell'host di 64 ms**. L'impostazione controlla la temporizzazione audio dell'host; la memoria principale/interna emulata rimane esattamente di 65.536 e 16.384 byte.

## Revisione 3: cancellazione UI e bordi nativi opzionali

Tre ulteriori chiamate modificate con guardie coprono la routine originale di cancellazione dei dialoghi e quella generale dei colori sorgenti. L'helper completa l'operazione originale, poi marca le righe UI native interessate. Si copre così il percorso di scrittura mancante quando un dialogo scompare. Il componente tipizzato dei colori occupa ora 278 byte, sempre nell'intervallo esistente `$40B4..$41D0`; l'ingresso di avvio occupa 64 byte, sempre in `$DF00..$DFFF`. Nessuna assegnazione si estende su dati originali attivi. L'immagine della revisione 3 conteneva 393 patch con guardie e 4.575 byte di componenti compilati.

Il bootstrap scrive FD9F bit4 (`P64_SIDE_BORDER_CLIP=16`) dopo l'inizializzazione degli sprite. Il nuovo emulatore corrispondente versiona questa regola opzionale al byte scenari 79=18 dello snapshot. Il passaggio finale sui pixel ripristina i bordi nativi chiusi dopo sprite/finestre, usando limiti TED, stato di apertura/blank catturato e colore nativo del bordo. Rispetta bordi aperti e disabilitati; l'accumulo delle collisioni rimane invariato. Descrittore temporaneo dell'host e decisione di ridisegnare la base non aggiungono RAM al programma. Restano gli stessi 64+16 KiB, record e slot. I profili precedenti ignorano il bit4; un vecchio eseguibile rifiuta snapshot con profilo 18. Le capacità dense 80/81 e la dimensione del payload non cambiano.

Gli addenda IT/EN sui bordi e le prove sui sorgenti specificano stato stabile di riga e compatibilità. Le prove native correnti coprono pixel dei bordi e cadenza su C16 e Plus/4; una qualifica UI separata lega tutti gli helper compilati e le guardie. L'ambito non comprende trucchi del bordo a precisione di ciclo dentro una riga o tutti i percorsi del gioco. Il nuovo disco va abbinato al nuovo runtime.

## Revisione 4: scansione tastiera interrompibile

Un lampeggio intermittente della barra vita è stato ricondotto alla scansione della matrice tastiera: gli interrupt rimanevano mascherati durante tutte le otto righe, ritardando il passaggio video all’HUD. La nuova routine rende atomica soltanto la transazione di lettura di una riga: salva FD30, seleziona e campiona la riga, ripristina FD30 e lo stato degli interrupt. Il lavoro sui bit e sulla priorità dei tasti può essere interrotto. I temporanei usano lo stack CPU già esistente e non condividono `$0E60` con i lettori del controller. L’ordine dei tasti e il risultato originali sono conservati.

Il componente tastiera cresce da 167 a **172 byte**, sempre in `$DE40..$DEEB`; i 15 componenti occupano ora **4.580 byte** all’interno della RAM principale esistente. Non si aggiungono flag residenti, record sprite o memoria interna. Le prove temporali e di interazione del nuovo disco sono separate dal presente controllo statico e dalla copia a freddo. La revisione 4 usa lo stesso emulatore corrispondente della revisione 3: questa correzione modifica il gioco, senza cambiare l’emulatore.

## Prove e limiti

`PROOF.json` e `review.py` registrano la ricostruzione indipendente e le vere istruzioni di uploader, finalizzatore, bootstrap e installazione eseguite nel modello CPU privato. La matrice esatta di ritiro della cache è conservata in `retirement-final-010/PROOF.json`, con identificazione binaria del candidato finale. Gli hash dei generatori sorgente coincidevano con quelli del candidato al momento del controllo.

Nel grafo del codice originale restano callback dinamici delle azioni non risolti. Questo controllo non dimostra la vitalità della memoria su ogni percorso, una campagna completata, il funzionamento su Windows nativo o su hardware fisico. Avvio a freddo C16/Plus/4, comandi ordinari, Wine, dialoghi e temporizzazioni devono essere valutati nei rispettivi rapporti riferiti agli artefatti corrispondenti. Il disco sorgente è la versione THT fornita, con trainer rimosso, non un originale editoriale incontaminato dimostrato. I diritti del gioco e gli avvisi GPL dell'emulatore rimangono distinti, come indicato nella guida rapida.
