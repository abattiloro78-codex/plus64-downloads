# Revision2 final QA receipt — game014

Exact tested stage: `/workspace/work/usagi-port-003/delivery-rev2/runtime`.
D64 SHA256: `23a14e792d1b8410083f6f1ff13e2f8c4556906071beb0883761ff4e61958b94`.
Windows PE SHA256: `f09fa305a7a7bf52093e253f800e1442c113869a49e4d740fa5c842c5356472b`.
`wine-rev2-014/PROOF.json` also records final PRG/VKM/both launcher hashes.

Ordinary KERNAL D64 cold boot and exact low-RAM restoration passed for both
C16 and Plus/4: `/workspace/work/usagi-port-003/cold-c16-014/PROOF.json` and
`.../cold-plus4-014/PROOF.json`. No RAM/PC injection or restored running
snapshot was used in these final game tests.

The exact staged production SDL Windows PE was tested under Wine with actual
XTest F1/F3/F7, arrows and Space, the staged custom map and joystick keysetA.
F1 selected original GAME, F3 toggled input option and restored it, F7 paused
and resumed original paths; held Right did not move the world during65,536
paused instructions. Up alone animated jumping; held/released Space and
Up+Space exercised the original action paths.

A continuous unwarped menu window ignored500SID-update hits and took10.102s,
with no monitor stops inside that window. The production sound engine opened
at48kHz,128-sample fragments and an effective64.00ms buffer, matching the new
launcher option. This uses the diagnostic file sink because this Linux/Wine
host has no working physical WMM sound device. It validates64ms recognition,
normal-speed generation and runtime behavior; it does not prove that the
user's native-Windows crackling is cured.

The real original repentance message executed and expanded through E9=1,2,3.
Two stationary visible captures at E8=89 had every native UI character and
standard TED ink equal to source2400/D800 for all visible rows0,1,2,3,24.
Dirty flags were clear. Camera0132 and both1000-cell D400/F400 background
matrices were unchanged across those captures. Natural expiry returned
E8=65/E9=0 and visible rows0/24 remained exact. This preserves the previous
late-colour-race fix.

The ordinary route ended through the original atonement path38A8 after1185
source-handler boundaries; player flags became0 while health stayed9. No
HP-loss claim is made for this specific scripted-ending route. No source
health/score/position/progress was assigned. This is bounded qualification,
not a full campaign/victory, native-Windows or hardware test.

Only the64ms buffer mitigation is enabled in the revision2 launchers.
Presentation VSync remains enabled; the emulator executable and SID model/
clock remain unchanged. The guest memory budget remains64+16KiB; host audio
buffering does not allocate another guest RAM pool.
