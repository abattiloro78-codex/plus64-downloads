# Usagi013 audio and host pacing audit

Production game/runtime files were not modified. Every Windows run used the
released013 game and exact stripped PE f09fa305a7a7bf52093e253f800e1442c113869a49e4d740fa5c842c5356472b
from `/workspace/work/usagi-port-002/delivery-010/runtime`.
The host is Linux/Wine/Xvfb, not native Windows or the user's sound/GPU driver.

## Concrete findings

* The launcher supplies no sound buffer override. Windows defaults request30ms;
  with48kHz and128-sample fragments the actual WMM/file buffer is32ms (1536
  samples). Existing other-game runtime launchers explicitly request64ms.
* The bootstrap clears native TED volume registerFF11. The original SID module
  is used, writes remapped toFD40. SID is the primary mixer. Clock0 selects
  exact C64 PAL985248Hz via the fractional native-clock wrapper; it is not
  simply advanced at the native TED clock.
* VICE3.10 has no RefreshRate resource in this build. Outside warp,
  `vsync_should_skip_frame()` returnsfalse. Its old adaptive-skip comment is
  stale. Normal playback does not automatically skip via that code path.
* SDL presentation VSync defaults on and requestsSDL_RENDERER_PRESENTVSYNC.
  `+TEDvsync` disables this presentation wait at renderer creation. It does
  not change guest emulation clock or game logic.
* WMM's playback buffer loops in waveOut. The implementation has no underrun
  counter/log and cannot establish healthy playback from absence of warnings;
  starvation can replay old buffer contents. SDL's ring likewise lacks a
  useful recorded underrun metric. This is a mechanism, not proof that the
  user's device starved.

## Continuous unwarped measurements

`host_pacing.py` uses ordinary cold D64, actual GUI keys, and no guest RAM/PC
assignments. Each measured window runs continuously, without monitor stops.
The test observes clock/metrics/ring pointers through read-only process memory;
addresses come from the matching unstripped PE's symbols, whose core sections
match production. These are host-emulator metadata, not extra guest RAM.

Filesink, default32ms effective (`fs-002/PROOF.json`):

| Window | Median emulator speed | Median emulated FPS |
|---|---:|---:|
| Menu |99.996%|49.859|
| GAME standing |99.999%|49.860|
| GAME Right |99.998%|49.860|

The initial monitor count literal500 was hexadecimal: these first windows
ignored1280SID-update hits each (~26s), explicitly corrected in their report.
Their actual wall times/metrics are unchanged. Later tests use$1F4=500.
The100Hz observer's maximum scheduling gaps were13–17ms. This environment
showed no sustained emulator CPU slowdown in any of the three cases.

SDL audio with dummy backend (`sdl-default-002/PROOF.json`) opened at48kHz,
256-sample fragments,32ms ring. After the initial0.7s, no sampled empty ring
occurred in any continuous window; median occupancy was the full1536samples.
Its dummy backend paces about104.5%/52.1fps, so it is not a physical-device
speed/quality qualification. “Buffer full during suspend” warnings were at
intentional monitor boundaries, not continuous-playback underruns.

The actual default WMM attempt (`wmm-001`) could not open host audio:
ALSA reported `cannot find card0` and `Unknown PCM default`. It timed out
beforeREADY. This is a host limitation, not a game failure; no native-Windows
WMM listening or user-device underrun measurement is claimed.

## Original sound reference

`c64-reference-001` uses the same extracted, trainer-removed original source
RAM image on standard x64sc, with explicit development RAM/PC injection. It is
an audio reference, not an autonomous original-D64 boot claim. Its original
menu ran501SID updates continuously, unwarped (~9.97s).

Eight-second48kHz/16bit mono excerpts, after the first0.5s, are
`native-menu.wav` and `original-C64-menu.wav`; basic statistics are saved in
`PCM_BASIC_STATS.json`.

| Statistic | Native013 | Original C64 |
|---|---:|---:|
| RMS |1662.98|1641.77|
| Clipped samples |0|0|
| Largest adjacent-sample step |7311|9227|
| Adjacent steps above12000 |0|0|

The native recording does not show gross clipping or discontinuities beyond
the original reference. This is numerical evidence, not a claim of perfect
perceived sound or bit-identical analogue synthesis. It does not measure the
physical output after the Windows driver/compositor.

## Bounded candidate changes

Neither proposed option was applied to production. Work-only replacement
launchers and exact one-token diffs are in `launcher-candidates/MANIFEST.json`.
They preserve the game, PE, SID model/clock and all RAM80 settings.

1. `audio64`: only add `-soundbufsize 64`. This supplies64ms rather than32ms reserve: about3.2rather than1.6
   PAL frame intervals, with the same128-sample fragment granularity. It
   aligns the other current-game launchers. It adds roughly32ms reserve and
   does not solve genuine synthesis corruption or sustained CPU overload.
   Option recognition and continuous menu pacing were tested in
   `fs-64-001`: effective64ms, about100.12%/49.92fps, no slowdown.
2. `vsync-off`: only add `+TEDvsync`. `fs-vsyncoff-001` confirms VSync disabled,
   actual32ms buffer retained, continuous menu99.984%/49.853fps. This isolates
   host presentation blocking; on this Xvfb host it showed no material gain.
   It can permit tearing and cannot turn PAL49.86Hz into an evenly divisible
   physical60Hz refresh rate. It is an A/B diagnostic option, not a proved fix.

A64ms-only launcher trial is the narrower audio-stability candidate if the
physical Windows device needs more scheduling reserve. Hardware crackling
has not been reproduced here; it would be inaccurate to promise that either
variant fixes it. Guest scrolling cadence is being investigated separately.

## Preserved harness failures

`fs-001` accidentally selectedfs as both playback and recording; soundfs has
one global FILE pointer, so this configuration is invalid and is excluded.
`sdl-default-001` used recording at startup/warp and did not reachREADY; it is
excluded. Successful measurements use no simultaneous startup recording.
No failed run is counted as a passed audio qualification.

## Revision2 receipt

Root selected only the64ms buffer mitigation, retaining VSync and the same
production executable. Final game014/stage was cold-tested on both models and
passed the full actualGUI/dialogue/expiry route. Its continuous unwarped
menu opened an effective64ms buffer and ran500 ignoredSID ticks in10.102s.
See `REV2_FINAL_QA.md` and `wine-rev2-014/PROOF.json`. This does not upgrade the
unavailable physical WMM test into a demonstrated crackle cure.
