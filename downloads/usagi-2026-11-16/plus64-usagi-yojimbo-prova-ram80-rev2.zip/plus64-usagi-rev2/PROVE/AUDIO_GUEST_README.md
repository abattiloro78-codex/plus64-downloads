# Guest SID timing audit:013 versus014

Result: **014 removes013's scrolling-related music-call timing swings.**
All measurements use unmodified guest code, ordinary joystick input and
uninterrupted normal-speed execution after an explicit snapshot restore.
The corrected C64 reference was started with ordinary FIRE, not attract mode.

| Case | Calls |5410 interval range | Short/long outliers |
| --- | ---: | ---: | ---: |
| Native013, RIGHT |512|5.673–34.442 ms|109|
| Native014, RIGHT |512|19.985–20.129 ms|0|
| Native014, stationary |512|20.0553–20.0564 ms|0|
| C64, RIGHT |512|19.946–19.953 ms|0|

An outlier is shorter than75% or longer than125% of one machine frame.
The small nominal C64/native frame-period difference follows their PAL clocks.
Native013,014 and C64 all advanced worldX96→597 under RIGHT, made383 actual
E000 updates and55 original scroll-related F3 resets in these512-call traces.
Stationary cases made384 updates. The source intentionally callsE000 on
three of every four5410 calls; scroll flips can reset that divider.

The013 menu trace made192 updates in256 calls, with no divider resets.
One initial UI-copy interval was40.11 ms; the remaining intervals were
20.054–20.058 ms. No recurring menu guest-cadence defect was observed.
The native SID clock configuration remains985248/1773447, with valid saved
fractional remainders and all TED audio registers zero.

## Separate remaining observation

IRQ interruption can leave approximately1.07–1.12 ms between adjacent native
SID frequency-low/high writes atE4C9/E4CF, versus at most63 microseconds in
the C64 moving trace. This is distinct from the corrected call-cadence defect.
Its audible impact is unproven, it is absent from menu traces, and it does
not explain the user's menu crackle. No atomic SID wrappers or actor-stage
changes were applied.

All retained WAV captures are48 kHz mono16-bit, with no clipped samples or
zero runs of64 samples. File captures do not measure physical output-driver
underruns and do not establish that the host output is crackle-free. The
64 ms host-buffer mitigation is evaluated separately by the host-audio audit.

`FINAL_PROOF.json` is the concise final result. `FINAL_ANALYSIS.json` contains
per-case measurements; trace directories preserve commands, automatic SID
register traces, source hashes and WAVs. `static/PROOF.json` proves unchanged
music/divider code and2560 private source-versus-mapped tick comparisons.
The old C64 attract-mode gameplay references are explicitly discarded.
No production files, sources or executable were modified by this audit.
