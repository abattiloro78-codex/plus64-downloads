@echo off
setlocal DisableDelayedExpansion
cd /d "%~dp0"
if not exist "%~dp0USAGI.D64" goto missing
"%~dp0xplus4.exe" -default -model c16 -ramsize 16 -directory "%~dp0." -kernal kernal-318004-05.bin -plus64 -plus64mainram -plus64packedcache -plus64leftmcm -plus64mixedsprites -plus64rastercollisions -symkeymap "%~dp0usagi.vkm" -keymap 2 -controlport2device 1 -joydev2 2 -drive8type 1541 -trapdevice8 -busdevice8 -sound -soundbufsize 64 -sidenginemodel 256 -sidcartaddress 0xFD40 -sidcartclock 0 -autostart "%~dp0USAGI.D64"
if errorlevel 1 goto failed
exit /b 0
:missing
echo Estrai tutto lo ZIP. / Extract the complete ZIP.
goto failed
:failed
pause
exit /b 1
