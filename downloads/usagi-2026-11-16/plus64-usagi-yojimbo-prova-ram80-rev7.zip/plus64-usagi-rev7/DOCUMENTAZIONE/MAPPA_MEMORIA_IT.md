# Usagi RAM80 — materiali composti, candidato 019

## Revisione 7: validazione dei materiali, versione 2

Il candidato 019 conserva esattamente l’immagine CPU e tutti i 19 componenti del candidato 018; il confronto dei byte è registrato in `GAME_CODE_IDENTITY.json`. Cambiano 97 rettangoli dei materiali dei vestiti, dal profilo 1 intenso al nuovo profilo 6 morbido. Il campo di distanza resta lo stesso, ma i livelli 0..6 diventano `1 + (livello + 1) // 2`, ossia 1, 2, 2, 3, 3, 4, 4. Tinte e nero opaco vengono conservati. Viso e parti chiare mantengono i profili 2/3; i pantaloni mantengono i profili 4/5. I dati dei materiali, il PRG e il D64 hanno pertanto nuovi hash.

Il renderer generico richiede il campo snapshot 82 di valore 2 e accetta il profilo 6 soltanto in tale versione. Ricette definite sullo spazio 72×63 possono essere usate con composti effettivi a due o tre colonne: si campiona soltanto entro la larghezza e altezza fisiche dichiarate, correggendo i personaggi che potevano scomparire. Collegamenti, directory, catene, maschere, priorità e collisioni conservano i propri controlli. Non si aggiunge memoria della macchina emulata; i componenti restano 5.096 byte e il totale resta 64+16 KiB.

La precedente prova C di 414 casi verificava le pose e i due orientamenti con directory a tre colonne. Non copriva la validazione con larghezza effettiva di due colonne; non è una prova completa di quella geometria. La regressione della revisione 7 confronta entrambi gli orientamenti con entrambe le larghezze effettive, per 828 casi, e include personaggi visibili nell’emulatore. Le prove CPU del candidato 018 vengono ereditate soltanto tramite l’identità dei byte di codice; materiali, trasporto di avvio e resa del candidato 019 richiedono propri rapporti e non ereditano gli hash dei dati precedenti.

Gli snapshot con versione 1 conservano intenzionalmente la validazione rigorosa precedente durante la riproduzione; il caricamento non li converte implicitamente. La versione 2 limita le interrogazioni alla sorgente effettiva e rifiuta comunque rettangoli fuori dall’area fissa 72×63. I lettori con supporto soltanto alla versione 1 rifiutano la versione 2.

Il controllo indipendente ricostruisce esattamente i 65.536 byte dell’immagine finale, applicando **400 patch con guardie** nell’ordine dichiarato e **19 componenti** disgiunti per **5.096 byte** nella RAM principale esistente. Esegue inoltre uploader e ripristino basso su una CPU 6502 privata con un modello delle porte. Questo controllo statico/CPU non sostituisce le prove del disco e dell’emulatore. I rapporti dei candidati precedenti restano storici.

## Artefatti esatti

| Artefatto | Byte | SHA256 |
| --- | ---: | --- |
| Immagine principale | 65,536 | `6bc77415e438f6d14d751b1f363e1d4c98b7f67a6cb184da2c13ec60ccd0858d` |
| Banchi originali D/F | 8,192 | `d07595210b1beb05a25c918e4b9eebb49a8ae7043e6797fa265b0afbdc1d9546` |
| Materiali | 4,608 | `deed8fa20463fba18f1e2aadf89666256fae9ed5ecb545d0b44970818ef5f645` |
| PRG | 60,673 | `762af5e27dfac5b624b4b4b4859f9a638d8233c1a22d58085ee51c744cbf7397` |
| D64 | 174,848 | `7da5ecc5323b192d7010746c24ae5cf50d4c58677169dc3b18c13605efbf69b2` |


La macchina emulata dispone sempre di **65.536 + 16.384 = 81.920 byte**. Non sono previsti altri pool per bitmap, sprite, cache, modem o decompressione.

| RAM interna, inizio incluso/fine esclusa | Byte | Uso a regime |
| --- | ---: | --- |
| `$0000..$0C94` | 3.220 | 46 record densi da 70 byte |
| `$0C94..$0E00` | 364 | Non assegnati; possono contenere residui dell’avvio |
| `$0E00..$2000` | 4.608 | Lookup, collegamenti, cache, directory e ricette dei materiali |
| `$2000..$3000` | 4.096 | Banco D originale |
| `$3000..$4000` | 4.096 | Banco F originale |
| **Totale** | **16.384** | |

Il payload dei materiali comprende due piani da 256 byte di puntatori alle ricette (`$0E00/$0F00`), una riserva di 46 collegamenti da 8 byte (`$1000..$1170`), 24 byte di directory delle colonne (`$1170..$1188`) e ricette deduplicate a partire da `$1190`. I 24 collegamenti degli attori occupano `$1000..$10BF`; una cache di 16 byte riusa collegamenti non selezionati del ritratto, a `$10C0..$10CF`. Il ritratto usa il modo originale 1 e non interpreta tali byte come collegamenti. Il margine tra directory e ricette resta compreso nel payload di 4.608 byte.

Le ricette sono dati del gioco generati da `materials/characters.json`, non riconoscimenti del personaggio nel renderer. Le 207 pose canoniche hanno assegnazioni esplicite. Si conservano bitmap RLE, tabelle delle pose, inchiostri nei record e banchi compressi originali. Le ricette possono modificare luminanze e, per regioni scure esplicite, selezionare una tinta neutra; non aggiungono pixel occupati.

Gli helper usano soltanto intervalli già disponibili nella RAM principale: `$0C90`, `$2CB0`, `$2EA8` e `$DF40`, più campi temporanei nello stato sprite già riservato. Il controllo sull’immagine finale verifica le dimensioni e l’assenza di sovrapposizioni. Gli otto slot video e i 46 record non aumentano.

Il caricatore carica materiali e banchi originali con decompressione all’avvio, riusando memoria principale e interna già esistenti. La sorgente dei riferimenti LZ è l’output già prodotto, senza una cronologia residente separata. L’avvio temporaneo sotto `$0E00` e il payload materiali da `$0E00` sono distinti e appartengono agli stessi 16 KiB.

Il formato corrente richiede il campo snapshot 82 di versione 2. I modi 2/82 usano puntatori a collegamenti espliciti, mantenendo il record da 70 byte; il modo 1 del ritratto e delle versioni precedenti resta invariato. Vedere `ADDENDUM_DENSE_MATERIALS_IT.md` per il contratto generico. Sono necessarie prove del nuovo eseguibile e del nuovo disco: le prove storiche del decoder precedente non vengono trasferite al produttore modificato.

Windows tramite Wine, Windows nativo e hardware fisico sono ambiti distinti. Non si dichiara una campagna completa o una prova su hardware.

## Payload e componenti finali

Il payload usa **4.577 byte** dei 4.608 riservati, lasciando **31 byte di padding** interni alla riserva. Le 107 definizioni di template diventano 85 ricette deduplicate; i dati delle ricette occupano 3.665 byte a partire da `$1190`. La selezione copre tutte le 207 pose canoniche: 171 hanno cambiamenti di colore effettivi e 36 pose di effetti o vuote conservano esplicitamente i colori originali. Sono comprese le 48 pose NPC con regioni chiare dei pantaloni definite esplicitamente. I byte dei banchi originali, dei bitmap RLE e delle tabelle delle pose restano invariati.

Il produttore denso conserva i byte di collegamento mentre aggiorna i 63 byte visibili del frammento. La vecchia matrice di 5.508 casi del produttore mode1 conserva valore storico per quel codice; non viene presentata come qualifica automatica del produttore modificato. Le prove CPU dei nuovi helper e i confronti del renderer sono rapporti separati, legati ai propri hash.

I materiali compressi occupano 2.349 byte di trasporto e i banchi originali compressi 6.212 byte. Queste dimensioni riguardano il caricamento: a regime restano un solo payload di 4.608 byte e gli originali 8 KiB di banchi nella medesima RAM interna. Il controllo dell’uploader verifica i materiali esatti; inizializzazione e ripristino basso li conservano.

| Componente | Inizio | Fine esclusa | Byte |
| --- | --- | --- | ---: |
| `ui_marks` | `$0A00` | `$0AAB` | 171 |
| `ui_data` | `$0B40` | `$0B80` | 64 |
| `bridge_stub` | `$0B80` | `$0BD5` | 85 |
| `ui_rows` | `$0C00` | `$0C89` | 137 |
| `material_finish` | `$0C90` | `$0D7F` | 239 |
| `bridge` | `$2800` | `$2A4E` | 590 |
| `video` | `$2A80` | `$2CA5` | 549 |
| `material_entries` | `$2CB0` | `$2CD3` | 35 |
| `timers` | `$2D00` | `$2EA6` | 422 |
| `material_cache` | `$2EA8` | `$2EFF` | 87 |
| `input` | `$2F00` | `$2FBA` | 186 |
| `direct_colour` | `$40B4` | `$41CA` | 278 |
| `direct_column` | `$43F1` | `$444A` | 89 |
| `memory` | `$DC00` | `$DD8F` | 399 |
| `menu` | `$DD90` | `$DE1F` | 143 |
| `keyboard` | `$DE40` | `$DEEC` | 172 |
| `bootstrap` | `$DF00` | `$DF40` | 64 |
| `material_record` | `$DF40` | `$DFDB` | 155 |
| `sprites` | `$F800` | `$FCCF` | 1231 |
