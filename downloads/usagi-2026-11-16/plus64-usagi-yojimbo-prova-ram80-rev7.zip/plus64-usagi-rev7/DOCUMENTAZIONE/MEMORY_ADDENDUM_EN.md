# Usagi RAM80 — composite materials, candidate 019

## Revision 7: material-validation version 2

Candidate 019 retains exactly candidate 018’s CPU image and all 19 components; byte identity is recorded in `GAME_CODE_IDENTITY.json`. It changes 97 garment-material rectangles from strong profile 1 to the new soft profile 6. The distance field stays the same, but levels 0..6 become `1 + (level + 1) // 2`, or 1, 2, 2, 3, 3, 4, 4. Source hues and opaque black are retained. Face and pale regions keep profiles 2/3; trousers keep profiles 4/5. Material data, PRG and D64 therefore have new hashes.

The generic renderer requires snapshot field 82 value 2 and accepts profile 6 only in that version. Recipes authored on a 72×63 canvas can be used with actual two- or three-column composites: sampling remains inside the declared physical width and height, restoring characters that could disappear. Bindings, directories, chains, masks, priority and collisions retain their respective checks. No guest memory is added; components remain 5,096 bytes and the total remains 64+16 KiB.

The previous 414-case C comparison checked poses and both orientations with three-column directories. It did not cover validation with an actual two-column width and is not complete evidence for that geometry. Revision 7’s regression checks both orientations at both actual widths, giving 828 cases, and includes visible characters in the emulator. Candidate-018 CPU tests are inherited only through exact code-byte identity; candidate-019 materials, cold transport and rendering require their own reports and do not inherit previous data hashes.

Version-1 snapshots intentionally retain the previous strict validation during replay; loading does not silently convert them. Version 2 clips queries to the actual source and still rejects rectangles outside the fixed 72×63 canvas. Readers supporting only version 1 reject version 2.

The independent audit reconstructs all 65,536 bytes of the final image exactly, applying **400 guarded patches** in declared order and **19 disjoint components** totalling **5,096 bytes** inside existing main RAM. It also executes the uploader and low-memory restore on a private 6502/port model. This static/CPU audit does not replace disk/emulator tests. Reports for previous candidates remain historical.

## Exact artifacts

| Artifact | Bytes | SHA256 |
| --- | ---: | --- |
| Main image | 65,536 | `6bc77415e438f6d14d751b1f363e1d4c98b7f67a6cb184da2c13ec60ccd0858d` |
| Original D/F banks | 8,192 | `d07595210b1beb05a25c918e4b9eebb49a8ae7043e6797fa265b0afbdc1d9546` |
| Materials | 4,608 | `deed8fa20463fba18f1e2aadf89666256fae9ed5ecb545d0b44970818ef5f645` |
| PRG | 60,673 | `762af5e27dfac5b624b4b4b4859f9a638d8233c1a22d58085ee51c744cbf7397` |
| D64 | 174,848 | `7da5ecc5323b192d7010746c24ae5cf50d4c58677169dc3b18c13605efbf69b2` |


The guest still has **65,536 + 16,384 = 81,920 bytes**. No additional bitmap, sprite, cache, modem or decompression pools are provided.

| Internal RAM, start inclusive/end exclusive | Bytes | Runtime ownership |
| --- | ---: | --- |
| `$0000..$0C94` | 3,220 | 46 dense records of 70 bytes |
| `$0C94..$0E00` | 364 | Unassigned; may retain stale cold-loading bytes |
| `$0E00..$2000` | 4,608 | Material lookup, bindings, cache, directories and recipes |
| `$2000..$3000` | 4,096 | Original D bank |
| `$3000..$4000` | 4,096 | Original F bank |
| **Total** | **16,384** | |

The material payload contains two 256-byte recipe-pointer planes (`$0E00/$0F00`), a reservation of 46 eight-byte bindings (`$1000..$1170`), 24 bytes of column directories (`$1170..$1188`), and deduplicated recipes starting at `$1190`. The 24 actor bindings occupy `$1000..$10BF`; a 16-byte cache reuses unselected portrait bindings at `$10C0..$10CF`. The portrait uses original mode 1 and does not interpret those bytes as bindings. The gap between directories and recipes remains inside the 4,608-byte payload.

Recipes are game data generated from `materials/characters.json`, not character recognition in the renderer. The 207 canonical poses have explicit assignments. Original RLE bitmaps, pose tables, record inks and compressed banks are retained. Recipes can change luminance and select neutral hue for explicit dark regions; they cannot add occupied pixels.

Helpers use existing available main-RAM intervals at `$0C90`, `$2CB0`, `$2EA8` and `$DF40`, plus temporary fields in the already reserved sprite state. The final-image audit verifies their sizes and non-overlap. The eight displayed slots and 46 records do not increase.

The loader uploads materials and original banks with cold-time decompression, reusing existing main/internal RAM. LZ matches read previously produced output, without a separate resident history. Temporary cold staging below `$0E00` and the material payload starting at `$0E00` occupy distinct ranges of the same internal 16 KiB.

The current format requires snapshot field 82 version 2. Modes 2/82 use explicit binding pointers while retaining 70-byte records; mode 1 for the portrait and older versions stays unchanged. See `ADDENDUM_DENSE_MATERIALS_EN.md` for the generic contract. The new executable and disk require matching tests: historical decoder results are not transferred to the changed producer.

Wine, native Windows and physical hardware are separate test scopes. No completed campaign or physical-hardware test is claimed.

## Final payload and components

The payload uses **4,577 bytes** of its 4,608-byte reservation, leaving **31 padding bytes** inside that reservation. Its 107 authored template definitions become 85 deduplicated recipes; recipe data occupy 3,665 bytes starting at `$1190`. Explicit selection covers all 207 canonical poses: 171 have actual colour changes and 36 effect or empty poses explicitly retain original colours. This includes the 48 NPC poses with authored light-trouser regions. Original banks, RLE bitmaps and pose-table bytes remain unchanged.

The dense producer preserves binding-header bytes while refreshing each part’s 63 visible bytes. The older 5,508-case mode1 producer matrix remains historical evidence for that code; it is not presented as automatic qualification of the changed producer. CPU tests of the new helpers and renderer comparisons are separate reports bound to their own hashes.

Compressed materials occupy 2,349 transport bytes and compressed original banks occupy 6,212. These are loading sizes: runtime retains one 4,608-byte payload and the original 8 KiB banks in the same internal RAM. The uploader audit verifies exact material bytes; initialization and low-memory restoration preserve them.

| Component | Start | End exclusive | Bytes |
| --- | --- | --- | ---: |
| `ui_marks` | `$0A00` | `$0AAB` | 171 |
| `ui_data` | `$0B40` | `$0B80` | 64 |
| `bridge_stub` | `$0B80` | `$0BD5` | 85 |
| `ui_rows` | `$0C00` | `$0C89` | 137 |
| `material_finish` | `$0C90` | `$0D7F` | 239 |
| `bridge` | `$2800` | `$2A4E` | 590 |
| `video` | `$2A80` | `$2CA5` | 549 |
| `material_entries` | `$2CB0` | `$2CD3` | 35 |
| `timers` | `$2D00` | `$2EA6` | 422 |
| `material_cache` | `$2EA8` | `$2EFF` | 87 |
| `input` | `$2F00` | `$2FBA` | 186 |
| `direct_colour` | `$40B4` | `$41CA` | 278 |
| `direct_column` | `$43F1` | `$444A` | 89 |
| `memory` | `$DC00` | `$DD8F` | 399 |
| `menu` | `$DD90` | `$DE1F` | 143 |
| `keyboard` | `$DE40` | `$DEEC` | 172 |
| `bootstrap` | `$DF00` | `$DF40` | 64 |
| `material_record` | `$DF40` | `$DFDB` | 155 |
| `sprites` | `$F800` | `$FCCF` | 1231 |
