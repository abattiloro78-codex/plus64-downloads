# Materiali definiti dal software per sprite densi composti

Questo addendum descrive il formato opzionale identificato dalla capacità
snapshot **82**. Estende il record MCM denso esistente di 70 byte senza
aggiungere slot sprite, un archivio di texture o RAM della macchina emulata.
Il software definisce collegamenti, directory delle colonne e ricette dei
materiali, conservandoli negli stessi 16 KiB condivisi. Il renderer non
riconosce giochi, personaggi, parti del corpo o indirizzi fissi.

Il contratto canonico dei byte si trova in
[`FORMAT.md`](../../emulator/experimental/sprite-formats/FORMAT.md), nella
sezione “Authored composite dense materials”. La capacità 82 è un campo
dell'intestazione snapshot, non un registro 6502. Il solo protocollo 05 non
identifica questo supporto: occorrono l'emulatore corrispondente e le opzioni
packed cache/formati misti.

## Versioni del formato

Il campo 82 dell'intestazione snapshot contiene una versione: **0** disabilita
i materiali definiti dal software, **1** conserva la validazione rigorosa
originaria, **2** usa un'area di authoring fissa di 72×63 pixel e limita le
interrogazioni alle dimensioni effettive della sorgente. La versione 2 è
l'impostazione predefinita corrente. I valori superiori a 2 vengono rifiutati.
Questo campo è distinto dal modo esadecimale `$82` del record, che seleziona
le coordinate riflesse.

La versione 1 richiede che ogni rettangolo rientri nella larghezza e altezza
effettive del composto. La versione 2 permette a una ricetta condivisa di
coprire l'area 72×63 anche quando il composto selezionato ha soltanto una o due
colonne, oppure un'altezza inferiore. Si campionano soltanto interrogazioni
interne al composto effettivo: una regione esterna non aggiunge pixel e non
provoca letture fuori limite. Collegamenti, directory e metadati della catena
devono ancora descrivere esattamente la geometria effettiva della sorgente.

## Record denso

Il modo 1 conserva esattamente la precedente semantica di bitmap, tag,
inchiostri e marcatore. Con la capacità 82 abilitata, il modo 2 o esadecimale
`$82` adotta questa interpretazione:

| Offset nel record | Significato |
| --- | --- |
| `$00` | Byte basso del puntatore al collegamento |
| `$01..$3F` | Bitmap a due bit nell'ordine inverso esistente, invariata |
| `$40` | Altezza della testa densa esistente |
| `$41` | 2, oppure `$82` per riflettere le coordinate della ricetta |
| `$42..$44` | Inchiostri sorgenti originali per le coppie 3, 2 e 1 |
| `$45` | `$80 | (puntatore_collegamento >> 8)`; i due bit alti devono essere `10` |

Il puntatore risultante è un offset completo di 14 bit negli stessi 16 KiB.
Il descrittore ordinario conserva il tag del puntatore denso e la selezione
dello slot packed. Una colonna di 63 righe occupa ancora tre record consecutivi
di 70 byte; ogni frammento ha il proprio collegamento, origine e metadati validi.
Il formato non aggiunge una copia espansa del bitmap.

## Collegamento e directory delle colonne

Ogni collegamento occupa otto byte e deve rientrare senza ritorno all'inizio
della memoria:

| Offset | Significato |
| --- | --- |
| 0..1 | Puntatore little-endian alla ricetta negli stessi 16 KiB |
| 2..3 | Puntatore little-endian alla directory delle colonne |
| 4 | Larghezza composta in colonne: 1, 2 oppure 3 |
| 5 | Origine X di questo frammento in pixel fisici: multiplo di 24 |
| 6 | Origine Y di questo frammento: multiplo di 21 |
| 7 | Altezza composta: 1..63 pixel sorgenti |

La directory contiene un indirizzo little-endian della testa per ogni colonna,
nell'effettivo ordine sorgente da sinistra a destra. Ogni colonna comprende
`ceil(altezza/21)` frammenti densi consecutivi. Le teste possono essere non
allineate e non contigue. Le directory contengono indirizzi, non altre
directory: non possono essere ricorsive.

La testa selezionata più `origineY/21 * 70` deve coincidere con l'indirizzo
del record corrente. Origini e righe visualizzate devono rientrare nelle
dimensioni dichiarate. Tutti i frammenti referenziati devono avere metadati
validi, anche fuori schermo. Questa topologia esplicita permette a un materiale
di seguire lo sprite composto attraverso colonne e confini di 21 righe senza
presumerne la disposizione in memoria.

## Codifica della ricetta

Una ricetta inizia con `$80 | numero`, dove numero è 0..63 e i due bit alti
dell'intestazione sono `10`. Seguono altrettanti rettangoli di quattro byte
little-endian:

| Bit | Significato |
| --- | --- |
| 0..5 | x0 incluso, in unità MCM di due pixel |
| 6..11 | y0 incluso, in pixel sorgenti |
| 12..17 | x1 incluso, in unità MCM di due pixel |
| 18..23 | y1 incluso, in pixel sorgenti |
| 24..25 | Coppia sorgente: 0 per qualsiasi coppia non nulla, oppure 1..3 |
| 26..28 | Profilo materiale: 0..5 in versione 1; 0..6 in versione 2; 7 non valido |
| 29..31 | Componente: 0..7 |

La formula equivalente è
`x0 | y0<<6 | x1<<12 | y1<<18 | coppia<<24 | profilo<<26 | componente<<29`.
Nella versione 1 le coordinate devono rientrare nel composto dichiarato.
Nella versione 2 devono rientrare nell'area fissa 72×63: x0/x1 non superano 35
e y0/y1 non superano 62. Le interrogazioni restano limitate al composto
effettivo. Vince l'ultimo
rettangolo corrispondente. Un pixel senza corrispondenza, il profilo 0 o una
ricetta senza rettangoli conserva l'inchiostro originale. La coppia 0 resta
trasparente: la ricetta non può aggiungere pixel occupati. Gli inchiostri
superiori a 120 conservano il normale comportamento non visibile.

Per i profili frontali, componente 0 indica soltanto quel rettangolo. I valori
1..7 uniscono i rettangoli vincenti con uguale profilo e selettore di coppia
in un unico intervallo di riga, anche attraverso colonne e frammenti di 21
righe. Gli estremi sono il primo e l'ultimo pixel sorgente opaco corrispondente.
Buchi e dettagli scuri conservati non generano altri centri di luce. Componenti
diversi mantengono indipendenti forme adiacenti. I gruppi sono definiti dal
software: il renderer non deduce l'anatomia.

## Profili

| Profilo | Risultato |
| --- | --- |
| 0 | Inchiostro sorgente originale |
| 1 | Tinta originale; luminanza 0..6 dalla distanza dal nero opaco originale |
| 2 | Tinta originale; luce frontale morbida con luminanza 5..7 |
| 3 | Tinta originale; luce frontale chiara con luminanza 6..7 |
| 4 | Tinta neutra 1; curva frontale scura, luminanza 0..3 |
| 5 | Tinta neutra 1; curva frontale scura meno intensa, luminanza 0..2 |
| 6 | Tinta originale; contrasto più morbido dei vestiti, luminanza 1..4; solo versione 2 |

I profili 1..3 e 6 mantengono nero il nero opaco. Per ricolorare una regione
originalmente nera occorre quindi un rettangolo esplicito di profilo 4 o 5.
Un rettangolo successivo di profilo 0 può proteggere un dettaglio che deve
conservare l'inchiostro originale.

Il profilo 6 è una selezione esplicita della ricetta per attenuare il contrasto
dei vestiti. Usa il campo di distanza dal nero originale con un intervallo
di luminanza più ristretto, 1..4. Il profilo 1 conserva l'intervallo più intenso
0..6. La versione 1 continua a rifiutare il profilo 6; la sua aggiunta alla
versione 2 non modifica le ricette esistenti che scelgono il profilo 1.
Se il calcolo della distanza del profilo 1 produce `intenso` in 0..6, il
profilo 6 usa `1 + (intenso + 1) // 2`: i sette livelli diventano
1, 2, 2, 3, 3, 4, 4. Qui `//` indica la divisione intera. Gli altri profili
conservano le proprie curve.

Il profilo 1 usa la distanza quadratica minima dai pixel neri opachi originali.
Le soglie 2, 4, 5, 8, 9 e 10 selezionano i livelli successivi; da distanza 10
la luminanza satura a 6. Basta un vicinato sorgente di raggio 3 attraverso il
composto definito. Si leggono maschere e inchiostri originali, mai il risultato
già ombreggiato.

Per i profili 2 e 3, `larghezza` è l'intervallo vincente della riga e `bordo`
la distanza dal suo estremo più vicino. Il profilo 2 usa profondità 1 per
larghezze 3/4 e 2 oltre 4; le larghezze 1/2 restano a 7. Il profilo 3 mantiene
a 7 le larghezze 1..4 e altrimenti usa profondità 1. Gli altri pixel usano
`min(7, 7-profondità+ceil(2*profondità*bordo/(larghezza-1)))`.

Per i profili 4 e 5, con estremi `min` e `max`, si usano
`t=abs(2*x-min-max)/(larghezza+1)` e `floor(guadagno*(1-t*t))`.
Il guadagno è 16/5 per il profilo 4 e 72/25 per il profilo 5. I calcoli usano
aritmetica intera limitata. Una ricetta può scegliere profili diversi su righe
definite dal software senza introdurre numeri di riga specifici nel renderer.

## Riflessione, validazione e compatibilità

Il modo `$82` riflette la X della ricetta sull'intera larghezza composta. Non
inverte i byte del bitmap: il loro orientamento è già gestito dal software.
Le distanze si calcolano nello spazio sorgente effettivo; le curve frontali
simmetriche usano le coordinate riflesse della ricetta e dei gruppi.
Espansione, ritaglio, priorità e collisioni seguono ancora il calcolo del colore.

I modi 2/82 ignorano i precedenti selettori materiali per tag dell'intero
record, radiali e diagonali. Il modo 1 resta invariato con capacità 82 attiva.
Puntatori, collegamenti, directory, ricette, rettangoli, metadati o limiti della
catena non validi fanno rifiutare l'intera catena visualizzata. I puntatori non
ritornano all'inizio della memoria.

Abilitare formati misti e packed cache con output disabilitato prima di
pubblicare questi record. Il campo snapshot 82 richiede capacità densa 80,
formati misti e packed cache e accetta soltanto le versioni 0, 1 e 2.
I byte 83..127 restano riservati a zero;
il payload serializzato esistente resta di 144.776 byte. Gli snapshot vecchi
con campo 82 nullo lasciano invalidi i modi 2/82. Gli snapshot di versione 1
mantengono la validazione rigorosa della versione 1 durante il caricamento:
non vengono aggiornati implicitamente. I lettori che supportano soltanto la
versione 1 rifiutano la versione 2; quelli precedenti al formato rifiutano il
campo riservato non nullo, senza interpretare erroneamente i nuovi record.

Collegamenti, directory e ricette rientrano nel budget applicativo di
**65.536 + 16.384 = 81.920 byte**. Il formato non definisce altri pool per bitmap,
materiali o cronologia. I rapporti di compilazione e prova dell'applicazione
devono identificare dati, indirizzi, emulatore corrispondente e ambito verificato.
