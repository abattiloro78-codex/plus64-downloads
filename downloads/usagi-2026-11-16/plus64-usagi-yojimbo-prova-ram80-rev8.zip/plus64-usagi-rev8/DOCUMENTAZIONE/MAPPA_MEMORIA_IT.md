# Usagi RAM80 — candidato 022, revisione 8

Il controllo indipendente ricostruisce esattamente l’immagine principale con **400 patch con guardie** e **19 componenti disgiunti per 5.096 byte**, negli stessi 64 KiB. Uploader e ripristino basso vengono eseguiti su una CPU 6502 privata con modello delle porte. Immagine CPU e componenti sono identici ai candidati 018/019: le prove CPU precedenti vengono ereditate soltanto tramite tale identità. Nuovi materiali, trasporto di avvio e renderer hanno proprie prove.

## Artefatti esatti

| Artefatto | Byte | SHA256 |
| --- | ---: | --- |
| Immagine principale | 65536 | `6bc77415e438f6d14d751b1f363e1d4c98b7f67a6cb184da2c13ec60ccd0858d` |
| Banchi D/F | 8192 | `d07595210b1beb05a25c918e4b9eebb49a8ae7043e6797fa265b0afbdc1d9546` |
| Materiali | 4608 | `cd6b2cd3a78118fb77f95029f7414eb163c11eee2bf39a834eff3138e2e265e3` |
| PRG | 60673 | `a713101266dccb572924e23096e80318f5b70c715defc56bdce14a6a8590f817` |
| D64 | 174848 | `c9f59a35cfa3a3e13529b1a5914e183225ac4073d6e77a366db51db304322d0e` |

## RAM interna condivisa

Il totale della macchina resta **65.536 + 16.384 = 81.920 byte**.

| Intervallo, fine esclusa | Byte | Uso |
| --- | ---: | --- |
| `$0000..$0C94` | 3220 | 46dense records |
| `$0C94..$0E00` | 364 | Unassigned,may retain cold bytes |
| `$0E00..$2000` | 4608 | Game-authored materials,lookup,bindings,cache,directories |
| `$2000..$3000` | 4096 | Original D bank |
| `$3000..$4000` | 4096 | Original F bank |

I 4.608 byte riservati ai materiali usano **4.548 byte**, con **60 byte di padding**. Contengono due piani lookup da 256 byte a `$0E00/$0F00`, 46 collegamenti da 8 byte a `$1000`, 24 byte di directory a `$1170`, ricette da `$1190` e le eventuali tabelle di colori in coda alle ricette. Restano separati i 364 byte non assegnati tra `$0C94` e `$0E00`. La cache di 16 byte a `$10C0..$10CF` riusa collegamenti del ritratto non selezionati; il ritratto usa il modo originale 1.

Le 104 definizioni diventano 81 ricette deduplicate per 3.636 byte complessivi. Tre ricette NPC vengono associate a una ricetta esistente con output identico: si risparmiano 37 byte senza cambiare i pixel, anche alle due larghezze effettive e ai due estremi di luminanza verificati. Questo consente di includere cappelli e correzione della corsa senza espandere il payload.

## Colori e formato versione 3

Il profilo generico 7 seleziona una base compatta da una tabella di 1..8 byte subito dopo i rettangoli. Il componente del rettangolo è l’indice della tabella; i valori validi sono 0..120. Il nero opaco sorgente viene conservato. Per una base non nulla, la tinta è quella selezionata e la luminanza è `clamp(baseL + morbido - 3, 0, 7)`, dove `morbido = 1 + (intenso + 1) // 2`. Nei tre colori dei cappelli si usa la base 112, giallo a luminanza 7: i risultati hanno luminanze 5..7. Le ricette definiscono la regione: il renderer non riconosce contadini o cappelli.

Dieci maschere di posa del cappello e 52 pixel interni dei pantaloni nella posa 09 cambiano colore rispetto alla revisione 7. Nel candidato 022, le parti bianche degli NPC ricevono inoltre il profilo 3 molto lieve, con i soli colori compatti 91/106 (luminanze 6/7), includendo anche pelo, piedi e dettagli bianchi degli accessori. Rispetto al candidato 021, nessun pixel del protagonista approvato, dei cappelli, dei vestiti, dei pantaloni o degli altri inchiostri cambia. Le tre associazioni di ricette NPC non producono differenze visibili. Le maschere RLE, i banchi originali, gli inchiostri nei record, gli otto slot, i 46 record da 70 byte e la logica CPU restano invariati. Il confronto C completo copre 207 pose, due larghezze e due orientamenti: 828 casi. Ogni pixel non richiesto, alpha e collisioni conserva il risultato precedente.

Il campo snapshot 82 vale 3 per la nuova capacità; le versioni 0/1/2 conservano le proprie regole, e i lettori precedenti rifiutano la versione 3. Il payload snapshot resta 144.776 byte. Non si aggiungono RAM, bitmap espanse, pool di texture o cronologia di decompressione. Vedere gli addenda tecnici IT/EN per il contratto completo.

## Componenti nella RAM principale

| Componente | Inizio | Fine esclusa | Byte |
| --- | --- | --- | ---: |
| `ui_marks` | `$0A00` | `$0AAB` | 171 |
| `ui_data` | `$0B40` | `$0B80` | 64 |
| `bridge_stub` | `$0B80` | `$0BD5` | 85 |
| `ui_rows` | `$0C00` | `$0C89` | 137 |
| `material_finish` | `$0C90` | `$0D7F` | 239 |
| `bridge` | `$2800` | `$2A4E` | 590 |
| `video` | `$2A80` | `$2CA5` | 549 |
| `material_entries` | `$2CB0` | `$2CD3` | 35 |
| `timers` | `$2D00` | `$2EA6` | 422 |
| `material_cache` | `$2EA8` | `$2EFF` | 87 |
| `input` | `$2F00` | `$2FBA` | 186 |
| `direct_colour` | `$40B4` | `$41CA` | 278 |
| `direct_column` | `$43F1` | `$444A` | 89 |
| `memory` | `$DC00` | `$DD8F` | 399 |
| `menu` | `$DD90` | `$DE1F` | 143 |
| `keyboard` | `$DE40` | `$DEEC` | 172 |
| `bootstrap` | `$DF00` | `$DF40` | 64 |
| `material_record` | `$DF40` | `$DFDB` | 155 |
| `sprites` | `$F800` | `$FCCF` | 1231 |

Le prove di avvio nell’emulatore, visualizzazione NPC e movimento identificano i propri artefatti. Wine, Windows nativo e hardware fisico sono ambiti distinti; non si dichiara una campagna completata o una prova hardware.

La correzione della posa 09 è verificata nei confronti del decoder C (52 pixel interni grigi) e attraverso l’identità del codice CPU qualificato. I percorsi di input limitati tentati non hanno raggiunto quella posa in una nuova cattura nativa: questa parte non viene presentata come osservazione nativa della posa 09. Le nuove catture native del candidato 022 riguardano l’avvio, i personaggi visibili, le due direzioni, i colori e il ripristino snapshot.
