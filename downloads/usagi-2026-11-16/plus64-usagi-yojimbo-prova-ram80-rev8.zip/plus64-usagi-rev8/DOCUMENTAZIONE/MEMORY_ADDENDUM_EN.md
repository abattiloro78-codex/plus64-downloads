# Usagi RAM80 — candidate 022, revision 8

The independent audit exactly reconstructs the main image with **400 guarded patches** and **19 disjoint components totalling 5,096 bytes**, within the same 64 KiB. Uploader and low restore execute on a private 6502/port model. The CPU image and components are identical to candidates 018/019: earlier CPU tests are inherited only through that identity. New materials, cold transport and renderer have separate evidence.

## Exact artifacts

| Artifact | Bytes | SHA256 |
| --- | ---: | --- |
| Main image | 65536 | `6bc77415e438f6d14d751b1f363e1d4c98b7f67a6cb184da2c13ec60ccd0858d` |
| D/F banks | 8192 | `d07595210b1beb05a25c918e4b9eebb49a8ae7043e6797fa265b0afbdc1d9546` |
| Materials | 4608 | `cd6b2cd3a78118fb77f95029f7414eb163c11eee2bf39a834eff3138e2e265e3` |
| PRG | 60673 | `a713101266dccb572924e23096e80318f5b70c715defc56bdce14a6a8590f817` |
| D64 | 174848 | `c9f59a35cfa3a3e13529b1a5914e183225ac4073d6e77a366db51db304322d0e` |

## Shared internal RAM

The guest total remains **65,536 + 16,384 = 81,920 bytes**.

| Range, end exclusive | Bytes | Ownership |
| --- | ---: | --- |
| `$0000..$0C94` | 3220 | 46dense records |
| `$0C94..$0E00` | 364 | Unassigned,may retain cold bytes |
| `$0E00..$2000` | 4608 | Game-authored materials,lookup,bindings,cache,directories |
| `$2000..$3000` | 4096 | Original D bank |
| `$3000..$4000` | 4096 | Original F bank |

The 4,608-byte material reservation uses **4,548 bytes**, leaving **60 padding bytes**. It contains two 256-byte lookup planes at `$0E00/$0F00`, 46 eight-byte bindings at `$1000`, 24 directory bytes at `$1170`, recipes from `$1190`, and optional colour tables after recipe rectangles. The 364 unassigned bytes between `$0C94` and `$0E00` remain separate. A 16-byte cache at `$10C0..$10CF` reuses unselected portrait bindings; the portrait uses original mode 1.

The 104 definitions become 81 deduplicated recipes totalling 3,636 bytes. Three NPC recipes alias an existing recipe with identical output, saving 37 bytes without changing pixels at both tested actual widths and local-ink luminance extremes. This fits the hats and running correction without expanding the payload.

## Colours and format version 3

Generic profile 7 selects a compact base from a 1..8-byte table immediately after the rectangles. The rectangle component is the table index; valid values are 0..120. Original opaque black is preserved. For a nonzero base, the selected hue is used with luminance `clamp(baseL + soft - 3, 0, 7)`, where `soft = 1 + (strong + 1) // 2`. The three hat colours use base 112, yellow at luminance 7: output levels are 5..7. Recipes select the region; the renderer does not recognise farmers or hats.

Ten hat-pose masks and 52 trouser-interior pixels in pose 09 change colour from revision 7. Candidate 022 also applies very gentle profile 3 to NPC white parts, using only compact colours 91/106 (luminance 6/7), including fur, feet and white accessory details. Relative to 021, approved protagonist, hat, garment, trouser and other-ink pixels do not change. The three NPC recipe aliases have no visible effect. Original RLE masks, asset banks, record inks, eight slots, 46 records of 70 bytes and CPU logic remain unchanged. The full C comparison covers 207 poses, two widths and two orientations: 828 cases. Between 021 and 022, every player, hat, garment, trouser and other-ink pixel is unchanged; alpha and collision remain exact.

Snapshot field 82 is 3 for the new capability; versions 0/1/2 retain their own rules, and older readers reject version 3. The snapshot payload remains 144,776 bytes. No RAM, expanded bitmap, texture pool or decompression history is added. See the IT/EN technical addenda for the full contract.

## Main-RAM components

| Component | Start | End exclusive | Bytes |
| --- | --- | --- | ---: |
| `ui_marks` | `$0A00` | `$0AAB` | 171 |
| `ui_data` | `$0B40` | `$0B80` | 64 |
| `bridge_stub` | `$0B80` | `$0BD5` | 85 |
| `ui_rows` | `$0C00` | `$0C89` | 137 |
| `material_finish` | `$0C90` | `$0D7F` | 239 |
| `bridge` | `$2800` | `$2A4E` | 590 |
| `video` | `$2A80` | `$2CA5` | 549 |
| `material_entries` | `$2CB0` | `$2CD3` | 35 |
| `timers` | `$2D00` | `$2EA6` | 422 |
| `material_cache` | `$2EA8` | `$2EFF` | 87 |
| `input` | `$2F00` | `$2FBA` | 186 |
| `direct_colour` | `$40B4` | `$41CA` | 278 |
| `direct_column` | `$43F1` | `$444A` | 89 |
| `memory` | `$DC00` | `$DD8F` | 399 |
| `menu` | `$DD90` | `$DE1F` | 143 |
| `keyboard` | `$DE40` | `$DEEC` | 172 |
| `bootstrap` | `$DF00` | `$DF40` | 64 |
| `material_record` | `$DF40` | `$DFDB` | 155 |
| `sprites` | `$F800` | `$FCCF` | 1231 |

Emulator cold boot, visible NPC and movement proofs identify their own artifacts. Wine, native Windows and physical hardware are separate scopes; no completed campaign or hardware test is claimed.

The pose-09 correction is verified by C-decoder comparisons (52 grey interior pixels) and identity of the qualified CPU code. Bounded input routes did not reach that pose in a new native capture, so this evidence is not presented as native observation of pose 09. New candidate-022 native captures cover cold boot, visible characters, both directions, colours and snapshot restore.
