# Usagi RAM80 — controllo memoria e patch del candidato finale 013

Il candidato usa **65.536 + 16.384 = 81.920 byte della macchina emulata (80 KiB)**. Non esistono pool aggiuntivi per sprite, modem, cache o decompressione. Questo controllo ricostruisce in modo indipendente l'immagine principale finale ed esegue il ripristino della memoria bassa con un modello privato di CPU 6502 e porte. Avvio nell'emulatore, comandi e gioco costituiscono prove separate.

## Artefatti esatti

| Artefatto | Byte | SHA256 |
| --- | ---: | --- |
| Immagine principale nativa | 65.536 | `332d963ca64e466c100f98cf80957d670bc09b10b66cb3b23f09c9a1b0153c86` |
| Banchi originali D/F conservati | 8.192 | `d07595210b1beb05a25c918e4b9eebb49a8ae7043e6797fa265b0afbdc1d9546` |
| D64 per avvio a freddo | 174.848 | `bb21fbb66fdc11460f6a81348cd5435ac06310f8464449f2d2e6066dd19ae308` |

L'immagine principale viene ricostruita byte per byte dall'immagine sorgente senza trainer, applicando tutte le **390 patch con guardie**, la copia di 2 KiB di tabelle, 15 componenti compilati e gli intervalli di inizializzazione dichiarati. Le 390 patch comprendono le 14 guardie per la rilocazione delle tabelle. Ogni sequenza attesa prima della patch coincide nell'ordine di applicazione. Non sono emerse differenze non dichiarate, troncamenti o sovrapposizioni tra componenti compilati. Codice e dati dei componenti occupano 4.581 byte nella RAM principale esistente: non si sommano ai 64 KiB.

## Uso della RAM principale

Gli intervalli seguenti hanno **inizio incluso e fine esclusa**. Descrivono l'assegnazione della memoria fisica sottostante, compresi i byte coperti da I/O: non tutti gli indirizzi sono direttamente utilizzabili dalla CPU mentre I/O o ROM sono visibili.

| Intervallo | Byte | Assegnazione |
| --- | ---: | --- |
| `$0000..$0200` | 512 | Zero page e stack CPU |
| `$0200..$0A00` | 2.048 | Tabelle originali spostate da `$1800..$1FFF` |
| `$0A00..$0D80` | 896 | Helper nativi bassi, area temporanea e dati UI |
| `$0D80..$0F00` | 384 | Copie dei registri VIC/CIA, stato adattatori e vettori originali |
| `$0F00..$1800` | 2.304 | Animazioni e dati originali |
| `$1800..$2000` | 2.048 | Coppia TED UI indipendente: attributi/codici `$1800/$1C00` |
| `$2000..$2800` | 2.048 | Font, matrice sorgente e stato HUD originali |
| `$2800..$3000` | 2.048 | Bridge, video, timer e input nativi |
| `$3000..$3800` | 2.048 | Font originale dell'area di gioco |
| `$3800..$8000` | 18.432 | Codice e dati originali con adattatori verificati e intervalli di codice riusati dichiarati |
| `$8000..$D000` | 20.480 | Asset compressi e intestazioni originali |
| `$D000..$D800` | 2.048 | Coppia TED fondale A: attributi `$D000`, codici `$D400` |
| `$D800..$DC00` | 1.024 | Copia della RAM colori C64 originale |
| `$DC00..$E000` | 1.024 | Memoria, menu, tastiera e ingresso nativi |
| `$E000..$F000` | 4.096 | Area SID/musica originale con modifiche dichiarate agli operandi delle periferiche |
| `$F000..$F800` | 2.048 | Coppia TED fondale B: attributi `$F000`, codici `$F400` |
| `$F800..$FD00` | 1.280 | Publisher sprite densi e spazio riservato restante |
| `$FD00..$10000` | 768 | I/O nativo, memoria sottostante non assegnata e vettori CPU reali |
| **Totale** | **65.536** | |

La disposizione bassa separa codice UI `$0A00`, area RLE temporanea da 64 byte `$0B00..$0B3F`, tabelle/scratch UI `$0B40..$0B7F`, stub del bridge `$0B80` e codice di pubblicazione delle righe `$0C00`. Le copie VIC/CIA restano a `$0D80/$0DC0/$0DD0`; lo stato denso occupa `$0DE0..$0E44`, i timer `$0E50..$0E5F`, lo scratch input/tastiera `$0E60`, lo stato del bridge `$0E61..$0E69` e la copia dei vettori originali `$0E70..$0E75`.

## RAM interna condivisa

| Intervallo durante il gioco | Byte | Assegnazione |
| --- | ---: | --- |
| `$0000..$0C94` | 3.220 | 46 record MCM densi × 70 byte |
| `$0C94..$2000` | 4.972 | Non assegnati dal runtime; possono contenere residui del caricamento |
| `$2000..$3000` | 4.096 | Banco originale di asset principali `$D000..$DFFF` |
| `$3000..$4000` | 4.096 | Banco originale `$F000..$FFFF`, compresi i byte dei vettori precedenti all'inizializzazione |
| **Totale** | **16.384** | |

Ogni byte dei due banchi originali è conservato esattamente. Gli scambi e le letture indirette durante il gioco vi accedono attraverso la porta della RAM interna condivisa: non sono asset conservati dall'host fuori dal budget. Anche gli intervalli principali originali `$2000..$27FF`, `$3000..$37FF` e `$8000..$CFFF` coincidono byte per byte con il sorgente pulito.

Quattro personaggi usano otto colonne dense di 63 righe. Le teste sono i record fisici `0,3,6,9,12,15,18,21`, ciascuno seguito da due blocchi da 21 righe. I record HUD `24..29` hanno altezza ordinaria da 21 righe. Le altre 16 posizioni conservano la propria mappatura, ma non sono selezionate come colonne dei personaggi. Formato denso e altezza concatenata richiedono le capacità correnti abilitate esplicitamente, rappresentate dai byte 80 e 81 dell'intestazione snapshot PLUS64. Si usano gli slot esistenti e gli stessi 16 KiB interni.

Durante l'avvio a freddo, la RAM interna `$0000..$0CFF` contiene temporaneamente i futuri byte principali `$0200..$0EFF`, mentre `$0D00..$0DFF` contiene la pagina del finalizzatore. I due banchi interni `$2000..$3FFF` rimangono presenti. Questi byte temporanei occupano la stessa memoria che diventerà record densi o resterà non assegnata: non costituiscono altri 3,5 KiB.

Il trasporto compresso del disco risiede nella RAM principale esistente. La coda di ingresso `$F500..$FCFF` viene protetta temporaneamente nella RAM principale `$0700..$0EFF`, usata per questo soltanto durante il caricamento; l'uscita stessa fornisce la cronologia LZ. Il finalizzatore ripristina `$0200..$09FF` e `$0B00..$0EFF`, preservando la propria pagina in esecuzione `$0A00`. L'ingresso `$DF00` ripristina `$0A00..$0AFF` dalla RAM interna `$0800..$08FF` prima di installare il bridge e inizializzare i record densi. L'inizializzazione sovrascrive poi soltanto la RAM interna `$0000..$0C93` con 46 record. Tabelle rilocate, codice basso ripristinato e banchi originali D/F rimangono intatti.

## Ritiro della cache, riuso di codice e automodifica

La vecchia cache sprite principale di 46 record `$0200..$0D7F` non conserva più i pixel. Quattro caricamenti del decoder, modificati con guardie, selezionano l'area temporanea `$0B00`; le due chiamate originali al bridge selezionano lo stub da 85 byte a `$0B80`. Gli indici logici della cache rimangono disponibili al gioco. Una matrice di **5.508 casi**, rieseguita in modo indipendente, confronta le chiamate originali complete `$45A9/$45B0` con questo percorso nella posizione finale `$F800/$0DE0/$0B00` e con la palette effettiva. I binari di publisher e stub coincidono esattamente con il candidato. Vengono confrontati stato CPU finale, tutta la zero page, RAM non ritirata, 30 maschere effettive degli sprite e byte interni estranei all'operazione. È una prova CPU circoscritta, non una partita completa.

I 14 riferimenti alle tabelle, l'helper copiato dei tasselli e il banco partner dello scambio glifi usano le tabelle rilocate. `$1800/$1C00` diventa così una coppia UI realmente indipendente, senza sovrapporsi ai dati originali.

Gli helper tipizzati dei colori riusano gli intervalli dei vecchi callback CIA e di avvio `$40B4..$41D0` e `$43F1..$444E`. Tra i 4.340 inizi di istruzione originali identificati non compaiono operandi assoluti diretti rivolti a questi intervalli. Il dispatcher nativo IRQ/NMI non entra nei callback ritirati. Le automodifiche note del dispatcher originale puntano a `$4082..$40AE`, fuori dagli intervalli riusati. La conclusione dipende dalla sostituzione del dispatcher nativo e non dimostra compatibilità con ingressi esterni arbitrari.

La scrittura dei record originariamente a `$3DAE` viene spostata intenzionalmente a `$418C`, mantenendo la forma `STA $FFFF,Y`. Tutte le sette letture/scritture originali del suo operando automodificante sono controllate e rivolte ai nuovi byte `$418D/$418E`. Non viene confusa con una scrittura ai vettori CPU. Le 16 scritture assolute identificate ai vettori originali vengono indirizzate separatamente a `$0E70..$0E75`; i vettori CPU nativi reali rimangono sotto il controllo del bridge.

## Prove e limiti

`PROOF.json` e `review.py` registrano la ricostruzione indipendente e le vere istruzioni di uploader, finalizzatore, bootstrap e installazione eseguite nel modello CPU privato. La matrice esatta di ritiro della cache è conservata in `retirement-final-010/PROOF.json`, con identificazione binaria del candidato finale. Gli hash dei generatori sorgente coincidevano con quelli del candidato al momento del controllo.

Nel grafo del codice originale restano callback dinamici delle azioni non risolti. Questo controllo non dimostra la vitalità della memoria su ogni percorso, una campagna completata, il funzionamento su Windows nativo o su hardware fisico. Avvio a freddo C16/Plus/4, comandi ordinari, Wine, dialoghi e temporizzazioni devono essere valutati nei rispettivi rapporti riferiti agli artefatti corrispondenti. Il disco sorgente è la versione THT fornita, con trainer rimosso, non un originale editoriale incontaminato dimostrato. I diritti del gioco e gli avvisi GPL dell'emulatore rimangono distinti, come indicato nella guida rapida.
