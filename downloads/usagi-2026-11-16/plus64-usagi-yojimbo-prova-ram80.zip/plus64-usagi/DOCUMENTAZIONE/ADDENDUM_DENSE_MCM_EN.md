# plus/64 development addendum: dense MCM and FD95

This source addendum describes the development implementation tested on
16 November 2026. Published manual/runtime 2.0 bundles remain historical.
Scenery revision 17 is unchanged; the new feature is separately versioned by
PLUS64 snapshot header byte 80. RAM protocol remains `$05`, the module remains
1.0 with a 144,776-byte payload, and guest RAM remains **64+16 KiB**.

Enable `-plus64packedcache -plus64mixedsprites` before enabling output. With
FD92's slot bit set, descriptor pointer bits 15..14=`10`, tag `$8000`, select a
dense MCM record in the existing sprite view. The lower 14 bits are its offset.
Every 70-byte record must fit without wrapping; `$3FBA` is the last valid start.
No alignment is required. There are still eight displayed slots. A chain must fit in full: 63 rows require 210 bytes and a start no later than `$3F2E`.

| Offset | Contents |
|---|---|
| `$00` | Source-byte 63 tag, not displayed |
| `$01..$3F` | Source bitmap bytes 62..0, reversed |
| `$40/$41` | Head height (0=21,1..252) with capability 81; otherwise shift 0. Mode 1 |
| `$42/$43/$44` | Inks for pairs `11/10/01` |
| `$45` | Valid marker `$A5` |

Pair 0 is transparent; ink 0 is opaque black. Existing materials, diagonal
lighting, clipping, expansion and sprite collisions are retained. This removes
the legacy record's `$200` bias rather than adding a texture store.

FD95's bit for an enabled dense slot places it behind native foreground.
Standard/ECM text and hires bitmap use set source bits; multicolour text cells
and bitmap use pairs`10/11`, while`00/01` remain background. Hires cells within
multicolour text use individual bits. Standard text honours reverse, blink and
cursor. Black foreground still occludes. The highest-priority visible sprite
remains the winner; hiding it reveals TED, not a lower sprite. No background
collision latch is added. FD95 remains reserved for older/non-dense formats.

The classifier is qualified for stable scanline state; cycle-exact intraline
changes of mode, font, scroll or border remain unqualified. Blank, idle and
illegal modes contribute no graphics foreground. Header 80=1 requires mixed
formats and packed cache. Restoring 80=0 retains previous pointer/register
meaning, even with mixed formats enabled; older readers reject 80=1. SRAM
protocol 05 alone does not identify dense support. Use the matching runtime.

## Chained height and snapshot 81

With height capability 81 enabled, head byte `$40` is 0 for 21 rows or 1..252
for the logical height; 253..255 are invalid. The column consists of
`ceil(height/21)` consecutive 70-byte parts, all with mode 1 and marker `$A5`.
The whole chain must fit without wrapping, including offscreen parts.
Following parts' `$40` fields are ignored. Row y selects part `y div21`, row
`y mod21`. Each part retains its own inks, tag, material and diagonal profile,
matching stacked 21-row records. Expansion follows source-row selection.
The column still uses one of the eight displayed slots.

With leftmcm, a dense column taller than 21 maps raw Y206..255 to −50..−1;
21-row/older paths retain the previous Y215..255 mapping. Capability 81=1
requires 80, mixed formats and packed cache. An older snapshot with 81=0 keeps
its former byte `$40`=0 requirement; old readers reject 81=1. Bytes 82..127
remain reserved zero. No payload size, RAM bank or sprite slot is added.

The following xa transaction assumes TED is configured and the caller owns the
sprite port. It uses the current SDK include, clobbers A/X and publishes last.
The record is an opaque 24×63 column in compact blue 81. FD92's SDK name
`P64_SPR_RAW8` also selects MCM under packed-cache configuration.

```asm
#include "plus64.inc"
* = $1100
dense_example:
    php
    sei
    lda #0
    sta P64_SPR_ENABLE
    sta P64_SPR_ADDR_LO
    sta P64_SPR_ADDR_HI
    ldx #0
dense_upload:
    lda dense_record,x
    sta P64_SPR_DATA
    inx
    cpx #3*P64_DENSE_MCM_BYTES
    bne dense_upload
    lda #40
    sta P64_SPR_DESC
    lda #80
    sta P64_SPR_DESC+1
    lda #0
    sta P64_SPR_DESC+2
    sta P64_SPR_DESC+3
    sta P64_SPR_DESC+4
    lda #>P64_DENSE_MCM_TAG
    sta P64_SPR_DESC+5
    lda #1
    sta P64_SPR_RAW8
    sta P64_SPR_BEHIND
    sta P64_SPR_ENABLE
    plp
    rts
dense_record:
    .byt 0
    .dsb 63,$aa
    .byt 63,1,81,81,81,$a5
    .byt 0
    .dsb 63,$aa
    .byt 0,1,81,81,81,$a5
    .byt 0
    .dsb 63,$aa
    .byt 0,1,81,81,81,$a5
```

From the repository root, save the code as `dense.asm` and assemble with `xa -Idocs/developers/sdk-current/include -o dense.bin dense.asm`. The headerless output is 275 bytes, including 210 source/metadata bytes; the callable entry is `$1100`.

The height suite additionally checks 5815 three-part versus stacked legacy frames and 1310 all-height 1..252, bounds, expansion and projection cases, including snapshot 81 dependencies and pre-height reader rejection.

The tested native Linux binary has SHA256
`edcabd4dc13421e15440ad9ccec31afe904b5dbdd14d39151bcb1eb9ce79faed`.
Optimized and ASan/UBSan tests cover 4779 dense/legacy frame equivalences,
256 legacy decoder configurations, snapshot compatibility, 75032 foreground/
priority cases and 2048 actual dense-slot filter cases. Actual 63-row C16 and Plus/4
fixtures preserve 756 black foreground pixels, leave legacy FD95 inert and
replay the complete BMP identically from a fresh capability 80/81 snapshot. The 63-row
immediate-collision path also passes on C16. The current C16 SDK cold-D64
regression passes. These are software fixtures, not complete-game, native
Windows, electrical-design or physical-hardware qualification.

See [the current video chapter](manual-current/chapters/en/03_video_sprite.md),
[wire format](../../emulator/experimental/sprite-formats/FORMAT.md) and
[snapshot specification](../../emulator/experimental/ram80-snapshot/FORMAT.md).
