# Usagi RAM80 — final candidate 013 memory and patch audit

The candidate uses **65,536 + 16,384 = 81,920 guest bytes (80 KiB)**. There is no additional sprite, modem, cache or decompression RAM pool. This audit independently reconstructs the final main image and exercises its low-memory restore with a private 6502/port model. Emulator boot, controls and gameplay results are separate evidence.

## Exact artifacts

| Artifact | Bytes | SHA256 |
| --- | ---: | --- |
| Native main image | 65,536 | `332d963ca64e466c100f98cf80957d670bc09b10b66cb3b23f09c9a1b0153c86` |
| Original D/F bank backing | 8,192 | `d07595210b1beb05a25c918e4b9eebb49a8ae7043e6797fa265b0afbdc1d9546` |
| Cold D64 | 174,848 | `bb21fbb66fdc11460f6a81348cd5435ac06310f8464449f2d2e6066dd19ae308` |

The main image is reconstructed byte for byte from the trainer-removed source image, all **390 guarded patches**, the 2 KiB table copy, 15 compiled components and declared initialization ranges. The 390 patches include the 14 table-relocation guards. Every before-byte guard matches in application order. No undeclared main-image difference, truncation or compiled-component overlap was found. Component code/data occupy 4,581 bytes within existing main RAM; these are not added to the 64 KiB total.

## Main RAM ownership

Ranges below are **start inclusive, end exclusive**. They describe physical backing ownership, including I/O-underlay bytes; not every backing address is directly usable through the CPU while I/O or ROM is visible.

| Range | Bytes | Ownership |
| --- | ---: | --- |
| `$0000..$0200` | 512 | CPU zero page and stack |
| `$0200..$0A00` | 2,048 | Original tables moved from `$1800..$1FFF` |
| `$0A00..$0D80` | 896 | Native low helpers, staging and UI data |
| `$0D80..$0F00` | 384 | VIC/CIA shadows, adapter state and original-vector shadow |
| `$0F00..$1800` | 2,304 | Original animation/data |
| `$1800..$2000` | 2,048 | Independent TED UI attributes/codes at `$1800/$1C00` |
| `$2000..$2800` | 2,048 | Original HUD font, source matrix and state |
| `$2800..$3000` | 2,048 | Native bridge, video, timers and input |
| `$3000..$3800` | 2,048 | Original viewport font |
| `$3800..$8000` | 18,432 | Original game code/data with guarded adapters and declared code leases |
| `$8000..$D000` | 20,480 | Original compressed assets/header data |
| `$D000..$D800` | 2,048 | TED background pair A: attributes `$D000`, codes `$D400` |
| `$D800..$DC00` | 1,024 | Original C64 colour-RAM shadow |
| `$DC00..$E000` | 1,024 | Native memory, menu, keyboard and entry bootstrap |
| `$E000..$F000` | 4,096 | Original SID/music area with declared peripheral operand changes |
| `$F000..$F800` | 2,048 | TED background pair B: attributes `$F000`, codes `$F400` |
| `$F800..$FD00` | 1,280 | Dense sprite publisher and remaining reserved space |
| `$FD00..$10000` | 768 | Native I/O, unassigned backing and real CPU vectors |
| **Total** | **65,536** | |

The low layout separates UI code `$0A00`, one 64-byte RLE staging area `$0B00..$0B3F`, UI tables/scratch `$0B40..$0B7F`, the bridge stub `$0B80`, and row-publishing code `$0C00`. VIC/CIA shadows remain at `$0D80/$0DC0/$0DD0`; dense state occupies `$0DE0..$0E44`, timer state `$0E50..$0E5F`, input/keyboard scratch `$0E60`, bridge state `$0E61..$0E69`, and source-vector shadow `$0E70..$0E75`.

## Shared internal RAM

| Runtime range | Bytes | Ownership |
| --- | ---: | --- |
| `$0000..$0C94` | 3,220 | 46 dense MCM records × 70 bytes |
| `$0C94..$2000` | 4,972 | Unassigned by the runtime; may contain stale cold-loading bytes |
| `$2000..$3000` | 4,096 | Original main `$D000..$DFFF` asset bank |
| `$3000..$4000` | 4,096 | Original main `$F000..$FFFF` bank, including its preinitialization vector bytes |
| **Total** | **16,384** | |

Every byte of the two original banks is retained exactly. Runtime swapping and indirect reads access those banks through the shared internal-RAM port. They are not a host-side asset store. Original main `$2000..$27FF`, `$3000..$37FF` and `$8000..$CFFF` are also byte-identical to the clean source image.

Four actors use eight dense columns of 63 rows. Actor heads are physical records `0,3,6,9,12,15,18,21`, each followed by two 21-row chunks. HUD records `24..29` have ordinary 21-row height. The other 16 record positions retain their mapping but are not selected as actor columns. Dense format and chained height require the current opt-in capabilities, represented by PLUS64 snapshot header bytes 80 and 81. Existing slots and the same internal 16 KiB are used.

During cold loading, internal `$0000..$0CFF` temporarily holds the future main `$0200..$0EFF`, and `$0D00..$0DFF` holds the finalizer page. Both banks at internal `$2000..$3FFF` remain present. These temporary bytes occupy the same internal backing later used for dense records or left unassigned. They are not another 3.5 KiB pool.

The compressed disk transport lives in existing main RAM. The input tail `$F500..$FCFF` is temporarily protected in cold-only main `$0700..$0EFF`; output itself supplies LZ history. Finalization restores main `$0200..$09FF` and `$0B00..$0EFF`, retaining its executing `$0A00` page. Entry `$DF00` restores `$0A00..$0AFF` from internal `$0800..$08FF` before bridge installation and dense initialization. Initialization then overwrites only internal `$0000..$0C93` with 46 initialized records. It preserves relocated tables, restored low code and original D/F banks.

## Cache retirement, code leases and self-modifying code

The old 46-record main sprite cache `$0200..$0D7F` is retired as a pixel store. Four guarded decoder loads select staging `$0B00`, while the two original bridge calls select the 85-byte stub at `$0B80`. Logical cache indices remain available to original game code. An independently rerun **5,508-case** matrix executes original whole calls `$45A9/$45B0` against this staged route at its final `$F800/$0DE0/$0B00` placement and actual palette. Its publisher and stub binaries exactly match this candidate. It compares CPU post-state, all zero page, nonretired RAM, the 30 true sprite masks and unrelated internal bytes; it is a bounded CPU test, not a campaign playthrough.

The 14 guarded table references, copied tile helper and glyph-swap partner now consume the relocated tables. This makes `$1800/$1C00` available as a genuine independent UI pair rather than overlapping original data.

Native typed colour helpers lease old CIA callback/startup intervals `$40B4..$41D0` and `$43F1..$444E`. The 4,340 identified original instruction starts contain no direct absolute operand targeting these intervals. The native IRQ/NMI dispatcher does not enter the retired callbacks. Known original dispatcher self-modifications target `$4082..$40AE`, outside the leases. This conclusion depends on the native dispatcher replacement and does not establish arbitrary external entry compatibility.

The high-score store originally at `$3DAE` is deliberately relocated to `$418C`, keeping its `STA $FFFF,Y` form. All seven original reads/writes of its self-modifying operand are guarded and retargeted to the new operand bytes `$418D/$418E`. It is not mistaken for a CPU-vector write. The 16 identified absolute source vector stores are separately redirected to `$0E70..$0E75`; real native CPU vectors remain under the bridge's control.

## Evidence and limits

`PROOF.json` and `review.py` record this independent replay and the actual uploader/finalizer/bootstrap/install instructions executed in the private CPU fixture. The exact retirement matrix is retained in `retirement-final-010/PROOF.json`, with a final-candidate binary binding. Source-generator hashes matched the candidate when this review ran.

Unresolved dynamic action callbacks remain in the original CFG. No exhaustive all-path memory-liveness, completed-campaign, native-Windows or physical-hardware claim follows from this audit. Actual C16/Plus/4 cold boot, ordinary controls, Wine execution, dialogue and timing tests must be read from their own matching-artifact reports. The source disk is the supplied THT-modified release with its trainer removed, not a demonstrated publisher-pristine image. Original game rights and emulator GPL notices remain separate, as described in the quickstart.
