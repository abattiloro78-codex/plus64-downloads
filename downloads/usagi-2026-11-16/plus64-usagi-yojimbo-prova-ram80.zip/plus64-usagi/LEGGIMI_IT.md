# Usagi Yojimbo — anteprima di sviluppo RAM80

Questo port adatta il gioco C64 originale al prototipo software corrente plus/64. Conserva logica di gioco, grafica compressa e musica SID; la deviazione del trainer THT e il codice che aveva inserito sono stati rimossi. Il disco sorgente fornito è una versione THT modificata: non viene presentato come un originale editoriale incontaminato.

Il limite di memoria della macchina emulata è **65.536 byte principali + 16.384 byte interni condivisi = 81.920 byte (80 KiB)**. C16 e Plus/4 usano lo stesso gioco e lo stesso contratto plus/64. Questa anteprima richiede l'emulatore plus/64 corrente con MCM denso e altezza estesa; un vecchio runtime di Impossible Mission non offre questa capacità.

## Avvio e comandi

Su Windows usare **`AVVIA_USAGI.cmd`** per C16 oppure **`AVVIA_USAGI_PLUS4.cmd`** per Plus/4. Entrambi usano lo stesso `USAGI.D64`. La keymap `usagi.vkm` del pacchetto associa **frecce e Space del PC** al joystick keyset A della porta 2. In alternativa montare il disco nell'unità 8 dell'emulatore plus/64 corrispondente e digitare:

```basic
LOAD"*",8,1
RUN
```

Attendere il menu originale. La scelta iniziale è **PRACTICE**, una modalità prevista dal gioco. Con il launcher PC fornito, premere e rilasciare **F1 del PC** una volta, verificare che compaia **GAME** e premere **Space** per iniziare. Usare le frecce per muoversi e Space per fire/azione.

| Tasto PC con `usagi.vkm` | Azione |
| --- | --- |
| F1 | Menu: alterna PRACTICE / GAME; gioco: torna al menu |
| F3 | Menu: alterna joystick / tastiera |
| F5 | Menu: avvia; avvia anche Space |
| F7 | Gioco: pausa; rilasciare, poi premere e rilasciare di nuovo per riprendere |

Questi tasti PC sono distinti dai nomi nativi C16/Plus/4. Il menu originale mostra ancora le etichette C64. Per la documentazione dei tasti nativi, o con un'altra keymap dell'host, la corrispondenza è:

| Contesto | Tasto nativo | Azione |
| --- | --- | --- |
| Menu | F1 | Alterna PRACTICE / GAME |
| Menu | F2 | Alterna joystick / tastiera |
| Menu | F3 oppure HELP | Avvia la modalità scelta; avvia anche FIRE del joystick |
| Gioco | F1 | Torna al menu |
| Gioco | HELP | Pausa; rilasciare, poi premere e rilasciare di nuovo HELP per riprendere |

Il launcher PC fornito è già pronto per il joystick con frecce e Space. Per usare il controller originale a tastiera, prima disabilitare in VICE **l'emulazione del joystick tramite tastiera dell'host sulla porta 2**, impostandone il dispositivo joystick su **None**; poi selezionare la tastiera nel menu del gioco con **F3 del PC (F2 nativo)**. I comandi sono **Q = su, P = destra, I = sinistra, Z = giù, SPACE = fire**. Con il keyset A attivo, VICE intercetta Space come fire del joystick prima che raggiunga la tastiera nativa: cambiare soltanto la scelta nel menu del gioco non basta. Le combinazioni direzione/fire sono gestite dal gioco originale; i tasti fisici dell'host dipendono dalla keymap dell'emulatore.

## Memoria e implementazione

Il decoder RLE originale usa una sola area temporanea da 64 byte, invece di conservare nella RAM principale tutti i 46 record espansi della cache sprite. La RAM interna contiene **46 × 70 = 3.220 byte** di record MCM densi e i due banchi originali di asset da 4 KiB, lasciando **4.972 byte non assegnati**. Quattro personaggi occupano otto colonne sprite da 24 pixel per 63 righe: si usano gli otto slot già disponibili, senza altra RAM sprite. I 16 record intermedi originali della cache conservano posizioni riservate, ma non vengono selezionati come colonne dei personaggi.

Le coppie TED native del fondale occupano `$D000/$D400` e `$F000/$F400`. Una coppia indipendente per l'interfaccia occupa `$1800/$1C00`. Le tabelle originali basse vengono spostate in `$0200..$09FF`; font originali e banchi di asset compressi vengono conservati. Il caricamento a freddo riusa temporaneamente le stesse RAM principale e interna e ripristina gli helper bassi prima dell'ingresso nel gioco originale. La dimensione del disco, il trasporto compresso e la memoria del processo emulatore sull'host sono distinti dal totale RAM della macchina emulata.

Il rapporto di memoria allegato identifica candidato e hash esatti. I suoi confronti dei byte, le prove CPU limitate di equivalenza e il test della copia a freddo sono distinti dalle prove di avvio e comandi nell'emulatore. Rimane un'anteprima di sviluppo: non si dichiara una campagna completata, una prova su Windows nativo o una qualifica su hardware fisico. Gli eseguibili Windows provati tramite Wine sono indicati come prove Wine.

## Sorgenti e attribuzione

`Usagi Yojimbo`, il codice, la grafica, la musica e i personaggi originali mantengono i crediti dei rispettivi autori e titolari dei diritti. L'adattamento tecnico e la rimozione del trainer non cambiano la licenza di quei materiali. Il port viene ricostruito dal D64 fornito, SHA256 `68e476cadac7160abdb290fc6d1636d9e52e14e4f0027bc7f04f752fa6325808`; il file di ingresso rimane invariato. Gli strumenti sorgente documentano le trasformazioni con guardie sui byte di quell'ingresso.

VICE e le modifiche plus/64 sono distribuiti con i relativi sorgenti GPL e avvisi applicabili. Conservare i file di licenza dell'emulatore e gli avvisi delle dipendenze insieme alla distribuzione corrispondente. Questa anteprima implementa un contratto nell'emulatore: non certifica un progetto elettrico di cartuccia né il funzionamento fisico su C16/Plus/4.
