# Usagi Yojimbo — sky and character materials RAM80

This port adapts the original C64 game to the current plus/64 software prototype. It preserves the original game logic, compressed graphics and SID music; the THT trainer detour and its injected code have been removed. The supplied source disk is a modified THT release, so this is not described as a pristine publisher-master conversion.

The guest memory limit is **65,536 bytes of main RAM + 16,384 bytes of shared internal RAM = 81,920 bytes (80 KiB)**. C16 and Plus/4 use the same game and plus/64 contract. Revision15 uses the same matching executable as revision14 with scenery20 and authored materials at snapshot byte82, version3. Use the supplied disk and executable together.

The game uses game-authored recipes for character regions: light follows the masks and authored groups across sprite columns and parts, rather than restarting at every 24×21 part. Original silhouettes and animations are retained. The 207 canonical poses have explicit recipe selections; the portrait now uses the composite format with the soft option, retaining the original mode with flat. Dark regions can use explicit neutral luminance profiles; protected details keep their original ink.

Revision 9 retains the approved protagonist and farmer colours. It extends the robe’s soft shading to monk hoods and separates the pigs’ pale facial regions from garment material: their original hue is retained with gentle frontal light. The pig’s existing spray is made red by thirteen guarded changes to compressed colour indices, retaining its shape. It also corrects the third-column binding of wide characters, restoring the monster’s front. Original artwork and animations are not redrawn. That revision 9 changed only the game; its renderer and executable remained byte-identical to revision 8. The total remains 64+16 KiB.

## Revision15: soft lighting for the portrait

The top-left portrait retains its six original parts and expressions.
White fur uses gentle luminances6/7 through three game-authored ear/face
regions. Blue, black, outline and frame retain their inks; original masks
and geometry are preserved. The supplied comparison uses actual before/
after screenshots and a portrait crop enlarged without interpolation;
the complete scene is also shown.

Rebuild this variant with **`--portrait-shading soft`** alongside
`--actor-shading materials --sky clouds`, then `boot.py --low-restore`.
Playing requires only the supplied launchers, without adding build flags.
`--portrait-shading flat` remains the build default: with actor materials
and sky it exactly rebuilds revision14/008. All-default options rebuild
the flat016 port.

This game-side change uses existing composite-material version3.
**The executable, renderer and scenery20 API are unchanged.** A64-byte
initializer runs only during sprite startup; periodic code is unchanged.
The65 bytes of bindings, directory and recipe occupy previously unused
internal RAM, leaving299 bytes unassigned. The main-RAM transport copy
is included in the existing64KiB. Total RAM remains
**65,536 +16,384 =81,920bytes**, without extra sprite slots or image buffers.

Sky, clouds and six green tones retain revision14 artwork. Five near
strips and one distant strip still select native green `$55`, intentionally
including matching foliage and textures; sprites and lower UI are distinct
from the ramp. Scene data are relocated within the same padding to reserve
the portrait helper.

Extract the ZIP into a new directory and use `AVVIA_USAGI.cmd` or
`AVVIA_USAGI_PLUS4.cmd`. Candidate009 evidence separates new initialization,
portrait, cold boot and gameplay checks from retained core qualification.
No new emulator build or SDK run, completed campaign, native Windows or
physical hardware test is claimed.

## Start and controls

On Windows, use **`AVVIA_USAGI.cmd`** for C16 or **`AVVIA_USAGI_PLUS4.cmd`** for Plus/4. Both use the same `USAGI.D64`. The package's `usagi.vkm` maps the PC **arrow keys and Space** to joystick keyset A on port 2. Alternatively, attach the disk as drive 8 in the matching plus/64 emulator and enter:

```basic
LOAD"*",8,1
RUN
```

Wait for the original menu. Its default is **PRACTICE**, an original game option. With the supplied PC launcher, press and release **PC F1** once, check that **GAME** is displayed, then press **Space** to start. Use the arrow keys to move and Space for fire/action.

| PC host key with `usagi.vkm` | Action |
| --- | --- |
| F1 | Menu: switch PRACTICE / GAME; gameplay: return to menu |
| F3 | Menu: switch joystick / keyboard controller |
| F5 | Menu: start; Space also starts |
| F7 | Gameplay: pause; release, then press and release again to resume |

These PC keys are distinct from the native C16/Plus/4 key names. The original menu still displays C64 labels. For native-key documentation or a different host keymap, the mapping is:

| Context | Native key | Action |
| --- | --- | --- |
| Menu | F1 | Switch PRACTICE / GAME |
| Menu | F2 | Switch joystick / keyboard controller |
| Menu | F3 or HELP | Start the selected mode; joystick FIRE also starts |
| Gameplay | F1 | Return to the menu |
| Gameplay | HELP | Pause; release, then press and release HELP again to resume |

The supplied PC launcher is ready for arrow-key/Space joystick control. For the optional original keyboard controller, first disable **host joystick keyboard emulation for port 2** in VICE by setting its joystick device to **None**, then select keyboard control in the game menu with **PC F3 (native F2)**. Its keys are **Q = up, P = right, I = left, Z = down, SPACE = fire**. With keyset A active, VICE consumes Space as joystick fire before it reaches the native keyboard, so switching only the game menu is insufficient. Direction/fire combinations are handled by the original game; physical host keys depend on the emulator keymap.

## Memory and implementation

The original RLE decoder uses one 64-byte staging area instead of keeping all 46 expanded sprite-cache records in main RAM. The internal RAM holds **46 × 70 = 3,220 bytes** of dense MCM records and both original 4 KiB asset banks, alongside **4,608 bytes** of recipes, lookup, bindings, cache and directories; the65-byte portrait metadata leave **299 bytes unassigned**. The eight existing slots use 24-pixel-wide, 63-row sprite columns. Wide characters reuse the original reserved channel; no sprite RAM is added. The 16 original intermediate cache records still have reserved record positions but are not selected as actor columns.

Native TED background pairs occupy `$D000/$D400` and `$F000/$F400`. An independent UI pair occupies `$1800/$1C00`. Original low tables are relocated to `$0200..$09FF`; original fonts and compressed asset banks are retained. Cold loading temporarily reuses the same main/internal RAM and restores the low helpers before the original game entry. Disk size, compressed transport and host emulator allocations are separate from the guest RAM total.

Revision 2 lets native raster interrupts continue during the original coarse-scroll routine, fixing the blocked viewport at scrolling wraps. Its two control bytes fit in the existing reserved state. The launcher uses a 64 ms host audio buffer; guest RAM remains 80 KiB.

Revision 3 also tracks the original dialogue/colour clear operations, so native UI rows are refreshed when text is removed. It opts into the generic FD9F bit4 border rule: sprites and presentation windows respect closed TED side borders. The added control uses the existing register and RAM; the original game art and rules are retained.

Revision 4 limits the keyboard reader’s interrupt mask to one row at a time, correcting the video delay behind an intermittent life-bar flash. It uses the same emulator as revision 3. Extract this ZIP into a new folder and use its updated disk. Memory and controls remain as described above.

Revision 6 uploads material data into the same internal 16 KiB at `$0E00..$1FFF`. Original D/F banks remain at `$2000..$3FFF`; sprite records remain 46×70 bytes. The compressed loader reuses existing RAM and keeps no second copy or external history. The generic format is documented in the IT/EN technical addenda.

The accompanying memory audit identifies its exact candidate and hashes. Its byte comparisons, bounded CPU equivalence tests and cold-copy fixture are distinct from emulator boot/control tests. This remains a development preview: no completed-campaign, native-Windows or physical-hardware qualification is claimed. Windows executables exercised under Wine are reported as Wine tests.

## Sources and attribution

`Usagi Yojimbo` and its original game code, graphics, music and characters retain their respective authors' and rights holders' credits. Technical adaptation and trainer removal do not relicense those materials. The port build uses the supplied D64 with SHA256 `68e476cadac7160abdb290fc6d1636d9e52e14e4f0027bc7f04f752fa6325808`; the input file is preserved unchanged. The source tools document guarded transformations of that input.

VICE and its plus/64 modifications are distributed with their applicable GPL source and notices. Keep the emulator licence files and third-party notices with the corresponding distribution. This preview implements an emulator contract; it does not certify an electrical cartridge design or physical C16/Plus/4 operation.
