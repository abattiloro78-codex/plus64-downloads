# Usagi revisione15 — mappa della memoria

Candidato `link-009` / `boot-009`; stesso core scenari20/materiali3 della revisione14.

Il limite resta **65.536 +16.384 =81.920byte**. La scena conserva260byte
e16nodi. L'helper del ritratto usa64byte di padding principale a
`$2FBA..$2FF9`; la scena viene riallocata fuori da quel lease. I42componenti
compilati totalizzano **5.492byte**. I65byte del trasporto principale a
`$0E94..$0ED4` sono dati separati: componenti più trasporto occupano5.557byte.
Gli altri byte principali contengono logica, font, musica, piani e dati del gioco.

| RAM interna condivisa | Byte |
| --- | ---: |
| 46 record sprite densi, incluso il ritratto | 3.220 |
| Collegamenti, directory e ricetta del ritratto | 65 |
| Non assegnati | 299 |
| Ricette/lookup/collegamenti/directory degli attori | 4.608 |
| Banchi originali D/F | 8.192 |

I65byte occupano `$0C94..$0CD4`:48byte per sei collegamenti,4per la
directory a `$0CC4` e13per la ricetta a `$0CC8`. La copia principale
`$0E94..$0ED4` viene trasferita dal caricamento basso già esistente.
Il payload attori `materials.bin` rimane quello approvato:4.602byte usati
e6liberi nei4.608. Nessun record sprite o banco aggiuntivo.

I sei record logici40..45 corrispondono ai record fisici24..29 esistenti.
Il profilo3 seleziona soltanto il pelo bianco(coppia1) a luminanze6/7;
blu, nero, maschere e cornice restano originali. Il nuovo helper interviene
solo nell'inizializzazione: il componente sprites cambia un hook da3byte,
gli altri diciotto componenti di base restano identici alla revisione14.
Gli indirizzi dei dati scena vengono aggiornati senza cambiare la grafica.
Core, API e binari non vengono modificati né ricompilati.

| Componente compilato | Intervallo principale | Byte |
| --- | --- | ---: |
| `ui_marks` | `$0A00..$0AAA` | 171 |
| `sky_14` | `$0AAB..$0AB6` | 12 |
| `sky_15` | `$0AB7..$0AC2` | 12 |
| `sky_16` | `$0AC3..$0ACE` | 12 |
| `sky_17` | `$0ACF..$0ADA` | 12 |
| `sky_18` | `$0ADB..$0AE6` | 12 |
| `sky_19` | `$0AE7..$0AF2` | 12 |
| `sky_20` | `$0AF3..$0AFE` | 12 |
| `ui_data` | `$0B40..$0B7F` | 64 |
| `bridge_stub` | `$0B80..$0BD4` | 85 |
| `sky_06` | `$0BD5..$0BE0` | 12 |
| `sky_08` | `$0BE1..$0BEC` | 12 |
| `sky_09` | `$0BED..$0BF4` | 8 |
| `ui_rows` | `$0C00..$0C88` | 137 |
| `material_finish` | `$0C90..$0D7E` | 239 |
| `bridge` | `$2800..$2A4D` | 590 |
| `sky_21` | `$2A50..$2A5F` | 16 |
| `sky_02` | `$2A60..$2A6F` | 16 |
| `sky_03` | `$2A70..$2A79` | 10 |
| `video` | `$2A80..$2CA4` | 549 |
| `material_entries` | `$2CB0..$2CFC` | 77 |
| `timers` | `$2D00..$2EA5` | 422 |
| `material_cache` | `$2EA8..$2EFD` | 86 |
| `input` | `$2F00..$2FB9` | 186 |
| `portrait_init` | `$2FBA..$2FF9` | 64 |
| `sky_00` | `$2FFA..$2FFF` | 6 |
| `direct_colour` | `$40B4..$41C9` | 278 |
| `direct_column` | `$43F1..$4449` | 89 |
| `memory` | `$DC00..$DD8E` | 399 |
| `menu` | `$DD90..$DE1E` | 143 |
| `sky_04` | `$DE1F..$DE2E` | 16 |
| `sky_05` | `$DE2F..$DE36` | 8 |
| `sky_07` | `$DE37..$DE3E` | 8 |
| `keyboard` | `$DE40..$DEEB` | 172 |
| `sky_01` | `$DEEC..$DEFB` | 16 |
| `bootstrap` | `$DF00..$DF3D` | 62 |
| `material_record` | `$DF40..$DFFB` | 188 |
| `sprites` | `$F800..$FCCE` | 1231 |
| `sky_10` | `$FCCF..$FCDA` | 12 |
| `sky_11` | `$FCDB..$FCE6` | 12 |
| `sky_12` | `$FCE7..$FCF2` | 12 |
| `sky_13` | `$FCF3..$FCFE` | 12 |

```sh
python3 tools-game/usagi-port/link.py --input '/percorso/Usagi Yojimbo.d64' --out build/link-new --actor-shading materials --sky clouds --portrait-shading soft
python3 tools-game/usagi-port/boot.py --link build/link-new --out build/boot-new --low-restore
```

Conservare `portrait.py`, `portrait.bin` e `PORTRAIT.json`. La ricostruzione
verifica otto artefatti del candidato009. L'opzione portrait-flat con
materiali/cielo riproduce i sette artefatti008, mentre la configurazione
predefinita riproduce i sei artefatti016. Le prove della nuova inizializzazione
sono distinte dalla qualifica conservata del core e dai test periodici.
