# Usagi revision15 — memory map

Candidate `link-009` / `boot-009`; unchanged scenery20/material3 core from revision14.

The limit remains **65,536 +16,384 =81,920bytes**. Scenery retains260bytes
and16nodes. The portrait helper occupies64bytes of main-RAM padding at
`$2FBA..$2FF9`; scene data are relocated outside that lease. The42compiled
components total **5,492bytes**. The65-byte main transport at
`$0E94..$0ED4` is separate data: components plus transport occupy5,557bytes.
Other main-RAM bytes retain game logic, fonts, music, display planes and assets.

| Shared internal RAM | Bytes |
| --- | ---: |
| 46 dense sprite records, including the portrait | 3,220 |
| Portrait bindings, directory and recipe | 65 |
| Unassigned | 299 |
| Actor recipes, lookup, bindings and directories | 4,608 |
| Original D/F asset banks | 8,192 |

The65bytes occupy `$0C94..$0CD4`:48bytes of six bindings,4for the directory
at `$0CC4` and13for the recipe at `$0CC8`. Main copy `$0E94..$0ED4` is
transported by the existing low-page upload. Actor `materials.bin` retains
the approved4,602used and6spare bytes within4,608. No extra sprite record or bank.

Logical records40..45 map to existing physical records24..29. Profile3
selects white fur only(pair1), using luminances6/7; blue, black, masks and
frame retain their original data. The helper runs only at initialization:
the sprites component changes one3-byte hook, while the other eighteen
base components are identical to revision14. Scene data pointers change
without changing scenery artwork. Core, API and binaries are neither
modified nor rebuilt.

| Compiled component | Main-RAM range | Bytes |
| --- | --- | ---: |
| `ui_marks` | `$0A00..$0AAA` | 171 |
| `sky_14` | `$0AAB..$0AB6` | 12 |
| `sky_15` | `$0AB7..$0AC2` | 12 |
| `sky_16` | `$0AC3..$0ACE` | 12 |
| `sky_17` | `$0ACF..$0ADA` | 12 |
| `sky_18` | `$0ADB..$0AE6` | 12 |
| `sky_19` | `$0AE7..$0AF2` | 12 |
| `sky_20` | `$0AF3..$0AFE` | 12 |
| `ui_data` | `$0B40..$0B7F` | 64 |
| `bridge_stub` | `$0B80..$0BD4` | 85 |
| `sky_06` | `$0BD5..$0BE0` | 12 |
| `sky_08` | `$0BE1..$0BEC` | 12 |
| `sky_09` | `$0BED..$0BF4` | 8 |
| `ui_rows` | `$0C00..$0C88` | 137 |
| `material_finish` | `$0C90..$0D7E` | 239 |
| `bridge` | `$2800..$2A4D` | 590 |
| `sky_21` | `$2A50..$2A5F` | 16 |
| `sky_02` | `$2A60..$2A6F` | 16 |
| `sky_03` | `$2A70..$2A79` | 10 |
| `video` | `$2A80..$2CA4` | 549 |
| `material_entries` | `$2CB0..$2CFC` | 77 |
| `timers` | `$2D00..$2EA5` | 422 |
| `material_cache` | `$2EA8..$2EFD` | 86 |
| `input` | `$2F00..$2FB9` | 186 |
| `portrait_init` | `$2FBA..$2FF9` | 64 |
| `sky_00` | `$2FFA..$2FFF` | 6 |
| `direct_colour` | `$40B4..$41C9` | 278 |
| `direct_column` | `$43F1..$4449` | 89 |
| `memory` | `$DC00..$DD8E` | 399 |
| `menu` | `$DD90..$DE1E` | 143 |
| `sky_04` | `$DE1F..$DE2E` | 16 |
| `sky_05` | `$DE2F..$DE36` | 8 |
| `sky_07` | `$DE37..$DE3E` | 8 |
| `keyboard` | `$DE40..$DEEB` | 172 |
| `sky_01` | `$DEEC..$DEFB` | 16 |
| `bootstrap` | `$DF00..$DF3D` | 62 |
| `material_record` | `$DF40..$DFFB` | 188 |
| `sprites` | `$F800..$FCCE` | 1231 |
| `sky_10` | `$FCCF..$FCDA` | 12 |
| `sky_11` | `$FCDB..$FCE6` | 12 |
| `sky_12` | `$FCE7..$FCF2` | 12 |
| `sky_13` | `$FCF3..$FCFE` | 12 |

```sh
python3 tools-game/usagi-port/link.py --input '/path/Usagi Yojimbo.d64' --out build/link-new --actor-shading materials --sky clouds --portrait-shading soft
python3 tools-game/usagi-port/boot.py --link build/link-new --out build/boot-new --low-restore
```

Retain `portrait.py`, `portrait.bin` and `PORTRAIT.json`. The staged rebuild
verifies eight candidate009 artifacts. Portrait-flat with actor materials
and sky reproduces the seven008 artifacts; all-default configuration
reproduces the six016 artifacts. New initialization evidence is separate
from retained core qualification and periodic execution checks.
