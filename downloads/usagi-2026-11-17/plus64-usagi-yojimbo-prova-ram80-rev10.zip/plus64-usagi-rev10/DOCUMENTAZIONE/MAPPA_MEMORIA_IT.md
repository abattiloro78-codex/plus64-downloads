# Usagi revisione 10 — mappa della memoria

Candidato `link-002` / `boot-002`.

I 320 byte del cielo occupano sette intervalli di padding principale
esplicitamente ritirati. Il bootstrap passa da 64 a 62 byte: il totale dei
componenti è 5.170 + 320 - 2 = **5.488 byte**, in **48 componenti** compresi
nodi e tavole. La quantità di RAM disponibile non aumenta. I 4.608 byte
dei materiali dei personaggi rimangono identici alla revisione 9: 4.602
usati e 6 liberi. Anche i 3.220 byte dei record e gli 8 KiB degli asset
originali mantengono le stesse riserve.

Il cielo usa venti nodi su un massimo generico di trentadue: diciannove
tinte e un collegamento condizionale. L'inizializzazione occupa 16 byte,
compresi nei 320; imposta `$FD9D/$FD9E` e `$FD9F=$11`. Il byte bridge
`$0E64` abilita il collegamento soltanto quando vale 1. Non si aggiungono
variabili di animazione o un archivio di bitmap fuori dalla macchina.

| RAM | Bytes |
| --- | ---: |
| Main RAM | 65,536 |
| Shared internal RAM | 16,384 |
| Total | **81,920** |
| Hidden/extra RAM | **0** |

| Internal allocation | Bytes |
| --- | ---: |
| 46 dense sprite records | 3,220 |
| Unassigned | 364 |
| Character recipes, lookup, bindings and directories | 4,608 |
| Original D/F asset banks | 8,192 |

| Componente | Intervallo principale | Byte |
| --- | --- | ---: |
| `ui_marks` | `$0A00..$0AAA` | 171 |
| `sky_22` | `$0AAB..$0AB6` | 12 |
| `sky_23` | `$0AB7..$0AC2` | 12 |
| `sky_24` | `$0AC3..$0ACE` | 12 |
| `sky_25` | `$0ACF..$0ADA` | 12 |
| `sky_26` | `$0ADB..$0AE6` | 12 |
| `sky_27` | `$0AE7..$0AF2` | 12 |
| `ui_data` | `$0B40..$0B7F` | 64 |
| `bridge_stub` | `$0B80..$0BD4` | 85 |
| `sky_08` | `$0BD5..$0BE0` | 12 |
| `sky_09` | `$0BE1..$0BEC` | 12 |
| `sky_10` | `$0BED..$0BF4` | 8 |
| `sky_12` | `$0BF5..$0BFC` | 8 |
| `ui_rows` | `$0C00..$0C88` | 137 |
| `material_finish` | `$0C90..$0D7E` | 239 |
| `bridge` | `$2800..$2A4D` | 590 |
| `sky_28` | `$2A50..$2A5F` | 16 |
| `sky_02` | `$2A60..$2A6B` | 12 |
| `sky_03` | `$2A6C..$2A73` | 8 |
| `sky_04` | `$2A74..$2A7F` | 12 |
| `video` | `$2A80..$2CA4` | 549 |
| `material_entries` | `$2CB0..$2CFC` | 77 |
| `timers` | `$2D00..$2EA5` | 422 |
| `material_cache` | `$2EA8..$2EFD` | 86 |
| `input` | `$2F00..$2FB9` | 186 |
| `sky_16` | `$2FBA..$2FC1` | 8 |
| `sky_17` | `$2FC2..$2FCD` | 12 |
| `sky_18` | `$2FCE..$2FD9` | 12 |
| `sky_19` | `$2FDA..$2FE5` | 12 |
| `sky_20` | `$2FE6..$2FF1` | 12 |
| `sky_21` | `$2FF2..$2FFD` | 12 |
| `direct_colour` | `$40B4..$41C9` | 278 |
| `direct_column` | `$43F1..$4449` | 89 |
| `memory` | `$DC00..$DD8E` | 399 |
| `menu` | `$DD90..$DE1E` | 143 |
| `sky_05` | `$DE1F..$DE26` | 8 |
| `sky_06` | `$DE27..$DE32` | 12 |
| `sky_07` | `$DE33..$DE3A` | 8 |
| `keyboard` | `$DE40..$DEEB` | 172 |
| `sky_00` | `$DEEC..$DEF3` | 8 |
| `sky_01` | `$DEF4..$DEFF` | 12 |
| `bootstrap` | `$DF00..$DF3D` | 62 |
| `material_record` | `$DF40..$DFFB` | 188 |
| `sprites` | `$F800..$FCCE` | 1231 |
| `sky_11` | `$FCCF..$FCDA` | 12 |
| `sky_13` | `$FCDB..$FCE6` | 12 |
| `sky_14` | `$FCE7..$FCEE` | 8 |
| `sky_15` | `$FCEF..$FCFA` | 12 |

Le altre diciotto componenti compilate del gioco restano identiche alla
revisione 9; cambia il bootstrap e si aggiungono dati e inizializzazione.
I font, i banchi originali e le tredici correzioni protette del colore dello
spruzzo restano quelli approvati. Nessuna modifica all'emulatore.

Per ricostruire la grafica pubblicata usare `--actor-shading materials --sky clouds`;
`--actor-shading materials --sky flat` ricostruisce esattamente i sette
artefatti della revisione 9. I rapporti conservano gli hash effettivi.
Le prove private di memoria/CPU sono distinte dagli avvii nell'emulatore.
