# Usagi RAM80 — candidato 024, revisione 9

Il controllo indipendente ricostruisce l’immagine principale con **413 patch con guardie** e **19 componenti disgiunti per 5.170 byte**, negli stessi 64 KiB. Uploader e ripristino basso vengono eseguiti su una CPU 6502 privata con modello delle porte. In questa revisione cambia il codice degli helper dei materiali: **non si eredita per identità l’intera qualifica CPU dei candidati 018/019/022**. Le nuove prove degli helper e delle sequenze di cache identificano il candidato 024.

## Artefatti esatti

| Artefatto | Byte | SHA256 |
| --- | ---: | --- |
| Immagine principale | 65536 | `39b9c66216b3e3e67c077b49f587bfb1dffe5a1f7f018ac75754dc5ce002159c` |
| Banchi D/F | 8192 | `d07595210b1beb05a25c918e4b9eebb49a8ae7043e6797fa265b0afbdc1d9546` |
| Materiali | 4608 | `31dcdf060e3ef48f276cc5465262ac399bc7e0468479d1a14f7f4dccf1fbdeb9` |
| PRG | 60673 | `4cc1055f2cd9d84de7add7c6dd1b4d401bfa99b5181b36ef2fd1c683180f4c50` |
| D64 | 174848 | `ddf726719735209dc881236109a45e7c649fd4a13a781cbb6bf98f0d612972d2` |

## RAM interna condivisa

Il totale della macchina resta **65.536 + 16.384 = 81.920 byte**.

| Intervallo, fine esclusa | Byte | Uso |
| --- | ---: | --- |
| `$0000..$0C94` | 3220 | 46 record densi |
| `$0C94..$0E00` | 364 | Non assegnati; possono conservare dati di avvio |
| `$0E00..$2000` | 4608 | Materiali, lookup, collegamenti, cache e directory del gioco |
| `$2000..$3000` | 4096 | Banco D originale |
| `$3000..$4000` | 4096 | Banco F originale |

I 4.608 byte dei materiali usano **4602 byte**, lasciando **6 byte di padding**. Le 105 definizioni diventano 85 ricette deduplicate. Rimangono invariati i 208 lookup attivi per piano a `$0E00/$0F00`, i 24 collegamenti attivi da `$1000`, directory a `$1170` e banchi originali a `$2000..$3FFF`. Le ricette usano `$1188..$1FFF`, la coda non selezionata `$10D1..$116F` e i due intervalli da 48 byte `$0ED0..$0EFF` e`$0FD0..$0FFF`, all’interno dello stesso payload. Il selettore conserva gli indici 0..206 e il fallback originale 207; ogni indice successivo viene limitato a 207 prima della lettura. I 46 record sprite restano 3.220 byte; restano separati 364 byte tra `$0C94` e`$0E00`.

## Sottoallocazioni del payload dei materiali

| Intervallo, fine esclusa | Byte | Uso |
| --- | ---: | --- |
| `$0E00..$0ED0` | 208 | 208 lookup attivi, byte basso |
| `$0ED0..$0F00` | 48 | Ricette immutabili nella coda lookup bassa |
| `$0F00..$0FD0` | 208 | 208 lookup attivi, byte alto |
| `$0FD0..$1000` | 48 | Ricette immutabili nella coda lookup alta |
| `$1000..$10C0` | 192 | 24 collegamenti attivi |
| `$10C0..$10D0` | 16 | Chiavi della cache |
| `$10D0..$10D1` | 1 | Proprietario della colonna in prestito |
| `$10D1..$1170` | 159 | Ricette immutabili nella coda dei collegamenti |
| `$1170..$1188` | 24 | Directory delle colonne |
| `$1188..$2000` | 3704 | Pool alto delle ricette |

## Terza colonna e gestione della cache

La larghezza originale in`$39` vale per tutti gli attori, non soltanto per il protagonista. I personaggi larghi usano i due canali del proprio corpo e un canale riservato in prestito: colonna fisica 2 a destra o 3 a sinistra. La directory dei materiali segue l’ordine spaziale effettivo; non presume che la terza colonna sia contigua alle prime due. Vengono riusati gli otto slot e i record esistenti. La cache a `$10C0..$10CF` conserva le chiavi; il byte proprietario a `$10D0` usa la coda non selezionata dei collegamenti già riservati. Il cambio di proprietario forza il rinnovo dei collegamenti presi in prestito. Non si aggiunge RAM.

La correzione viene verificata sui dati originali completi 72×63, nei due orientamenti e dopo sequenze che cambiano l’attore proprietario della colonna. Le prove statiche dei materiali non sostituiscono queste prove CPU/topologiche.

## Colori e compatibilità

Il cappuccio usa il materiale morbido della veste, conservando tinta e bordi neri. L’immagine CPU del candidato 024 è identica al candidato 023 già qualificato: soltanto materiali e trasporto cambiano. Le nuove prove CPU della revisione 9 si riusano attraverso questa identità esplicita, non attraverso i vecchi candidati 018/019/022. I dettagli gialli del viso dei maiali usano il profilo 3, con tinta originale e luminanze 6/7, separati dalla maglia dorata del profilo 7 ancorato a 112 (luminanze 5..7). Il viso bianco dei maiali usa un rettangolo dedicato del profilo 2, con luminanze 5..7, per dare volume; mani, piedi e dettagli bianchi esterni alla testa conservano il profilo 3 lieve a 6/7. La separazione della testa modifica gli span residui del profilo 3 nella stessa riga: fuori dalla ROI alcuni bianchi dei maiali possono passare fra 91 e 106 (258 pixel nei 52 casi combinatori), sempre con differenza massima di una luminanza. Questa redistribuzione non cambia gli altri inchiostri, i bordi neri o i personaggi non interessati. Lo spruzzo rosso usa il profilo 7 con base 62, su 17 coppie di pixel già opache: 13 byte letterali del record RLE unico vengono protetti e convertiti dall’indice 3 all’indice 2. Nessun byte di conteggio RLE, puntatore di posa, bordo del viso o pixel trasparente cambia. Il resto degli asset compressi resta esatto; i banchi originali D/F e i font restano interamente invariati. Le ricette approvate del protagonista e dei contadini, compreso il cappello giallo 112, restano protette. Alpha e maschere originali restano i riferimenti.

Il renderer generico non cambia: formato materiale versione 3, snapshot 82=3, profili 0..7. Il payload snapshot resta 144.776 byte. Le prove SDK/snapshot dell’eseguibile precedente rimangono associate soltanto a quegli stessi byte verificati; non vengono presentate come nuove compilazioni. I test del nuovo gioco e i loro hash sono separati.

## Componenti nella RAM principale

| Componente | Inizio | Fine esclusa | Byte |
| --- | --- | --- | ---: |
| `ui_marks` | `$0A00` | `$0AAB` | 171 |
| `ui_data` | `$0B40` | `$0B80` | 64 |
| `bridge_stub` | `$0B80` | `$0BD5` | 85 |
| `ui_rows` | `$0C00` | `$0C89` | 137 |
| `material_finish` | `$0C90` | `$0D7F` | 239 |
| `bridge` | `$2800` | `$2A4E` | 590 |
| `video` | `$2A80` | `$2CA5` | 549 |
| `material_entries` | `$2CB0` | `$2CFD` | 77 |
| `timers` | `$2D00` | `$2EA6` | 422 |
| `material_cache` | `$2EA8` | `$2EFE` | 86 |
| `input` | `$2F00` | `$2FBA` | 186 |
| `direct_colour` | `$40B4` | `$41CA` | 278 |
| `direct_column` | `$43F1` | `$444A` | 89 |
| `memory` | `$DC00` | `$DD8F` | 399 |
| `menu` | `$DD90` | `$DE1F` | 143 |
| `keyboard` | `$DE40` | `$DEEC` | 172 |
| `bootstrap` | `$DF00` | `$DF40` | 64 |
| `material_record` | `$DF40` | `$DFFC` | 188 |
| `sprites` | `$F800` | `$FCCF` | 1231 |

I componenti cambiati rispetto a 022 sono: `material_entries`, `material_record`, `material_finish`, `material_cache`.

Le prove distinguono avvio normale del disco, catture controllate e fixture con stato diagnostico. Uno stato seminato per selezionare un tipo di NPC non è una partita naturale né un trainer nel disco distribuito. Wine, Windows nativo e hardware fisico rimangono ambiti distinti; nessuna campagna completa o prova hardware viene dichiarata.
