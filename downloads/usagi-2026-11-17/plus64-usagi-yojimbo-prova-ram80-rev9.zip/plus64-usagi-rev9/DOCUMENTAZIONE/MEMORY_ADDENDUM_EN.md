# Usagi RAM80 — candidate 024, revision 9

The independent audit reconstructs the main image with **413 guarded patches** and **19 disjoint components totalling 5,170 bytes**, within the same 64 KiB. Uploader and low restore execute on a private 6502/port model. This revision changes material-helper code: **the full CPU qualification of018/019/022 is not inherited by byte identity**. New helper and cache-sequence evidence identifies candidate 024.

## Exact artifacts

| Artifact | Bytes | SHA256 |
| --- | ---: | --- |
| Main image | 65536 | `39b9c66216b3e3e67c077b49f587bfb1dffe5a1f7f018ac75754dc5ce002159c` |
| D/F banks | 8192 | `d07595210b1beb05a25c918e4b9eebb49a8ae7043e6797fa265b0afbdc1d9546` |
| Materials | 4608 | `31dcdf060e3ef48f276cc5465262ac399bc7e0468479d1a14f7f4dccf1fbdeb9` |
| PRG | 60673 | `4cc1055f2cd9d84de7add7c6dd1b4d401bfa99b5181b36ef2fd1c683180f4c50` |
| D64 | 174848 | `ddf726719735209dc881236109a45e7c649fd4a13a781cbb6bf98f0d612972d2` |

## Shared internal RAM

The guest total remains **65,536 + 16,384 = 81,920 bytes**.

| Range, end exclusive | Bytes | Ownership |
| --- | ---: | --- |
| `$0000..$0C94` | 3220 | 46dense records |
| `$0C94..$0E00` | 364 | Unassigned,may retain cold bytes |
| `$0E00..$2000` | 4608 | Game-authored materials,lookup,bindings,cache,directories |
| `$2000..$3000` | 4096 | Original D bank |
| `$3000..$4000` | 4096 | Original F bank |

The 4,608-byte material reservation uses **4602 bytes**, leaving **6 padding bytes**. Its 105 definitions become 85 deduplicated recipes. The 208 live lookup entries per plane at `$0E00/$0F00`, the 24 live bindings from `$1000`, directories at `$1170` and original banks at `$2000..$3FFF` remain in place. Recipes use `$1188..$1FFF`, the unselected `$10D1..$116F` tail and the two 48-byte ranges `$0ED0..$0EFF`/`$0FD0..$0FFF`, inside the same payload. The loader retains indices 0..206 and original fallback 207; higher indices are clamped to 207 before lookup. The 46 sprite records remain 3,220 bytes; the 364 bytes between `$0C94` and `$0E00` remain separate.

## Material-payload suballocations

| Range, end exclusive | Bytes | Ownership |
| --- | ---: | --- |
| `$0E00..$0ED0` | 208 | 208 live low-byte lookup entries |
| `$0ED0..$0F00` | 48 | Immutable low-lookup recipe pool |
| `$0F00..$0FD0` | 208 | 208 live high-byte lookup entries |
| `$0FD0..$1000` | 48 | Immutable high-lookup recipe pool |
| `$1000..$10C0` | 192 | 24 live bindings |
| `$10C0..$10D0` | 16 | Cache keys |
| `$10D0..$10D1` | 1 | Borrowed-column owner |
| `$10D1..$1170` | 159 | Immutable binding-tail recipe pool |
| `$1170..$1188` | 24 | Column directories |
| `$1188..$2000` | 3704 | High recipe pool |

## Third column and cache ownership

Original width flag `$39` applies to every actor, not only the protagonist. Wide characters use their two body channels plus a reserved borrowed channel: physical column 2 on the right or 3 on the left. Material directories follow actual spatial order rather than assuming a contiguous third column. The same eight slots and existing records are reused. The key cache remains at `$10C0..$10CF`; owner byte `$10D0` uses unselected tail space inside the already reserved bindings. Ownership changes force borrowed bindings to refresh. No RAM is added.

The correction is checked against complete original 72×63 data, both orientations and sequences that change borrowed-column ownership. Static material comparisons do not replace CPU/topology checks.

## Colours and compatibility

The cowl uses the robe’s soft material while preserving hue and black outlines. Candidate024 retains the qualified023 CPU image exactly: only materials and cold transport change. Revision9 CPU tests are reused through this explicit identity, not through older018/019/022 candidates. Yellow pig facial details use profile 3 with original hue and luminance 6/7, separately from the gold shirt’s profile 7 anchored to 112 (levels 5..7). A dedicated profile-2 white-head region uses luminance 5..7 for volume; white hands, feet and details outside the head retain gentle profile 3 at 6/7. Separating the head changes the remaining profile-3 row spans: some pig whites outside the ROI can move between 91 and 106 (258 pixels across 52 combinatorial cases), with a maximum one-luminance difference. This redistribution does not change other inks, black outlines or unrelated characters. The red spray uses profile 7 base 62 on 17 already opaque pixel pairs: 13 guarded literal bytes in its unique RLE record change source index 3 to 2. No RLE count byte, pose pointer, facial outline or transparent pixel changes. All other compressed asset bytes remain exact; original D/F banks and fonts remain entirely unchanged. Approved protagonist and farmer recipes, including yellow hat 112, remain protected. Original alpha and source masks remain the references.

The generic renderer is unchanged: material format version 3, snapshot 82=3, profiles 0..7. Snapshot payload remains 144,776 bytes. Existing SDK/snapshot tests remain bound only to that same verified executable, and are not described as fresh builds. New game tests and their hashes are separate.

## Main-RAM components

| Component | Start | End exclusive | Bytes |
| --- | --- | --- | ---: |
| `ui_marks` | `$0A00` | `$0AAB` | 171 |
| `ui_data` | `$0B40` | `$0B80` | 64 |
| `bridge_stub` | `$0B80` | `$0BD5` | 85 |
| `ui_rows` | `$0C00` | `$0C89` | 137 |
| `material_finish` | `$0C90` | `$0D7F` | 239 |
| `bridge` | `$2800` | `$2A4E` | 590 |
| `video` | `$2A80` | `$2CA5` | 549 |
| `material_entries` | `$2CB0` | `$2CFD` | 77 |
| `timers` | `$2D00` | `$2EA6` | 422 |
| `material_cache` | `$2EA8` | `$2EFE` | 86 |
| `input` | `$2F00` | `$2FBA` | 186 |
| `direct_colour` | `$40B4` | `$41CA` | 278 |
| `direct_column` | `$43F1` | `$444A` | 89 |
| `memory` | `$DC00` | `$DD8F` | 399 |
| `menu` | `$DD90` | `$DE1F` | 143 |
| `keyboard` | `$DE40` | `$DEEC` | 172 |
| `bootstrap` | `$DF00` | `$DF40` | 64 |
| `material_record` | `$DF40` | `$DFFC` | 188 |
| `sprites` | `$F800` | `$FCCF` | 1231 |

Components changed from 022: `material_entries`, `material_record`, `material_finish`, `material_cache`.

Proofs distinguish ordinary disk cold boot, controlled captures and diagnostic seeded fixtures. State seeded to select an NPC type is neither a natural playthrough nor a trainer in the distributed disk. Wine, native Windows and physical hardware remain separate scopes; no complete campaign or hardware qualification is claimed.
