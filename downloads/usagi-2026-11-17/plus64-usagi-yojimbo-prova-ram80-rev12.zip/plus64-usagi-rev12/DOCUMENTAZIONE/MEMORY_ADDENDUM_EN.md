# Usagi revision 12 — memory map

Candidate `link-006` / `boot-006`. Requires the matching scenery20 runtime.

RAM remains **65,536 + 16,384 = 81,920 bytes**, without extra pools. The222
sky bytes reuse retired main-RAM padding. The bootstrap remains62 bytes:
5,170 -2 +222 = **5,390 bytes** in **38 components**, including nodes,
tables and initialization. No additional per-frame routine is introduced.

| Shared internal RAM | Bytes |
| --- | ---: |
| 46 dense sprite records | 3,220 |
| Unassigned | 364 |
| Recipes, lookup, bindings and directories | 4,608 |
| Original D/F asset banks | 8,192 |

Character materials are identical to revision9:4,602 bytes used and6 spare.
Fonts, original assets and the thirteen guarded spray-colour fixes are
retained. All nineteen base CPU components are identical to revision10;
the new scenery20 renderer has its own tests.

The sky uses14 of32 nodes: twelve ellipses, one palette ramp and one
conditional link. Byte `$0E64=1` enables the list during play;16-byte
initialization sets `$FD9D/$FD9E` and `$FD9F=$11`. The222 bytes comprise
12×12 ellipse bytes,24 cloud-table bytes,16 ramp-node bytes,10 palette
bytes,12 conditional-link bytes and16 initialization bytes. Clouds precede
the ramp, whose key `$56` and mask `$7F` affect Y16..87 and hold the final
colour through111.

| Band from top | Compact colour | Hue | Luminance |
| --- | ---: | ---: | ---: |
| 1 | 36 | 6 | 2 |
| 2 | 51 | 6 | 3 |
| 3 | 66 | 6 | 4 |
| 4 | 81 | 6 | 5 |
| 5 | 96 | 6 | 6 |
| 6 | 111 | 6 | 7 |
| 7 | 107 | 2 | 7 |
| 8 | 92 | 2 | 6 |
| 9 | 77 | 2 | 5 |
| 10 | 62 | 2 | 4 |

| Component | Main-RAM range | Bytes |
| --- | --- | ---: |
| `ui_marks` | `$0A00..$0AAA` | 171 |
| `ui_data` | `$0B40..$0B7F` | 64 |
| `bridge_stub` | `$0B80..$0BD4` | 85 |
| `sky_07` | `$0BD5..$0BE0` | 12 |
| `sky_08` | `$0BE1..$0BEC` | 12 |
| `sky_09` | `$0BED..$0BF8` | 12 |
| `ui_rows` | `$0C00..$0C88` | 137 |
| `material_finish` | `$0C90..$0D7E` | 239 |
| `bridge` | `$2800..$2A4D` | 590 |
| `sky_18` | `$2A50..$2A5F` | 16 |
| `sky_01` | `$2A60..$2A6F` | 16 |
| `sky_03` | `$2A70..$2A7B` | 12 |
| `video` | `$2A80..$2CA4` | 549 |
| `material_entries` | `$2CB0..$2CFC` | 77 |
| `timers` | `$2D00..$2EA5` | 422 |
| `material_cache` | `$2EA8..$2EFD` | 86 |
| `input` | `$2F00..$2FB9` | 186 |
| `sky_14` | `$2FBA..$2FC5` | 12 |
| `sky_15` | `$2FC6..$2FD1` | 12 |
| `sky_16` | `$2FD2..$2FDD` | 12 |
| `sky_17` | `$2FDE..$2FE9` | 12 |
| `direct_colour` | `$40B4..$41C9` | 278 |
| `direct_column` | `$43F1..$4449` | 89 |
| `memory` | `$DC00..$DD8E` | 399 |
| `menu` | `$DD90..$DE1E` | 143 |
| `sky_04` | `$DE1F..$DE26` | 8 |
| `sky_05` | `$DE27..$DE32` | 12 |
| `sky_06` | `$DE33..$DE3A` | 8 |
| `keyboard` | `$DE40..$DEEB` | 172 |
| `sky_00` | `$DEEC..$DEF5` | 10 |
| `sky_02` | `$DEF6..$DEFD` | 8 |
| `bootstrap` | `$DF00..$DF3D` | 62 |
| `material_record` | `$DF40..$DFFB` | 188 |
| `sprites` | `$F800..$FCCE` | 1231 |
| `sky_10` | `$FCCF..$FCDA` | 12 |
| `sky_11` | `$FCDB..$FCE6` | 12 |
| `sky_12` | `$FCE7..$FCF2` | 12 |
| `sky_13` | `$FCF3..$FCFE` | 12 |

Node9 requires scenery20; profiles through19 ignore it. Ellipses19,
snapshot module1.0,144,776-byte payload, RAM protocol05 and dense
capabilities80/81/82 are unchanged. The addenda's generic sixteen-colour
example is distinct from the final ten-colour game palette.

`--actor-shading materials --sky clouds` rebuilds this presentation;
`--actor-shading materials --sky flat` exactly rebuilds the seven revision9
game artifacts. CPU, C, cold-boot and Wine tests retain separate scopes,
without physical-hardware or completed-campaign qualification.
