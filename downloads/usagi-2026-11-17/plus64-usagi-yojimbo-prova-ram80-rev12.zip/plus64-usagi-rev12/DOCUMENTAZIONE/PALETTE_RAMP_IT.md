# plus/64 — rampa verticale di palette con chiave nativa

La revisione scenari **20** aggiunge il nodo **9** da **16 byte**: una
palette fornita dal programma viene campionata lungo un intervallo verticale
espresso in pixel locali. Il rettangolo esterno conserva le coordinate in
celle da 8 pixel. Una rampa può quindi contenere fasce più sottili di una
cella senza aggiungere un nodo per ogni fascia.

Le costanti SDK sono `P64_NODE_PALETTE_RAMP=9`,
`P64_SCENERY_PALETTE_RAMP_VERSION=20` e `P64_RAMP_HOLD_BOTTOM=1`.
La capacità scenari rimane al byte HOST snapshot 79: non è un registro
6502 e il protocollo RAM `$05` non dimostra il supporto del nuovo nodo.

## Descrittore

| Offset | Byte | Significato |
| --- | ---: | --- |
| 0–1 | 2 | Puntatore LE16 al nodo successivo, zero termina la lista |
| 2–5 | 4 | x, y, larghezza, altezza in celle da 8 pixel |
| 6–7 | 2 | Puntatore LE16 alla palette nella RAM principale |
| 8 | 1 | Numero di colori, 1..32 |
| 9 | 1 | Chiave del colore TED nativo, 0..127 |
| 10 | 1 | Maschera della chiave TED, 0..127 |
| 11 | 1 | Tipo del nodo: 9 |
| 12 | 1 | Inizio della rampa, Y locale in pixel |
| 13 | 1 | Altezza della rampa in pixel, non nulla |
| 14 | 1 | Bit 0: mantieni l'ultimo colore dopo la rampa; altri bit zero |
| 15 | 1 | Riservato, deve essere zero |

Rettangolo e rampa devono rientrare nel canvas 320×200 e nel rettangolo
del nodo: `inizio + altezza_rampa <= altezza_rettangolo`. L'intera palette
deve rientrare nella RAM principale: `puntatore + numero_colori <= 65536`.
Anche tutti i 16 byte del nodo devono rientrare nella RAM principale.
Il puntatore palette `$0000` è valido; non significa disabilitato. Restano
32 nodi al massimo per lista, senza un buffer di texture separato.

Con `locale = y - y_rettangolo`, prima dell'inizio il nodo conserva i pixel.
Durante la rampa sceglie:

```text
indice = floor((locale - inizio) * numero_colori / altezza_rampa)
```

All'estremo inferiore escluso, `locale >= inizio + altezza_rampa`, il bit 0
del byte 14 sceglie fra mantenere l'ultimo colore e conservare i pixel
nativi. La palette contiene colori **compatti 0..120**, non codici TED:
0 produce nero; 255 conserva la riga. Anche una voce selezionata 121..254
conserva la riga, senza impedire l'uso delle altre voci valide. Chiave o
maschera oltre 127, flag riservati, byte 15 nonzero o geometria non valida
fanno ignorare il nodo.

Il byte 10 è una maschera, non il byte di stile dei tipi 5/7: non applicare
qui il bit ellisse o i flag dell'illuminazione.

## Filtro e ordine

Un pixel viene sostituito soltanto se
`(pixel_nativo & maschera) == (chiave & maschera)`. Il nero non ha un'esclusione
speciale: un programma può selezionarlo intenzionalmente con la chiave.
Per modificare soltanto il cielo `$56`, usare chiave `$56` e maschera `$7F`;
il nero e il blu locale `$36` non corrispondono. Una maschera zero seleziona
invece tutti i pixel del rettangolo: la scelta appartiene al programma.

La rampa agisce nel passaggio dei livelli, prima di scena e sprite; non
scrive RAM, non cambia sagome sprite e non modifica collisioni. Si applicano
le regole esistenti di proprietà condizionale e protezione UI nativa. Il
filtro usa il colore del pixel corrente nel passaggio: un livello precedente
può averlo già cambiato. Ordine della lista e palette restano responsabilità
del programma. Il renderer non riconosce cielo, nuvole o un gioco specifico.

## Esempio: sedici fasce in 72 pixel

```asm
sky_ramp:
    .word 0
    .byte 0,2,40,12         ; y16..111, larghezza320
    .word sky_palette
    .byte 16,$56,$7f,9     ;16 colori; seleziona solo TED56
    .byte 0,72,1,0         ;rampa y16..87, ultimo colore fino a111
sky_palette:
    .byte 6,21,36,51,66,81,96,111
    .byte 107,92,77,62,47,32,17,2
```

Le prime otto voci sono blu a luminanza 0..7; le successive rosso a luminanza
7..0. Le sedici fasce si alternano fra 5 e 4 pixel nell'intervallo globale
Y=16..87. Il tratto Y=88..111 mantiene il rosso scuro finale. Questa rampa
non tocca Y=0..15; eventuali altri nodi della lista hanno i propri limiti.
Nell'integrazione Usagi, le nuvole ellittiche approvate precedono la rampa
e non corrispondono più alla chiave del cielo, quindi conservano i loro colori.
La presenza effettiva di ogni colore dipende dai pixel che corrispondono
alla chiave e da quelli coperti dagli altri elementi della scena.

## Compatibilità e memoria

Usare il nuovo eseguibile corrispondente con scenari 20. I profili precedenti
supportati, fino a 19, ignorano il nodo 9 e proseguono con il successivo.
Il significato di tutti i nodi precedenti resta invariato: le ellissi dei
tipi 5/7 continuano a richiedere almeno 19, mentre i profili fino a 18 ne
ignorano il bit di forma. Un lettore che supporta al massimo 19 rifiuta uno
snapshot 20 prima del ripristino.

Non cambiano protocollo RAM `$05`, modulo PLUS64 1.0, payload da 144.776
byte, capacità dense 80/81/82 o totale **65.536 + 16.384 = 81.920 byte**.
Nodo e palette occupano RAM del programma già riservata; non vengono
aggiunti registri, slot sprite o pool indirizzabili dalla CPU. Questa API
software e le relative prove non qualificano una cartuccia fisica.
