# plus/64 — keyed vertical palette ramp

Scenery revision **20** adds **16-byte node 9**: a software-owned palette
is sampled over an explicit vertical interval in local pixels. Its outer
rectangle retains 8-pixel-cell coordinates. A ramp can therefore contain
bands thinner than a cell without allocating one node per band.

SDK constants are `P64_NODE_PALETTE_RAMP=9`,
`P64_SCENERY_PALETTE_RAMP_VERSION=20` and `P64_RAMP_HOLD_BOTTOM=1`.
The scenery capability remains HOST snapshot byte 79; it is not a 6502
register, and RAM protocol `$05` does not establish support for this node.

## Descriptor

| Offset | Bytes | Meaning |
| --- | ---: | --- |
| 0–1 | 2 | Next-node LE16 pointer; zero ends the list |
| 2–5 | 4 | x, y, width, height in 8-pixel cells |
| 6–7 | 2 | Palette LE16 pointer in main RAM |
| 8 | 1 | Colour count, 1..32 |
| 9 | 1 | Native TED colour key, 0..127 |
| 10 | 1 | TED key mask, 0..127 |
| 11 | 1 | Node type: 9 |
| 12 | 1 | Ramp start in local pixel Y |
| 13 | 1 | Nonzero ramp height in pixels |
| 14 | 1 | Bit 0: hold final colour below ramp; all other bits zero |
| 15 | 1 | Reserved; must be zero |

Rectangle and ramp must fit the 320×200 canvas and node bounds:
`start + span <= rectangle_height`. The complete palette must fit main RAM:
`pointer + count <= 65536`. Palette pointer `$0000` is valid and does not
mean disabled. The list remains limited to 32 nodes, without a separate
texture buffer.
All16 bytes of the node must also fit main RAM.

For `local = y - rectangle_y`, rows before the start are preserved. During
the ramp, the selected entry is:

```text
index = floor((local - start) * count / span)
```

At the excluded bottom endpoint, `local >= start + span`, byte14 bit0
chooses between holding the final colour and preserving native pixels.
The palette contains **compact colours 0..120**, not TED codes: 0 paints
black; 255 preserves the row. A selected entry121..254 also preserves that
row, without preventing other valid entries from being used. A key or
mask above127, reserved flags, nonzero byte15 or invalid geometry causes
the node to be ignored.

Byte10 is a mask, not the style byte used by types5/7: do not apply ellipse
or lighting-style flags to that field.

## Filtering and order

A pixel is replaced only if
`(native_pixel & mask) == (key & mask)`. Black has no special exclusion;
software can deliberately select it with the key. To change only sky `$56`,
use key `$56` and mask `$7F`; black and local blue `$36` do not match.
A zero mask instead selects every pixel in the rectangle; this is a
software choice.

The ramp runs in the layer pass before scenery and sprites. It does not
write RAM or alter sprite shapes or collisions. Existing conditional
ownership and native-UI protection still apply. Filtering uses the current
pixel in this pass, which may already have been changed by an earlier
node. List order and palette remain software responsibilities. The renderer
contains no sky, cloud or game recognition.

## Example: sixteen bands over 72 pixels

```asm
sky_ramp:
    .word 0
    .byte 0,2,40,12         ;y16..111, width320
    .word sky_palette
    .byte 16,$56,$7f,9     ;16 colours; select only TED56
    .byte 0,72,1,0         ;ramp y16..87, hold final colour through111
sky_palette:
    .byte 6,21,36,51,66,81,96,111
    .byte 107,92,77,62,47,32,17,2
```

The first eight entries are blue at luminances0..7; the following entries
are red at7..0. Sixteen bands alternate between5 and4 pixels over global
Y=16..87. Y=88..111 holds the final dark red. This ramp does not affect
Y=0..15; other nodes in the list retain their own bounds. In the Usagi
integration, approved elliptical clouds precede the ramp and no longer
match the sky key, retaining their colours.
Actual colour visibility depends on matching source pixels and occlusion
by other scene elements.

## Compatibility and memory

Use the matching new executable with scenery20. Supported earlier profiles
through19 ignore node9 and continue at its next pointer. All previous
node meanings are retained: type5/7 ellipses still require at least19,
while profiles through18 ignore their shape bit. A reader supporting at
most19 rejects a version20 snapshot before restoring it.

RAM protocol `$05`, PLUS64 module1.0, the144,776-byte payload, dense
capabilities80/81/82 and total **65,536 + 16,384 = 81,920 bytes** remain
unchanged. Node and palette occupy already reserved guest RAM; no registers,
sprite slots or CPU-addressable pools are added. This software API and
its tests do not qualify a physical cartridge.
