# Usagi revisione 12 — mappa della memoria

Candidato `link-006` / `boot-006`. Richiede il runtime scenari20 corrispondente.

La RAM resta **65.536 + 16.384 = 81.920 byte**, senza pool aggiuntivi.
I 222 byte del cielo riusano padding principale già ritirato. Il bootstrap
rimane di 62 byte: 5.170 - 2 + 222 = **5.390 byte** in **38 componenti**,
compresi nodi, tavole e inizializzazione. Nessuna nuova routine per fotogramma.

| RAM interna condivisa | Byte |
| --- | ---: |
| 46 record sprite densi | 3.220 |
| Non assegnati | 364 |
| Ricette, lookup, collegamenti e directory | 4.608 |
| Banchi originali D/F | 8.192 |

Materiali dei personaggi identici alla revisione9: 4.602 byte usati e 6
liberi. Font, asset originali e tredici correzioni protette dello spruzzo
restano quelli approvati. Tutti i diciannove componenti CPU di base sono
identici alla revisione10; il nuovo renderer scenari20 ha prove proprie.

Il cielo usa 14 nodi su un massimo di32: dodici ellissi, una rampa di
palette e un collegamento condizionale. Il byte `$0E64=1` abilita la lista
nel gioco; l'inizializzazione da16byte imposta `$FD9D/$FD9E` e `$FD9F=$11`.
I 222 byte comprendono12×12byte di ellissi,24byte di tavole delle nuvole,
16byte del nodo rampa,10byte della palette,12byte del collegamento e16
dell'inizializzazione. Le nuvole precedono la rampa con chiave `$56` e
maschera `$7F`, che agisce da Y16 a87 e mantiene l'ultimo colore fino a111.

| Fascia dall'alto | Colore compatto | Tinta | Luminanza |
| --- | ---: | ---: | ---: |
| 1 | 36 | 6 | 2 |
| 2 | 51 | 6 | 3 |
| 3 | 66 | 6 | 4 |
| 4 | 81 | 6 | 5 |
| 5 | 96 | 6 | 6 |
| 6 | 111 | 6 | 7 |
| 7 | 107 | 2 | 7 |
| 8 | 92 | 2 | 6 |
| 9 | 77 | 2 | 5 |
| 10 | 62 | 2 | 4 |

| Componente | Intervallo principale | Byte |
| --- | --- | ---: |
| `ui_marks` | `$0A00..$0AAA` | 171 |
| `ui_data` | `$0B40..$0B7F` | 64 |
| `bridge_stub` | `$0B80..$0BD4` | 85 |
| `sky_07` | `$0BD5..$0BE0` | 12 |
| `sky_08` | `$0BE1..$0BEC` | 12 |
| `sky_09` | `$0BED..$0BF8` | 12 |
| `ui_rows` | `$0C00..$0C88` | 137 |
| `material_finish` | `$0C90..$0D7E` | 239 |
| `bridge` | `$2800..$2A4D` | 590 |
| `sky_18` | `$2A50..$2A5F` | 16 |
| `sky_01` | `$2A60..$2A6F` | 16 |
| `sky_03` | `$2A70..$2A7B` | 12 |
| `video` | `$2A80..$2CA4` | 549 |
| `material_entries` | `$2CB0..$2CFC` | 77 |
| `timers` | `$2D00..$2EA5` | 422 |
| `material_cache` | `$2EA8..$2EFD` | 86 |
| `input` | `$2F00..$2FB9` | 186 |
| `sky_14` | `$2FBA..$2FC5` | 12 |
| `sky_15` | `$2FC6..$2FD1` | 12 |
| `sky_16` | `$2FD2..$2FDD` | 12 |
| `sky_17` | `$2FDE..$2FE9` | 12 |
| `direct_colour` | `$40B4..$41C9` | 278 |
| `direct_column` | `$43F1..$4449` | 89 |
| `memory` | `$DC00..$DD8E` | 399 |
| `menu` | `$DD90..$DE1E` | 143 |
| `sky_04` | `$DE1F..$DE26` | 8 |
| `sky_05` | `$DE27..$DE32` | 12 |
| `sky_06` | `$DE33..$DE3A` | 8 |
| `keyboard` | `$DE40..$DEEB` | 172 |
| `sky_00` | `$DEEC..$DEF5` | 10 |
| `sky_02` | `$DEF6..$DEFD` | 8 |
| `bootstrap` | `$DF00..$DF3D` | 62 |
| `material_record` | `$DF40..$DFFB` | 188 |
| `sprites` | `$F800..$FCCE` | 1231 |
| `sky_10` | `$FCCF..$FCDA` | 12 |
| `sky_11` | `$FCDB..$FCE6` | 12 |
| `sky_12` | `$FCE7..$FCF2` | 12 |
| `sky_13` | `$FCF3..$FCFE` | 12 |

Il nuovo nodo9 richiede scenari20; i profili fino a19 lo ignorano. Ellissi19,
modulo snapshot1.0, payload144.776byte, protocolloRAM05 e capacità dense
80/81/82 restano invariati. L'esempio generico a sedici colori degli
addenda non è la palette finale del gioco, che contiene dieci colori.

`--actor-shading materials --sky clouds` ricostruisce la versione corrente;
`--actor-shading materials --sky flat` ricostruisce esattamente i sette
artefatti di gioco della revisione9. Prove CPU, C, avvii e Wine mantengono
ambiti separati, senza qualifica di hardware fisico o campagna completa.
