# Usagi Yojimbo — preview18: ears and face

Start AVVIA_USAGI.cmd or AVVIA_USAGI_PLUS4.cmd. Arrow keys and Space; use F1 in the menu to select GAME instead of PRACTICE. The emulator executable is unchanged from rev17.

Rev18: the two newly added pixels on each ear top change exactly from luminance6/colour91 to luminance5/colour76; everything else is identical to rev17. Previous retouches: the artificial vertical grey face edge is removed, leaving the right side white. Each top ear row ends in two light-grey pixels, with two dark-grey bridge pixels on the left ear. Original blue shading inside the ears becomes dark grey. Right-hand light leaves the right side white and adds two grey levels along the left sides; three cells outside the right-ear outline remain blue. The face has a rounded volume with right-hand light: a shaded left cheek and bright right side, preserving the original eyes and mouth. Approved scenery and gameplay characters are preserved. Total memory:65536+16384=81920bytes;108bytes of portrait metadata occupy existing internal RAM. No new emulator code.

This is an artwork preview. Fresh C16/Plus4 cold boots and graphics comparisons are recorded in PROVE. SDK, Wine and a full campaign were not rerun. Executable acfd198538d4a112389081807e636a5db253ed4531173e89978c755194eb89a9 is the already-tested rev15 executable. No native-Windows or physical-hardware test is claimed.

Rebuild using the bundled source and user-provided original D64: python3 tools-game/usagi-port/link.py --input INPUT.d64 --out link --actor-shading materials --sky clouds --portrait-shading face; then python3 tools-game/usagi-port/boot.py --link link --out boot --low-restore. Historical source reports remain evidence for their own candidates.

The original game, artwork and music retain their authors' credits and rights. VICE and plus64 changes include GPL source and licenses. Shading uses profile7 with neutral bases76/106/91 and soft relief; profile7 now produces exactly colour76 at the four top pixels. The right face uses original white, without an artificial frontal-profile edge.
