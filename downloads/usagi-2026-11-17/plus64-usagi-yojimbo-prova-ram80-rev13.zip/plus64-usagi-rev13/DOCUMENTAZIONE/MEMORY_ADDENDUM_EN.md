# Usagi revision13 — memory map

Candidate `link-007` / `boot-007`; scenery20 runtime unchanged from revision12.

RAM remains **65,536 +16,384 =81,920 bytes**, without extra pools. Scene
data grow from222 to242 bytes: an additional16-byte node9 and4-byte green
palette reuse existing padding. The bootstrap remains62bytes:
5,170 -2 +242 = **5,410 bytes** in **40 components**, including data and
tables. No per-frame CPU routine is added.

| Shared internal RAM | Bytes |
| --- | ---: |
| 46 dense sprite records | 3,220 |
| Unassigned | 364 |
| Recipes, lookup, bindings and directories | 4,608 |
| Original D/F asset banks | 8,192 |

Character materials remain identical to revision9:4,602bytes used and6
spare. All nineteen base CPU components, fonts, banked assets and thirteen
guarded spray-colour fixes are identical to revision12. Only scene data
and initialization operands in padding change. Core, formats, SDK and
binaries are not modified or rebuilt.

The scene uses15 of32nodes: twelve ellipses, two palette ramps and one
conditional link. Byte `$0E64=1` enables the list during play;16-byte
initialization sets `$FD9D/$FD9E` and `$FD9F=$11`. The242bytes comprise
12×12ellipse bytes,24cloud-table bytes, two16-byte ramp nodes,10sky palette
bytes,4green palette bytes,12conditional-link bytes and16initialization bytes.

Sky palette `[36,51,66,81,96,111,107,92,77,62]` and geometry are retained
from revision12. The right cloud moves down16pixels; the other eight
ellipses are unchanged. Green uses native key `$55`, mask `$7F`, Y104..183
and palette `[35,50,65,80]`:20-pixel bands at luminances2,3,4,5. Matching
native foliage and textures intentionally share the ambient depth shading.
Sprites are composited afterwards; the node ends before the lower UI atY184.

| Component | Main-RAM range | Bytes |
| --- | --- | ---: |
| `ui_marks` | `$0A00..$0AAA` | 171 |
| `sky_19` | `$0AAB..$0AB6` | 12 |
| `ui_data` | `$0B40..$0B7F` | 64 |
| `bridge_stub` | `$0B80..$0BD4` | 85 |
| `sky_07` | `$0BD5..$0BE0` | 12 |
| `sky_08` | `$0BE1..$0BE8` | 8 |
| `sky_09` | `$0BE9..$0BF4` | 12 |
| `ui_rows` | `$0C00..$0C88` | 137 |
| `material_finish` | `$0C90..$0D7E` | 239 |
| `bridge` | `$2800..$2A4D` | 590 |
| `sky_20` | `$2A50..$2A5F` | 16 |
| `sky_02` | `$2A60..$2A69` | 10 |
| `sky_03` | `$2A6A..$2A79` | 16 |
| `video` | `$2A80..$2CA4` | 549 |
| `material_entries` | `$2CB0..$2CFC` | 77 |
| `timers` | `$2D00..$2EA5` | 422 |
| `material_cache` | `$2EA8..$2EFD` | 86 |
| `input` | `$2F00..$2FB9` | 186 |
| `sky_14` | `$2FBA..$2FC5` | 12 |
| `sky_15` | `$2FC6..$2FD1` | 12 |
| `sky_16` | `$2FD2..$2FDD` | 12 |
| `sky_17` | `$2FDE..$2FE9` | 12 |
| `sky_18` | `$2FEA..$2FF5` | 12 |
| `direct_colour` | `$40B4..$41C9` | 278 |
| `direct_column` | `$43F1..$4449` | 89 |
| `memory` | `$DC00..$DD8E` | 399 |
| `menu` | `$DD90..$DE1E` | 143 |
| `sky_04` | `$DE1F..$DE26` | 8 |
| `sky_05` | `$DE27..$DE32` | 12 |
| `sky_06` | `$DE33..$DE3A` | 8 |
| `keyboard` | `$DE40..$DEEB` | 172 |
| `sky_00` | `$DEEC..$DEEF` | 4 |
| `sky_01` | `$DEF0..$DEFF` | 16 |
| `bootstrap` | `$DF00..$DF3D` | 62 |
| `material_record` | `$DF40..$DFFB` | 188 |
| `sprites` | `$F800..$FCCE` | 1231 |
| `sky_10` | `$FCCF..$FCDA` | 12 |
| `sky_11` | `$FCDB..$FCE6` | 12 |
| `sky_12` | `$FCE7..$FCF2` | 12 |
| `sky_13` | `$FCF3..$FCFE` | 12 |

`--actor-shading materials --sky clouds` rebuilds this presentation;
`--actor-shading materials --sky flat` exactly rebuilds the seven revision9
artifacts. API20 and its generic sixteen-colour addendum example are
unchanged; the game uses ten sky colours. C, CPU, cold-boot and Wine checks
retain separate scopes.
