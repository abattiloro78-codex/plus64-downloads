# Usagi revisione13 — mappa della memoria

Candidato `link-007` / `boot-007`, runtime scenari20 invariato dalla revisione12.

La RAM resta **65.536 +16.384 =81.920 byte**, senza pool aggiuntivi.
I dati di scena passano da222 a242 byte: un nodo9 da16byte e una palette
verde da4byte riusano il padding esistente. Il bootstrap rimane62byte:
5.170 -2 +242 = **5.410 byte** in **40 componenti**, compresi dati e tavole.
Nessuna nuova routine CPU per fotogramma.

| RAM interna condivisa | Byte |
| --- | ---: |
| 46 record sprite densi | 3.220 |
| Non assegnati | 364 |
| Ricette, lookup, collegamenti e directory | 4.608 |
| Banchi originali D/F | 8.192 |

Materiali dei personaggi identici alla revisione9:4.602byte usati e6 liberi.
I diciannove componenti CPU di base, i font, gli asset bancati e le tredici
correzioni protette dello spruzzo sono identici alla revisione12. Cambiano
soltanto dati di scena e operandi dell'inizializzazione nel padding.
Core, formati, SDK e binari non vengono modificati o ricompilati.

La scena usa15 nodi su32: dodici ellissi, due rampe di palette e un
collegamento condizionale. Il byte `$0E64=1` abilita la lista nel gioco;
l'inizializzazione da16byte imposta `$FD9D/$FD9E` e `$FD9F=$11`.
I242byte comprendono12×12byte di ellissi,24byte di tavole delle nuvole,
due nodi rampa da16byte,10byte per il cielo,4byte per il verde,12byte
del collegamento e16dell'inizializzazione.

Il cielo conserva palette `[36,51,66,81,96,111,107,92,77,62]` e geometria
della revisione12. La nuvola destra scende di16pixel, le altre otto ellissi
restano invariate. Il verde usa chiaveTED `$55`, maschera `$7F`, rettangolo
Y104..183 e palette `[35,50,65,80]`: fasce da20pixel con luminanze2,3,4,5.
Vegetazione e texture native corrispondenti sono intenzionalmente incluse
nella profondità d'ambiente. Gli sprite vengono composti dopo; il nodo
termina prima della UI inferiore aY184.

| Componente | Intervallo principale | Byte |
| --- | --- | ---: |
| `ui_marks` | `$0A00..$0AAA` | 171 |
| `sky_19` | `$0AAB..$0AB6` | 12 |
| `ui_data` | `$0B40..$0B7F` | 64 |
| `bridge_stub` | `$0B80..$0BD4` | 85 |
| `sky_07` | `$0BD5..$0BE0` | 12 |
| `sky_08` | `$0BE1..$0BE8` | 8 |
| `sky_09` | `$0BE9..$0BF4` | 12 |
| `ui_rows` | `$0C00..$0C88` | 137 |
| `material_finish` | `$0C90..$0D7E` | 239 |
| `bridge` | `$2800..$2A4D` | 590 |
| `sky_20` | `$2A50..$2A5F` | 16 |
| `sky_02` | `$2A60..$2A69` | 10 |
| `sky_03` | `$2A6A..$2A79` | 16 |
| `video` | `$2A80..$2CA4` | 549 |
| `material_entries` | `$2CB0..$2CFC` | 77 |
| `timers` | `$2D00..$2EA5` | 422 |
| `material_cache` | `$2EA8..$2EFD` | 86 |
| `input` | `$2F00..$2FB9` | 186 |
| `sky_14` | `$2FBA..$2FC5` | 12 |
| `sky_15` | `$2FC6..$2FD1` | 12 |
| `sky_16` | `$2FD2..$2FDD` | 12 |
| `sky_17` | `$2FDE..$2FE9` | 12 |
| `sky_18` | `$2FEA..$2FF5` | 12 |
| `direct_colour` | `$40B4..$41C9` | 278 |
| `direct_column` | `$43F1..$4449` | 89 |
| `memory` | `$DC00..$DD8E` | 399 |
| `menu` | `$DD90..$DE1E` | 143 |
| `sky_04` | `$DE1F..$DE26` | 8 |
| `sky_05` | `$DE27..$DE32` | 12 |
| `sky_06` | `$DE33..$DE3A` | 8 |
| `keyboard` | `$DE40..$DEEB` | 172 |
| `sky_00` | `$DEEC..$DEEF` | 4 |
| `sky_01` | `$DEF0..$DEFF` | 16 |
| `bootstrap` | `$DF00..$DF3D` | 62 |
| `material_record` | `$DF40..$DFFB` | 188 |
| `sprites` | `$F800..$FCCE` | 1231 |
| `sky_10` | `$FCCF..$FCDA` | 12 |
| `sky_11` | `$FCDB..$FCE6` | 12 |
| `sky_12` | `$FCE7..$FCF2` | 12 |
| `sky_13` | `$FCF3..$FCFE` | 12 |

`--actor-shading materials --sky clouds` ricostruisce la versione corrente;
`--actor-shading materials --sky flat` ricostruisce esattamente i sette
artefatti della revisione9. L'API20 e l'esempio generico a sedici colori
degli addenda restano invariati; il gioco usa dieci colori del cielo.
Prove C, CPU, avvii e Wine conservano ambiti separati.
