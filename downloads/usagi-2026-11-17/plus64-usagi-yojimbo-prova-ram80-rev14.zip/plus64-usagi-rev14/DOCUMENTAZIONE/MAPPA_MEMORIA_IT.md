# Usagi revisione14 — mappa della memoria

Candidato `link-008` / `boot-008`, stesso runtime scenari20 delle revisioni12/13.

La RAM resta **65.536 +16.384 =81.920 byte**, senza pool aggiuntivi. Scena
e inizializzazione passano da242 a260 byte: una rampa da16byte in più e
due byte aggiuntivi di palette. Il bootstrap resta62byte:5.170 -2 +260 =
**5.428 byte** in **41 componenti**, compresi nodi e tavole. Nessuna nuova
routine CPU per fotogramma.

| RAM interna condivisa | Byte |
| --- | ---: |
| 46 record sprite densi | 3.220 |
| Non assegnati | 364 |
| Ricette, lookup, collegamenti e directory | 4.608 |
| Banchi originali D/F | 8.192 |

Materiali dei personaggi invariati:4.602byte usati e6 liberi nei4.608.
I diciannove componenti CPU di base, font, asset bancati e tredici correzioni
protette dello spruzzo restano identici alla revisione13. Cambiano dati di
scena e operandi dell'inizializzazione nel padding. Core, API, SDK e binari
restano invariati, senza nuovi build o collaudi SDK.

La scena usa16 nodi su32: dodici ellissi, tre rampe e un collegamento
condizionale. Il byte `$0E64=1` abilita la lista;16byte d'inizializzazione
impostano `$FD9D/$FD9E` e `$FD9F=$11`. I260byte comprendono144byte di
ellissi,24di tavole nuvole,48di nodi rampa,10di palette cielo,6di palette
verde condivisa,12del collegamento e16dell'inizializzazione.

La zona verde lontana Y104..135 usa35, la vicina Y136..183 usa
`[57,50,65,75,80]` in cinque fasce da10,10,9,10,9pixel. Sei toni complessivi
usano quattro luminanze2..5:35 e80 conservano gli estremi precedenti,
57 e75 aggiungono tinte verdi intermedie. ChiaveTED `$55` e maschera `$7F`
includono intenzionalmente vegetazione e texture corrispondenti. Sprite
composti dopo e UI inferiore daY184 restano esclusi.

| Tono verde | Colore compatto | Tinta | Luminanza |
| --- | ---: | ---: | ---: |
| 1 | 35 | 5 | 2 |
| 2 | 57 | 12 | 3 |
| 3 | 50 | 5 | 3 |
| 4 | 65 | 5 | 4 |
| 5 | 75 | 15 | 4 |
| 6 | 80 | 5 | 5 |

| Componente | Intervallo principale | Byte |
| --- | --- | ---: |
| `ui_marks` | `$0A00..$0AAA` | 171 |
| `sky_19` | `$0AAB..$0AB6` | 12 |
| `sky_20` | `$0AB7..$0AC2` | 12 |
| `ui_data` | `$0B40..$0B7F` | 64 |
| `bridge_stub` | `$0B80..$0BD4` | 85 |
| `sky_06` | `$0BD5..$0BE0` | 12 |
| `sky_08` | `$0BE1..$0BEC` | 12 |
| `sky_09` | `$0BED..$0BF4` | 8 |
| `ui_rows` | `$0C00..$0C88` | 137 |
| `material_finish` | `$0C90..$0D7E` | 239 |
| `bridge` | `$2800..$2A4D` | 590 |
| `sky_21` | `$2A50..$2A5F` | 16 |
| `sky_01` | `$2A60..$2A6F` | 16 |
| `sky_02` | `$2A70..$2A7F` | 16 |
| `video` | `$2A80..$2CA4` | 549 |
| `material_entries` | `$2CB0..$2CFC` | 77 |
| `timers` | `$2D00..$2EA5` | 422 |
| `material_cache` | `$2EA8..$2EFD` | 86 |
| `input` | `$2F00..$2FB9` | 186 |
| `sky_14` | `$2FBA..$2FC5` | 12 |
| `sky_15` | `$2FC6..$2FD1` | 12 |
| `sky_16` | `$2FD2..$2FDD` | 12 |
| `sky_17` | `$2FDE..$2FE9` | 12 |
| `sky_18` | `$2FEA..$2FF5` | 12 |
| `direct_colour` | `$40B4..$41C9` | 278 |
| `direct_column` | `$43F1..$4449` | 89 |
| `memory` | `$DC00..$DD8E` | 399 |
| `menu` | `$DD90..$DE1E` | 143 |
| `sky_04` | `$DE1F..$DE2E` | 16 |
| `sky_05` | `$DE2F..$DE36` | 8 |
| `sky_07` | `$DE37..$DE3E` | 8 |
| `keyboard` | `$DE40..$DEEB` | 172 |
| `sky_00` | `$DEEC..$DEF1` | 6 |
| `sky_03` | `$DEF2..$DEFB` | 10 |
| `bootstrap` | `$DF00..$DF3D` | 62 |
| `material_record` | `$DF40..$DFFB` | 188 |
| `sprites` | `$F800..$FCCE` | 1231 |
| `sky_10` | `$FCCF..$FCDA` | 12 |
| `sky_11` | `$FCDB..$FCE6` | 12 |
| `sky_12` | `$FCE7..$FCF2` | 12 |
| `sky_13` | `$FCF3..$FCFE` | 12 |

`--actor-shading materials --sky clouds` ricostruisce questa versione;
`--actor-shading materials --sky flat` ricostruisce i sette artefatti della
revisione9. Il cielo a dieci colori e la posizione delle nuvole restano
quelli della revisione13. Le prove del candidato008 sono distinte dalla
qualifica conservata del core20 e dall'esempio generico a sedici colori.
