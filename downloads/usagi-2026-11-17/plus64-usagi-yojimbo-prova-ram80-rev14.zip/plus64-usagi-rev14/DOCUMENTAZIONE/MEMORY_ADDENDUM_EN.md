# Usagi revision14 — memory map

Candidate `link-008` / `boot-008`, unchanged scenery20 runtime from revisions12/13.

RAM remains **65,536 +16,384 =81,920 bytes**, without extra pools. Scene
data and initialization grow from242 to260 bytes: one more16-byte ramp
and two additional palette bytes. The bootstrap remains62bytes:
5,170 -2 +260 = **5,428 bytes** in **41 components**, including nodes and
tables. No additional per-frame CPU routine is introduced.

| Shared internal RAM | Bytes |
| --- | ---: |
| 46 dense sprite records | 3,220 |
| Unassigned | 364 |
| Recipes, lookup, bindings and directories | 4,608 |
| Original D/F asset banks | 8,192 |

Character materials are unchanged:4,602bytes used and6spare within4,608.
Nineteen base CPU components, fonts, banked assets and thirteen guarded
spray-colour fixes are byte-identical to revision13. Scene data and
initialization operands in padding change. Core, API, SDK and binaries
are retained, without new builds or SDK test runs.

The scene uses16 of32 nodes: twelve ellipses, three ramps and one
conditional link. Byte `$0E64=1` enables the list;16-byte initialization
sets `$FD9D/$FD9E` and `$FD9F=$11`. The260bytes comprise144ellipse bytes,
24cloud-table bytes,48ramp-node bytes,10sky palette bytes,6shared green
palette bytes,12conditional-link bytes and16initialization bytes.

Distant green Y104..135 uses35; near green Y136..183 uses
`[57,50,65,75,80]` over five10,10,9,10,9-pixel bands. Six tones share four
luminances2..5:35 and80 retain the previous endpoints, while57 and75 add
intermediate green hues. Native key `$55` and mask `$7F` intentionally
include matching foliage and textures. Sprites composited afterwards and
the lower UI atY>=184 remain outside these ramps.

| Green tone | Compact colour | Hue | Luminance |
| --- | ---: | ---: | ---: |
| 1 | 35 | 5 | 2 |
| 2 | 57 | 12 | 3 |
| 3 | 50 | 5 | 3 |
| 4 | 65 | 5 | 4 |
| 5 | 75 | 15 | 4 |
| 6 | 80 | 5 | 5 |

| Component | Main-RAM range | Bytes |
| --- | --- | ---: |
| `ui_marks` | `$0A00..$0AAA` | 171 |
| `sky_19` | `$0AAB..$0AB6` | 12 |
| `sky_20` | `$0AB7..$0AC2` | 12 |
| `ui_data` | `$0B40..$0B7F` | 64 |
| `bridge_stub` | `$0B80..$0BD4` | 85 |
| `sky_06` | `$0BD5..$0BE0` | 12 |
| `sky_08` | `$0BE1..$0BEC` | 12 |
| `sky_09` | `$0BED..$0BF4` | 8 |
| `ui_rows` | `$0C00..$0C88` | 137 |
| `material_finish` | `$0C90..$0D7E` | 239 |
| `bridge` | `$2800..$2A4D` | 590 |
| `sky_21` | `$2A50..$2A5F` | 16 |
| `sky_01` | `$2A60..$2A6F` | 16 |
| `sky_02` | `$2A70..$2A7F` | 16 |
| `video` | `$2A80..$2CA4` | 549 |
| `material_entries` | `$2CB0..$2CFC` | 77 |
| `timers` | `$2D00..$2EA5` | 422 |
| `material_cache` | `$2EA8..$2EFD` | 86 |
| `input` | `$2F00..$2FB9` | 186 |
| `sky_14` | `$2FBA..$2FC5` | 12 |
| `sky_15` | `$2FC6..$2FD1` | 12 |
| `sky_16` | `$2FD2..$2FDD` | 12 |
| `sky_17` | `$2FDE..$2FE9` | 12 |
| `sky_18` | `$2FEA..$2FF5` | 12 |
| `direct_colour` | `$40B4..$41C9` | 278 |
| `direct_column` | `$43F1..$4449` | 89 |
| `memory` | `$DC00..$DD8E` | 399 |
| `menu` | `$DD90..$DE1E` | 143 |
| `sky_04` | `$DE1F..$DE2E` | 16 |
| `sky_05` | `$DE2F..$DE36` | 8 |
| `sky_07` | `$DE37..$DE3E` | 8 |
| `keyboard` | `$DE40..$DEEB` | 172 |
| `sky_00` | `$DEEC..$DEF1` | 6 |
| `sky_03` | `$DEF2..$DEFB` | 10 |
| `bootstrap` | `$DF00..$DF3D` | 62 |
| `material_record` | `$DF40..$DFFB` | 188 |
| `sprites` | `$F800..$FCCE` | 1231 |
| `sky_10` | `$FCCF..$FCDA` | 12 |
| `sky_11` | `$FCDB..$FCE6` | 12 |
| `sky_12` | `$FCE7..$FCF2` | 12 |
| `sky_13` | `$FCF3..$FCFE` | 12 |

`--actor-shading materials --sky clouds` rebuilds this presentation;
`--actor-shading materials --sky flat` rebuilds the seven revision9
artifacts. The ten-colour sky and cloud positions are retained from
revision13. Candidate008 evidence is distinct from retained core20
qualification and the generic sixteen-colour API example.
