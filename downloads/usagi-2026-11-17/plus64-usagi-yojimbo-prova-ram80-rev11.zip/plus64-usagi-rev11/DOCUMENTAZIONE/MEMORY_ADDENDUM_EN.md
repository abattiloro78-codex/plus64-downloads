# Usagi revision 11 — memory map

Candidate `link-004` / `boot-004`. Requires the matching scenery19 runtime.

Available RAM remains **65,536 + 16,384 = 81,920 bytes**, with no additional
sprite, background, audio or cache allocation. The 336 sky bytes reuse
seven already retired main-RAM padding ranges. The bootstrap shrinks
from64 to62 bytes:5,170 +336 -2 = **5,504 bytes** in **50 components**,
including data and tables. The16-byte initialization is included in336,
not a new per-frame routine.

| Shared internal RAM | Bytes |
| --- | ---: |
| 46 dense sprite records | 3,220 |
| Unassigned | 364 |
| Recipes, lookup, bindings and directories | 4,608 |
| Original D/F asset banks | 8,192 |

The character payload is identical to revision9:4,602 used and6 spare.
Fonts, original asset banks and the thirteen guarded mouth-spray colour
fixes are retained. The eighteen live game helpers are byte-identical to
revision9; the bootstrap is the revision10 version. The renderer is a
new scenery19 build with its own tests, distinct from historical evidence.

The sky uses twenty nodes out of thirty-two: twelve elliptical cloud tints,
seven rectangular bands and one conditional link. Byte `$0E64=1` enables
the list during play. Initialization sets `$FD9D/$FD9E` and `$FD9F=$11`.
Cloud style `$c8` selects ellipse, bright bank and hue0..7 filtering;
bands use `$c0`. Profile18 ignores the ellipse bit and19 applies it;
snapshot-module size and RAM protocol05 remain unchanged.

| Band from top | Compact colour | Hue | Luminance |
| --- | ---: | ---: | ---: |
| 1 | 51 | 6 | 3 |
| 2 | 66 | 6 | 4 |
| 3 | 64 | 4 | 4 |
| 4 | 86 | 11 | 5 |
| 5 | 77 | 2 | 5 |
| 6 | 92 | 2 | 6 |
| 7 | 107 | 2 | 7 |

| Component | Main-RAM range | Bytes |
| --- | --- | ---: |
| `ui_marks` | `$0A00..$0AAA` | 171 |
| `sky_23` | `$0AAB..$0AB6` | 12 |
| `sky_24` | `$0AB7..$0AC2` | 12 |
| `sky_25` | `$0AC3..$0ACE` | 12 |
| `sky_26` | `$0ACF..$0ADA` | 12 |
| `sky_27` | `$0ADB..$0AE6` | 12 |
| `sky_28` | `$0AE7..$0AF2` | 12 |
| `sky_29` | `$0AF3..$0AFE` | 12 |
| `ui_data` | `$0B40..$0B7F` | 64 |
| `bridge_stub` | `$0B80..$0BD4` | 85 |
| `sky_08` | `$0BD5..$0BDC` | 8 |
| `sky_09` | `$0BDD..$0BE8` | 12 |
| `sky_10` | `$0BE9..$0BF0` | 8 |
| `sky_11` | `$0BF1..$0BFC` | 12 |
| `ui_rows` | `$0C00..$0C88` | 137 |
| `material_finish` | `$0C90..$0D7E` | 239 |
| `bridge` | `$2800..$2A4D` | 590 |
| `sky_30` | `$2A50..$2A5F` | 16 |
| `sky_02` | `$2A60..$2A67` | 8 |
| `sky_03` | `$2A68..$2A73` | 12 |
| `sky_04` | `$2A74..$2A7B` | 8 |
| `video` | `$2A80..$2CA4` | 549 |
| `material_entries` | `$2CB0..$2CFC` | 77 |
| `timers` | `$2D00..$2EA5` | 422 |
| `material_cache` | `$2EA8..$2EFD` | 86 |
| `input` | `$2F00..$2FB9` | 186 |
| `sky_17` | `$2FBA..$2FC5` | 12 |
| `sky_18` | `$2FC6..$2FCD` | 8 |
| `sky_19` | `$2FCE..$2FD9` | 12 |
| `sky_20` | `$2FDA..$2FE5` | 12 |
| `sky_21` | `$2FE6..$2FF1` | 12 |
| `sky_22` | `$2FF2..$2FFD` | 12 |
| `direct_colour` | `$40B4..$41C9` | 278 |
| `direct_column` | `$43F1..$4449` | 89 |
| `memory` | `$DC00..$DD8E` | 399 |
| `menu` | `$DD90..$DE1E` | 143 |
| `sky_05` | `$DE1F..$DE2A` | 12 |
| `sky_06` | `$DE2B..$DE32` | 8 |
| `sky_07` | `$DE33..$DE3E` | 12 |
| `keyboard` | `$DE40..$DEEB` | 172 |
| `sky_00` | `$DEEC..$DEF3` | 8 |
| `sky_01` | `$DEF4..$DEFF` | 12 |
| `bootstrap` | `$DF00..$DF3D` | 62 |
| `material_record` | `$DF40..$DFFB` | 188 |
| `sprites` | `$F800..$FCCE` | 1231 |
| `sky_12` | `$FCCF..$FCD6` | 8 |
| `sky_13` | `$FCD7..$FCE2` | 12 |
| `sky_14` | `$FCE3..$FCEA` | 8 |
| `sky_15` | `$FCEB..$FCF6` | 12 |
| `sky_16` | `$FCF7..$FCFE` | 8 |

`--actor-shading materials --sky clouds` rebuilds this presentation;
`--actor-shading materials --sky flat` exactly rebuilds the seven revision9
game artifacts. Use an executable matching the selected formats. C checks,
private CPU tests, cold boots and Wine retain separate scopes; no physical
circuitry or completed campaign is certified.
