# Usagi revisione 11 — mappa della memoria

Candidato `link-004` / `boot-004`. Richiede il runtime scenari19 corrispondente.

La RAM disponibile resta **65.536 + 16.384 = 81.920 byte**, senza altre
allocazioni per sprite, sfondo, audio o cache. I 336 byte del cielo riusano
sette intervalli di padding già ritirato nella RAM principale. Il bootstrap
passa da 64 a 62 byte: 5.170 + 336 - 2 = **5.504 byte** in **50 componenti**, compresi dati e tavole. L'inizializzazione da16byte è inclusa
nei336, non è una routine aggiuntiva per fotogramma.

| RAM interna condivisa | Byte |
| --- | ---: |
| 46 record sprite densi | 3.220 |
| Non assegnati | 364 |
| Ricette, lookup, collegamenti e directory | 4.608 |
| Banchi originali D/F | 8.192 |

Il payload dei personaggi resta identico alla revisione9: 4.602byte usati e
6 liberi. Restano invariati font, banchi originali e le tredici correzioni
protette del colore dello spruzzo. I diciotto helper attivi del gioco sono
identici alla revisione9; il bootstrap è quello della revisione10. Il
renderer invece è una nuova build scenari19: le sue prove sono nuove e
distinte dalle prove storiche.

Il cielo usa venti nodi su un limite di trentadue: dodici tinte ellittiche
per le nuvole, sette bande rettangolari e un collegamento condizionale.
Il byte `$0E64=1` abilita la lista durante il gioco. L'inizializzazione
imposta `$FD9D/$FD9E` e `$FD9F=$11`. Lo stile `$c8` delle nuvole seleziona
ellisse, banca luminosa e filtro tinte0..7; le bande usano `$c0`.
I profili18 ignorano il bit ellisse, mentre19 lo applica; dimensione del
modulo snapshot e protocolloRAM05 restano invariati.

| Banda dall'alto | Colore compatto | Tinta | Luminanza |
| --- | ---: | ---: | ---: |
| 1 | 51 | 6 | 3 |
| 2 | 66 | 6 | 4 |
| 3 | 64 | 4 | 4 |
| 4 | 86 | 11 | 5 |
| 5 | 77 | 2 | 5 |
| 6 | 92 | 2 | 6 |
| 7 | 107 | 2 | 7 |

| Componente | Intervallo principale | Byte |
| --- | --- | ---: |
| `ui_marks` | `$0A00..$0AAA` | 171 |
| `sky_23` | `$0AAB..$0AB6` | 12 |
| `sky_24` | `$0AB7..$0AC2` | 12 |
| `sky_25` | `$0AC3..$0ACE` | 12 |
| `sky_26` | `$0ACF..$0ADA` | 12 |
| `sky_27` | `$0ADB..$0AE6` | 12 |
| `sky_28` | `$0AE7..$0AF2` | 12 |
| `sky_29` | `$0AF3..$0AFE` | 12 |
| `ui_data` | `$0B40..$0B7F` | 64 |
| `bridge_stub` | `$0B80..$0BD4` | 85 |
| `sky_08` | `$0BD5..$0BDC` | 8 |
| `sky_09` | `$0BDD..$0BE8` | 12 |
| `sky_10` | `$0BE9..$0BF0` | 8 |
| `sky_11` | `$0BF1..$0BFC` | 12 |
| `ui_rows` | `$0C00..$0C88` | 137 |
| `material_finish` | `$0C90..$0D7E` | 239 |
| `bridge` | `$2800..$2A4D` | 590 |
| `sky_30` | `$2A50..$2A5F` | 16 |
| `sky_02` | `$2A60..$2A67` | 8 |
| `sky_03` | `$2A68..$2A73` | 12 |
| `sky_04` | `$2A74..$2A7B` | 8 |
| `video` | `$2A80..$2CA4` | 549 |
| `material_entries` | `$2CB0..$2CFC` | 77 |
| `timers` | `$2D00..$2EA5` | 422 |
| `material_cache` | `$2EA8..$2EFD` | 86 |
| `input` | `$2F00..$2FB9` | 186 |
| `sky_17` | `$2FBA..$2FC5` | 12 |
| `sky_18` | `$2FC6..$2FCD` | 8 |
| `sky_19` | `$2FCE..$2FD9` | 12 |
| `sky_20` | `$2FDA..$2FE5` | 12 |
| `sky_21` | `$2FE6..$2FF1` | 12 |
| `sky_22` | `$2FF2..$2FFD` | 12 |
| `direct_colour` | `$40B4..$41C9` | 278 |
| `direct_column` | `$43F1..$4449` | 89 |
| `memory` | `$DC00..$DD8E` | 399 |
| `menu` | `$DD90..$DE1E` | 143 |
| `sky_05` | `$DE1F..$DE2A` | 12 |
| `sky_06` | `$DE2B..$DE32` | 8 |
| `sky_07` | `$DE33..$DE3E` | 12 |
| `keyboard` | `$DE40..$DEEB` | 172 |
| `sky_00` | `$DEEC..$DEF3` | 8 |
| `sky_01` | `$DEF4..$DEFF` | 12 |
| `bootstrap` | `$DF00..$DF3D` | 62 |
| `material_record` | `$DF40..$DFFB` | 188 |
| `sprites` | `$F800..$FCCE` | 1231 |
| `sky_12` | `$FCCF..$FCD6` | 8 |
| `sky_13` | `$FCD7..$FCE2` | 12 |
| `sky_14` | `$FCE3..$FCEA` | 8 |
| `sky_15` | `$FCEB..$FCF6` | 12 |
| `sky_16` | `$FCF7..$FCFE` | 8 |

`--actor-shading materials --sky clouds` ricostruisce questa versione;
`--actor-shading materials --sky flat` ricostruisce esattamente i sette
artefatti di gioco della revisione9. Il disco richiede sempre l'eseguibile
adatto ai formati scelti. Prove C, CPU private, avvii e Wine mantengono
ambiti separati; non si certificano circuiti fisici o una campagna completa.
