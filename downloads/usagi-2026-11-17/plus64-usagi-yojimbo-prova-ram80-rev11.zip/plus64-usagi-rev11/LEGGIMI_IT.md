# Usagi Yojimbo — cielo e personaggi RAM80

Questo port adatta il gioco C64 originale al prototipo software corrente plus/64. Conserva logica di gioco, grafica compressa e musica SID; la deviazione del trainer THT e il codice che aveva inserito sono stati rimossi. Il disco sorgente fornito è una versione THT modificata: non viene presentato come un originale editoriale incontaminato.

Il limite di memoria della macchina emulata è **65.536 byte principali + 16.384 byte interni condivisi = 81.920 byte (80 KiB)**. C16 e Plus/4 usano lo stesso gioco e contratto plus/64. La revisione 11 richiede il nuovo eseguibile corrispondente, con scenari 19 e materiali composti al byte snapshot 82, versione 3. Usare disco ed eseguibile forniti insieme.

Il gioco usa ricette definite dal gioco per le regioni dei personaggi: la luce segue le maschere e i gruppi descritti nelle ricette attraverso colonne e frammenti sprite, anziché ripartire a ogni tessera di 24×21 pixel. Le sagome e le animazioni originali sono conservate. Le 207 pose canoniche hanno una selezione esplicita della ricetta; il ritratto dell’interfaccia continua a usare il formato originale. Per le regioni scure possono essere previste luminanze neutre esplicite; i dettagli protetti conservano l’inchiostro originale.

La revisione 9 conserva i colori approvati del protagonista e dei contadini. Estende la sfumatura morbida della veste anche ai cappucci dei monaci e separa le parti chiare del viso dei maiali dal materiale dei vestiti: la tinta originale resta, con luce frontale lieve. Lo spruzzo già presente nella posa del maiale viene reso rosso con tredici modifiche protette ai soli indici di colore compressi, conservando la sagoma. Corregge inoltre il collegamento della terza colonna dei personaggi larghi, così il mostro comprende anche la parte frontale. Le immagini e le animazioni originali non vengono ridisegnate. In quella revisione 9 cambiava soltanto il gioco; renderer ed eseguibile restavano identici alla revisione 8. Il totale resta 64+16 KiB.

## Revisione 11: nuvole arrotondate e cielo rosso/blu

Le tre nuvole mantengono i colori approvati, con una sagoma arrotondata
ottenuta da dodici ellissi sovrapposte. Il cielo passa da blu intenso in
alto a porpora, rosa e rosso luminoso verso l'orizzonte. Le sette bande
usano sette inchiostri distinti e cinque luminanze 3..7. La geometria delle
nuvole approvate resta invariata. Il menu conserva la propria grafica.

Questa versione richiede il **nuovo eseguibile incluso, con revisione scenari 19**.
Il bit di stile `$08` dei nodi di tinta generici 5/7 seleziona la sagoma
ellittica. I profili snapshot fino a 18 ignorano quel bit e mantengono i
rettangoli storici: non usare un vecchio eseguibile per questa prova.
Il bit è distinto da FD9F bit 3 delle finestre di presentazione.

Il cielo seleziona soltanto il blu nativo luminoso `$56`; il blu locale
`$36` di montagne e altri elementi resta protetto. L'effetto termina a
Y=112. Nero, altre tinte, ritratto, simboli dell'interfaccia e materiali
approvati dei personaggi conservano i propri pixel. Le nuvole vengono
elaborate prima delle bande e non ricolorano i dettagli bianchi originali.

Nodi, tavole e inizializzazione occupano **336 byte di padding principale
già ritirato**; non viene aggiunta una routine CPU per fotogramma. Non ci
sono nuovi slot sprite o una bitmap fuori dal budget. Il totale rimane
**65.536 + 16.384 = 81.920 byte**. Eseguibile e renderer sono nuovi e hanno
prove proprie: la loro qualifica non viene ereditata dai vecchi binari.

Estrarre lo ZIP in una cartella nuova e avviare `AVVIA_USAGI.cmd` oppure
`AVVIA_USAGI_PLUS4.cmd`. Le prove del nuovo disco identificano il candidato
004. Prove C, avvii Linux, Wine e snapshot sono distinti; non si dichiara
una campagna completata, Windows nativo o hardware fisico collaudato.

## Avvio e comandi

Su Windows usare **`AVVIA_USAGI.cmd`** per C16 oppure **`AVVIA_USAGI_PLUS4.cmd`** per Plus/4. Entrambi usano lo stesso `USAGI.D64`. La keymap `usagi.vkm` del pacchetto associa **frecce e Space del PC** al joystick keyset A della porta 2. In alternativa montare il disco nell'unità 8 dell'emulatore plus/64 corrispondente e digitare:

```basic
LOAD"*",8,1
RUN
```

Attendere il menu originale. La scelta iniziale è **PRACTICE**, una modalità prevista dal gioco. Con il launcher PC fornito, premere e rilasciare **F1 del PC** una volta, verificare che compaia **GAME** e premere **Space** per iniziare. Usare le frecce per muoversi e Space per fire/azione.

| Tasto PC con `usagi.vkm` | Azione |
| --- | --- |
| F1 | Menu: alterna PRACTICE / GAME; gioco: torna al menu |
| F3 | Menu: alterna joystick / tastiera |
| F5 | Menu: avvia; avvia anche Space |
| F7 | Gioco: pausa; rilasciare, poi premere e rilasciare di nuovo per riprendere |

Questi tasti PC sono distinti dai nomi nativi C16/Plus/4. Il menu originale mostra ancora le etichette C64. Per la documentazione dei tasti nativi, o con un'altra keymap dell'host, la corrispondenza è:

| Contesto | Tasto nativo | Azione |
| --- | --- | --- |
| Menu | F1 | Alterna PRACTICE / GAME |
| Menu | F2 | Alterna joystick / tastiera |
| Menu | F3 oppure HELP | Avvia la modalità scelta; avvia anche FIRE del joystick |
| Gioco | F1 | Torna al menu |
| Gioco | HELP | Pausa; rilasciare, poi premere e rilasciare di nuovo HELP per riprendere |

Il launcher PC fornito è già pronto per il joystick con frecce e Space. Per usare il controller originale a tastiera, prima disabilitare in VICE **l'emulazione del joystick tramite tastiera dell'host sulla porta 2**, impostandone il dispositivo joystick su **None**; poi selezionare la tastiera nel menu del gioco con **F3 del PC (F2 nativo)**. I comandi sono **Q = su, P = destra, I = sinistra, Z = giù, SPACE = fire**. Con il keyset A attivo, VICE intercetta Space come fire del joystick prima che raggiunga la tastiera nativa: cambiare soltanto la scelta nel menu del gioco non basta. Le combinazioni direzione/fire sono gestite dal gioco originale; i tasti fisici dell'host dipendono dalla keymap dell'emulatore.

## Memoria e implementazione

Il decoder RLE originale usa una sola area temporanea da 64 byte, invece di conservare nella RAM principale tutti i 46 record espansi della cache sprite. La RAM interna contiene **46 × 70 = 3.220 byte** di record MCM densi e i due banchi originali di asset da 4 KiB, affiancati da **4.608 byte** di ricette, lookup, collegamenti, cache e directory; restano **364 byte non assegnati**. Si usano gli otto slot già disponibili, con colonne da 24 pixel per 63 righe. I personaggi larghi riusano il canale riservato originale; non si aggiunge RAM sprite. I 16 record intermedi originali della cache conservano posizioni riservate, ma non vengono selezionati come colonne dei personaggi.

Le coppie TED native del fondale occupano `$D000/$D400` e `$F000/$F400`. Una coppia indipendente per l'interfaccia occupa `$1800/$1C00`. Le tabelle originali basse vengono spostate in `$0200..$09FF`; font originali e banchi di asset compressi vengono conservati. Il caricamento a freddo riusa temporaneamente le stesse RAM principale e interna e ripristina gli helper bassi prima dell'ingresso nel gioco originale. La dimensione del disco, il trasporto compresso e la memoria del processo emulatore sull'host sono distinti dal totale RAM della macchina emulata.

La revisione 2 consente agli interrupt raster nativi di procedere durante la routine originale di scorrimento grossolano, correggendo il blocco dell'area di gioco al cambio di blocco dello scorrimento. I due byte di controllo rientrano nello stato già riservato. Il launcher usa un buffer audio dell'host di 64 ms; la RAM emulata resta 80 KiB.

La revisione 3 segue anche le cancellazioni originali di dialoghi e colori: le righe UI native si aggiornano quando il testo viene rimosso. Abilita la regola generica dei bordi FD9F bit4: sprite e finestre di presentazione rispettano i bordi TED laterali chiusi. Il controllo usa registro e RAM esistenti; grafica e regole originali del gioco sono conservate.

La revisione 4 riduce il blocco degli interrupt nella lettura della tastiera a una sola riga per volta, correggendo il ritardo video che produceva un lampeggio intermittente della barra vita. Usa lo stesso emulatore della revisione 3. Estrarre questo ZIP in una cartella nuova e usare il suo disco aggiornato. Memoria e comandi rimangono quelli descritti sopra.

La revisione 6 carica i dati dei materiali negli stessi 16 KiB interni, all’intervallo `$0E00..$1FFF`. Gli originali banchi D/F rimangono a `$2000..$3FFF`; i record sprite restano 46×70 byte. Il caricatore compresso riusa le RAM esistenti e non conserva una seconda copia o una cronologia esterna. Il formato generico è documentato anche negli addenda tecnici IT/EN.

Il rapporto di memoria allegato identifica candidato e hash esatti. I suoi confronti dei byte, le prove CPU limitate di equivalenza e il test della copia a freddo sono distinti dalle prove di avvio e comandi nell'emulatore. Rimane un'anteprima di sviluppo: non si dichiara una campagna completata, una prova su Windows nativo o una qualifica su hardware fisico. Gli eseguibili Windows provati tramite Wine sono indicati come prove Wine.

## Sorgenti e attribuzione

`Usagi Yojimbo`, il codice, la grafica, la musica e i personaggi originali mantengono i crediti dei rispettivi autori e titolari dei diritti. L'adattamento tecnico e la rimozione del trainer non cambiano la licenza di quei materiali. Il port viene ricostruito dal D64 fornito, SHA256 `68e476cadac7160abdb290fc6d1636d9e52e14e4f0027bc7f04f752fa6325808`; il file di ingresso rimane invariato. Gli strumenti sorgente documentano le trasformazioni con guardie sui byte di quell'ingresso.

VICE e le modifiche plus/64 sono distribuiti con i relativi sorgenti GPL e avvisi applicabili. Conservare i file di licenza dell'emulatore e gli avvisi delle dipendenze insieme alla distribuzione corrispondente. Questa anteprima implementa un contratto nell'emulatore: non certifica un progetto elettrico di cartuccia né il funzionamento fisico su C16/Plus/4.
