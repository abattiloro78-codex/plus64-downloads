# Usagi Yojimbo — anteprima17: orecchie e viso

Avvia AVVIA_USAGI.cmd oppure AVVIA_USAGI_PLUS4.cmd. Frecce e Space; F1 nel menu seleziona GAME invece di PRACTICE. Eseguibile identico alla rev16.

Ritocchi della rev17: eliminato il bordo verticale grigio sul viso, destra bianca; aggiunti due pixel chiari su ciascuna riga superiore delle orecchie, con due pixel scuri di raccordo sul lato sinistro. Le ombre blu originali dentro le orecchie diventano grigio scuro. La luce da destra lascia bianco quel lato e aggiunge due grigi sui bordi sinistri; tre celle esterne sotto il contorno destro restano blu. Il viso ha un volume arrotondato con luce da destra: guancia sinistra in ombra e lato destro chiaro, con occhi e bocca originali conservati. Fondali e personaggi conservano la grafica approvata. Memoria totale:65536+16384=81920byte;108byte di metadati del ritratto nella RAM interna già disponibile. Nessun nuovo codice emulatore.

Questa è un'anteprima per valutare il disegno. I nuovi avvii C16/Plus4 e il confronto grafico sono documentati in PROVE. Non sono stati ripetuti il collaudo SDK, Wine o una campagna completa. L'eseguibile acfd198538d4a112389081807e636a5db253ed4531173e89978c755194eb89a9 è quello già provato della rev15. Nessuna prova su Windows nativo o hardware fisico.

Ricostruzione con gli strumenti nei sorgenti allegati e il D64 originale fornito dall'utente: python3 tools-game/usagi-port/link.py --input INPUT.d64 --out link --actor-shading materials --sky clouds --portrait-shading face; poi python3 tools-game/usagi-port/boot.py --link link --out boot --low-restore. I report storici nei sorgenti restano riferiti ai propri candidati.

Gioco, grafica e musica originali mantengono i crediti e i diritti dei rispettivi autori. VICE e modifiche plus64 sono accompagnati da sorgenti e licenze GPL. Le ombre usano il profilo7 con basi neutre76/106/91 e rilievo morbido; il profilo2 raccorda le righe superiori. Il bianco destro del viso usa il colore originale, senza bordo frontale artificiale.
