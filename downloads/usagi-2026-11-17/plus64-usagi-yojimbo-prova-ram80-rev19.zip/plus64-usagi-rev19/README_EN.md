# Usagi Yojimbo — revision19: portrait backgrounds

The upper-left portrait retains the approved expressions and right-lit face. Its four expressions now have **blue, purple, red and green backgrounds**, each shaded as a rectangle from a light centre to dark edges. The primitive supports luminances0..7; the portrait shows0..6 because the figure covers the brightest centre. The silhouette, eyes, mouth and frame remain protected. The cheek point uses grey61; the neck connector has three exact blue tones51,66,81.

This version requires **the new executable supplied with the disk**, supporting composite materials version4 with literal palette support and scenery version20. Extract the ZIP into a new directory and keep the executable, support files and `USAGI.D64` together. C16 and Plus/4 run the same game with the same limit: **65,536 +16,384 =81,920bytes (80KiB)**. The source THT release's trainer is removed; PRACTICE remains an original game mode.

## Start and controls

On Windows, start **`AVVIA_USAGI.cmd`** for C16 or **`AVVIA_USAGI_PLUS4.cmd`** for Plus/4. Both use the same `USAGI.D64`. The supplied `usagi.vkm` assigns the PC **arrow keys and Space** to joystick port2. Alternatively, mount the disk as drive8 in the matching plus/64 emulator and enter:

```basic
LOAD"*",8,1
RUN
```

The original menu defaults to **PRACTICE**. Press and release **PC F1** once, check that **GAME** is shown, then press **Space** to start. Use the arrows to move and Space for fire/action.

| PC key with `usagi.vkm` | Action |
| --- | --- |
| F1 | Menu: PRACTICE/GAME; gameplay: return to menu |
| F3 | Menu: joystick/keyboard controller |
| F5 | Menu: start; Space also starts |
| F7 | Pause; release, then press and release again to resume |

Native key names differ from PC keys. The menu retains its original C64 labels:

| Context | Native C16/Plus4 key | Action |
| --- | --- | --- |
| Menu | F1 | PRACTICE/GAME |
| Menu | F2 | Joystick/keyboard controller |
| Menu | F3 or HELP | Start; joystick FIRE also starts |
| Gameplay | F1 | Return to menu |
| Gameplay | HELP | Pause; release, then press and release again to resume |

For the original keyboard controller, first disable keyboard joystick emulation for port2 in VICE by setting its device to **None**, then select keyboard in the game menu with **PC F3 (native F2)**. The keys are **Q=up, P=right, I=left, Z=down, Space=fire**. Changing only the game menu is insufficient: with keysetA active, VICE consumes Space as joystick input.

## Graphics and rebuilding

The material-shaded actors and their original animations remain, together with the ten-tone sky and three rounded clouds, including the lowered right cloud. The ground retains six actual colours over four luminances: one distant strip and five near strips. Selection of native green `$55` on rows104..183 intentionally includes matching foliage and textures; sprites and the lower UI are outside the ramp.

To rebuild the source, supply your original D64 with SHA256 `68e476cadac7160abdb290fc6d1636d9e52e14e4f0027bc7f04f752fa6325808`, Python3 and an external xa65 assembler. Output directories must be new. The original disk is neither modified nor included in the source archive.

```sh
python3 tools-game/usagi-port/link.py --input '/path/to/Usagi Yojimbo.d64' --out build/usagi-link-new --actor-shading materials --sky clouds --portrait-shading face --portrait-backgrounds
python3 tools-game/usagi-port/boot.py --link build/usagi-link-new --out build/usagi-boot-new --low-restore
```

`--portrait-backgrounds` requires `--portrait-shading face`. Without the backgrounds flag, the face variant retains the019 binary outputs; all-default options retain the flat016 port. `--low-restore` is required by the current loader. Playing needs no extra launcher options.

The accompanying evidence distinguishes the new materials4 core, builds and SDK tests, candidate025 graphics/CPU checks, native Linux cold boots and Windows execution under Wine. Historical proofs remain tied to their own candidates. No completed campaign, native Windows run or physical-hardware test is claimed.

Usagi Yojimbo and its original code, graphics, music and characters retain their respective authors' credits and rights. VICE and plus/64 modifications retain the applicable source and licences. This package implements a software/emulator contract; it does not qualify an electrical cartridge.
