# Usagi revision19 — memory addendum

Candidate `link-025` / `boot-025`, composite materials4 and scenery20. The matching new executable is required: the older materials3 core does not implement the new rectangular profile.

Total RAM remains **65,536 +16,384 =81,920bytes**. The42compiled components occupy **5,508bytes**; the scene retains260bytes and16nodes within those components. The portrait's main transport copy adds108data bytes at `$0E94..$0EFF`, separate from the components: components plus main copy total **5,616bytes**. Another15temporary bytes occupy the already-reserved finalizer prefix; they are not a new permanent buffer.

| Shared internal RAM | Bytes |
| --- | ---: |
| 46 dense sprite records, including portrait | 3,220 |
| Portrait bindings, directory and recipe | 123 |
| Unassigned | 241 |
| Actor recipes/lookup/bindings/directories | 4,608 |
| Original D/F banks | 8,192 |
| Total | 16,384 |

The123portrait bytes occupy `$0C94..$0D0E`:48bytes for six bindings,4for the directory at `$0CC4`,71for the recipe and table at `$0CC8`. The first108bytes travel through `$0E94..$0EFF`; the final15 (`7C 4C C6 74 9C 4D D6 74 BC 4C 6A 5B B3 C2 D1`) use a data prefix at `$0A00..$0A0E` and reach internal `$0D00..$0D0E`. The CPU finalizer entry is **`$0A0F`**: its prefix is skipped as data rather than executed. Original main data at `$0F00` are preserved. Address ranges in this document are inclusive.

The64-byte `portrait_init` helper at `$2FBA..$2FF9` performs startup initialization. Background selection follows the lower part actually present in the cache; the sprite publisher also changes during gameplay. The `sprites` component is1247bytes,16more than candidate019: whole-CPU identity with019 is not inherited. The accompanying candidate-specific proofs identify other component comparisons and checks.

The materials4 opt-in recipe uses header `$C0` and profile0/component1 for rectangular falloff. Legacy header `$80` and earlier materials retain their semantics. The primitive can produce all eight luminances0..7; the figure covers centre7, leaving0..6 visible in the portrait backgrounds. The cheek point at (4,55) becomes grey61 through base91 and soft profile7. Columns11/12/13 on rows25..29 use exact blue colours51/66/81 through inline entries179/194/209: bit7 selects literal colour only in material4 opt-in recipes. Actor data retain4608bytes,4602used and6spare. No sprite records, framebuffers or hidden RAM are added.

| Compiled component | Inclusive main range | Bytes |
| --- | --- | ---: |
| `ui_marks` | `$0A00..$0AAA` | 171 |
| `sky_06` | `$0AAB..$0AB6` | 12 |
| `sky_08` | `$0AB7..$0AC2` | 12 |
| `sky_10` | `$0AC3..$0ACE` | 12 |
| `sky_11` | `$0ACF..$0ADA` | 12 |
| `sky_12` | `$0ADB..$0AE6` | 12 |
| `sky_13` | `$0AE7..$0AF2` | 12 |
| `sky_14` | `$0AF3..$0AFE` | 12 |
| `ui_data` | `$0B40..$0B7F` | 64 |
| `bridge_stub` | `$0B80..$0BD4` | 85 |
| `sky_03` | `$0BD5..$0BDE` | 10 |
| `sky_09` | `$0BDF..$0BE6` | 8 |
| `sky_15` | `$0BE7..$0BF2` | 12 |
| `sky_16` | `$0BF3..$0BFE` | 12 |
| `ui_rows` | `$0C00..$0C88` | 137 |
| `material_finish` | `$0C90..$0D7E` | 239 |
| `bridge` | `$2800..$2A4D` | 590 |
| `sky_21` | `$2A50..$2A5F` | 16 |
| `sky_01` | `$2A60..$2A6F` | 16 |
| `sky_02` | `$2A70..$2A7F` | 16 |
| `video` | `$2A80..$2CA4` | 549 |
| `material_entries` | `$2CB0..$2CFC` | 77 |
| `timers` | `$2D00..$2EA5` | 422 |
| `material_cache` | `$2EA8..$2EFD` | 86 |
| `input` | `$2F00..$2FB9` | 186 |
| `portrait_init` | `$2FBA..$2FF9` | 64 |
| `sky_00` | `$2FFA..$2FFF` | 6 |
| `direct_colour` | `$40B4..$41C9` | 278 |
| `direct_column` | `$43F1..$4449` | 89 |
| `memory` | `$DC00..$DD8E` | 399 |
| `menu` | `$DD90..$DE1E` | 143 |
| `sky_07` | `$DE1F..$DE26` | 8 |
| `sky_19` | `$DE27..$DE32` | 12 |
| `sky_20` | `$DE33..$DE3E` | 12 |
| `keyboard` | `$DE40..$DEEB` | 172 |
| `sky_04` | `$DEEC..$DEFB` | 16 |
| `bootstrap` | `$DF00..$DF3D` | 62 |
| `material_record` | `$DF40..$DFFB` | 188 |
| `sprites` | `$F800..$FCDE` | 1247 |
| `sky_05` | `$FCDF..$FCE6` | 8 |
| `sky_17` | `$FCE7..$FCF2` | 12 |
| `sky_18` | `$FCF3..$FCFE` | 12 |

```sh
python3 tools-game/usagi-port/link.py --input '/path/to/Usagi Yojimbo.d64' --out build/usagi-link-new --actor-shading materials --sky clouds --portrait-shading face --portrait-backgrounds
python3 tools-game/usagi-port/boot.py --link build/usagi-link-new --out build/usagi-boot-new --low-restore
```

The source rebuild compares the eight025 artifacts. With backgrounds disabled, the eight face019 binary outputs must remain identical, including PRG/D64 and boot helpers. Provenance hashes in a new `BOOT.json` describe the current sources and can differ from the historical receipt. All-default options retain the six flat016 artifacts. Keep sources, authoring data, licences and historical evidence; historical proof does not automatically qualify the new core.
