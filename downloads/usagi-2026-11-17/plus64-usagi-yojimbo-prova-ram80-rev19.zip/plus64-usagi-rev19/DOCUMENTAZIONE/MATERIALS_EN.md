# Authored materials for composite dense sprites

This addendum specifies the opt-in dense-material format identified by snapshot
capability **82**. It extends the existing 70-byte dense MCM record without adding
sprite slots, a texture store or guest RAM. Bindings, column directories and
material recipes are authored by software and stored in the same shared 16 KiB.
The renderer has no game, character, body-part or fixed-address recognition.

The canonical byte contract is in
[`FORMAT.md`](../../emulator/experimental/sprite-formats/FORMAT.md), under
“Authored composite dense materials”. Capability 82 is a snapshot-header field,
not a 6502 register. Protocol 05 alone does not identify support for this format;
use the corresponding emulator and its packed-cache/mixed-sprite options.

## Format versions

Snapshot-header field 82 stores a version: **0** disables authored materials,
**1** retains the original strict validation, **2** uses the fixed 72×63
authoring canvas with queries clipped to the actual source dimensions, and
**3** adds inline compact-colour tables and profile 7, and **4** adds an explicit
rectangular-light recipe header. Version 4 is the current
default. Values above 4 are rejected. This field is separate
from the record's hexadecimal mode `$82`, which selects reflected coordinates.

Version 1 requires every recipe rectangle to fit the actual composite width
and height. Versions 2..4 allow a shared recipe to cover the 72×63 canvas even
when the selected composite has only one or two columns, or a shorter height.
Only queries inside the actual composite are sampled; an off-composite region
cannot add pixels or cause out-of-bounds reads. Bindings, directories and chain
metadata still have to describe the actual source geometry exactly.

## Dense record

Mode 1 keeps its previous bitmap, tag, ink and marker semantics exactly. With
capability 82 enabled, mode 2 or hexadecimal `$82` uses this interpretation:

| Record offset | Meaning |
| --- | --- |
| `$00` | Binding pointer low byte |
| `$01..$3F` | Existing inverse two-bit bitmap, unchanged |
| `$40` | Existing dense head height |
| `$41` | 2, or `$82` for reflected recipe coordinates |
| `$42..$44` | Original source inks for pairs 3, 2 and 1 |
| `$45` | `$80 | (binding_pointer >> 8)`; its top two bits must be `10` |

The resulting binding pointer is a full 14-bit offset in the existing 16 KiB
view. The ordinary descriptor still uses the dense pointer tag and packed-slot
selection. A 63-row column still occupies three consecutive 70-byte records;
each part has its own binding, origin and valid metadata. The format does not
add an expanded copy of the bitmap.

## Binding and column directory

Each binding occupies eight bytes and must fit without wrapping:

| Binding offset | Meaning |
| --- | --- |
| 0..1 | Recipe pointer, little-endian, in the shared 16 KiB |
| 2..3 | Column-directory pointer, little-endian |
| 4 | Composite width in columns: 1, 2 or 3 |
| 5 | This part's X origin in physical pixels: a multiple of 24 |
| 6 | This part's Y origin: a multiple of 21 |
| 7 | Composite height: 1..63 source pixels |

The directory holds one little-endian column-head address per column, in
actual left-to-right source order. Each column contains `ceil(height/21)`
consecutive dense parts. Column heads can be unaligned and noncontiguous.
Directories contain addresses, not other directories, so they cannot recurse.

The selected column head plus `originY/21 * 70` must equal the current record
address. Origins and displayed rows must lie inside the composite dimensions.
All referenced parts must have valid metadata, including parts outside the
visible screen. This explicit topology lets a material follow a composite
sprite across columns and 21-row boundaries without assuming its memory layout.

## Recipe encoding

A legacy recipe begins with `$80 | count`, where count is 0..63 and the
header's top two bits are `10`. Version 4 also accepts `$C0 | count` for
explicit rectangular centre light; versions 0..3 reject it. Either header
is followed by `count` four-byte little-endian rectangles:

| Bits | Meaning |
| --- | --- |
| 0..5 | Inclusive x0 in two-pixel MCM units |
| 6..11 | Inclusive y0 in source pixels |
| 12..17 | Inclusive x1 in two-pixel MCM units |
| 18..23 | Inclusive y1 in source pixels |
| 24..25 | Source pair: 0 for any nonzero pair, or 1..3 |
| 26..28 | Material profile: 0..5 in version 1; 0..6 in version 2; 0..7 in versions 3/4 |
| 29..31 | Component: 0..7 |

Equivalent packing is
`x0 | y0<<6 | x1<<12 | y1<<18 | pair<<24 | profile<<26 | component<<29`.
In version 1, coordinates must fit the declared composite. In versions 2..4, they
must fit the fixed 72×63 canvas: x0/x1 are at most 35 and y0/y1 at most 62.
Queries remain clipped to the actual composite. The last matching rectangle wins.
An unmatched pixel or a zero-rectangle recipe retains the original ink.
Profile 0 does too unless the version-4 `$C0` header explicitly selects its
rectangular computation. Pair 0 remains transparent: a recipe cannot create occupied pixels. Inks
above 120 retain their ordinary non-visible behaviour.

For frontal profiles, component 0 means that rectangle alone. Components 1..7
join winning rectangles with the same profile and pair selector into one row
span, including across dense columns and 21-row parts. The first and last
matching opaque source pixels determine its extrema. Holes and retained dark
details do not create additional light centres. Different component values keep
adjacent shapes independent. Software authors these groups; the renderer does
not infer anatomy.

## Profiles

| Profile | Output |
| --- | --- |
| 0 | Original source ink; explicit rectangular light with version-4 `$C0` header |
| 1 | Original hue; luminance 0..6 from distance to original opaque black |
| 2 | Original hue; soft frontal luminance 5..7 |
| 3 | Original hue; pale frontal luminance 6..7 |
| 4 | Neutral hue 1; dark frontal curve, luminance 0..3 |
| 5 | Neutral hue 1; lower-gain dark frontal curve, luminance 0..2 |
| 6 | Original hue; softer garment contrast, luminance 1..4; versions 2..4 |
| 7 | Inline compact base colour with relative soft shading; versions 3/4 |

Profiles 1..3, 6 and 7 preserve opaque black. Recolouring an original black region
therefore requires an explicit profile 4 or 5 rectangle. A later profile-0
rectangle can protect a detail that should keep its original ink.

Profile 6 is an explicit recipe selection for softer garment contrast. It uses
the original-black distance field with a narrower luminance range of 1..4.
Profile 1 retains its stronger 0..6 range. Version 1 still rejects profile 6;
adding it to version 2 does not change existing profile-1 recipes.
If the profile-1 distance calculation gives `strong` in 0..6, profile 6 uses
`1 + (strong + 1) // 2`: the seven input levels become 1, 2, 2, 3, 3, 4, 4.
Here `//` denotes integer division. Other profiles retain their own curves.

## Inline colour table and profile 7

Version 3 keeps the four-byte rectangles unchanged. If any rectangle selects
profile 7, a compact-colour table follows immediately after the `count * 4`
rectangle bytes. Its length is one plus the largest component value used by a
profile-7 rectangle: 1..8 bytes. Entries must be 0..120, except explicit version-4 literal entries,
including unused lower indices. The complete table must fit the shared 16 KiB
without wrapping. There is no table when profile 7 is absent; trailing bytes of
older recipes remain unrelated data. Versions 1/2 reject profile 7 before
reading a table.

For profile 7, component 0..7 selects a table entry instead of joining a row-span
group. Source-pair filters and the last-matching-rectangle rule still apply.
Original opaque black is retained before selecting the base colour. Table
entry 0 makes a selected nonblack opaque pixel black, preserving occupancy.
An otherwise non-visible source ink is not made visible.

For a nonzero base, `hue = 1 + (base-1) % 15` and
`baseL = (base-1) // 15`. With the same soft distance level from profile 6,
the result uses that hue and `clamp(baseL + soft - 3, 0, 7)`. All 121 compact
bases are supported. A luminance-3 base uses the soft 1..4 ramp; a luminance-7
base uses levels 5..7 after clipping. For example, compact base 112 selects
yellow at luminance 7. This is software-owned colour data, not a hardcoded
colour or material identity in the renderer.

Profile 1 uses nearest squared distance to opaque original black pixels.
Thresholds 2, 4, 5, 8, 9 and 10 select successive levels; distances at least 10
saturate at 6. Sampling needs only a radius-3 source neighbourhood across the
authored composite. It reads original masks and inks, never shaded output.

For profiles 2 and 3, let `width` be the winning row span and `edge` the distance
to its nearer extremum. Profile 2 uses depth 1 at widths 3/4 and depth 2 above
4; widths 1/2 stay at 7. Profile 3 keeps widths 1..4 at 7 and otherwise uses
depth 1. Other pixels use
`min(7, 7-depth+ceil(2*depth*edge/(width-1)))`.

For profiles 4 and 5, with span extrema `lo` and `hi`, use
`t=abs(2*x-lo-hi)/(width+1)` and `floor(gain*(1-t*t))`.
Gain is 16/5 for profile 4 and 72/25 for profile 5. Computations use bounded
integer arithmetic. A recipe can select different profiles on authored rows
without putting source-specific row numbers in the renderer.

## Rectangular centre light in version 4

Version 4 accepts the additional recipe header `$C0 | count`. Its low six bits
still encode 0..63 rectangles; the rectangles and optional profile-7 table are
unchanged. Readers with material versions 0..3 reject this header. The legacy
`$80 | count` header keeps every previous meaning even in version 4.

Only with the `$C0` header, profile 0 and component 1..7 select a rectangular
centre-to-edge luminance ramp. Component 0 retains the original ink. Component
1 selects luminance 0..7, component 2 selects 1..7, through component 7 selecting
6..7. Hue comes from the original source ink; opaque black stays black and inks
above 120 retain their previous non-visible behaviour. No source occupancy is
added. Later matching rectangles may protect or shade foreground details.

After decoding bounds to physical pixels, let
`rx=max((x1-x0)//2,1)`, `ry=max((y1-y0)//2,1)`,
`ex=min(x-x0,x1-x)` and `ey=min(y-y0,y1-y)`. With `minimum=component-1`, use
`min(7, minimum+(7-minimum)*min(ex*ry,ey*rx)//(rx*ry))`.
All division is integer division. The rectangle supplies both axes of the
falloff; source holes, black details and row spans do not move its centre.
Degenerate one-row or two-pixel-wide rectangles are defined without division
by zero. Reflected mode uses the existing reflected recipe coordinates.

### Literal inline colours in version 4

Only a `$C0 | count` recipe with material capability 4 may store profile-7 table
bytes 128..248. Bit 7 selects a literal compact colour: `colour=byte & 127`.
This returns that colour without edge-distance attenuation. Values 0..120 keep
the existing relative-shading computation. Values 121..127 and 249..255 reject
the entire displayed chain. A legacy `$80` recipe, including in version 4,
continues to reject every table entry above 120; versions 0..3 gain no new
palette interpretation. Table bounds and maximum index remain unchanged.

Source opaque black is retained before selecting either relative or literal
colour; literal 128 can turn a selected nonblack pixel black while keeping its
occupancy. Source transparent or non-visible pixels are not made visible.
Last-matching-rectangle precedence is unchanged. These bytes are software-owned
material data in the existing shared 16 KiB, without a new cache or game ID.

## Reflection, validation and compatibility

Mode `$82` reflects recipe lookup X across the complete composite width. It
does not reverse bitmap bytes: software already owns their orientation.
Distance sampling uses actual source space; symmetric frontal curves use the
reflected recipe/group coordinates. Expansion, clipping, display priority and
collision processing still follow the colour calculation.

Mode 2/82 bypasses the older whole-record tag, radial and diagonal material
selectors. Mode 1 is unchanged when capability 82 is enabled. Bad pointers,
bindings, directories, recipes, rectangles, part metadata or complete-chain
bounds reject the entire displayed chain. Pointers never wrap.

Enable mixed formats and packed cache while output is disabled, before
publishing these records. Snapshot header 82 requires dense capability 80,
mixed formats and packed cache, and accepts versions 0, 1, 2, 3 and 4 only.
Bytes 83..127 remain reserved
zero; the existing serialized payload remains 144,776 bytes. Old snapshots
with header 82 zero leave modes 2/82 invalid. Version-1 snapshots retain strict
version-1 validation when loaded; they are not silently upgraded. Readers that
support only version 1 reject versions 2/3; version-2 readers reject version 3.
Version-2/3 snapshots retain their exact validation and rendering when loaded.
Version-3 readers reject version 4.
Readers predating the format reject the nonzero reserved field instead of
interpreting the new record incorrectly.

Bindings, directories and recipes must be counted in the application's
**65,536 + 16,384 = 81,920-byte** budget. This format defines no additional
bitmap, material or history pool. Application build and test reports must
identify their data, addresses, matching emulator and validation scope.
