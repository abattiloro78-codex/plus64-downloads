# Usagi revisione19 — mappa della memoria

Candidato `link-025` / `boot-025`, materiali compositi4 e scenari20. Occorre il nuovo eseguibile corrispondente: il vecchio core materiali3 non implementa il nuovo profilo rettangolare.

La RAM totale resta **65.536 +16.384 =81.920byte**. I42componenti compilati occupano **5,508byte** (separatore delle migliaia inglese nei dati JSON); la scena conserva260byte e16nodi all'interno di questi componenti. La copia principale del ritratto aggiunge108byte di dati a `$0E94..$0EFF`, separati dai componenti: componenti più copia principale totalizzano **5616byte**. Altri15byte sono dati temporanei nel prefisso del finalizzatore già riservato, non un nuovo buffer permanente.

| RAM interna condivisa | Byte |
| --- | ---: |
| 46 record sprite densi, incluso il ritratto | 3.220 |
| Collegamenti, directory e ricetta del ritratto | 123 |
| Non assegnati | 241 |
| Ricette/lookup/collegamenti/directory degli attori | 4.608 |
| Banchi originali D/F | 8.192 |
| Totale | 16.384 |

I123byte del ritratto occupano `$0C94..$0D0E`:48byte per sei collegamenti,4per la directory a `$0CC4`,71per ricetta e tavola a `$0CC8`. I108byte iniziali transitano da `$0E94..$0EFF`; i15finali (`7C 4C C6 74 9C 4D D6 74 BC 4C 6A 5B B3 C2 D1`) transitano come prefisso a `$0A00..$0A0E` e raggiungono `$0D00..$0D0E` in RAM interna. Il punto di ingresso CPU del finalizzatore è **`$0A0F`**: il prefisso è saltato come dati, non eseguito. Il vecchio dato principale a `$0F00` è preservato. Tutti gli intervalli qui espressi sono inclusivi.

L'helper `portrait_init` occupa64byte a `$2FBA..$2FF9` ed esegue l'inizializzazione. La selezione dello sfondo segue il pezzo inferiore realmente presente nella cache; il publisher sprite viene modificato anche durante il gioco. Il componente `sprites` è1247byte,16più del candidato019: non viene ereditata l'identità dell'intera CPU019. Gli altri componenti e i controlli specifici sono identificati nelle prove del candidato.

La ricetta opt-in materiali4 usa header `$C0` e profilo0/componente1 per il decadimento rettangolare. Header legacy `$80` e i materiali precedenti conservano le proprie semantiche. Il primitivo può produrre otto luminanze0..7; la figura copre il centro7 e gli sfondi del ritratto mostrano0..6. Il punto della guancia a (4,55) diventa grigio61 mediante base91 e profilo7 morbido. Le colonne11/12/13, righe25..29, usano i colori blu esatti51/66/81 tramite voci inline179/194/209: il bit7 attiva il colore literal soltanto nelle ricette opt-in materiali4. Il payload attori resta4608byte,4602usati e6liberi. Non si aggiungono sprite, framebuffer o RAM nascosta.

| Componente compilato | Intervallo principale inclusivo | Byte |
| --- | --- | ---: |
| `ui_marks` | `$0A00..$0AAA` | 171 |
| `sky_06` | `$0AAB..$0AB6` | 12 |
| `sky_08` | `$0AB7..$0AC2` | 12 |
| `sky_10` | `$0AC3..$0ACE` | 12 |
| `sky_11` | `$0ACF..$0ADA` | 12 |
| `sky_12` | `$0ADB..$0AE6` | 12 |
| `sky_13` | `$0AE7..$0AF2` | 12 |
| `sky_14` | `$0AF3..$0AFE` | 12 |
| `ui_data` | `$0B40..$0B7F` | 64 |
| `bridge_stub` | `$0B80..$0BD4` | 85 |
| `sky_03` | `$0BD5..$0BDE` | 10 |
| `sky_09` | `$0BDF..$0BE6` | 8 |
| `sky_15` | `$0BE7..$0BF2` | 12 |
| `sky_16` | `$0BF3..$0BFE` | 12 |
| `ui_rows` | `$0C00..$0C88` | 137 |
| `material_finish` | `$0C90..$0D7E` | 239 |
| `bridge` | `$2800..$2A4D` | 590 |
| `sky_21` | `$2A50..$2A5F` | 16 |
| `sky_01` | `$2A60..$2A6F` | 16 |
| `sky_02` | `$2A70..$2A7F` | 16 |
| `video` | `$2A80..$2CA4` | 549 |
| `material_entries` | `$2CB0..$2CFC` | 77 |
| `timers` | `$2D00..$2EA5` | 422 |
| `material_cache` | `$2EA8..$2EFD` | 86 |
| `input` | `$2F00..$2FB9` | 186 |
| `portrait_init` | `$2FBA..$2FF9` | 64 |
| `sky_00` | `$2FFA..$2FFF` | 6 |
| `direct_colour` | `$40B4..$41C9` | 278 |
| `direct_column` | `$43F1..$4449` | 89 |
| `memory` | `$DC00..$DD8E` | 399 |
| `menu` | `$DD90..$DE1E` | 143 |
| `sky_07` | `$DE1F..$DE26` | 8 |
| `sky_19` | `$DE27..$DE32` | 12 |
| `sky_20` | `$DE33..$DE3E` | 12 |
| `keyboard` | `$DE40..$DEEB` | 172 |
| `sky_04` | `$DEEC..$DEFB` | 16 |
| `bootstrap` | `$DF00..$DF3D` | 62 |
| `material_record` | `$DF40..$DFFB` | 188 |
| `sprites` | `$F800..$FCDE` | 1247 |
| `sky_05` | `$FCDF..$FCE6` | 8 |
| `sky_17` | `$FCE7..$FCF2` | 12 |
| `sky_18` | `$FCF3..$FCFE` | 12 |

```sh
python3 tools-game/usagi-port/link.py --input '/percorso/Usagi Yojimbo.d64' --out build/usagi-link-new --actor-shading materials --sky clouds --portrait-shading face --portrait-backgrounds
python3 tools-game/usagi-port/boot.py --link build/usagi-link-new --out build/usagi-boot-new --low-restore
```

La ricostruzione confronta gli otto artefatti025. Il flag sfondi disattivato deve conservare gli otto artefatti binari face019, inclusi PRG/D64 e helper di boot. Gli hash di provenienza nel nuovo `BOOT.json` descrivono le fonti correnti e possono differire dal rapporto storico. I sei artefatti della configurazione tutta predefinita restano quelli flat016. Sorgenti, dati autorali, licenze e prove storiche vanno conservati; queste ultime non qualificano automaticamente il nuovo core.
