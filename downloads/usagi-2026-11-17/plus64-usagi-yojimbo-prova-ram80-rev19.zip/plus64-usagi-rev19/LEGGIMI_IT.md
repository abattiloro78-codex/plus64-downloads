# Usagi Yojimbo — revisione19: sfondi del ritratto

Il ritratto in alto a sinistra conserva le espressioni e il viso con luce da destra già approvati. Le quattro espressioni hanno ora sfondi **blu, viola, rosso e verde**, ciascuno con sfumatura rettangolare dal centro chiaro ai bordi scuri. Il primitivo supporta le luminanze0..7; nel ritratto risultano visibili0..6, perché la figura copre il centro più luminoso. Sagoma, occhi, bocca e cornice restano protetti. Il punto della guancia usa grigio61; il raccordo del collo ha tre toni blu esatti51,66,81.

Questa versione richiede **il nuovo eseguibile fornito insieme al disco**, con materiali compositi versione4 con palette literal e scenari versione20. Estrarre lo ZIP in una cartella nuova e tenere insieme eseguibile, supporti e `USAGI.D64`. C16 e Plus/4 usano lo stesso gioco e lo stesso limite: **65.536 +16.384 =81.920byte (80KiB)**. Il trainer della versione THT di origine è rimosso; PRACTICE è invece una modalità originale del gioco.

## Avvio e comandi

Su Windows avviare **`AVVIA_USAGI.cmd`** per C16 oppure **`AVVIA_USAGI_PLUS4.cmd`** per Plus/4. Entrambi caricano lo stesso `USAGI.D64`. Il file `usagi.vkm` assegna **frecce e Spazio** al joystick, porta2. In alternativa, montare il disco nell'unità8 dell'emulatore plus/64 corrispondente e digitare:

```basic
LOAD"*",8,1
RUN
```

Il menu originale parte in **PRACTICE**. Premere e rilasciare **F1 del PC** una volta, verificare che compaia **GAME**, poi premere **Spazio** per iniziare. Frecce per muoversi, Spazio per fuoco/azione.

| Tasto PC con `usagi.vkm` | Azione |
| --- | --- |
| F1 | Menu: PRACTICE/GAME; durante il gioco: ritorno al menu |
| F3 | Menu: joystick/tastiera |
| F5 | Menu: avvio; funziona anche Spazio |
| F7 | Pausa; rilasciare e premere/rilasciare di nuovo per riprendere |

I nomi dei tasti nativi sono diversi dai tasti PC. Il menu conserva le etichette C64 originali:

| Contesto | Tasto nativo C16/Plus4 | Azione |
| --- | --- | --- |
| Menu | F1 | PRACTICE/GAME |
| Menu | F2 | Joystick/tastiera |
| Menu | F3 oppure HELP | Avvio; funziona anche FIRE |
| Gioco | F1 | Ritorno al menu |
| Gioco | HELP | Pausa; rilasciare e premere/rilasciare di nuovo per riprendere |

Per il controller originale da tastiera, disabilitare prima l'emulazione joystick da tastiera della porta2 in VICE, impostando il dispositivo su **None**, quindi selezionare tastiera nel menu con **F3 PC (F2 nativo)**. I comandi sono **Q=alto, P=destra, I=sinistra, Z=basso, Spazio=fuoco**. Il solo cambio nel menu non basta: con keysetA attivo VICE intercetta Spazio come joystick.

## Grafica e ricostruzione

Restano i personaggi con materiali e le loro animazioni originali, il cielo a dieci toni e le tre nuvole arrotondate, con quella destra più bassa. Il terreno conserva sei colori effettivi su quattro luminanze: una fascia lontana e cinque vicine. La selezione del verde nativo `$55` fra le righe104 e183 comprende intenzionalmente anche fogliame e texture dello stesso colore; sprite e interfaccia inferiore restano fuori dalla sfumatura.

Per ricostruire dai sorgenti, usare il proprio D64 originale con SHA256 `68e476cadac7160abdb290fc6d1636d9e52e14e4f0027bc7f04f752fa6325808`, Python3 e un assemblatore xa65 esterno. Le cartelle di uscita devono essere nuove. Il disco originale non viene modificato né incluso nell'archivio sorgenti.

```sh
python3 tools-game/usagi-port/link.py --input '/percorso/Usagi Yojimbo.d64' --out build/usagi-link-new --actor-shading materials --sky clouds --portrait-shading face --portrait-backgrounds
python3 tools-game/usagi-port/boot.py --link build/usagi-link-new --out build/usagi-boot-new --low-restore
```

`--portrait-backgrounds` richiede `--portrait-shading face`. Senza il flag sfondi, la variante face conserva l'uscita binaria019; la configurazione interamente predefinita conserva il port flat016. Il flag `--low-restore` è richiesto dal caricamento attuale. Per giocare non occorre aggiungere opzioni agli avviatori.

Le prove allegate identificano separatamente il nuovo core/materiali4, le build e i test SDK, i controlli grafici/CPU del candidato025, gli avvii nativi Linux e l'esecuzione Windows tramite Wine. Le prove storiche restano associate ai propri candidati. Non viene dichiarata una partita completa, una prova Windows nativa o una prova su hardware fisico.

Usagi Yojimbo, codice, grafica, musica e personaggi originali mantengono crediti e diritti dei rispettivi autori. VICE e le modifiche plus/64 conservano sorgenti e licenze applicabili. Il pacchetto realizza un contratto software/emulatore, non una qualifica di cartuccia elettrica.
