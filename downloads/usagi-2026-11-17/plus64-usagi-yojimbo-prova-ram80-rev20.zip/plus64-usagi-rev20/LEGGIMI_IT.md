# Usagi Yojimbo — revisione20: sangue rosso del ninja

L'effetto di morte del ninja usa ora sangue rosso. È una modifica cromatica definita dal gioco: occupazione e geometria dello sprite originale restano, mentre l'inchiostro selezionato dell'effetto viene riassegnato al rosso esatto62 (luminanza4), tramite la voce literal190 del renderer materiali4 esistente. Restano gli sfondi del ritratto approvati, il raccordo blu del collo, il viso, gli attori, il cielo, le nuvole e il terreno.

Usare gli avviatori e l'eseguibile allegati. **Emulatore, API materiali4/scenari20 ed eseguibile restano quelli della revisione19/candidato025.** Cambia il gioco. La RAM totale resta **65.536 +16.384 =81.920byte (80KiB)** su C16 e Plus/4. Estrarre in una cartella nuova e tenere insieme `USAGI.D64`, eseguibile e supporti. Il trainer della versione THT di origine è rimosso; PRACTICE resta una modalità originale del gioco.

## Avvio e comandi

Su Windows avviare **`AVVIA_USAGI.cmd`** per C16 oppure **`AVVIA_USAGI_PLUS4.cmd`** per Plus/4. Entrambi caricano lo stesso `USAGI.D64`. Il file `usagi.vkm` assegna **frecce e Spazio** al joystick, porta2. In alternativa, montare il disco nell'unità8 dell'emulatore plus/64 corrispondente e digitare:

```basic
LOAD"*",8,1
RUN
```

Il menu originale parte in **PRACTICE**. Premere e rilasciare **F1 del PC** una volta, verificare che compaia **GAME**, poi premere **Spazio** per iniziare. Frecce per muoversi, Spazio per fuoco/azione.

| Tasto PC con `usagi.vkm` | Azione |
| --- | --- |
| F1 | Menu: PRACTICE/GAME; durante il gioco: ritorno al menu |
| F3 | Menu: joystick/tastiera |
| F5 | Menu: avvio; funziona anche Spazio |
| F7 | Pausa; rilasciare e premere/rilasciare di nuovo per riprendere |

I nomi dei tasti nativi sono diversi dai tasti PC. Il menu conserva le etichette C64 originali:

| Contesto | Tasto nativo C16/Plus4 | Azione |
| --- | --- | --- |
| Menu | F1 | PRACTICE/GAME |
| Menu | F2 | Joystick/tastiera |
| Menu | F3 oppure HELP | Avvio; funziona anche FIRE |
| Gioco | F1 | Ritorno al menu |
| Gioco | HELP | Pausa; rilasciare e premere/rilasciare di nuovo per riprendere |

Per il controller originale da tastiera, disabilitare prima l'emulazione joystick da tastiera della porta2 in VICE, impostando il dispositivo su **None**, quindi selezionare tastiera nel menu con **F3 PC (F2 nativo)**. I comandi sono **Q=alto, P=destra, I=sinistra, Z=basso, Spazio=fuoco**. Il solo cambio nel menu non basta: con keysetA attivo VICE intercetta Spazio come joystick.

## Ricostruzione e prove

L'opzione facoltativa `--ninja-blood` richiede i materiali degli attori e la disposizione degli sfondi del ritratto; usare tutti i flag mostrati sotto. Servono Python3, un assemblatore xa65 esterno e il D64 originale fornito dall'utente. SHA256 ingresso: `68e476cadac7160abdb290fc6d1636d9e52e14e4f0027bc7f04f752fa6325808`. Gli strumenti non lo sovrascrivono e l'archivio sorgenti non lo include. Le cartelle di uscita devono essere nuove.

```sh
python3 tools-game/usagi-port/link.py --input '/percorso/Usagi Yojimbo.d64' --out build/usagi-link-new --actor-shading materials --sky clouds --portrait-shading face --portrait-backgrounds --ninja-blood
python3 tools-game/usagi-port/boot.py --link build/usagi-link-new --out build/usagi-boot-new --low-restore
```

Omettendo soltanto `--ninja-blood`, gli otto artefatti025 e i binari boot vengono ricostruiti identici. Restano verificati separatamente face019 senza sfondi e flat016 con tutte le opzioni predefinite. Per giocare non servono nuovi flag negli avviatori.

Le prove026 identificano trasformazione dei dati/ricetta, caricamento, memoria e controlli limitati nativi/Wine. Le qualifiche core/build/SDK sono conservate soltanto tramite identità esatta degli input e dei binari025; non sono nuove build o nuove esecuzioni SDK. Non viene dichiarata una partita completa, Windows nativo o hardware fisico.

Usagi Yojimbo, codice, grafica, personaggi e musica originali mantengono crediti e diritti dei rispettivi autori. Sorgenti e licenze VICE/plus64 accompagnano il runtime. Il progetto resta un contratto software/emulatore.
