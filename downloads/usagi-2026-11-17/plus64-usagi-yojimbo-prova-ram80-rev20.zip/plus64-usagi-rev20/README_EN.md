# Usagi Yojimbo — revision20: red ninja blood

The ninja death effect now uses red blood. The effect is a game-authored colour change: original sprite occupancy and geometry remain, while the selected death-effect ink is reassigned to exact red62 (luminance4), using literal palette entry190 in the existing material4 renderer. The approved portrait backgrounds, blue neck tones, face, actors, sky, clouds and ground remain.

Use the supplied launchers and matching executable. **The emulator, material4/scenery20 APIs and executable are unchanged from revision19/candidate025.** This revision changes the game. Total RAM remains **65,536 +16,384 =81,920bytes (80KiB)** on both C16 and Plus/4. Extract into a new directory; keep `USAGI.D64`, executable and support files together. The source THT release's trainer is removed; PRACTICE remains an original game mode.

## Start and controls

On Windows, start **`AVVIA_USAGI.cmd`** for C16 or **`AVVIA_USAGI_PLUS4.cmd`** for Plus/4. Both use the same `USAGI.D64`. The supplied `usagi.vkm` assigns the PC **arrow keys and Space** to joystick port2. Alternatively, mount the disk as drive8 in the matching plus/64 emulator and enter:

```basic
LOAD"*",8,1
RUN
```

The original menu defaults to **PRACTICE**. Press and release **PC F1** once, check that **GAME** is shown, then press **Space** to start. Use the arrows to move and Space for fire/action.

| PC key with `usagi.vkm` | Action |
| --- | --- |
| F1 | Menu: PRACTICE/GAME; gameplay: return to menu |
| F3 | Menu: joystick/keyboard controller |
| F5 | Menu: start; Space also starts |
| F7 | Pause; release, then press and release again to resume |

Native key names differ from PC keys. The menu retains its original C64 labels:

| Context | Native C16/Plus4 key | Action |
| --- | --- | --- |
| Menu | F1 | PRACTICE/GAME |
| Menu | F2 | Joystick/keyboard controller |
| Menu | F3 or HELP | Start; joystick FIRE also starts |
| Gameplay | F1 | Return to menu |
| Gameplay | HELP | Pause; release, then press and release again to resume |

For the original keyboard controller, first disable keyboard joystick emulation for port2 in VICE by setting its device to **None**, then select keyboard in the game menu with **PC F3 (native F2)**. The keys are **Q=up, P=right, I=left, Z=down, Space=fire**. Changing only the game menu is insufficient: with keysetA active, VICE consumes Space as joystick input.

## Rebuild and evidence

The optional `--ninja-blood` switch requires actor materials and the portrait-background layout; use all the flags shown below. Python3, an external xa65 assembler and the original user-supplied D64 are required for rebuilding. Original input SHA256: `68e476cadac7160abdb290fc6d1636d9e52e14e4f0027bc7f04f752fa6325808`. The tools do not overwrite it; the source archive does not include it. Output directories must be new.

```sh
python3 tools-game/usagi-port/link.py --input '/path/to/Usagi Yojimbo.d64' --out build/usagi-link-new --actor-shading materials --sky clouds --portrait-shading face --portrait-backgrounds --ninja-blood
python3 tools-game/usagi-port/boot.py --link build/usagi-link-new --out build/usagi-boot-new --low-restore
```

Omitting only `--ninja-blood` exactly rebuilds the eight025 artifacts and boot binaries. The existing background-off face019 and all-default flat016 regressions remain checked separately. Playing needs no new launcher switches.

Candidate026 evidence identifies its source/recipe transformation, boot transport, memory and bounded native/Wine checks. Core/build/SDK qualification is retained only through exact025 input and binary identity; it is not reported as a new emulator build or SDK run. No completed campaign, native Windows or physical-hardware test is claimed.

Usagi Yojimbo and its original code, artwork, characters and music retain their authors' credits and rights. VICE and plus/64 source and licences accompany the runtime. This remains a software/emulator contract.
