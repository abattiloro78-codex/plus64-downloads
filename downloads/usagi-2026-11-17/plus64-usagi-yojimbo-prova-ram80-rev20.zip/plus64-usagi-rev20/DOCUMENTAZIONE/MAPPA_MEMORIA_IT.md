# Usagi revisione20 — mappa della memoria

Il candidato026 usa l'eseguibile materiali4/scenari20 invariato della025. Il limite resta **65.536 +16.384 =81.920byte**, senza RAM sprite/immagini nascosta.

| RAM interna condivisa | Byte |
| --- | ---: |
| 46 record sprite densi | 3.220 |
| Collegamenti/directory/ricetta ritratto | 123 |
| Ricetta morte del ninja | 46 |
| Non assegnati | 195 |
| Payload materiali attori | 4.608 |
| Banchi originali D/F | 8.192 |
| Totale | 16.384 |

Il bundle di169byte occupa `$0C94..$0D3C`. La ricetta ninja è a `$0D0F..$0D3C`, dopo i123byte del ritratto. I primi108byte transitano dalla copia principale esistente `$0E94..$0EFF`. Gli altri61sono un prefisso dati saltato a `$0A00..$0A3C` nella pagina del finalizzatore già riservata; il corpo CPU di107byte comincia a **`$0A3D`**. Il dato principale a `$0F00` resta intatto. Gli intervalli qui espressi sono inclusivi.

I componenti compilati totalizzano **5508byte** in 42componenti; i108byte della copia principale permanente sono separati, per **5616byte** complessivi. Il prefisso di61byte riusa la pagina del finalizzatore. I42componenti compilati e il corpo finalizzatore da107byte sono identici025; nessun nuovo codice per fotogramma. L'immagine principale cambia soltanto17byte letterali di dati sprite. L'override della ricetta player1B usa5byte nei4608già assegnati agli attori, ora4607usati e1libero. L'helper ritratto resta64byte e la scena approvata260byte/16nodi. Nessuna modifica al core/API, nuovo record sprite o framebuffer.

`ninja_blood.py` contiene la riassegnazione cromatica con guardie sui dati originali e la ricetta morte da46byte. `NINJA_BLOOD.json` documenta sorgenti e memoria; conservarlo con `PORTRAIT.json`, `portrait.bin` e JSON autorale dei materiali. Il payload attori mantiene la propria allocazione di4608byte. I controlli occupazione/alpha/collisione sono distinti dai confronti cromatici.

| Componente compilato | Intervallo principale inclusivo | Byte |
| --- | --- | ---: |
| `ui_marks` | `$0A00..$0AAA` | 171 |
| `sky_06` | `$0AAB..$0AB6` | 12 |
| `sky_08` | `$0AB7..$0AC2` | 12 |
| `sky_10` | `$0AC3..$0ACE` | 12 |
| `sky_11` | `$0ACF..$0ADA` | 12 |
| `sky_12` | `$0ADB..$0AE6` | 12 |
| `sky_13` | `$0AE7..$0AF2` | 12 |
| `sky_14` | `$0AF3..$0AFE` | 12 |
| `ui_data` | `$0B40..$0B7F` | 64 |
| `bridge_stub` | `$0B80..$0BD4` | 85 |
| `sky_03` | `$0BD5..$0BDE` | 10 |
| `sky_09` | `$0BDF..$0BE6` | 8 |
| `sky_15` | `$0BE7..$0BF2` | 12 |
| `sky_16` | `$0BF3..$0BFE` | 12 |
| `ui_rows` | `$0C00..$0C88` | 137 |
| `material_finish` | `$0C90..$0D7E` | 239 |
| `bridge` | `$2800..$2A4D` | 590 |
| `sky_21` | `$2A50..$2A5F` | 16 |
| `sky_01` | `$2A60..$2A6F` | 16 |
| `sky_02` | `$2A70..$2A7F` | 16 |
| `video` | `$2A80..$2CA4` | 549 |
| `material_entries` | `$2CB0..$2CFC` | 77 |
| `timers` | `$2D00..$2EA5` | 422 |
| `material_cache` | `$2EA8..$2EFD` | 86 |
| `input` | `$2F00..$2FB9` | 186 |
| `portrait_init` | `$2FBA..$2FF9` | 64 |
| `sky_00` | `$2FFA..$2FFF` | 6 |
| `direct_colour` | `$40B4..$41C9` | 278 |
| `direct_column` | `$43F1..$4449` | 89 |
| `memory` | `$DC00..$DD8E` | 399 |
| `menu` | `$DD90..$DE1E` | 143 |
| `sky_07` | `$DE1F..$DE26` | 8 |
| `sky_19` | `$DE27..$DE32` | 12 |
| `sky_20` | `$DE33..$DE3E` | 12 |
| `keyboard` | `$DE40..$DEEB` | 172 |
| `sky_04` | `$DEEC..$DEFB` | 16 |
| `bootstrap` | `$DF00..$DF3D` | 62 |
| `material_record` | `$DF40..$DFFB` | 188 |
| `sprites` | `$F800..$FCDE` | 1247 |
| `sky_05` | `$FCDF..$FCE6` | 8 |
| `sky_17` | `$FCE7..$FCF2` | 12 |
| `sky_18` | `$FCF3..$FCFE` | 12 |

```sh
python3 tools-game/usagi-port/link.py --input '/percorso/Usagi Yojimbo.d64' --out build/usagi-link-new --actor-shading materials --sky clouds --portrait-shading face --portrait-backgrounds --ninja-blood
python3 tools-game/usagi-port/boot.py --link build/usagi-link-new --out build/usagi-boot-new --low-restore
```

La ricostruzione verifica gli otto artefatti026 e il rapporto boot. Omettendo `--ninja-blood`, otto artefatti e binari boot restano identici025; gli hash di provenienza nel nuovo `BOOT.json` possono differire perché le fonti sono correnti. Vengono controllati anche face019 senza sfondi e flat016 predefinito. Le prove core/SDK025 conservate sono identificate dagli hash esatti, non dichiarate rieseguite.
