# Usagi revision20 — memory addendum

Candidate026 uses the unchanged025 material4/scenery20 executable. The budget remains **65,536 +16,384 =81,920bytes**, without hidden sprite/image RAM.

| Shared internal RAM | Bytes |
| --- | ---: |
| 46 dense sprite records | 3,220 |
| Portrait bindings/directory/recipe | 123 |
| Ninja death material recipe | 46 |
| Unassigned | 195 |
| Actor material payload | 4,608 |
| Original D/F banks | 8,192 |
| Total | 16,384 |

The combined169-byte metadata bundle occupies `$0C94..$0D3C`. The ninja recipe occupies `$0D0F..$0D3C`; it follows the existing123-byte portrait metadata. The first108bytes travel through the existing main mirror `$0E94..$0EFF`. The remaining61bytes are a skipped data prefix at `$0A00..$0A3C` in the existing cold-finalizer page; its107-byte CPU body starts at **`$0A3D`**. Original main data at `$0F00` remain intact. All ranges here are inclusive.

The compiled components total **5,508bytes** in 42components; the108-byte permanent main mirror is separate, making **5,616bytes** together. The61-byte cold prefix reuses the already-reserved finalizer page. All42compiled components and the107-byte finalizer body are025-identical; no per-frame code is added. The main image changes only17original sprite-data literals. A5-byte player1B recipe override occupies the existing4608-byte actor payload, now4607used/1spare. The portrait helper remains64bytes, and the approved scene remains260bytes/16nodes. No core or API change, new sprite record or framebuffer is added.

`ninja_blood.py` contains guarded source-colour reassignment and the authored46-byte death recipe. `NINJA_BLOOD.json` records its source and memory audit; retain it with `PORTRAIT.json`, `portrait.bin` and the original material-authoring JSON. The main actor material payload retains its4608-byte allocation. Source occupancy/alpha/collision checks are separate from colour checks.

| Compiled component | Inclusive main range | Bytes |
| --- | --- | ---: |
| `ui_marks` | `$0A00..$0AAA` | 171 |
| `sky_06` | `$0AAB..$0AB6` | 12 |
| `sky_08` | `$0AB7..$0AC2` | 12 |
| `sky_10` | `$0AC3..$0ACE` | 12 |
| `sky_11` | `$0ACF..$0ADA` | 12 |
| `sky_12` | `$0ADB..$0AE6` | 12 |
| `sky_13` | `$0AE7..$0AF2` | 12 |
| `sky_14` | `$0AF3..$0AFE` | 12 |
| `ui_data` | `$0B40..$0B7F` | 64 |
| `bridge_stub` | `$0B80..$0BD4` | 85 |
| `sky_03` | `$0BD5..$0BDE` | 10 |
| `sky_09` | `$0BDF..$0BE6` | 8 |
| `sky_15` | `$0BE7..$0BF2` | 12 |
| `sky_16` | `$0BF3..$0BFE` | 12 |
| `ui_rows` | `$0C00..$0C88` | 137 |
| `material_finish` | `$0C90..$0D7E` | 239 |
| `bridge` | `$2800..$2A4D` | 590 |
| `sky_21` | `$2A50..$2A5F` | 16 |
| `sky_01` | `$2A60..$2A6F` | 16 |
| `sky_02` | `$2A70..$2A7F` | 16 |
| `video` | `$2A80..$2CA4` | 549 |
| `material_entries` | `$2CB0..$2CFC` | 77 |
| `timers` | `$2D00..$2EA5` | 422 |
| `material_cache` | `$2EA8..$2EFD` | 86 |
| `input` | `$2F00..$2FB9` | 186 |
| `portrait_init` | `$2FBA..$2FF9` | 64 |
| `sky_00` | `$2FFA..$2FFF` | 6 |
| `direct_colour` | `$40B4..$41C9` | 278 |
| `direct_column` | `$43F1..$4449` | 89 |
| `memory` | `$DC00..$DD8E` | 399 |
| `menu` | `$DD90..$DE1E` | 143 |
| `sky_07` | `$DE1F..$DE26` | 8 |
| `sky_19` | `$DE27..$DE32` | 12 |
| `sky_20` | `$DE33..$DE3E` | 12 |
| `keyboard` | `$DE40..$DEEB` | 172 |
| `sky_04` | `$DEEC..$DEFB` | 16 |
| `bootstrap` | `$DF00..$DF3D` | 62 |
| `material_record` | `$DF40..$DFFB` | 188 |
| `sprites` | `$F800..$FCDE` | 1247 |
| `sky_05` | `$FCDF..$FCE6` | 8 |
| `sky_17` | `$FCE7..$FCF2` | 12 |
| `sky_18` | `$FCF3..$FCFE` | 12 |

```sh
python3 tools-game/usagi-port/link.py --input '/path/to/Usagi Yojimbo.d64' --out build/usagi-link-new --actor-shading materials --sky clouds --portrait-shading face --portrait-backgrounds --ninja-blood
python3 tools-game/usagi-port/boot.py --link build/usagi-link-new --out build/usagi-boot-new --low-restore
```

Staged rebuild verifies all eight026 artifacts and its boot receipt. With `--ninja-blood` omitted, eight artifacts and boot binaries remain025-identical; historical `BOOT.json` provenance hashes can differ because source files are current. Background-off face019 and default flat016 are also checked. Retained025 core/SDK evidence is identified by exact hashes, not rerun claims.
