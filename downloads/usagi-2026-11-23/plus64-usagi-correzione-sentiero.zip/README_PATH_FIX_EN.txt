USAGI YOJIMBO - R8 PATH CORRECTION

1. Close the game.
2. Extract the complete ZIP into the R8 folder containing xplus4.exe
   and USAGI.D64. Allow the updated files to replace the previous versions.
3. Run AVVIA_USAGI_FLUIDO.cmd; press F1 to select GAME, wait a moment,
   then press F7.

Start a new game: snapshots saved before this update still contain the
previous program in memory.

This update corrects background alignment while the uphill path scrolls
near the end of the first level. It retains the SDL audio/pixel launch
profile used for the smoother test and the 64+16 KiB memory limit.

For the Plus/4 model use AVVIA_USAGI_PLUS4_FLUIDO.cmd. The other R8 resources,
controls and complete manuals remain in the folder you previously extracted.

SORGENTI contains the complete corresponding source for the new executable
and disk. DOCUMENTAZIONE_AGGIORNAMENTO contains technical camera API addenda;
PROVE_CORREZIONE contains the final qualification. MANIFEST_CORREZIONE.json
and SHA256SUMS_CORREZIONE.txt cover this update. Previous R8 inventories
describe the previous version.
