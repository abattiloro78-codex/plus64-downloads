# 8. Current source and material formats

This is a **programmer reference** for the software model. It supplements all seven original chapters; it is not a game guide. Source/API evidence, final identities and actual release tests are listed in chapter 9 and `RELEASE_STATUS.json`. Memory protocol `$05`, PLUS64 snapshot module `1.0`, scenery capability at HOST header byte **79**, and material capability at byte **82** are independent selectors. The header bytes are not 6502 registers.

| Capability | Meaning |
|---|---|
| Materials 0..4 | Earlier dense70 and authored-material versions, retained with their versioned semantics |
| Materials 5 | Source16 records, including borrowed physical MAIN source access |
| Materials 6 | Optional acyclic shared pair grammar, source flag `$04` |
| Materials 7 | Shared material contexts and generic SVM4 programs, source modes 2/3 |
| Materials 8 | Optional bounded frame-bank source, flag `$08`; final direct IDs use P64F version 4 |
| Scenery 22 | Guest background node11 and external lighting-phase node12, independently gated |

An older reader must reject unsupported snapshot capability combinations before restoring state. Enabling a resource is not a substitute for validating its record. The original formats and registers retain their meanings when their newer capabilities are disabled. Snapshot payload size and backing ownership do not imply a larger RAM budget.

## Source16 record and C8 direct frame IDs

In packed/mixed mode, with the slot's FD92 bit set, descriptor tag `$C000` addresses a **16-byte record in existing AUX16K**. The lower14 bits are its AUX offset. Tag `$8000` still selects dense70; `$4000` retains RAW8 semantics. Tags do not allocate new RAM.

| Offset | Bytes | Meaning |
|---|---:|---|
|0|2|RLE/grammar source address; with P64Fv4, opaque unsigned frame ID, including ID0|
|2|1|Source software length; exactly2 for P64Fv4, not a byte-stream length|
|3|1|Bit0 mirror; bit1 source/root backing AUX instead of MAIN; bit2 shared grammar; bit3 frame bank|
|4..6|3|Compact sprite inks for pairs1/2/3, each0..120|
|7|1|Head height:0 means21, otherwise 1..252; a chain uses `ceil(height/21)` records|
|8..9|2|AUX material binding/context pointer|
|10|1|0 plain;1 earlier authored binding;2 primary SVM base;3 first alternate SVM base|
|11|1|Software-owned byte; ignored by final P64Fv4 source decoding|
|12|1|Stride marker16|
|13..14|2|Grammar dictionary or P64F root in the same backing as the source|
|15|1|Validity marker `$A6`|

Bits4..7 are reserved. Grammar and frame-bank flags cannot both be set. A non-grammar/non-frame record requires bytes13/14 zero. Capabilities5/6 do not accept C8-only fields. Missing MAIN, bounds violations, malformed inks/markers or a wrong codec reject the complete source. Pair0 is transparent; compact ink0 is opaque black. Geometry, alpha, expansion, priority and collisions are separate from colour selection.

A63-row column uses three source16 parts,48 record bytes. These are descriptors, not the source archive or material-program storage: all three must be counted separately. The borrowed-MAIN drawing API receives the caller's physical64KiB view; it keeps no MAIN copy. Legacy C wrappers without MAIN cannot resolve MAIN-backed source records.

## Earlier RLE and shared-grammar sources

Without a codec flag, the source is original RLE: the low seven control bits give a nonzero length; a high bit repeats the following byte, otherwise that many literal bytes follow. The declared stream is consumed exactly and must produce63 bytes. With capability6/flag4, the source begins with software length and token count1..63, then groups of one high-bit bitmap plus up to eight low token bytes. Bitmap bit0 belongs to the first token. Tokens0..255 are literals;256..511 name rules. The explicit dictionary has three256-byte planes: left child low, right child low, and child-high flags bits0/1. Other flag bits are zero and each child is less than its parent token, giving an acyclic grammar. Bounds, unused high bits, token count and exact output are validated. C8 does not reinterpret these older records when flag8 is clear.

## P64F version4 frame bank

| Root offset | Bytes | Meaning |
|---|---:|---|
|0|4|ASCII `P64F`|
|4|1|Version4; old private1/2 are preserved,3 is rejected|
|5|1|Frames per group,1..32|
|6|1|Expanded frame bytes, exactly63|
|7|1|Reserved0|
|8|2|Positive logical frame count|
|10|2|Group count, exactly `ceil(frame_count/frames_per_group)`|
|12|4 per group|Absolute backing address u16 and complete P64Z packet length u16|

`group=frameID/group_size`; `within=frameID%group_size`. IDs are checked against the logical frame count, not RAM capacity. The decoder expands only the selected group, at most32×63=**2,016 bytes**, copies one63-byte frame and frees the temporary view. Header/table/packet bounds, exact expanded group length, complete codec member and checksum are validated before output is committed. No complete sprite atlas is retained. The source bytes are original three-byte-per-row MCM data; mirroring reverses pixels without changing source occupancy.

## Shared eight-byte material context and SVM4

Modes2/3 point to the same guest AUX context from every participating source record:

| Context offset | Meaning |
|---|---|
|0..1|AUX metadata archive root|
|2..3|AUX directory of explicit source-column heads|
|4|Column count1..3|
|5|Composite height1..63|
|6|Opaque material key|
|7|Opaque selector|

Every part agrees on context and mode. The column directory may be noncontiguous; parts advance by16 bytes. The guest supplies selector/key meanings and all geometry. The circuit contains no actor IDs or anatomical catalogue.

SVM4 starts with `SVM4`, six little-endian u16 section lengths and six u16 counts: **28 header bytes**. Sections are mask selectors, postfix expressions, binary64 constants, paint programs, sparse routing and legacy base recipes. Masks select original source pairs and rectangles; coordinates use MCM-X/native-Y. Expressions can sample source pair/ink, occupied-row bounds and bounded distance. Programs apply literal colours, profiles, ramps, retinting and expressions. Dictionary offsets, stacks, indices, programs and traversal are validated by the generic decoder. Exact instruction encodings and examples are in the supplied `sprite_vm.c/.h` and technical source inventory. A program may explicitly produce a transparent sentinel; therefore verify alpha and collisions for the authored recipe instead of assuming every paint operation stays opaque.

The renderer prepares at most eight material contexts within one draw operation. Repeated parts may reuse that operation's validated metadata/source state. All views and temporary source data are destroyed before the draw returns; no cache survives into the next draw, snapshot or guest-visible memory. Controlled C tests measured nine source opens for an ordinary composite and six for a HUD composite; those counts are not whole-game FPS.

## P64Z compressed resident representation

| Offset | Bytes | Meaning |
|---|---:|---|
|0|4|ASCII `P64Z`|
|4|1|Wrapper version1|
|5|1|Method1 zlib or method2 LZMA1|
|6|2|Expanded length1..65,535|
|8|2|Stored payload length, exactly region length minus12|
|10|2|Reserved0|

Method1 contains exactly one complete zlib member with its Adler checksum. Method2 contains five LZMA1 properties, an EOS-terminated stream and a final little-endian CRC32 of the expanded bytes. Its dictionary property is4,096..65,536; `lc+lp<=4`. Exact input/output lengths, EOS, properties, checksum and absence of trailing bytes are mandatory. Raw unwrapped metadata is borrowed; compressed metadata owns a bounded temporary allocation. The shared `p64_metadata_open/close` API transfers `bytes`, `size`, `owned` explicitly and empties the view on failure/close.

Persistent encoded sources, tables, contexts and programs remain guest-resident and count within81,920 bytes. Temporary metadata expansion, source-group decode, expression stacks, alpha and scanline buffers are HOST working state, never an addressable asset pool. The LZMA decoder uses its bounded output as dictionary and frees probability working data; it does not add another guest64KiB. This software arrangement is not proof of physical-cartridge bandwidth or circuitry.

## Scenery22 node11: generic guest background

The node is24 bytes in physical MAIN. It remains in the existing linked scenery list.

|Offset|Meaning|
|---|---|
|0..1|Next node u16|
|2|Blob backing0 MAIN /1 AUX|
|3..4,5..6|Blob address u16, complete region length u16|
|7..8|MAIN address of scene-selector byte|
|9..10|MAIN address of gate byte|
|11|Node kind11|
|12..13|MAIN address of camera-X u16|
|14,15|Gate value and mask: `(MAIN[gate]&mask)==value`|
|16..17,18|World width u16, world height u8|
|19|Flags: bit0 MODE_FILTER; all others0|
|20|Flags0 requires0. MODE_FILTER requires a nonzero native-mode mask, bits0..4 only|
|21..23|Reserved0|

For example, flags1/mask2 selects multicolour-text mode1 and leaves mode0 text untouched. No font address, HUD coordinates or game ID is built in. Flags0 preserves all five native source modes. A filtered row leaves pixels unchanged and clears its optional selection mask. Invalid flags/masks/addresses fail closed.

The decoder samples immutable native TED pair, raw matrix glyph, attribute `cbuf&127` and original native colour, before recolouring. Camera and fine-scroll origins locate the visible source; there is no world bitmap. Apply background paint after earlier scenery tinting, before saving final foreground colours and composing actors. Existing collisions, source priority, final native borders, blanking and UI gates remain independent.

## P64B bytecode and material operators

The header is `P64B`, version1, reserved0. Each TLV is kind u8, payload length u16, then payload. IDs are guest-defined; duplicates and invalid references reject. Palette entries are **native TED0..127**, not compact sprite0..120. Pair-mask bit0 explicitly authorizes source background; it is not sprite transparency.

|TLV|Meaning|
|---|---|
|1/2/3|Palette, glyph membership set, narrow row clip|
|4/5/6/7|Template, instance, inline global field, shared field definition|
|12|Repeated rows of sorted nonoverlapping u16 `(left,width)` clip intervals|
|13|Shared signed row envelope: initial L/R, bounded periodic delta segments|
|14/16|Eight-byte shared field reference: scene,x16,y8,width16,height8,fieldID;16 runs early|
|15|Glyph/subcell selector: glyph plus8 LSB-first row bitmaps; phase uses world X/Y modulo8|
|17|Nearest-volume table: positive X/Y scales, explicit anchors, optional override rectangles and lighting rectangles|

The order is **16 →5 →6 →14**, retaining record order within each group. Definitions contain selectors for immutable pair/native colour/attribute/glyph and clip, followed by an operator. Global outer dimensions override the stored positive field dimensions. The exact typed layouts are in `reference/formats/` and the corresponding source copies.

|Shader|Operation|
|---|---|
|0/1/2|Constant, affine two-colour, cylindrical three-colour|
|3/4/5/6|Legacy source-ranked runs, vertical ramp, explicit row indices, coordinate runs|
|7/8/9|Radial lighting rectangle, endpoint Y ramp, palette across a guest row envelope|
|10/11/12|Original glyph-row LUT, periodic X LUT, parameterized radial field|
|13|Quadratic surface light, optional blend with current encoded luminance|
|14|Guest palette/exponent symmetric power envelope, optional fixed-point scale|
|15|Nearest guest-authored volume followed by shader13 light|

New operators need no offscreen source. Legacy operator3 requires the selected-source prefix; operator6 replaces it for viewport-only use. Quadratic percentages are0..100; hue 1..15, luminances0..7, dimensions positive. Nearest distance uses physical local pixels, first strict minimum wins; override rectangles apply in order, last match wins. Rounding is nearest-even where specified. Source code must be compiled without fast-math or contraction.

## Scenery22 node12: external lighting phase

This **scenery node kind12 is separate from P64B TLV12**. It is16 bytes: next u16 at0, phase-X u16 at2 (0..319), MAIN gate address u16 at4, value/mask at6/7, reserved0 at8..10, kind12 at11 and reserved0 at12..15. The first valid gate-matching phase owner in the active branch wins, including phase0. The bounded traversal follows up to32 nodes; a replaced material branch can replace its phase too.

The phase rotates only the existing320-pixel lighting viewport. It never scrolls source glyphs or changes foreground classification. A nonzero phase uses a transient320-byte row; false gates, phase0 and older scenery versions preserve their former path. Scene04's intermediate reference uses phase280; this is guest recipe data, not a circuit-specific scene rule.

## Loading a staged game and checking a port

The Usagi disk contains 20 ordinary files: `USAGI` bootstraps, then loads `ASSETS` and `MAIN` through KERNAL. The 17 `B01`..`B17` packets are loaded at a scene change, with a loading pause there. Chapter 9 records their actual disk total and largest resident packet. The recovered 8825-byte MAIN region is shared by a 7376-byte background slot, 1278 bytes of resident loader code and a 171-byte reserve; these uses are counted once. There is no additional background RAM.

`USAGI.PRG` is an internal disk bootstrap, not a standalone program; `MAIN.PRG` is not a launcher. Keep the complete D64 and file names. Use the first raw directory entry/index1; avoid a textual uppercase `:USAGI` suffix which VICE may translate into a different PETSCII name.

One game/D64 retains the same64+16KiB contract on C16 and Plus/4. Chapter 9 receipts distinguish real loader execution, PC keys, source/materials, presented pixels, HUD/dialogue exclusion, snapshots and performance. C fixtures, CPU stubs, Linux, Wine and complete campaigns remain distinct evidence; read the stated coverage of each receipt.
