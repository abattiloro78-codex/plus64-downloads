# 9. Build, memory and release evidence

| Field|Value |
|---|---|
| Candidate | `033-approved178-r7` |
| MAIN SHA256 | `899b3a6602cadf3b46127a36fa66072710079f4e3a679e0f8de634707030ce40` |
| D64 SHA256 | `aff57ed640226d33dd54a6e85db625849841ae08a5de6e5f04966567f347a5a4` |
| Windows PE SHA256 | `f365c471d5a97476b7b58c744e66901dab9df62a09fe4878c65fc872f9c138f7` |
| Linux headless SHA256 | `c8c20d836a74a8f757371db0d278c9882930bf20289ee189a417e88bc4b184ef` |
| Scenery / sprite material capability | 22 / 8 |
| MAIN / AUX / total | 65536 / 16384 / 81920 |
| Additional guest backing | 0 |
| P64Fv4 source archive | 10409 bytes, MAIN84D0..AD78 |
| SVM4 / P64Z method2 | 6294 bytes, AUX02E0..1B75 |
| Active BG packet capacity | 7376 bytes |
| Largest actual packet | 7376 bytes |
| All 17 packets on disk | 53802 bytes |
| BG MAIN half-open interval | [44409, 51785] |
| Loader half-open interval | [51785, 53063] |
| ROM-call stub half-open interval | [18308, 18405] |
| LOAD workspace saved | 3838 bytes |
| Temporary existing MAIN output-plane lease | 2848 bytes |
| Temporary existing AUX lease | 990 bytes |

The contract remains **64 KiB MAIN +16 KiB AUX =81,920 bytes**, with zero additional guest backing. Code, music, fonts, TED matrices, descriptors, compressed source and materials share these bytes. Memory views are aliases, not extra pools.

Backgrounds `B01`..`B17` are stored on disk, while only the active scene packet is loaded into its MAIN slot. A scene change may pause for loading; rendering never consults a host asset catalogue or file. The recovered 8825-byte MAIN region is shared by a 7376-byte background slot, 1278 bytes of resident loader code and a 171-byte reserve; these uses are counted once. During LOAD, KERNAL workspace is temporarily saved in the declared output-matrix and AUX leases. After restoration, the constructor rebuilds the matrices and preserves source byte D798 required for scrolling. Capacity and simultaneous peak use matter, not summed disk files or ZIP/EXE size.

The timer fix checks the TED beam again after IRQ arming, avoiding a full-frame wait if the deadline has passed. P64Z1 and its stored bytes are unchanged; libdeflate 1.26 accelerates zlib decompression in the runtime. Temporary resources and decoder work are released in the same call; there is no persistent image cache.

The receipts below bind these hashes and distinguish isolated tests, actual D64 cold starts, real PC inputs and coverage limits. The native Linux build is headless for development/QA; the Linux GUI launchers use the same PE through Wine64. Wine is not native Windows or physical hardware. No completed campaign is claimed.

- `reference/receipts/final-00-FINAL_QUALIFICATION.json` — SHA256 `96250cdf2a6102cbc6f4bb513582d49db28fbf586edec0438079825512a79d56`
- `reference/receipts/final-01-MULTILOAD_BUILD.json` — SHA256 `f5e84e9c3ff4c7565bb367a9d54a38122b0ac6cdf7f8410761e66afa02d7e7be`
- `reference/receipts/final-02-PLATFORM_RELEASE_QUALIFICATION.json` — SHA256 `aff1b8007996af4506f2200bdaf02759267fb96e387e5db651d91ed937c13fdd`
- `reference/receipts/final-03-FINAL_NATIVE_QUALIFICATION.json` — SHA256 `21e9fbb6eb08d3adb13374c015cfb45d6b48daba3bad8b372a98f5dbd960c193`
- `reference/receipts/final-04-DIALOGUE_R7_QUALIFICATION.json` — SHA256 `85720133dbff747554df9b5352e63d161c084fe16f476e8e947188e222c912c5`
- `reference/receipts/final-05-PROOF.json` — SHA256 `03918618c89d488e268c39c93f6331d688ad8299fb181e7478349cdf496a9afb`
- `reference/receipts/final-06-PROOF.json` — SHA256 `a39d08621c40e35fc7b79644d02c8459751f25ca061abc146d7d0555ad255f42`
- `reference/receipts/final-07-FINAL_PACING_AUDIT.json` — SHA256 `9b5b70ef0c2bd306b6e06e427d3b7ffdbe29259dc03825236941d4f68c2e3421`
- `reference/receipts/final-08-CURATION_R7_FINAL_PROOF.json` — SHA256 `d80f7ef62d92072af7a47f2d4c7701b2f70c362e7a748ffb4219b5c44dfc3c4e`
- `reference/receipts/final-09-PROOF.json` — SHA256 `db4095eada8c7f0f126109f4d7cdbeedbbd3afce72f3d9b1318f97b055f96564`
- `reference/receipts/final-10-C_NATIVE_PROOF.json` — SHA256 `31a76c660ddb9841abd01b1405850d6fc77013d5b48db740c36b61b07bc058eb`
- `reference/receipts/final-11-R7_DELTA_PROOF.json` — SHA256 `4409c1766dc0773f4e8850b5a502e030129ed6bccaab808536eae06daa636540`
