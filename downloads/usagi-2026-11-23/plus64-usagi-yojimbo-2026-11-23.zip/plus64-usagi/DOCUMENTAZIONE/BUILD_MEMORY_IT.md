# 9. Build, memoria e prove della consegna

| Campo|Valore |
|---|---|
| Candidato | `033-approved178-r7` |
| MAIN SHA256 | `899b3a6602cadf3b46127a36fa66072710079f4e3a679e0f8de634707030ce40` |
| D64 SHA256 | `aff57ed640226d33dd54a6e85db625849841ae08a5de6e5f04966567f347a5a4` |
| Windows PE SHA256 | `f365c471d5a97476b7b58c744e66901dab9df62a09fe4878c65fc872f9c138f7` |
| Linux headless SHA256 | `c8c20d836a74a8f757371db0d278c9882930bf20289ee189a417e88bc4b184ef` |
| Capacità scenery / materiali sprite | 22 / 8 |
| MAIN / AUX / total | 65536 / 16384 / 81920 |
| RAM guest aggiuntiva | 0 |
| Archivio sorgenti P64Fv4 | 10409 byte, MAIN84D0..AD78 |
| SVM4 / P64Z method2 | 6294 byte, AUX02E0..1B75 |
| Capacità pacchetto sfondo attivo | 7376 byte |
| Pacchetto più grande | 7376 byte |
| Totale dei 17 pacchetti sul disco | 53802 byte |
| Intervallo MAIN sfondo (estremo finale escluso) | [44409, 51785] |
| Intervallo loader (estremo finale escluso) | [51785, 53063] |
| Intervallo stub chiamata ROM (estremo finale escluso) | [18308, 18405] |
| Workspace LOAD salvato | 3838 byte |
| Area temporanea nelle matrici di output MAIN | 2848 byte |
| Area temporanea nella AUX esistente | 990 byte |

Il contratto resta **64 KiB MAIN +16 KiB AUX =81.920 byte**, con zero backing guest aggiuntivo. Codice, musica, font, matrici TED, descrittori, sorgenti compressi e materiali condividono questi byte. Le viste di memoria sono alias, non ulteriori pool.

Gli sfondi `B01`..`B17` risiedono sul disco, ma soltanto il pacchetto della scena attiva viene caricato nello slot MAIN. Il cambio scena può avere una pausa di caricamento; il rendering non consulta un catalogo o file host. Gli 8825 byte recuperati nella build 032 comprendono 7376 byte per lo sfondo attivo, 1278 byte di codice residente del loader e 171 byte di riserva; queste occupazioni si contano una sola volta. Durante LOAD il workspace KERNAL viene salvato temporaneamente nelle matrici di output e nell’area AUX dichiarata; dopo il ripristino, il costruttore ricrea le matrici e conserva il byte sorgente D798 richiesto dallo scorrimento. Contano la capacità del contenitore e il suo picco simultaneo, non la somma dei file del disco o le dimensioni di ZIP/EXE.

La correzione del timer verifica nuovamente il fascio TED dopo l’armamento IRQ, evitando l’attesa di un frame se la scadenza è già trascorsa. Il formato P64Z1 e i suoi byte restano invariati; libdeflate 1.26 accelera la decompressione zlib nel runtime. Le risorse e il decoder temporanei vengono liberati nella stessa chiamata: non c’è una cache persistente di immagini.

I rapporti sotto vincolano questi hash e separano prove isolate, avvii D64, input PC reali e limiti di copertura. Il runtime Linux nativo è headless per sviluppo/QA; la GUI Linux degli avviatori usa lo stesso PE tramite Wine64. Wine non è Windows nativo né hardware fisico. Non viene dichiarata una campagna completa.

- `reference/receipts/final-00-FINAL_QUALIFICATION.json` — SHA256 `96250cdf2a6102cbc6f4bb513582d49db28fbf586edec0438079825512a79d56`
- `reference/receipts/final-01-MULTILOAD_BUILD.json` — SHA256 `f5e84e9c3ff4c7565bb367a9d54a38122b0ac6cdf7f8410761e66afa02d7e7be`
- `reference/receipts/final-02-PLATFORM_RELEASE_QUALIFICATION.json` — SHA256 `aff1b8007996af4506f2200bdaf02759267fb96e387e5db651d91ed937c13fdd`
- `reference/receipts/final-03-FINAL_NATIVE_QUALIFICATION.json` — SHA256 `21e9fbb6eb08d3adb13374c015cfb45d6b48daba3bad8b372a98f5dbd960c193`
- `reference/receipts/final-04-DIALOGUE_R7_QUALIFICATION.json` — SHA256 `85720133dbff747554df9b5352e63d161c084fe16f476e8e947188e222c912c5`
- `reference/receipts/final-05-PROOF.json` — SHA256 `03918618c89d488e268c39c93f6331d688ad8299fb181e7478349cdf496a9afb`
- `reference/receipts/final-06-PROOF.json` — SHA256 `a39d08621c40e35fc7b79644d02c8459751f25ca061abc146d7d0555ad255f42`
- `reference/receipts/final-07-FINAL_PACING_AUDIT.json` — SHA256 `9b5b70ef0c2bd306b6e06e427d3b7ffdbe29259dc03825236941d4f68c2e3421`
- `reference/receipts/final-08-CURATION_R7_FINAL_PROOF.json` — SHA256 `d80f7ef62d92072af7a47f2d4c7701b2f70c362e7a748ffb4219b5c44dfc3c4e`
- `reference/receipts/final-09-PROOF.json` — SHA256 `db4095eada8c7f0f126109f4d7cdbeedbbd3afce72f3d9b1318f97b055f96564`
- `reference/receipts/final-10-C_NATIVE_PROOF.json` — SHA256 `31a76c660ddb9841abd01b1405850d6fc77013d5b48db740c36b61b07bc058eb`
- `reference/receipts/final-11-R7_DELTA_PROOF.json` — SHA256 `4409c1766dc0773f4e8850b5a502e030129ed6bccaab808536eae06daa636540`
