from __future__ import annotations
def memory(f,lang):
 it=lang=='it';m=f['memory'];q=f['qualification'];b=f['artifacts'];rows=[
  ('Candidate',f['final_candidate']),('MAIN SHA256',b['main']),('D64 SHA256',b['D64']),
  ('Windows PE SHA256',b['windows_portable_exe']),('Linux headless SHA256',b['native_exe']),
  ('Scenery / sprite material capability','22 / 8'),('MAIN / AUX / total','65536 / 16384 / 81920'),
  ('Additional guest backing','0'),('P64Fv4 source archive','10409 bytes, MAIN84D0..AD78'),
  ('SVM4 / P64Z method2','6294 bytes, AUX02E0..1B75'),
  ('Active BG packet capacity',str(m['BG_capacity'])+' bytes'),
  ('Largest actual packet',str(f['background_max_bytes'])+' bytes'),
  ('All17 packets on disk',str(f['background_disk_bytes'])+' bytes'),
  ('BG MAIN half-open interval',str(m['BG_buffer'])),('Loader half-open interval',str(m['loader_code'])),
  ('ROM-call stub half-open interval',str(m['ROM_stub'])),
  ('LOAD workspace saved',str(m['workspace_bytes'])+' bytes'),
  ('Temporary existing MAIN output-plane lease',str(sum(r['bytes']for r in m['transient_MAIN']))+' bytes'),
  ('Temporary existing AUX lease',str(m['transient_AUX_bytes'])+' bytes')]
 title='# 9. Build, memoria e prove della consegna'if it else'# 9. Build, memory and release evidence'
 italian_labels={'Candidate':'Candidato','Additional guest backing':'RAM guest aggiuntiva','P64Fv4 source archive':'Archivio sorgenti P64Fv4',
  'Scenery / sprite material capability':'Capacità scenery / materiali sprite','Active BG packet capacity':'Capacità pacchetto sfondo attivo',
  'Largest actual packet':'Pacchetto più grande','All17 packets on disk':'Totale dei 17 pacchetti sul disco',
  'BG MAIN half-open interval':'Intervallo MAIN sfondo (estremo finale escluso)','Loader half-open interval':'Intervallo loader (estremo finale escluso)',
  'ROM-call stub half-open interval':'Intervallo stub chiamata ROM (estremo finale escluso)','LOAD workspace saved':'Workspace LOAD salvato',
  'Temporary existing MAIN output-plane lease':'Area temporanea nelle matrici di output MAIN','Temporary existing AUX lease':'Area temporanea nella AUX esistente'}
 def value(k,v):
  if 'SHA256'in k or k=='Candidate':return '`'+str(v)+'`'
  return str(v).replace(' bytes',' byte')if it else str(v)
 table='| '+('Campo|Valore'if it else'Field|Value')+' |\n|---|---|\n'+'\n'.join('| '+str(italian_labels.get(k,k)if it else k)+' | '+value(k,v)+' |'for k,v in rows)
 if it:
  body='''Il contratto resta **64 KiB MAIN +16 KiB AUX =81.920 byte**, con zero backing guest aggiuntivo. Codice, musica, font, matrici TED, descrittori, sorgenti compressi e materiali condividono questi byte. Le viste di memoria sono alias, non ulteriori pool.

Gli sfondi `B01`..`B17` risiedono sul disco, ma soltanto il pacchetto della scena attiva viene caricato nello slot MAIN. Il cambio scena può avere una pausa di caricamento; il rendering non consulta un catalogo o file host. Gli 8825 byte recuperati nella build 032 comprendono 7376 byte per lo sfondo attivo, 1278 byte di codice residente del loader e 171 byte di riserva; queste occupazioni si contano una sola volta. Durante LOAD il workspace KERNAL viene salvato temporaneamente nelle matrici di output e nell’area AUX dichiarata; dopo il ripristino, il costruttore ricrea le matrici e conserva il byte sorgente D798 richiesto dallo scorrimento. Contano la capacità del contenitore e il suo picco simultaneo, non la somma dei file del disco o le dimensioni di ZIP/EXE.

La correzione del timer verifica nuovamente il fascio TED dopo l’armamento IRQ, evitando l’attesa di un frame se la scadenza è già trascorsa. Il formato P64Z1 e i suoi byte restano invariati; libdeflate1.26 accelera la decompressione zlib nel runtime. Le risorse e il decoder temporanei vengono liberati nella stessa chiamata: non c’è una cache persistente di immagini.

I rapporti sotto vincolano questi hash e separano prove isolate, avvii D64, input PC reali e limiti di copertura. Il runtime Linux nativo è headless per sviluppo/QA; la GUI Linux degli avviatori usa lo stesso PE tramite Wine64. Wine non è Windows nativo né hardware fisico. Non viene dichiarata una campagna completa.
'''
 else:
  body='''The contract remains **64 KiB MAIN +16 KiB AUX =81,920 bytes**, with zero additional guest backing. Code, music, fonts, TED matrices, descriptors, compressed source and materials share these bytes. Memory views are aliases, not extra pools.

Backgrounds `B01`..`B17` are stored on disk, while only the active scene packet is loaded into its MAIN slot. A scene change may pause for loading; rendering never consults a host asset catalogue or file. The recovered 8825-byte MAIN region is shared by a 7376-byte background slot, 1278 bytes of resident loader code and a 171-byte reserve; these uses are counted once. During LOAD, KERNAL workspace is temporarily saved in the declared output-matrix and AUX leases. After restoration, the constructor rebuilds the matrices and preserves source byte D798 required for scrolling. Capacity and simultaneous peak use matter, not summed disk files or ZIP/EXE size.

The timer fix checks the TED beam again after IRQ arming, avoiding a full-frame wait if the deadline has passed. P64Z1 and its stored bytes are unchanged; libdeflate1.26 accelerates zlib decompression in the runtime. Temporary resources and decoder work are released in the same call; there is no persistent image cache.

The receipts below bind these hashes and distinguish isolated tests, actual D64 cold starts, real PC inputs and coverage limits. The native Linux build is headless for development/QA; the Linux GUI launchers use the same PE through Wine64. Wine is not native Windows or physical hardware. No completed campaign is claimed.
'''
 receipts='\n'.join('- `'+r['name']+'` — SHA256 `'+r['sha256']+'`'for r in f['receipts'])
 note=''
 if not f.get('overall_release_qualified',False):
  note=('**Identità del candidato vincolate; aggregato finale delle prove ancora da completare.** La grafica178 è approvata; questa edizione documentale non sostituisce la qualifica complessiva del gioco.\n\n'if it else'**Candidate identities are bound; the final evidence aggregate is not yet complete.** Artwork178 is approved; this document edition does not replace overall game qualification.\n\n')
 return title+'\n\n'+note+table+'\n\n'+body+'\n'+receipts+'\n'
