Usagi Yojimbo per plus/64 — 23 novembre 2026

La revisione comprende personaggi, ritratti, schermate iniziali, menu e sfondi con le colorazioni approvate. Negli interni sono stati corretti i quadratini accanto alle porte; la fascia superiore mantiene la stessa trama con quadratini più scuri. Le panche hanno sfumature del legno e le loro ombre scuriscono le righe del pavimento senza cancellarle.

F5 seleziona italiano o inglese. Il disco è lo stesso per i profili C16 e Plus/4. Il limite della memoria guest resta di 81.920 byte: 64 KiB + 16 KiB complessivi. I dati colore della sola scena attiva sono caricati dal disco quando si cambia scena.

Sono inclusi il manuale tecnico completo in italiano e inglese, i sorgenti corrispondenti dell'emulatore e i dati grafici modificabili con gli strumenti di ricostruzione. Il launcher Linux usa Wine; l'eseguibile Linux headless è uno strumento per sviluppatori.

La qualifica finale e gli hash dei file distribuiti sono riportati nei rapporti inclusi nel pacchetto. Le prove con Wine sono distinte dalle prove Windows native e da quelle su hardware fisico.
