# Usagi Yojimbo — 2026-11-23

Porting Usagi Yojimbo plus/64 con grafica approvata, stessa memoria64+16KiB su C16 e Plus/4.

Personaggi e sfondi approvati, inclusi reticoli superiori scuri, panche sfumate e ombre che conservano la trama del pavimento.

Estrarre tutto lo ZIP in una nuova cartella scrivibile. Avviare AVVIA_USAGI.cmd (C16) oppure AVVIA_USAGI_PLUS4.cmd (Plus/4). Entrambi usano lo stesso disco. Non avviare i singoli PRG interni: il disco contiene USAGI, ASSETS, MAIN e i17pacchetti B01..B17.

Linux: AVVIA_USAGI_LINUX.sh oppure AVVIA_USAGI_PLUS4_LINUX.sh usa lo stesso eseguibile Windows tramite Wine64, da installare separatamente. Non è una GUI Linux nativa. L’eventuale xplus4-headless in STRUMENTI_SVILUPPO_LINUX è uno strumento di sviluppo/QA, non l’avviatore per giocare.

Frecce e Spazio: joystick porta2. In modalità tastiera: Q=su, P=destra, I=sinistra, Z=giù, Spazio=fire. F1 seleziona GAME/PRACTICE, F3 joystick/tastiera, F5 inglese/italiano, F7 o FIRE avvia. In gioco F1 torna al menu e F7 mette in pausa: rilasciare, premere e rilasciare per riprendere. Il trainer è rimosso; PRACTICE appartiene al gioco originale.

Il budget guest resta64KiB MAIN +16KiB AUX =81920byte, senza RAM aggiuntiva. I dati dello sfondo attivo vengono caricati dal disco al cambio scena: può esserci una pausa di caricamento. La somma dei file del disco non è RAM simultaneamente residente.

DOCUMENTAZIONE contiene il manuale tecnico completo per programmare plus/64, in italiano e inglese, PDF/HTML, sorgenti ed esempi. SORGENTI contiene una sola copia dei sorgenti corrispondenti VICE e del gioco, licenze e ricetta di ricostruzione. Il D64 originale fornito come input è incluso nei sorgenti per il controllo della ricostruzione e mantiene crediti e diritti dei suoi autori. Sono documentate prove Linux e Windows tramite Wine, non Windows nativo, hardware fisico o una campagna completa.
