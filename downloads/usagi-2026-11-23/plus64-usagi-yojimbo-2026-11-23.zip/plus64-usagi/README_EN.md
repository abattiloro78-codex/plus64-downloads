# Usagi Yojimbo — 2026-11-23

Usagi Yojimbo plus/64 port with approved artwork and the same64+16KiB memory on C16 and Plus/4.

Approved characters and backgrounds, including darker upper-wall squares, shaded benches and shadows that preserve the floor pattern.

Extract the complete ZIP into a new writable directory. Start AVVIA_USAGI.cmd (C16) or AVVIA_USAGI_PLUS4.cmd (Plus/4). Both use the same disk. Do not launch individual internal PRGs: the disk contains USAGI, ASSETS, MAIN and17 B01..B17 packets.

Linux: AVVIA_USAGI_LINUX.sh or AVVIA_USAGI_PLUS4_LINUX.sh uses the same Windows executable through separately installed Wine64. This is not a native Linux GUI. The optional STRUMENTI_SVILUPPO_LINUX/xplus4-headless is a development/QA tool, not the player launcher.

Arrow keys and Space: joystick port2. Keyboard mode: Q=up, P=right, I=left, Z=down, Space=fire. F1 selects GAME/PRACTICE, F3 joystick/keyboard, F5 English/Italian, F7 or FIRE starts. In gameplay F1 returns to the menu and F7 pauses: release, press and release to resume. The trainer is removed; PRACTICE is part of the original game.

The guest budget remains64KiB MAIN +16KiB AUX =81920bytes, with no extra RAM. Active-background data is loaded from disk at a scene change, with a possible loading pause. The sum of disk files is not simultaneously resident RAM.

DOCUMENTAZIONE contains the full technical plus/64 programming manual in Italian and English, PDF/HTML, editable sources and examples. SORGENTI contains corresponding VICE and game source once, licences and a rebuild recipe. The supplied original D64 is included as a checked rebuild input and retains its authors’ credits and rights. Evidence covers Linux and Windows through Wine, not native Windows, physical hardware or a completed campaign.
