USAGI YOJIMBO R8 - WINDOWS TEST PROFILE
23 November 2026

1. Close the game.
2. Extract these files into the R8 folder containing xplus4.exe and
   USAGI.D64. There is no need to download the whole game again.
3. Run AVVIA_USAGI_FLUIDO.cmd.
   AVVIA_USAGI_PLUS4_FLUIDO.cmd uses the same profile with the Plus/4 model.
4. In the menu press F1 to select GAME, wait a moment, then press F7.
   Game controls are the same as in R8.

This profile selects SDL audio, disables the CRT filter and video VSync wait,
and requests normal speed at 100%. Pixels look sharper without CRT simulation.
The game retains its 64+16 KiB memory budget.

Both launchers were checked with the original R8 Windows executable through
Wine: cold startup, GAME selection and ordinary movement passed. The test
environment uses a simulated audio device. A test on your Windows PC is
needed to establish whether this resolves the reported slowdown.

These files add a launch profile. To return to the previous profile, close
the game and run the R8 AVVIA_USAGI.cmd or AVVIA_USAGI_PLUS4.cmd launcher.
