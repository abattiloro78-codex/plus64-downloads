#!/bin/sh
set -eu
cd -- "$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
if command -v wine64 >/dev/null 2>&1; then runtime_wine=wine64
elif command -v wine >/dev/null 2>&1; then runtime_wine=wine
else printf '%s\n' 'Wine64 richiesto / Wine64 is required.'; exit 1; fi
runtime_keymap=$("$runtime_wine" winepath.exe -w "$PWD/usagi.vkm" | tr -d '\r')
exec "$runtime_wine" ./xplus4.exe -default -model c16 -ramsize 16 -directory . -kernal kernal-318004-05.bin -plus64 -plus64mainram -plus64packedcache -plus64leftmcm -plus64mixedsprites -plus64rastercollisions -symkeymap "$runtime_keymap" -keymap 2 -controlport2device 1 -joydev2 2 -drive8type 1541 +drive8truedrive -trapdevice8 -busdevice8 -sound -soundbufsize 64 -sidenginemodel 256 -sidcartaddress 0xFD40 -sidcartclock 0 -autostart USAGI.D64 "$@"
