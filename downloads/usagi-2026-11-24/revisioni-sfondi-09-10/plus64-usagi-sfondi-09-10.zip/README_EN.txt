Usagi Yojimbo plus/64 — backgrounds 09 and 10 review — 24 November 2026

GAME-ONLY UPDATE
Replace USAGI.D64 in the current plus/64 release folder. Use the recent
scenery23-compatible emulator already supplied. No new executable is
needed. Start a new game (F1: GAME, then F7).

09: opaque black undergrowth shadows between trunks now use dark green.
10: all 12 trees use the exact approved scene01 materials.
Flowers, real branch openings, other scenes and sprites are unchanged.
The farmer005 coherent sprite-cache corrections remain included.

Guest memory: 64 KiB MAIN + 16 KiB AUX = 81,920 bytes. B09: 4,762 bytes;
B10: 2,703 bytes in the existing 7,376-byte buffer. No extra guest RAM.

SOURCE_GAME supplies editable artwork, drivers and explicit binary inputs.
Offline rebuild requires Python3.12+ and xa2.4.1:
python3 -S SOURCE_GAME/rebuild_final.py --xa /path/to/xa --output /tmp/usagi-build
Use a new output directory. Original licences and port inputs are retained;
this is not a claim to supply the game's original assembly source.
The emulator and its sources are distributed separately.

PROOFS records this revision's focused C-renderer, forward-rebuild and
20-file disk checks. Main is identical to farmer005; its earlier bounded
qualification is included as historical context. This is not another full
campaign, native Windows or physical-hardware test. No trainer, save state
or executable is included.
