# Ricostruzione della versione RAM80 approvata

Da Linux o WSL servono CPython3.12+ e xa2.4.1. Tutti i dati necessari sono
locali; l'assemblatore viene scelto dal sistema o dall'argomento `--xa`.

```sh
python3 rebuild_final.py --xa /percorso/xa --output /tmp/usagi-build
```

La directory di output deve essere nuova. `boot/USAGI.D64` contiene i20file
`USAGI`, `ASSETS`, `MAIN`, `B01`…`B17`. Il bootstrapPRG si avvia dal disco.

Il comando ricostruisce i17sfondi daiJSON modificabili in `art/backgrounds`,
il programmaSVM4 e il source bankP64Fv4 daiJSON di `art`, quindi assembla
caricatore e scheduler, prepara i tre file iniziali e tutti17packet di scena.
Le impronte finali vengono confrontate con `EXPECTED_FINAL.json` e registrate
in `REBUILD_PROOF.json`. LaVM reale è `sprite_vm.method2.p64z`,6294byte;
il risultato7197byte resta disponibile per il metodo1 di compatibilità.

Gli otto file in `inputs/baseline-032` sono l'input binario e i metadati del
port già realizzato. La sua immagineMain ha una guardiaSHA256. Il kit rende
esplicito questo input insieme ai nuovi sorgenti grafici, ai generatori e al
codice6502 del caricatore033. Il fileD64 originale incluso in `art/input`
verifica la provenienza dei342stream grafici C64, con le due rimappature
approvate elencate nei dati. I sorgenti dell'emulatore sono forniti separatamente.

Le regole di memoria restano64KiBMain+16KiBAUX=81920byte. I17packet non sono
residenti insieme: il cambio scenario carica soltanto quello attivo, nel
buffer7376byte. Il codice del caricatore usa1278byte dei1449riservati; gli
adattatori della camera grafica usano74byte, inclusi4byte di stato per le
due matrici video. La stessa area contiene anche i12byte già usati dal
caricatore per salvare il trampolino OS; restano85byte liberi. I file sul disco e i file di lavoro del
compilatore sono dati di distribuzione e sviluppo.

Per studiare i colori, partire da `art/sprites/sprite_vm.json` e
`art/backgrounds/recipes/sceneNN.json`. I relativi assemblatori hanno opzioni
per compilare dati modificati; il comando di riproduzione qui sopra mantiene
le verifiche della versione approvata. Nuovi dati vanno collegati rispettando
gli indirizzi, le capacità e le verifiche descritte nel manuale tecnico.

Il builder applica inoltre due correzioni con guardie sui byte precedenti,
leggibili in `drivers`: il selettore dei colori degli sprite legge l’indice
originale dell’attore in `$43` (l’ordine delle coppie cache è `0,4,6,2`);
il secondo modello originale del ponte riceve gli stessi marcatori del
corrimano anteriore degli altri ponti. La prima correzione cambia cinque byte
di codice e aggiunge un ciclo CPU per ricostruzione dell’attore; la seconda
cambia quindici byte dei dati. Nessuna aggiunge RAM guest o modifica le
collisioni. `GAME_FIXES_BUILD.json` registra gli interventi.

La correzione del sentiero finale usa `drivers/background_camera.asm` e
`patch_background_camera.py`: ogni matrice video mantiene il proprio
contatore grafico, indipendente da `$A4/$A5`, `$A8/$A9` e dal futuro fine
scroll `$BB`. Prima di cambiare matrice, il gioco prepara completamente
il contatore della matrice successiva; il selettore TED pubblica poi la
matrice e il relativo puntatore usando lo stesso valore. Il fine scroll
effettivo viene applicato dal flag generico native-origin di **scenery23**.
L'adattatore del cambio matrice conserva X/Y e il risultato originale di
A/P. La correzione camera lascia invariati i dati grafici.
`BACKGROUND_CAMERA_BUILD.json` registra indirizzi, guardie e occupazione.

Il primo scenario include gli alberi approvati e la correzione di 728 pixel
neri sulle punte dei pini e negli angoli delle chiome. Il rispettivo packet
B01 occupa4018byte. Il riferimento storico è conservato in
`SOURCE_ROUNDTRIP_PARENT_PATH_CAMERA.json`. La revisione seguente cambia
soltanto gli sfondi09 e10 rispetto alla versione contadini005.
`drivers/patch_grass_palette.py` imposta la rampaC21 esistente con sei
luminanze TED effettive del verde: `$15,$25,$35,$45,$55,$65`, dal più scuro
in alto al più chiaro in basso. Ogni fascia è schiarita di una luminanza
rispetto alla revisioneL0..L5, conservando posizione e spessore delle fasce.
La guardia verifica il Main dopo la correzione camera, l'unicità della
palette e i due nodiC21. `GRASS_BUILD.json` registra i quattro byte diversi
rispetto all'input binario dopo la correzione camera; nessuna istruzione o
allocazione RAM viene aggiunta.

### Correzione cache delle pose specchiate

`drivers/mirror_cache.asm` e `patch_mirror_cache.py` aggiornano la cache di orientamento anche quando cambia il pezzo sorgente. I tre trampolini occupano 30 byte già liberi in MAIN `$CF8D..$CFAB`, senza nuova RAM né cambiamenti a sprite, AI, spawn o prestito di colonne. `MIRROR_CACHE_BUILD.json` registra la fase iniziale della correzione (14 cicli aggiuntivi per pezzo realmente decodificato); `PUBLISHER_MIRROR_BUILD.json` registra il successivo wrapper di upload (68 cicli per upload) e le invalidazioni. Le qualifiche CPU/C e le prove di partita sono separate; il solo aggiornamento della cache non risolveva la pubblicazione interrotta di una posa.

### Pubblicazione coerente delle pose

`publisher_mirror.asm`, `publisher_validate.asm` e `patch_publisher_mirror.py` gestiscono le interruzioni della ricostruzione originale fra un pezzo e il successivo. La pubblicazione usa la direzione del relativo attore originale (`$62[attore]&1`) e una cache di quattro tag che includono direzione e larghezza. Un tag invariato richiede 193 cicli e nessuna scrittura AUX; un controllo completo è limitato a due o tre colonne. Chiave255, upload di un pezzo e cambio di proprietario invalidano la cache. Il publisher non marca pronto il tag mentre l'upload è in corso o se un binding/formato non coincide. Ogni scrittura verifica formatoC8, binding e modo2 e cambia soltanto il bit di specchiatura, preservando frameID, directory, chiavi e grafica.

Il vecchio publisher generico del gioco, non più raggiungibile dal bridge attuale, fornisce la lease `$F8FB..$FA20`; l'inizializzazione precedente e `us_set_colours` restano intatti. Il validatore e 15 byte privati di scratch/cache usano la precedente area di staging CPU `$0B00..$0B40`, che il decoderC8 non legge o scrive. Il wrapper usa il padding `$47E5..$480E` dopo lo stub KERNAL; l'invalidatore usa `$CFD2..$CFE5` tra i due stati camera. Le prove delle lease sono incluse; i descrittori cielo `$DFCA..$DFDE` sono preservati. Nessuna nuova memoria o modifica al decoder del plus/64. `PUBLISHER_MIRROR_BUILD.json` e le qualifiche CPU/C/cold documentano separatamente il risultato.

### Revisione sfondi09 e10 — 24 novembre 2026

Nel boschetto09 le ombre opache nere fra i tronchi usano due toni di verde
scuro; le aperture reali fra i rami restano trasparenti. I12alberi dello
sfondo10 usano esattamente i materiali approvati dello sfondo01, compresi
tronchi e ombre dei rami. Fiori e altri elementi restano identici.

B09 occupa4762byte e B10 occupa2703byte nel buffer esistente7376byte.
I restanti15packet, Main, sprite, VM, AUX e codice sono identici alla
versione contadini005. Le verifiche di questa revisione riguardano renderC
e byte dei dati; non costituiscono una nuova partita completa o una prova
Windows nativa. `SOURCE_ROUNDTRIP_PARENT_SCENES09_10.json` conserva il
riferimento precedente e `SCENE09_REVIEW_PROOF.json`/`SCENE10_REVIEW_PROOF.json`
descrivono le verifiche dei rispettivi dati grafici. Memoria guest invariata:
64KiBMain+16KiBAUX=81920byte.
