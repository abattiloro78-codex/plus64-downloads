# Rebuilding the approved RAM80 version

Linux or WSL requires CPython3.12+ and xa2.4.1. Every data input is local;
the assembler is selected from the system or through `--xa`.

```sh
python3 rebuild_final.py --xa /path/to/xa --output /tmp/usagi-build
```

Use a new output directory. `boot/USAGI.D64` contains20files: `USAGI`,
`ASSETS`, `MAIN`, and `B01`…`B17`. Launch the bootstrapPRG from that disk.

The command rebuilds all17backgrounds from editableJSON, theSVM4 program and
theP64Fv4 source bank, then assembles the033 loader and scheduler and builds
the complete disk. Final hashes are checked against `EXPECTED_FINAL.json`
and recorded in `REBUILD_PROOF.json`. The actualVM is the6294-byte
`sprite_vm.method2.p64z`; the7197-byte output remains available for method1
compatibility.

The eight files in `inputs/baseline-032` are explicit binary and metadata
inputs from the existing port. ItsMain image is SHA256 guarded. This kit
supplies that input, new readable artwork sources, generators and0336502
loader code. The originalD64 in `art/input` verifies the provenance of all342
C64 graphic streams, including the two approved remappings listed in the
source data. Emulator sources are supplied separately.

Guest memory remains64KiBMain+16KiBAUX=81920bytes. Only the active scene packet
is loaded into the7376-byte buffer. Loader code uses1278of its1449reserved
bytes. Background camera adapters use another74bytes, including4state bytes
for the two source matrices. The lease also contains12bytes already used by
the loader to save the OS trampoline;85bytes remain free. Disk and compiler work files are
distribution and development data.

For artwork study, start with `art/sprites/sprite_vm.json` and
`art/backgrounds/recipes/sceneNN.json`. Their assemblers support edited data;
the reproduction command above keeps all approved-release checks enabled.
Link edited data within the addresses, capacities and checks documented in
the technical manual.

The forward builder also applies two guarded, fixed-size corrections from readable
source in `drivers`: the sprite colour selector reads the original actor index
at `$43` (the cache-pair order is `0,4,6,2`), and the second original bridge
template receives the same front-rail markers as the other bridges. The actor
patch changes five code bytes and adds one CPU cycle per actor reconstruction;
the bridge patch changes fifteen asset bytes. Neither adds guest RAM or changes
collision geometry. `GAME_FIXES_BUILD.json` records these edits.

The final-path correction is implemented in `drivers/background_camera.asm`
and `patch_background_camera.py`. Each source matrix has its own background
camera word, independent of `$A4/$A5`, `$A8/$A9` and the future fine-scroll
value `$BB`. Before flipping matrices, the game fully prepares the future
matrix word. The TED selector then publishes the matrix and its camera
pointer using the same value. The generic native-origin flag of **scenery23**
applies the actual source fine scroll. The flip adapter preserves X/Y and
the original A/P result. Reviewed artwork data is unchanged.
`BACKGROUND_CAMERA_BUILD.json` records guarded patches,
addresses and allocation.

The first scene includes the approved trees and the correction of 728 black
pixels on pine branches and broadleaf corners. Its B01 packet is4018bytes;
all other16packets match the preserved reference in
`SOURCE_ROUNDTRIP_PARENT_PATH_CAMERA.json`. `drivers/patch_grass_palette.py`
sets the existing C21 ramp to six actual TED luminances of the same green:
`$15,$25,$35,$45,$55,$65`, darkest at the top and lightest at the bottom.
Each band is one luminance brighter than theL0..L5 revision, with band
positions and widths unchanged. The guard checks the post-camera Main,
the unique palette and both C21 nodes. `GRASS_BUILD.json` records the four
bytes that differ from the post-camera binary input; no instructions or
RAM allocations are added.

### Mirrored-pose cache correction

`drivers/mirror_cache.asm` and `patch_mirror_cache.py` update the orientation cache even when the source piece changes. Three trampolines occupy 30 already-free MAIN bytes at `$CF8D..$CFAB`, without new RAM or changes to artwork, AI, spawning, or column borrowing. `MIRROR_CACHE_BUILD.json` records this initial correction (14 additional cycles per actually decoded piece); `PUBLISHER_MIRROR_BUILD.json` records the subsequent upload wrapper (68 cycles per upload) and invalidations. CPU/C and gameplay qualification are separate; cache bookkeeping alone did not fix interrupted pose publication.

### Coherent pose publication

`publisher_mirror.asm`, `publisher_validate.asm`, and `patch_publisher_mirror.py` handle interruption of the original reconstruction between source pieces. Publication uses the corresponding original actor direction (`$62[actor]&1`) and four cached tags containing direction and width. An unchanged tag takes 193 cycles and performs no AUX writes; a full check is bounded to two or three columns. Key255, source uploads, and owner changes invalidate the cache. Publication never stamps a tag while an upload is busy or a binding/format check fails. Each write checks C8 format, exact binding, and mode2, and changes only the mirror bit while preserving frame IDs, directories, keys, and artwork.

The legacy generic game publisher, unreachable from the current bridge, supplies lease `$F8FB..$FA20`; preceding initialization and `us_set_colours` remain intact. The validator and 15 private scratch/cache bytes use the former CPU staging lease `$0B00..$0B40`, which the C8 source decoder neither reads nor writes. The upload wrapper uses padding `$47E5..$480E` after the KERNAL stub; the invalidator uses `$CFD2..$CFE5` between the camera state words. Lease evidence is included; sky descriptors `$DFCA..$DFDE` are preserved. There is no additional memory or plus/64 decoder change. `PUBLISHER_MIRROR_BUILD.json` and separate CPU/C/cold qualification document the result.
