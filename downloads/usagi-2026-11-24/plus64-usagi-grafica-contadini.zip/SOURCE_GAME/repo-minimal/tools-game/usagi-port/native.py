"""Linking utilities and the ordinary CPU upload for a RAM80 development run.

The development monitor loads source bytes explicitly; this is not the final
D64/KERNAL boot path. Auxiliary data reaches its backing through FD96, using
guest 6502 instructions. No additional emulated RAM is introduced.
"""
from __future__ import annotations

import subprocess
from pathlib import Path


def compile_xa(source: str, out: Path, name: str, *, xa: Path) -> tuple[bytes, dict[str, int]]:
    assembly = out / (name + ".asm")
    binary = out / (name + ".bin")
    labels_file = out / (name + ".labels")
    assembly.write_text(source)
    subprocess.run([str(xa), "-C", "-o", str(binary), "-l", str(labels_file),
                    str(assembly)], check=True, capture_output=True, text=True)
    labels = {}
    for line in labels_file.read_text().splitlines():
        parts = line.split(",")
        if len(parts) > 1:
            try:
                labels[parts[0].strip()] = int(parts[1].strip().replace("$", "0x"), 0)
            except ValueError:
                continue
    return binary.read_bytes(), labels


def upload_source(auxiliary: bytes, *, data_origin: int | None = None,
                  low_memory: bytes | None = None,
                  materials: bytes | None = None, low_tail: bytes = b'') -> str:
    """Upload the two preserved 4-KiB asset banks to auxiliary $2000..$3FFF.

    Staging is in main RAM only before the complete cold main image is loaded.
    The live game's decoded sprite caches later replace this staging. It is
    not an extra copy retained outside the 81920-byte memory model.
    Optional materials occupy auxiliary$0E00..$1FFF, outside cold low restore.
    Their extra page loops select a default$1400 data origin; without materials
    the generated source and default$1300 origin remain unchanged.
    An optional low_tail of at most149 constant bytes follows the thirteen
    low pages in the same backing; it adds no retained transport buffer.
    """
    if len(auxiliary) != 8192:
        raise ValueError("D and F source banks must occupy exactly 8192 bytes")
    if len(low_tail) > 149:
        raise ValueError('Low metadata tail must fit the finalizer data-prefix contract')
    from boot_materials import MATERIAL_START, MATERIAL_SIZE, validate_materials
    validate_materials(materials)
    if data_origin is None:
        data_origin = 0x1400 if materials is not None else 0x1300
        # Longer read-only metadata prefixes require more cold upload code,
        # not more retained RAM. Preserve the old layout for <=16 bytes.
        data_origin += ((max(0, len(low_tail)-16)*5 + 255)//256)*256
    lines = ["*=$1100", "upload_entry:", " sei", " cld", " ldx #$ff", " txs",
             " lda #0", " sta $fd90", " sta $ff0a", " sta $ff3f",
             " sta $fd97", " lda #$20", " sta $fd98", " ldx #0"]
    for page in range(32):
        lines += [f"upload_page_{page}:", f" lda ${data_origin + 256 * page:04x},x",
                  " sta $fd96", " inx", f" bne upload_page_{page}"]
    if low_memory is not None:
        if len(low_memory) != 0xD00:
            raise ValueError("Cold low-memory staging must cover $0200..$0EFF")
        lines += [" lda #0", " sta $fd97", " sta $fd98"]
        for page in range(13):
            lines += [f"upload_low_page_{page}:",
                      f" lda ${data_origin + 8192 + 256*page:04x},x",
                      " sta $fd96", " inx", f" bne upload_low_page_{page}"]
        for value in low_tail:
            lines += [f' lda #${value:02x}', ' sta $fd96']
    elif low_tail:
        raise ValueError('Low metadata tail requires low-memory transport')
    if materials is not None:
        source = data_origin + len(auxiliary) + len(low_memory or b"")
        lines += [" lda #0", " sta $fd97", f" lda #${MATERIAL_START >> 8:02x}",
                  " sta $fd98"]
        for page in range(MATERIAL_SIZE // 256):
            lines += [f"upload_material_page_{page}:",
                      f" lda ${source + 256*page:04x},x",
                      " sta $fd96", " inx", f" bne upload_material_page_{page}"]
    # Unroll only page selection, not each byte. The selected data origin leaves
    # room for the loops; the assembler rejects an explicit overlapping origin.
    lines += ["upload_done:", " jmp upload_done",
              f" .dsb ${data_origin:04x}-*,0", "upload_data:"]
    payload = auxiliary + (low_memory or b"") + (materials or b"")
    for offset in range(0, len(payload), 24):
        lines.append(" .byt " + ",".join(f"${v:02x}" for v in payload[offset:offset + 24]))
    return "\n".join(lines) + "\n"


def install(image: bytearray, code: bytes, origin: int, end: int, *, name: str) -> dict:
    """Install only in a caller-approved code interval, never silently spill."""
    if not 0 <= origin < end <= 65536 or origin + len(code) > end:
        raise ValueError(f"{name} exceeds approved allocation ${origin:04X}..${end:04X}")
    image[origin:origin + len(code)] = code
    return {"name": name, "start": origin, "end_exclusive": origin + len(code),
            "bytes": len(code), "reserved_end_exclusive": end}
