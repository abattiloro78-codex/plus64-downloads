"""Cold-only LZ upload into the existing auxiliary material interval.

The grammar is boot.py's absolute16 stream with a logical output origin of
$0F00. Matches read already produced bytes through FD96; output occupies
$0E00..$1FFF. There is no resident history array or second asset pool.
"""
from __future__ import annotations

MATERIAL_START = 0x0E00
MATERIAL_SIZE = 0x1200
MATERIAL_END = MATERIAL_START + MATERIAL_SIZE
HELPER_ORIGIN = 0x0520


def validate_materials(materials: bytes | None) -> None:
    if materials is not None and len(materials) != MATERIAL_SIZE:
        raise ValueError("Materials must cover auxiliary $0E00..$1FFF exactly (4608 bytes)")


BANK_HELPER_ORIGIN = HELPER_ORIGIN + 4


def decoder_source(stream_start: int, stream_size: int, *,
                   bank_stream: tuple[int, int] | None = None,
                   split_at: int | None = None, resume_at: int | None = None) -> str:
    """Cold CPU upload with optional shared decoding of original8KiB banks.

    Entry0520 uploads materials; entry0524 uploads the optional banks. The
    bootstrap owns both calls, masked IRQs and disabled FD90. Match addresses
    are translated from codec-origin0F00 into the chosen auxiliary interval.
    """
    if (split_at is None) != (resume_at is None):
        raise ValueError("A split material stream needs both physical boundaries")
    first_size = stream_size if split_at is None else split_at - stream_start
    if not 0 < first_size <= stream_size:
        raise ValueError("Invalid split material stream")
    end = (stream_start + stream_size if split_at is None
           else resume_at + stream_size - first_size)
    if not 0x1001 <= stream_start < end <= 0xFD00:
        raise ValueError("Material stream must fit the cold main-RAM transport")
    bank_start, bank_end = ((0, 0) if bank_stream is None else
                            (bank_stream[0], sum(bank_stream)))
    source = f"""*=${HELPER_ORIGIN:04x}
bm_decode:
 ldx #1
 bne bm_init
bm_banks:
 ldx #0
bm_init:
 sei
 cld
 lda bm_source_lo,x
 sta $f7
 lda bm_source_hi,x
 sta $f8
 lda bm_source_end_lo,x
 sta bm_end_lo+1
 sta bm_get_end_lo+1
 lda bm_source_end_hi,x
 sta bm_end_hi+1
 sta bm_get_end_hi+1
 lda bm_dest_start,x
 sta $fa
 sta bm_match_min+1
 lda bm_dest_end,x
 sta bm_output_end+1
 sta bm_put_end+1
 lda bm_history_delta,x
 sta bm_delta+1
 lda #0
 sta $f9
 lda #1
 sta $fd
 ldy #0
bm_token:
 lsr $fd
 bne bm_flag
 jsr bm_get
 sec
 ror
 sta $fd
bm_flag:
 bcc bm_literal
 jsr bm_get
 sta $fb
 jsr bm_get
 clc
bm_delta:
 adc #0
 sta $fc
bm_match_min:
 cmp #0
 bcc bm_bad
 cmp $fa
 bcc bm_match_valid
 bne bm_bad
 lda $fb
 cmp $f9
 bcs bm_bad
bm_match_valid:
 jsr bm_get
 tax
 jsr bm_copy
 jsr bm_copy
 jsr bm_copy
 txa
 beq bm_after
bm_match:
 jsr bm_copy
 dex
 bne bm_match
 jmp bm_after
bm_literal:
 jsr bm_get
 jsr bm_put
bm_after:
 lda $fa
bm_output_end:
 cmp #0
 bne bm_token
 lda $f9
 bne bm_bad
 lda $f7
bm_end_lo:
 cmp #0
 bne bm_bad
 lda $f8
bm_end_hi:
 cmp #0
 bne bm_bad
 rts
bm_get:
"""
    if split_at is not None:
        if split_at & 255 or resume_at & 255:
            raise ValueError("Split boundaries must be page aligned")
        source += f""" lda $f8
 cmp #>{split_at}
 bne bm_get_bounds
 lda $f7
 bne bm_get_bounds
 lda #>{resume_at}
 sta $f8
bm_get_bounds:
"""
    source += f""" lda $f8
bm_get_end_hi:
 cmp #0
 bcc bm_fetch
 bne bm_bad
 lda $f7
bm_get_end_lo:
 cmp #0
 bcs bm_bad
bm_fetch:
 lda ($f7),y
 inc $f7
 bne bm_got
 inc $f8
bm_got:
 rts
bm_copy:
 lda $fb
 sta $fd97
 lda $fc
 sta $fd98
 lda $fd96
 jsr bm_put
 inc $fb
 bne bm_copied
 inc $fc
bm_copied:
 rts
bm_put:
 pha
 lda $fa
bm_put_end:
 cmp #0
 bcs bm_bad
 sta $fd98
 lda $f9
 sta $fd97
 pla
 sta $fd96
 inc $f9
 bne bm_put_done
 inc $fa
bm_put_done:
 rts
bm_bad:
 sei
 lda #$32
 sta $ff19
bm_stop:
 jmp bm_stop
bm_source_lo:
 .byt ${bank_start & 255:02x},${stream_start & 255:02x}
bm_source_hi:
 .byt ${bank_start >> 8:02x},${stream_start >> 8:02x}
bm_source_end_lo:
 .byt ${bank_end & 255:02x},${end & 255:02x}
bm_source_end_hi:
 .byt ${bank_end >> 8:02x},${end >> 8:02x}
bm_dest_start:
 .byt $20,$0e
bm_dest_end:
 .byt $40,$20
bm_history_delta:
 .byt $11,$ff
"""
    for opcode, inverse in (("bcc", "bcs"), ("bcs", "bcc"), ("bne", "beq")):
        source = source.replace(f" {opcode} bm_bad", f" {inverse} *+5\n jmp bm_bad")
    # The split/configuration options can move the backwards token branch.
    source = source.replace(" bne bm_token", " beq *+5\n jmp bm_token")
    return source
