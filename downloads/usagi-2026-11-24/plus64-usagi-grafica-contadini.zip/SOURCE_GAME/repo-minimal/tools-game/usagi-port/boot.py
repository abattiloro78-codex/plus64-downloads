#!/usr/bin/env python3
"""Build a self-contained ordinary-KERNAL Usagi PRG and D64 within RAM80.

Transport and compressed input occupy the existing main64KiB before gameplay.
The decoder reuses output as LZ history. It never allocates another guest RAM
pool. Auxiliary assets arrive through guest CPU writes toFD96; I/O-underlay
main-RAM tail bytes are copied through the aliasing SRAM portFDEA.
"""
from __future__ import annotations
import argparse
from collections import defaultdict, deque
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import zipfile
sys.dont_write_bytecode = True
from native import compile_xa

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
ORIGIN, END = 0x0F00, 0xFD00
TAIL_SOURCE, AUX_SOURCE = 0x1200, 0x1500
DECODER_SOURCE, FINAL_SOURCE, HEADER_END = 0x3500, 0x3800, 0x3900
INPUT_TAIL, INPUT_CACHE = 0xF500, 0x0700
LOW_SOURCE, LOW_SIZE, LOW_HEADER_END = 0x3900, 0x0D00, 0x4600


def sha(data: bytes | bytearray) -> str:
    return hashlib.sha256(data).hexdigest()


def encode(data: bytes) -> tuple[bytes, dict]:
    """Absolute16 LZ grammar used by the existing cold loader, greedy parse.

    Flag bits are low-bit first; zero=literal, one=absolute output addressLE16
    plus length-3. Overlapping copies are legal; no history buffer is needed.
    """
    table = defaultdict(lambda: deque(maxlen=128))
    out = bytearray(); i = literals = matches = 0
    while i < len(data):
        flag = len(out); out.append(0)
        for bit in range(8):
            if i == len(data):
                break
            best = at = 0; limit = min(258, len(data) - i)
            if limit >= 4:
                for j in reversed(table[data[i:i + 3]]):
                    if best == limit:
                        break
                    if data[i:i + best + 1] != data[j:j + best + 1]:
                        continue
                    k = max(3, best + 1)
                    while k < limit and data[i + k] == data[j + k]:
                        k += 1
                    if k > best:
                        best, at = k, j
            n = best if best >= 4 else 1
            if n == 1:
                out.append(data[i]); literals += 1
            else:
                out[flag] |= 1 << bit
                address = ORIGIN + at
                out.extend((address & 255, address >> 8, n - 3)); matches += 1
            for j in range(i, i + n):
                table[data[j:j + 3]].append(j)
            i += n
    return bytes(out), {"literals": literals, "matches": matches,
                        "grammar": "absolute16-lowbit-flags", "parse": "greedy128candidates"}


def decode(stream: bytes, size: int) -> bytes:
    out = bytearray(); p = 0
    while len(out) < size:
        flags = stream[p]; p += 1
        for bit in range(8):
            if len(out) == size:
                break
            if flags & (1 << bit):
                at = int.from_bytes(stream[p:p + 2], "little") - ORIGIN
                n = stream[p + 2] + 3; p += 3
                if not 0 <= at < len(out):
                    raise ValueError("Invalid backward source")
                for j in range(n):
                    out.append(out[at + j])
            else:
                out.append(stream[p]); p += 1
    if len(out) != size or p != len(stream):
        raise ValueError("LZ stream/output size mismatch")
    return bytes(out)


def inplace_proof(stream: bytes, size: int) -> dict:
    start = END - len(stream); p = written = 0
    minimum = minimum_unbuffered = 65536
    while written < size:
        flags = stream[p]; p += 1
        for bit in range(8):
            if written == size:
                break
            if flags & (1 << bit):
                n = stream[p + 2] + 3; p += 3
            else:
                n = 1; p += 1
            written += n
            gap = start + p - (ORIGIN + written)
            minimum = min(minimum, gap)
            if start + p < INPUT_TAIL:
                minimum_unbuffered = min(minimum_unbuffered, gap)
    if p != len(stream) or written != size or minimum_unbuffered < 0:
        raise ValueError("Compressed input would be overwritten before reading")
    return {"stream_start": start, "stream_end_exclusive": END,
            "output_start": ORIGIN, "output_end_exclusive": ORIGIN + size,
            "minimum_raw_input_write_gap": minimum,
            "minimum_unbuffered_input_write_gap": minimum_unbuffered,
            "protected_input_tail": [INPUT_TAIL, END],
            "cold_main_RAM_input_cache": [INPUT_CACHE, ORIGIN]}


def decoder_source(stream_start: int, *, low_restore: bool = False,
                   finalizer_offset: int = 0) -> str:
    if not 0 <= finalizer_offset <= 149 or (finalizer_offset and not low_restore):
        raise ValueError('Invalid finalizer data-prefix length')
    source = f"""*=$0400
boot_decode:
 sei
 cld
 ldx #$ff
 txs
 lda #0
 sta $ff3f
 ldx #0
bd_cache_tail:
 lda $f500,x
 sta $0700,x
 lda $f600,x
 sta $0800,x
 lda $f700,x
 sta $0900,x
 lda $f800,x
 sta $0a00,x
 lda $f900,x
 sta $0b00,x
 lda $fa00,x
 sta $0c00,x
 lda $fb00,x
 sta $0d00,x
 lda $fc00,x
 sta $0e00,x
 inx
 bne bd_cache_tail
 lda #<{stream_start}
 sta $f7
 lda #>{stream_start}
 sta $f8
 lda #0
 sta $f9
 lda #$0f
 sta $fa
 lda #1
 sta $fd
 ldy #0
bd_token:
 lsr $fd
 bne bd_flag
 jsr bd_get
 sec
 ror
 sta $fd
bd_flag:
 bcc bd_literal
 jsr bd_get
 sta $fb
 jsr bd_get
 sta $fc
 jsr bd_get
 tax
 jsr bd_copy
 jsr bd_copy
 jsr bd_copy
 txa
 beq bd_after
bd_match:
 jsr bd_copy
 dex
 bne bd_match
 jmp bd_after
bd_literal:
 jsr bd_get
 jsr bd_put
bd_after:
 lda $fa
 cmp #$fd
 bne bd_token
 lda $f9
 bne bd_bad
 lda $f7
 bne bd_bad
 lda $f8
 cmp #$fd
 bne bd_bad
 jmp $0200
bd_get:
 lda $f8
 cmp #$fd
 bcs bd_bad
 cmp #$f5
 bcc bd_direct
 sec
 sbc #$ee
 sta bd_cached+2
 lda $f7
 sta bd_cached+1
bd_cached:
 lda $0700
 jmp bd_got_byte
bd_direct:
 lda ($f7),y
bd_got_byte:
 inc $f7
 bne bd_got
 inc $f8
bd_got:
 rts
bd_copy:
 lda ($fb),y
 jsr bd_put
 inc $fb
 bne bd_copied
 inc $fc
bd_copied:
 rts
bd_put:
 pha
 lda $fa
 cmp #$fd
 bcs bd_bad
 pla
 sta ($f9),y
 inc $f9
 bne bd_put_done
 inc $fa
bd_put_done:
 rts
bd_bad:
 sei
 lda #$32
 sta $ff19
bd_stop:
 jmp bd_stop
"""
    if low_restore:
        source = source.replace(" jmp $0200\nbd_get:", """ lda #0
 sta $fd97
 lda #$0d
 sta $fd98
 ldx #0
bd_restore_finalizer:
 lda $fd96
 sta $0a00,x
 inx
 bne bd_restore_finalizer
 jmp $0a00
bd_get:""")
        source = source.replace(" bne bd_bad", " beq *+5\n jmp bd_bad")
        source = source.replace(" bcs bd_bad", " bcc *+5\n jmp bd_bad")
    if finalizer_offset:
        source = source.replace(' jmp $0a00\nbd_get:',
                                f' jmp ${0x0A00+finalizer_offset:04x}\nbd_get:')
    return source


def finalizer_source(entry: int, *, low_restore: bool = False,
                     data_prefix: bytes = b'') -> str:
    if len(data_prefix) > 149 or (data_prefix and not low_restore):
        raise ValueError('Finalizer data prefix requires low restore and at most149 bytes')
    prefix = ''.join(f' .byt ${value:02x}\n' for value in data_prefix)
    if low_restore:
        return f"""*=$0a00
{prefix}boot_finalize:
 sei
 lda #0
 sta $ff0a
 sta $fd90
 sta $fdeb
 sta $fde9
 lda #2
 sta $fde8
 lda #0
 ldx #$fe
bf_zero_zp:
 sta $fdea
 dex
 bne bf_zero_zp
 ldx #0
bf_zero_stack:
 sta $fdea
 inx
 bne bf_zero_stack
 lda #0
 sta $fd97
 sta $fd98
 sta $fde8
 lda #2
 sta $fde9
 ldx #0
 ldy #8
bf_restore_low_tables:
 lda $fd96
 sta $fdea
 inx
 bne bf_restore_low_tables
 dey
 bne bf_restore_low_tables
 lda #0
 sta $fd97
 sta $fde8
 lda #9
 sta $fd98
 lda #$0b
 sta $fde9
 ldx #0
 ldy #4
bf_restore_low_helpers:
 lda $fd96
 sta $fdea
 inx
 bne bf_restore_low_helpers
 dey
 bne bf_restore_low_helpers
 ; Native entry must restore A00..AFF from aux0800..08FF before us_init.
 jmp ${entry:04x}
"""
    return f"""*=$0200
boot_finalize:
 sei
 lda #0
 sta $ff0a
 sta $fd90
 sta $fdeb
 sta $fde9
 lda #2
 sta $fde8
 lda #0
 ldx #$fe
bf_zero_zp:
 sta $fdea
 dex
 bne bf_zero_zp
 ldx #0
bf_zero_stack:
 sta $fdea
 inx
 bne bf_zero_stack
 lda #0
 sta $fde8
 lda #3
 sta $fde9
 lda #0
 ldx #0
 ldy #12
bf_zero_rest:
 sta $fdea
 inx
 bne bf_zero_rest
 dey
 bne bf_zero_rest
 jmp ${entry:04x}
"""


def bootstrap_source(aux_layout: str, *, low_restore: bool = False,
                     materials: bool = False, compressed_banks: bool = False) -> str:
    lines = ["*=$1100", "boot_start:", " sei", " cld", " ldx #$ff", " txs",
             " lda $fdec", " cmp #$64", " bne boot_fail", " lda $fded", " cmp #5",
             " bne boot_fail", " lda #0", " sta $fd90", " sta $fd9f", " sta $ff0a",
             " sta $ff11", " sta $ff3f", " lda $ff06", " and #$ef", " sta $ff06",
             " ldx #0", "boot_copy_code:"]
    if not low_restore:
        lines += [" lda $3800,x", " sta $0200,x"]
    for p in range(3):
        lines += [f" lda ${DECODER_SOURCE + 256*p:04x},x", f" sta ${0x400 + 256*p:04x},x"]
    lines += [" inx", " bne boot_copy_code", " lda #3", " sta $fdeb", " lda #0",
              " sta $fde8", " lda #$3d", " sta $fde9", " ldx #0"]
    for p in range(3):
        lines += [f"boot_tail_{p}:", f" lda ${TAIL_SOURCE + 256*p:04x},x", " sta $fdea",
                  " inx", f" bne boot_tail_{p}"]
    lines += [" lda #0", " sta $fd97", " sta $fd98", " ldx #0", " ldy #64",
              "boot_clear_aux:", " sta $fd96", " inx", " bne boot_clear_aux",
              " dey", " bne boot_clear_aux", f" lda #<{AUX_SOURCE}", " sta $f7",
              f" lda #>{AUX_SOURCE}", " sta $f8", " ldy #0"]
    if aux_layout == "contiguous":
        if compressed_banks:
            from boot_materials import BANK_HELPER_ORIGIN
            lines += [f" jsr ${BANK_HELPER_ORIGIN:04x}"]
        else:
            lines += [" lda #0", " sta $fd97", " lda #$20", " sta $fd98", " ldx #32"]
        if low_restore:
            if compressed_banks:
                lines += [" lda #0", " sta $f7"]
            else:
                lines += [" jsr boot_aux_pages"]
            lines += [" lda #0", " sta $fd97", " sta $fd98",
                      " lda #$39", " sta $f8", " ldx #13", " jsr boot_aux_pages",
                      " lda #$38", " sta $f8", " ldx #1", " jsr boot_aux_pages",
                      " jmp $0400", "boot_aux_pages:"]
        if low_restore or not compressed_banks:
            lines += ["boot_aux_page:", " lda ($f7),y", " sta $fd96", " iny",
                      " bne boot_aux_page", " inc $f8", " dex", " bne boot_aux_page"]
        if low_restore:
            lines += [" rts"]
    elif aux_layout == "scatter-half-records":
        lines += [" lda #0", " sta $f9", " ldx #16", "boot_aux_record:", " lda #0",
                  " sta $fd97", " lda $f9", " sta $fd98", "boot_aux_first:",
                  " lda ($f7),y", " sta $fd96", " iny", " bne boot_aux_first", " inc $f8",
                  "boot_aux_second:", " lda ($f7),y", " sta $fd96", " iny",
                  " bne boot_aux_second", " inc $f8", " lda $f9", " clc", " adc #4",
                  " sta $f9", " dex", " bne boot_aux_record"]
    else:
        raise ValueError("Unknown auxiliary layout")
    lines += [" jmp $0400", "boot_fail:", " lda #$32", " sta $ff19", "boot_failed:",
              " jmp boot_failed"]
    # Use long branches for the signature-failure exits; code may exceed128B.
    source = "\n".join(lines) + "\n"
    if materials:
        from boot_materials import HELPER_ORIGIN
        source = source.replace(" jmp $0400", f" jsr ${HELPER_ORIGIN:04x}\n jmp $0400")
    source = source.replace(" bne boot_fail", " beq *+5\n jmp boot_fail")
    return source


def expected_aux(auxiliary: bytes, aux_layout: str, *,
                 main_low: bytes | None = None, finalizer: bytes | None = None,
                 materials: bytes | None = None) -> bytes:
    from boot_materials import MATERIAL_START, MATERIAL_END, validate_materials
    validate_materials(materials)
    if len(auxiliary) != 8192:
        raise ValueError("Expected 8192 original auxiliary bytes")
    if materials is not None and aux_layout != "contiguous":
        raise ValueError("Materials overlap the historical scattered-bank layout")
    result = bytearray(16384)
    if aux_layout == "contiguous":
        result[0x2000:0x4000] = auxiliary
    elif aux_layout == "scatter-half-records":
        for r in range(16):
            result[r*1024:r*1024+512] = auxiliary[r*512:(r+1)*512]
    else:
        raise ValueError("Unknown auxiliary layout")
    if main_low is not None:
        if aux_layout != "contiguous" or len(main_low) != LOW_SIZE or finalizer is None or len(finalizer) > 256:
            raise ValueError("Low restore needs thirteen pages and one finalizer page below aux2000")
        result[:LOW_SIZE] = main_low
        result[0x0D00:0x0E00] = finalizer.ljust(256, b"\0")
    if materials is not None:
        result[MATERIAL_START:MATERIAL_END] = materials
    return bytes(result)


def build_boot(main: bytes, auxiliary: bytes, entry: int, out: Path, *,
               aux_layout: str = "contiguous", xa: Path | None = None,
               source_manifest: dict | None = None, low_restore: bool = False,
               materials: bytes | None = None) -> dict:
    """Create standaloneUSAGI.PRG plus one-fileUSAGI.D64, preserving prior builds.

    Legacy entry clears the finalizer's$0200 page. With low_restore, entry must
    restore persistent$0A00..$0AFF from aux$0800 before GPU cache initialization.
    All$0200..$0EFF source bytes are then preserved; CPU ports$00/$01 stay live.
    Optional low-tail metadata shares a skipped data prefix in the already
    reserved finalizer page. The CPU jumps past that prefix before execution.
    """
    if len(main) != 65536 or len(auxiliary) != 8192:
        raise ValueError("Expected64KiB main and8KiB original banked assets")
    from boot_materials import (HELPER_ORIGIN, MATERIAL_START, MATERIAL_END,
                               validate_materials, decoder_source as material_decoder_source)
    validate_materials(materials)
    finalizer_prefix = bytes.fromhex((source_manifest or {}).get(
        'portrait_shading',{}).get('cold_finalizer_prefix_hex',''))
    if finalizer_prefix and not low_restore:
        raise ValueError('Persistent low metadata prefix requires --low-restore')
    if materials is not None and aux_layout != "contiguous":
        raise ValueError("Materials require the contiguous original-bank layout")
    if not ORIGIN <= entry < END or 0xFD00 <= entry < 0xFE00:
        raise ValueError("Native entry outside decompressed executable range")
    if low_restore and aux_layout != "contiguous":
        raise ValueError("Cold low restore would overlap scattered original assets")
    if not low_restore and any(main[0x200:ORIGIN]):
        raise ValueError("Meaningful low RAM requires explicit low_restore bootstrap contract")
    if out.exists():
        raise FileExistsError("Choose a fresh boot output directory")
    out.mkdir(parents=True)
    xa = xa or ROOT / "tools-game/bin/xa"
    stream, stats = encode(main[ORIGIN:END])
    if decode(stream, END - ORIGIN) != main[ORIGIN:END]:
        raise AssertionError("Lossless LZ roundtrip failed")
    layout = inplace_proof(stream, END - ORIGIN)
    header_end = LOW_HEADER_END if low_restore else HEADER_END
    if layout["stream_start"] < header_end:
        raise ValueError("Compressed game overlaps cold-only transport header")
    material_stream = bank_stream = None
    material_at = header_end
    material_split = material_resume = None
    if materials is not None:
        material_stream, material_stats = encode(materials)
        if decode(material_stream, len(materials)) != materials:
            raise AssertionError("Material LZ roundtrip failed")
        if header_end + len(material_stream) > layout["stream_start"]:
            bank_stream, bank_stats = encode(auxiliary)
            if decode(bank_stream, len(auxiliary)) != auxiliary:
                raise AssertionError("Original-bank LZ roundtrip failed")
            material_at = AUX_SOURCE + len(bank_stream)
            if material_at >= DECODER_SOURCE:
                raise ValueError("Compressed banks leave no material transport interval")
            first_size = min(len(material_stream), DECODER_SOURCE - material_at)
            if first_size < len(material_stream):
                material_split, material_resume = DECODER_SOURCE, header_end
                material_end = header_end + len(material_stream) - first_size
            else:
                material_end = material_at + len(material_stream)
            if material_end > layout["stream_start"]:
                raise ValueError("Compressed banks/materials exceed cold transport intervals")
    dec, dl = compile_xa(decoder_source(layout["stream_start"], low_restore=low_restore,
        finalizer_offset=len(finalizer_prefix)), out, "decode", xa=xa)
    final, fl = compile_xa(finalizer_source(entry, low_restore=low_restore,
        data_prefix=finalizer_prefix), out, "finalize", xa=xa)
    stub, sl = compile_xa(bootstrap_source(aux_layout, low_restore=low_restore,
                                          materials=materials is not None,
                                          compressed_banks=bank_stream is not None), out, "start", xa=xa)
    if len(dec) > 0x300 or len(final) > 0x100 or 0x1100 + len(stub) > TAIL_SOURCE:
        raise ValueError("Boot code exceeds its explicit cold transport interval")
    transport = bytearray(END - 0x1001)
    def put(address: int, data: bytes) -> None:
        start = address - 0x1001
        if not 0 <= start <= start + len(data) <= len(transport):
            raise ValueError("Transport write outsidePRG")
        transport[start:start+len(data)] = data
    # BASIC line2026 SYS4352, then end-of-program pointer.
    put(0x1001, bytes.fromhex("0b10ea079e34333532000000"))
    put(0x1100, stub)
    put(TAIL_SOURCE, main[END:0x10000])
    put(AUX_SOURCE, auxiliary if bank_stream is None else bank_stream)
    put(DECODER_SOURCE, dec)
    if material_stream is not None:
        helper, hl = compile_xa(material_decoder_source(material_at, len(material_stream),
                                bank_stream=None if bank_stream is None else (AUX_SOURCE, len(bank_stream)),
                                split_at=material_split, resume_at=material_resume),
                                out, "material-decode", xa=xa)
        helper_source = DECODER_SOURCE + HELPER_ORIGIN - 0x0400
        if (HELPER_ORIGIN < 0x0400 + len(dec)
                or helper_source + len(helper) > FINAL_SOURCE):
            raise ValueError("Material decoder overlaps cold code transport")
        put(helper_source, helper)
        first_size = (len(material_stream) if material_split is None
                      else material_split - material_at)
        put(material_at, material_stream[:first_size])
        if material_split is not None:
            put(material_resume, material_stream[first_size:])
        (out / "compressed-materials.bin").write_bytes(material_stream)
        (out / "materials.bin").write_bytes(materials)
        if bank_stream is not None:
            (out / "compressed-banks.bin").write_bytes(bank_stream)
    put(FINAL_SOURCE, final)
    if low_restore:
        put(LOW_SOURCE, main[0x200:ORIGIN])
    put(layout["stream_start"], stream)
    prg = bytes.fromhex("0110") + transport
    (out / "USAGI.PRG").write_bytes(prg)
    spec = importlib.util.spec_from_file_location("usagi_d64_pack", ROOT / "docs/developers/sdk-current/baseline/d64.py")
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    disk = module.pack([("USAGI", prg)], label="USAGI PLUS64", disk_id="UY")
    (out / "USAGI.D64").write_bytes(disk)
    (out / "compressed-main.bin").write_bytes(stream)
    report = {"status": "BUILT-ordinary-KERNAL-boot-unqualified", "source": source_manifest,
              "boot_source_sha256": sha(Path(__file__).read_bytes()),
              "main_sha256": sha(main), "auxiliary_sha256": sha(auxiliary),
              "native_entry": entry, "boot_entry": 0x1100,
              "PRG_load_start": 0x1001, "PRG_end_exclusive": END,
              "PRG_bytes": len(prg), "PRG_sha256": sha(prg),
              "D64_bytes": len(disk), "D64_sha256": sha(disk),
              "decompressed_range": [ORIGIN, END], "stream": layout,
              "codec": stats, "compressed_bytes": len(stream),
              "tail_under_IO_ROM_range": [END, 0x10000],
              "tail_CPU_upload_port": "$FDEA,bank3,offset$3D00",
              "auxiliary_layout": aux_layout, "auxiliary_CPU_upload_port": "$FD96",
              "expected_auxiliary_backing_sha256": sha(expected_aux(auxiliary, aux_layout,
                  main_low=main[0x200:ORIGIN] if low_restore else None,
                  finalizer=final if low_restore else None, materials=materials)),
              "guest_main_bytes": 65536, "guest_internal_bytes": 16384,
              "guest_total_bytes": 81920, "additional_guest_RAM_bytes": 0,
              "low_restore": low_restore,
              "low_RAM_zeroed": [[2, 0x200]] if low_restore else [[2, 0x200], [0x300, ORIGIN]],
              "low_RAM_preserved_source": [0x200, ORIGIN] if low_restore else None,
              "low_RAM_restored_by_finalizer": [[0x200, 0xA00], [0xB00, ORIGIN]] if low_restore else [],
              "cold_auxiliary_low_stage": [0, 0xE00] if low_restore else None,
              "cold_input_tail_cache": {"source": [INPUT_TAIL, END],
                  "existing_main_RAM_scratch": [INPUT_CACHE, ORIGIN],
                  "cleared_before_native_entry": True, "additional_backing_bytes": 0},
              "CPU_ports_00_01_preserved": True,
              "native_entry_must_clear_finalizer_page": None if low_restore else [0x200, 0x300],
              "native_entry_must_restore_page": ({"main": [0xA00, 0xB00],
                  "auxiliary_source": [0x800, 0x900],
                  "before": "bridge install and us_init; no clearing of relocated tables"}
                  if low_restore else None),
              "expected_configuration": {"Plus64MainRAM": 1, "protocol": 5,
                  "C16_Plus4_same_PRG": True, "modem_in_use": False},
              "labels": {"start": sl, "decoder": dl, "finalizer": fl},
              "limits": ["No disk boot is claimed until separate cold tests pass",
                  "Guest checks protocol05; MainRAM resource selection is a launch prerequisite",
                  "Cold transport bytes are overwritten; no extra resident history or asset copy"]}
    if materials is not None:
        report["materials"] = {"auxiliary_range": [MATERIAL_START, MATERIAL_END],
            "cold_decoder_source_sha256": sha((HERE / "boot_materials.py").read_bytes()),
            "bytes": len(materials), "sha256": sha(materials),
            "compressed_bytes": len(material_stream), "compressed_sha256": sha(material_stream),
            "codec": material_stats,
            "transport_ranges": [[material_at, material_at + first_size]] +
                ([[material_resume, material_resume + len(material_stream) - first_size]]
                 if material_split is not None else []),
            "cold_decoder_CPU_range": [HELPER_ORIGIN, HELPER_ORIGIN + len(helper)],
            "cold_decoder_transport_range": [helper_source, helper_source + len(helper)],
            "history": "already produced auxiliary bytes read through FD96; no extra buffer",
            "additional_guest_RAM_bytes": 0, "labels": hl}
        if bank_stream is not None:
            report["materials"]["compressed_original_banks"] = {
                "bytes": len(bank_stream), "sha256": sha(bank_stream), "codec": bank_stats,
                "transport_range": [AUX_SOURCE, AUX_SOURCE + len(bank_stream)],
                "output_auxiliary_range": [0x2000, 0x4000]}
    if finalizer_prefix:
        report['cold_finalizer_data_prefix'] = dict(auxiliary_start=0x0D00,
            bytes=len(finalizer_prefix), hex=finalizer_prefix.hex(),
            skipped_by_CPU=True, finalizer_entry=fl['boot_finalize'],
            retained_after_boot=True, additional_guest_RAM_bytes=0)
    (out / "BOOT.json").write_text(json.dumps(report, indent=2) + "\n")
    return report


def package_test(boot_dir: Path, zip_path: Path, *,
                 extra_files: dict[str, Path] | None = None,
                 launchers: dict[str, str] | None = None) -> dict:
    """Package explicit game/runtime files without copying unrelated releases.

    The default ZIP contains the two self-contained game files and readable
    RAM80 requirements. A final distributor can supply an explicitly selected
    emulator, its corresponding source/licenses and launchers through the two
    optional mappings. No runtime version or qualification is inferred here.
    """
    if zip_path.exists():
        raise FileExistsError("Preserve prior test packages")
    files = {"USAGI.PRG": boot_dir / "USAGI.PRG",
             "USAGI.D64": boot_dir / "USAGI.D64"}
    config = json.loads((boot_dir / "BOOT.json").read_text())
    if (sha(files["USAGI.PRG"].read_bytes()) != config["PRG_sha256"]
            or sha(files["USAGI.D64"].read_bytes()) != config["D64_sha256"]):
        raise ValueError("Boot artifacts no longer match their manifest")
    if set(files).intersection(extra_files or {}):
        raise ValueError("Extra files cannot replace the game artifacts")
    files.update(extra_files or {})
    texts = {
        "LEGGIMI.txt": (
            "USAGI YOJIMBO — plus/64 RAM80, prova di sviluppo\n\n"
            "USAGI.D64 e USAGI.PRG contengono lo stesso programma completo.\n"
            "Il D64 avvia il programma tramite il normale LOAD/RUN del KERNAL.\n"
            "Il PRG contiene gioco, asset e caricatore; non richiede altri file di gioco.\n\n"
            "Richiede l'emulatore plus/64 corrispondente a questa build, profilo\n"
            "MainRAM: 64 KiB + 16 KiB totali. C16 e Plus/4 usano gli stessi file.\n"
            "SID a FD40; joystick porta 2. FIRE nel menu avvia l'opzione selezionata.\n"
            "Il trainer THT e la relativa attivazione con F sono rimossi. La voce\n"
            "Practice appartiene invece alle opzioni originali del gioco.\n\n"
            "Non e' un disco commerciale originale incontaminato: deriva dalla\n"
            "copia fornita dall'utente. Le prove di questa build sono separate;\n"
            "questo archivio non dichiara un collaudo completo o su hardware fisico.\n"
        ),
        "README.txt": (
            "USAGI YOJIMBO — plus/64 RAM80 development test\n\n"
            "USAGI.D64 and USAGI.PRG contain the same self-contained program.\n"
            "The disk uses ordinary KERNAL LOAD/RUN; no monitor RAM/PC injection\n"
            "is required. The PRG contains the game, assets and cold loader.\n\n"
            "Requires the matching plus/64 emulator and MainRAM profile: exactly\n"
            "64 KiB + 16 KiB guest RAM. C16 and Plus/4 use identical game files.\n"
            "SID address FD40; joystick port 2. FIRE starts the selected menu option.\n"
            "The THT trainer and F activation are removed. Practice is an original\n"
            "game option. This is a derivative of the user-supplied disk, not a\n"
            "claimed pristine publisher master. Build validation is separate;\n"
            "no complete-game or physical-hardware qualification is implied.\n"
        ),
    }
    texts.update(launchers or {})
    names = [*files, *texts, "MANIFEST.json"]
    if len(names) != len(set(names)):
        raise ValueError("Duplicate test-package paths")
    for name in names:
        if name.startswith(("/", "\\")) or ".." in Path(name.replace("\\", "/")).parts:
            raise ValueError("Package paths must stay inside the ZIP")
    entries = []
    zip_path.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, path in files.items():
            raw = path.read_bytes(); archive.writestr(name, raw)
            entries.append({"file": name, "bytes": len(raw), "sha256": sha(raw)})
        for name, text in texts.items():
            raw = text.encode("utf-8"); archive.writestr(name, raw)
            entries.append({"file": name, "bytes": len(raw), "sha256": sha(raw)})
        archive.writestr("MANIFEST.json", json.dumps({"files": entries,
            "guest_RAM_bytes": 81920, "extra_files_selected_by_caller": bool(extra_files)},
            indent=2) + "\n")
    with zipfile.ZipFile(zip_path) as archive:
        if archive.testzip() is not None:
            raise AssertionError("Test package CRC failure")
        for item in entries:
            if sha(archive.read(item["file"])) != item["sha256"]:
                raise AssertionError("Test package content mismatch")
    return {"file": str(zip_path), "bytes": zip_path.stat().st_size,
            "sha256": sha(zip_path.read_bytes()), "files": entries,
            "CRC_and_extracted_hashes_verified": True}


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--link", type=Path, required=True)
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--aux-layout", choices=("contiguous", "scatter-half-records"), default="contiguous")
    ap.add_argument("--low-restore", action="store_true")
    args = ap.parse_args()
    config = json.loads((args.link / "BUILD.json").read_text())
    result = build_boot((args.link / "native-main.bin").read_bytes(),
                        (args.link / "banked-assets.bin").read_bytes(),
                        config["native_entry"], args.out.resolve(),
                        aux_layout=args.aux_layout, source_manifest=config,
                        low_restore=args.low_restore,
                        materials=((args.link / "materials.bin").read_bytes()
                                   if (args.link / "materials.bin").exists() else None))
    print(result["status"], result["PRG_bytes"], result["D64_sha256"])
