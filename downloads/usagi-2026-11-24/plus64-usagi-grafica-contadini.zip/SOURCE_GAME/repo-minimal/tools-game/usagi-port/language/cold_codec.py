"""Offline DP parser for the existing Usagi cold absolute16 LZ grammar.

Only compression parsing changes. The guest decoder, history, backing and
memory map remain those of the parent boot builder. No workspace paths.
"""
from array import array
from collections import defaultdict, deque
import time

def encode(data: bytes, candidates: int = 128, *, origin: int = 0x0F00):
    """Byte-optimal parse over128-most-recent matching starts,8tokenflag state.

    It considers all lengths3..258 supported by the EXISTINGdecoder. This is
    optimal for this bounded candidate set, not globally over everypaststart.
    Returns the exact existing(stream,stats) API. No file/image is changed.
    """
    if not 0 <= origin <= 65535 or len(data) > 65536-origin:
        raise ValueError("LZ output addresses must fit16bits")
    if not isinstance(candidates, int) or candidates < 1:
        raise ValueError("LZ matching candidate count must be positive")
    begin=time.monotonic();N=len(data)
    bestlen=array('H',[0])*N;bestat=array('H',[0])*N
    table=defaultdict(lambda:deque(maxlen=candidates))
    for i in range(N):
        limit=min(258,N-i);best=at=0
        if limit>=3:
            key=data[i:i+3]
            for j in reversed(table[key]):
                if best==limit:break
                if data[i:i+best+1]!=data[j:j+best+1]:continue
                k=max(3,best+1)
                while k<limit and data[i+k]==data[j+k]:k+=1
                if k>best:best,at=k,j
            table[key].append(i)
        bestlen[i]=best;bestat[i]=at
    match_s=time.monotonic()-begin
    costs=[array('I',[0])*(N+1)for k in range(8)]
    choice=[array('H',[1])*N for k in range(8)]
    for i in range(N-1,-1,-1):
        L=bestlen[i]
        for k in range(8):
            nxt=(k+1)&7;future=costs[nxt]
            best=1+future[i+1];n=1
            if L>=3:
                low=i+3;high=i+L+1
                m=min(future[low:high]);v=3+m
                if v<best:
                    # Longest minimum-cost tie reduces cold token work.
                    j=high-1
                    while future[j]!=m:j-=1
                    best=v;n=j-i
            costs[k][i]=best+(1 if k==0 else 0);choice[k][i]=n
    out=bytearray();i=lit=mat=match3=0
    while i<N:
        flag=len(out);out.append(0)
        for bit in range(8):
            if i==N:break
            n=choice[bit][i]
            if n==1:out.append(data[i]);lit+=1
            else:
                out[flag]|=1<<bit;address=origin+bestat[i]
                out.extend((address&255,address>>8,n-3));mat+=1;match3+=n==3
            i+=n
    assert len(out)==costs[0][0]
    return bytes(out),dict(literals=lit,matches=mat,length3_matches=match3,grammar='absolute16-lowbit-flags',parse=f'flagstate-DP{candidates}candidates',matching_seconds=match_s,total_seconds=time.monotonic()-begin,optimality='minimum bytecount for the bounded matching-start set and exact8-token flaggroupstate')

