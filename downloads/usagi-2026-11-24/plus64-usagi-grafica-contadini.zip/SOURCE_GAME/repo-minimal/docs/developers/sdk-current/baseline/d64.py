"""Self-contained copy of the existing project D64 packing conventions.

Based on engine/reuse/native_disk.py::_pack and make_d64.py nsec/ofs.
Only the reusable geometry/packing code is included; no game data/imports.
"""
def nsec(t):
    assert 1 <= t <= 35
    return 21 if t <= 17 else 19 if t <= 24 else 18 if t <= 30 else 17


def ofs(t, s):
    assert 0 <= s < nsec(t)
    return 256 * (sum(nsec(j) for j in range(1, t)) + s)


def pack(files, label='PLUS64 SDK DEMO', disk_id='SD'):
    assert 1 <= len(files) <= 8*(nsec(18)-1)
    directory_sectors = (len(files)+7)//8
    available = [(track, sector) for track in range(1, 36) if track != 18
                 for sector in range(nsec(track))]
    used = {(18, sector) for sector in range(directory_sectors+1)}
    disk = bytearray(174848)
    cursor = 0
    for entry, (name, raw) in enumerate(files):
        assert raw and 1 <= len(name) <= 16
        chunks = [raw[i:i + 254] for i in range(0, len(raw), 254)]
        chain = available[cursor:cursor + len(chunks)]
        cursor += len(chunks)
        assert len(chain) == len(chunks) and not used.intersection(chain)
        used.update(chain)
        for i, (track, sector) in enumerate(chain):
            p = ofs(track, sector)
            chunk = chunks[i]
            disk[p:p + 2] = bytes(chain[i + 1]) if i + 1 < len(chain) else bytes((0, len(chunk) + 1))
            disk[p + 2:p + 2 + len(chunk)] = chunk
        p = ofs(18, 1+entry//8) + 2 + 32 * (entry%8)
        disk[p] = 0x82
        disk[p + 1:p + 3] = bytes(chain[0])
        disk[p + 3:p + 19] = name.encode('ascii').ljust(16, b'\xa0')
        disk[p + 28:p + 30] = len(chain).to_bytes(2, 'little')
    for sector in range(1,directory_sectors+1):
        directory = ofs(18, sector)
        disk[directory:directory + 2] = bytes((18,sector+1)) if sector<directory_sectors else b'\x00\xff'
    bam = ofs(18, 0)
    disk[bam:bam + 4] = bytes((18, 1, 0x41, 0))
    for track in range(1, 36):
        bitmap = [0, 0, 0]
        free = 0
        for sector in range(nsec(track)):
            if (track, sector) not in used:
                free += 1
                bitmap[sector // 8] |= 1 << (sector % 8)
        disk[bam + 4 * track:bam + 4 * track + 4] = bytes((free, *bitmap))
    disk[bam + 0x90:bam + 0xa0] = label.encode('ascii').ljust(16, b'\xa0')
    disk[bam + 0xa2:bam + 0xa4] = disk_id.encode('ascii')
    disk[bam + 0xa5:bam + 0xa7] = b'2A'
    assert len(disk) == 174848
    return bytes(disk)
