*=$4750
; Enter by tail JMP from ut_arm, with A=next logical VIC line.
; Arm first. A target crossed before this write would otherwise wait312lines.
; Recheck afterward; the original bounded late-event drain handles it.
ua_post_arm:
 jsr $28ef
 jsr $2908
 tax
 lda $0e53
 cmp $0e5c
 bcc ua_wrap
 lda $0e63
 bne ua_late
 txa
 cmp $0e53
 bcs ua_late
 cmp $0e5c
 bcc ua_late
 rts
ua_wrap:
 lda $0e63
 bne ua_done
 txa
 cmp $0e5c
 bcs ua_done
 cmp $0e53
 bcc ua_done
ua_late:
 jmp $2e16
ua_done:
 rts
