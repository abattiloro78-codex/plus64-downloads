#!/usr/bin/env python3
"""Offline forward rebuild of the reviewed RAM80 game from explicit inputs.

Python3.12+ and an installed xa2.4.1 assembler are required. The supplied
frozen032 port image is an explicit binary input, not original assembly source.
All new sprite/background authoring data and all033 transition code are local.
"""
from pathlib import Path
import argparse,hashlib,json,shutil,subprocess,sys
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def run(*args):subprocess.run([sys.executable,*map(str,args)],check=True)
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,required=True);p.add_argument('--xa',type=Path);a=p.parse_args()
    xa=a.xa or shutil.which('xa')
    if not xa:raise SystemExit('Install xa2.4.1 or supply --xa /path/to/xa')
    xa=Path(xa).resolve();out=a.output.resolve();out.mkdir(parents=True,exist_ok=False)
    expected=json.loads((HERE/'EXPECTED_FINAL.json').read_text())
    repo=out/'repo';shutil.copytree(HERE/'repo-minimal',repo)
    target=repo/'tools-game/bin/xa';target.parent.mkdir(parents=True);shutil.copy2(xa,target)
    background=out/'backgrounds';run(HERE/'art/backgrounds/build_backgrounds.py','--output',background,'--check-baseline')
    bg=json.loads((background/'BACKGROUND_BUILD.json').read_text())
    manifest={'status':'REBUILT-approved178-JSON-inputs','max_p64z_bytes':bg['max_packet_bytes'],
        'scenes':[{'scene':r['scene'],'p64z_bytes':r['packet_bytes'],'p64z_sha256':r['packet_sha256']}for r in bg['records']]}
    (background/'PRUNED_SCENES_PROOF.json').write_text(json.dumps(manifest,indent=2)+'\n')
    art=out/'art';run(HERE/'art/build_art.py','--output',art)
    base=out/'baseline';shutil.copytree(HERE/'inputs/baseline-032',base)
    main=(base/'native-main.bin').read_bytes();aux=bytearray((base/'vm-full-initial-aux.bin').read_bytes())
    bank=(art/'framebank-method2.bin').read_bytes();vm=(art/'sprite_vm.method2.p64z').read_bytes()
    assert main[0x84d0:0xad79]==bank,'P64Fv4 reconstructed bank differs from frozen port input'
    assert aux[736:7030]==vm and len(vm)==6294,'Runtime VM must be the actual reviewed method2 archive'
    # Consume the freshly assembled source output in the actual cold inputs.
    aux[736:7030]=vm;(base/'vm-full-initial-aux.bin').write_bytes(aux)
    (base/'vm-low-payload.bin').write_bytes(aux[736:0xe00]);(base/'materials.bin').write_bytes(aux[0xe00:0x2000])
    link=out/'link';boot=out/'boot'
    run(HERE/'drivers/build_multiload.py','--repo',repo,'--baseline',base,'--packets',background,
        '--scheduler',HERE/'inputs/scheduler/SCHEDULER_PATCH_PACKET.json','--out',link,'--boot-out',boot)
    assert sha(link/'native-main.bin')==expected['native_main_sha256']
    assert sha(boot/'USAGI.D64')==expected['D64_sha256']
    proof=dict(status='PASS-curated-source-forward-rebuild-byte-exact',
        frozen_port_input='inputs/baseline-032/native-main.bin',not_a_claim_of_original_assembly_source=True,
        Main_sha256=sha(link/'native-main.bin'),D64_sha256=sha(boot/'USAGI.D64'),
        sprite_VM_method2_bytes=len(vm),sprite_VM_method2_sha256=sha(art/'sprite_vm.method2.p64z'),
        background_count=17,BG_max_bytes=bg['max_packet_bytes'],disk_file_count=20,
        guest_bytes=81920,minimum_scenery_formats=23,
        physical_background_camera=json.loads((link/'BACKGROUND_CAMERA_BUILD.json').read_text()),
        grass_palette=json.loads((link/'GRASS_BUILD.json').read_text()),
        mirror_cache=json.loads((link/'MIRROR_CACHE_BUILD.json').read_text()),
        publisher_mirror=json.loads((link/'PUBLISHER_MIRROR_BUILD.json').read_text()),
        external_workspace_dependencies=0,external_assembler_sha256=sha(xa),
        source_entry_sha256=sha(Path(__file__)),native_or_Wine_gameplay_qualified_here=False)
    (out/'REBUILD_PROOF.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof,indent=2))
if __name__=='__main__':main()
