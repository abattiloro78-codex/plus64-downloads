*=$47e5
source_upload_guard:
 php
 pha
 lda #255
 sta $0b3d
 sta $0b39
 sta $0b3a
 sta $0b3b
 sta $0b3c
 pla
 plp
 jsr $f800
 php
 pha
 lda #0
 sta $0b3d
 pla
 plp
 rts
source_upload_guard_end:
