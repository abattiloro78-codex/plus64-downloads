*=$cfd2
owner_cache_invalidate:
 sta $fd96
 lda #255
 sta $0b39
 sta $0b3a
 sta $0b3b
 sta $0b3c
 clc
 rts
owner_cache_invalidate_end:
