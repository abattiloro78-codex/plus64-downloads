#!/usr/bin/env python3
"""Portableexperimental033builder;17diskassets,onlycurrentBGresident."""
from pathlib import Path
import sys,argparse,json,hashlib,shutil,struct,subprocess,importlib.util
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
import scene_context as S,multiload_runtime as M
import patch_owner,patch_bridge_templates,patch_background_camera,patch_grass_palette,patch_mirror_cache,patch_publisher_mirror
sha=lambda b:hashlib.sha256(b).hexdigest()
BASE_SHA='dcfebb863311ec0cc9ccd88b49ee299e413e2899b22ea3624580aed156e4efdd'

def build(repo,base,packets,scheduler,out):
 repo,base,packets,scheduler,out=[Path(x).resolve()for x in(repo,base,packets,scheduler,out)]
 if out.exists():raise FileExistsError(out)
 PORT=repo/'tools-game/usagi-port';sys.path.insert(0,str(PORT));from native import compile_xa
 raw=(base/'native-main.bin').read_bytes();assert sha(raw)==BASE_SHA and len(raw)==65536
 manifest=packets/'PRUNED_SCENES_PROOF.json'
 if not manifest.exists():manifest=packets.parent/'BUILD_PROOF.json'
 proof=json.loads(manifest.read_text());assert len(proof['scenes'])==17 and proof.get('max_p64z_bytes',proof.get('max_packet_bytes',0))<=M.MAX_BG_BYTES
 assert sorted(r['scene']for r in proof['scenes'])==list(range(1,18))
 file_receipts=[]
 for row in proof['scenes']:
  n=row['scene'];blob=(packets/f'scene{n:02d}.p64z').read_bytes();assert sha(blob)==row.get('p64z_sha256',row.get('packet_sha256'))and len(blob)==row.get('p64z_bytes',row.get('packet_bytes'))<=M.MAX_BG_BYTES
  file_receipts.append(dict(scene=n,name=f'B{n:02d}',bytes=len(blob),sha256=sha(blob),node_length=len(blob)))
 sp=json.loads(scheduler.read_text());binary=(scheduler.parent/'scheduler_post_arm.bin').read_bytes();assert sha(binary)==sp['helper_sha256']and len(binary)==52
 assert raw[sp['hook_address']:sp['hook_address']+3].hex()==sp['hook_original_hex'];assert raw[0x4750:0x4784]==bytes(52)
 assert raw[S.HELPER:S.LEASE_END]==bytes(S.LEASE_END-S.HELPER)and raw[M.BUFFER:M.CORE_END]==bytes(M.CORE_END-M.BUFFER)
 shutil.copytree(base,out);C=out/'multiload-components';C.mkdir();image=bytearray(raw);b=json.loads((base/'BUILD.json').read_text());labels=json.loads((base/'labels.json').read_text());lang=json.loads((base/'LANGUAGE_BUILD.json').read_text());xa=repo/'tools-game/bin/xa'
 dummy=dict(ml_filename=0x47d0,ml_load_A=0x47d3,ml_load_end=0x47d4,ml_load_P=0x47d6,ml_load_ST=0x47d7)
 code,L=compile_xa(M.core_source(rom_labels=dummy),C,'core-first',xa=xa);rom,R=compile_xa(M.rom_source(core_labels=L),C,'rom',xa=xa);code,L=compile_xa(M.core_source(rom_labels=R),C,'core',xa=xa)
 assert len(code)<=M.CORE_END-M.CORE and len(rom)<=M.ROM_END-M.ROM_STUB
 assert M.ROM_STUB+len(rom)<=patch_publisher_mirror.UPLOAD_GUARD
 scene,SL=compile_xa(S.source(continuation=L['ml_enter']),C,'scene_capture',xa=xa);assert len(scene)==10
 image[M.CORE:M.CORE+len(code)]=code;image[M.ROM_STUB:M.ROM_STUB+len(rom)]=rom;image[S.HELPER:S.STATE]=scene;image[S.STATE]=0;S.patch_header(image)
 image[sp['helper_origin']:sp['helper_end_exclusive']]=binary;image[sp['hook_address']:sp['hook_address']+3]=bytes.fromhex(sp['hook_replacement_hex'])
 gate=lang['sky_gate'];assert image[gate+11]==6 and image[gate+4:gate+8]==bytes([0x64,0xe,1,255]);oldtrue=int.from_bytes(image[gate+2:gate+4],'little')
 node=bytearray(24);struct.pack_into('<H',node,0,S.PHASE_NODE);node[2]=0;struct.pack_into('<HHHH',node,3,M.BUFFER,0,S.STATE,0xe64);node[11]=11;struct.pack_into('<H',node,12,0xa4);node[14:16]=bytes([1,255]);struct.pack_into('<H',node,16,65535);node[18]=200;node[19:21]=bytes([1,2]) # Only nativeMCtext receives background materials; HUD/dialogue modes stay original.
 phase=bytearray(16);struct.pack_into('<HHH',phase,0,oldtrue,280,S.STATE);phase[6:8]=bytes([4,255]);phase[11]=12
 image[S.BG_CONFIG:S.BG_CONFIG+24]=node;image[S.PHASE_NODE:S.PHASE_NODE+16]=phase;image[gate+2:gate+4]=S.BG_CONFIG.to_bytes(2,'little')
 assert image[gate:gate+2]==raw[gate:gate+2]and image[0xfd9d:0xfd9f]==raw[0xfd9d:0xfd9f]
 # Correct colour ownership using the original scheduler actor index, and
 # install the same foreground markers in the second original bridge template.
 # Both guarded edits are fixed size; original mechanics and RAM leases remain.
 pre_fix_main_sha=sha(image)
 image=bytearray(patch_owner.apply(image))
 fixed_banks,bridge_fix=patch_bridge_templates.patch((out/'banked-assets.bin').read_bytes())
 (out/'banked-assets.bin').write_bytes(fixed_banks)
 camera_code,CL=compile_xa(patch_background_camera.source(),C,'background_camera',xa=xa)
 assert M.CORE+len(code)==patch_background_camera.ORIGIN
 image,camera_fix=patch_background_camera.apply(image,camera_code,CL)
 image,grass_fix=patch_grass_palette.apply(image)
 mirror_code,ML=compile_xa(patch_mirror_cache.source(),C,'mirror_cache',xa=xa)
 image,mirror_fix=patch_mirror_cache.apply(image,mirror_code,ML)
 labels.update(ML)
 publisher_code,PL=compile_xa(patch_publisher_mirror.source('publisher_mirror'),C,'publisher_mirror',xa=xa)
 validator_code,VL=compile_xa(patch_publisher_mirror.source('publisher_validate'),C,'publisher_validate',xa=xa)
 upload_code,UL=compile_xa(patch_publisher_mirror.source('source_upload_guard'),C,'source_upload_guard',xa=xa)
 owner_guard_code,OL=compile_xa(patch_publisher_mirror.source('owner_cache_invalidate'),C,'owner_cache_invalidate',xa=xa)
 image,publisher_fix=patch_publisher_mirror.apply(image,publisher_code,PL,validator_code,VL,upload_code,UL,owner_guard_code,OL)
 labels.update(PL)
 labels.update(VL)
 labels.update(UL)
 labels.update(OL)
 mirror_fix['source_upload_guard_receipt']='PUBLISHER_MIRROR_BUILD.json'
 mirror_fix['actual_helper_code_sha256_after_upload_guard']=sha(image[patch_mirror_cache.ORIGIN:patch_mirror_cache.ORIGIN+len(mirror_code)])
 retired_publisher_labels={k:v for k,v in labels.items()if k.startswith('us_')and patch_publisher_mirror.ORIGIN<=v<patch_publisher_mirror.LIMIT}
 for k in retired_publisher_labels:del labels[k]
 labels.update(CL)
 (out/'BACKGROUND_CAMERA_BUILD.json').write_text(json.dumps(camera_fix,indent=2)+'\n')
 (out/'GRASS_BUILD.json').write_text(json.dumps(grass_fix,indent=2)+'\n')
 (out/'MIRROR_CACHE_BUILD.json').write_text(json.dumps(mirror_fix,indent=2)+'\n')
 (out/'PUBLISHER_MIRROR_BUILD.json').write_text(json.dumps(publisher_fix,indent=2)+'\n')
 game_fixes=dict(status='BUILT-actor-owner-bridge-camera-and-green-grass-corrections',
     original_MAIN_sha256=pre_fix_main_sha,MAIN_sha256=sha(image),
     owner_code_address=patch_owner.ADDRESS,owner_code_before=patch_owner.BEFORE.hex(),
     owner_code_after=patch_owner.AFTER.hex(),owner_cycles_delta_per_draw=1,
     bridge=bridge_fix,background_camera=camera_fix,grass_palette=grass_fix,mirror_cache=mirror_fix,publisher_mirror=publisher_fix,additional_guest_bytes=0,guest_bytes=81920)
 game_fixes['status']='BUILT-actor-owner-bridge-camera-grass-and-mirror-cache-corrections'
 (out/'GAME_FIXES_BUILD.json').write_text(json.dumps(game_fixes,indent=2)+'\n')
 b['artifacts']['banked-assets.bin']=dict(bytes=len(fixed_banks),sha256=sha(fixed_banks))
 b['game_fixes']=game_fixes
 cold=bytearray(image);low=(base/'vm-low-payload.bin').read_bytes();cursor=0
 for at,n in((0xd258,1448),(0xf258,1400)):
  assert image[at:at+n]==bytes(n);cold[at:at+n]=low[cursor:cursor+n];cursor+=n
 labels.update(L);labels.update(R);labels.update(SL)
 for name,data in(('native-main.bin',image),('cold-main.bin',cold),('cold-low-memory.bin',image[0x200:0xf00])):
  (out/name).write_bytes(data);b['artifacts'][name]=dict(bytes=len(data),sha256=sha(data))
 for name,start,data in(('transition_loader',M.CORE,code),('transition_ROM_stub',M.ROM_STUB,rom),('scene_capture',S.HELPER,scene),('scene_state',S.STATE,b'\0'),('background_config',S.BG_CONFIG,image[S.BG_CONFIG:S.BG_CONFIG+24]),('background_phase',S.PHASE_NODE,phase),('scheduler_post_arm',sp['helper_origin'],binary),('background_camera',patch_background_camera.ORIGIN,camera_code[:CL['camera_code_end']-patch_background_camera.ORIGIN]),('background_camera_d0',0xcfd0,bytes(2)),('background_camera_f0',0xcff0,bytes(2))):
  b['components'][name]=dict(name=name,start=start,end_exclusive=start+len(data),bytes=len(data),sha256=sha(data));(out/(name+'.bin')).write_bytes(data)
 b['components']['mirror_cache']=dict(name='mirror_cache',start=patch_mirror_cache.ORIGIN,end_exclusive=patch_mirror_cache.ORIGIN+len(mirror_code),bytes=len(mirror_code),sha256=sha(mirror_code))
 b['components']['mirror_cache']['sha256']=sha(image[patch_mirror_cache.ORIGIN:patch_mirror_cache.ORIGIN+len(mirror_code)])
 (out/'mirror_cache.bin').write_bytes(image[patch_mirror_cache.ORIGIN:patch_mirror_cache.ORIGIN+len(mirror_code)])
 (out/'publisher_mirror.bin').write_bytes(publisher_code)
 (out/'publisher_validate.bin').write_bytes(validator_code)
 (out/'source_upload_guard.bin').write_bytes(upload_code)
 (out/'owner_cache_invalidate.bin').write_bytes(owner_guard_code)
 b['components']['sprites']['upstream_sha256_before_publisher_override']=b['components']['sprites']['sha256']
 sb=b['components']['sprites'];sb['sha256']=sha(image[sb['start']:sb['end_exclusive']]);sb['publisher_mirror_override']=publisher_fix
 b['components']['publisher_validate']=dict(name='publisher_validate',start=patch_publisher_mirror.VALIDATE,end_exclusive=VL['publisher_validate_end'],bytes=len(validator_code),sha256=sha(validator_code))
 b['components']['source_upload_guard']=dict(name='source_upload_guard',start=UL['source_upload_guard'],end_exclusive=UL['source_upload_guard_end'],bytes=len(upload_code),sha256=sha(upload_code))
 b['components']['owner_cache_invalidate']=dict(name='owner_cache_invalidate',start=OL['owner_cache_invalidate'],end_exclusive=OL['owner_cache_invalidate_end'],bytes=len(owner_guard_code),sha256=sha(owner_guard_code))
 b['sprites']['retired_legacy_generic_publisher_entries']=retired_publisher_labels
 b['sprites']['CPU_decoder_staging'].update(bytes_used=len(validator_code),role='private IRQ publisher validator and scratch; source decoder still performs no staging reads or writes')
 for name,data in [('publisher_mirror.bin',publisher_code),('publisher_validate.bin',validator_code),('source_upload_guard.bin',upload_code),('owner_cache_invalidate.bin',owner_guard_code)]:b['artifacts'][name]=dict(bytes=len(data),sha256=sha(data))
 lang['baseline_native_main_sha256']=lang['native_main_sha256'];lang['native_main_sha256']=sha(image);lang['background_delta']='MULTILOAD_BUILD.json';b['language']=lang
 receipt=dict(status='BUILT033-experimental-multiload-not-qualified',base_MAIN_sha256=BASE_SHA,native_main_sha256=sha(image),cold_main_sha256=sha(cold),minimum_scenery_formats=23,required_dense_material_formats=8,P64B_operator_ABI=5,current_asset_only=True,gameplay_scene_LOADs=True,guest_main_bytes=65536,guest_aux_bytes=16384,guest_total_bytes=81920,additional_guest_backing=0,BG_buffer=[M.BUFFER,M.CORE],BG_capacity=M.MAX_BG_BYTES,loader_code=[M.CORE,M.CORE+len(code)],loader_code_limit=M.CORE_END,background_camera=camera_fix,grass_palette=grass_fix,ROM_stub=[M.ROM_STUB,M.ROM_STUB+len(rom)],workspace=[2,0xf00],workspace_bytes=3838,transient_MAIN=[dict(range=[0xd258,0xd800],bytes=1448),dict(range=[0xf258,0xf7d0],bytes=1400)],transient_AUX=[M.AUX_BACKUP,M.AUX_BACKUP+M.AUX_BACKUP_BYTES],transient_AUX_bytes=M.AUX_BACKUP_BYTES,unassigned_AUX_after_restore_zeroed=True,node_length_from_LOAD_end_minus_AD79=True,foreground_and_false_menu_branch_unchanged=True,phase_scene4=280,constructor0_or_outside1_17='NoLOAD;disableBGandcontinueoriginal',same_active_scene='Reuseonlyifready;oneassetresident',error='Latchstatus,restoreworkspace,keepDEN/BG/audiooff,redborder;SPACEretry',files=file_receipts,total_BG_on_disk=sum(r['bytes']for r in file_receipts),scheduler_packet_sha256=sha(scheduler.read_bytes()),original032_unchanged=True,labels=labels,source_sha256={p.name:sha(p.read_bytes())for p in(Path(__file__),HERE/'multiload_runtime.py',HERE/'scene_context.py',HERE/'cold.py',HERE/'patch_owner.py',HERE/'patch_bridge_templates.py',HERE/'patch_background_camera.py',HERE/'background_camera.asm',HERE/'patch_grass_palette.py')},scope='Experimentalguestloaderanddiskpack;CPUandactualKERNALfootprint/C16/Plus4coldqualificationrequired')
 b.update(status=receipt['status'],background=receipt,cold_D64_boot_verified=False,gameplay_verified=False)
 receipt['mirror_cache']=mirror_fix
 receipt['publisher_mirror']=publisher_fix
 receipt['retired_legacy_generic_publisher_entries']=retired_publisher_labels
 receipt['source_sha256'].update({p.name:sha(p.read_bytes())for p in(HERE/'patch_mirror_cache.py',HERE/'mirror_cache.asm')})
 receipt['source_sha256'].update({p.name:sha(p.read_bytes())for p in(HERE/'patch_publisher_mirror.py',HERE/'publisher_mirror.asm',HERE/'publisher_validate.asm',HERE/'publisher_lease_PROOF.json')})
 receipt['source_sha256'].update({p.name:sha(p.read_bytes())for p in(HERE/'source_upload_guard.asm',HERE/'owner_cache_invalidate.asm')})
 receipt['source_sha256']['upload_guard_lease_PROOF.json']=sha((HERE/'upload_guard_lease_PROOF.json').read_bytes())
 b['known_integration_limits']=['Requires source8 and scenery23/P64B native-origin flag runtime','Disk contains17packets; onlycurrentBGisaddressable in7376Bslot','TransitionusesexistingKERNALROM plus measuredlowworkspaceanddisplayleases','Artpacketandnative/Wine/visualqualificationsmustbindthisexactcandidate']
 b['materials']['transition_workspace_reservation']=[M.AUX_BACKUP,M.AUX_BACKUP+M.AUX_BACKUP_BYTES]
 b['materials']['unassigned_peak_LOAD_bytes']=0x2000-(M.AUX_BACKUP+M.AUX_BACKUP_BYTES)
 b['memory']['transition_lifetimes']=dict(workspace=[2,0xf00],MAIN_output_leases=[[0xd258,0xd800],[0xf258,0xf7d0]],AUX_workspace=[M.AUX_BACKUP,M.AUX_BACKUP+M.AUX_BACKUP_BYTES],all_restored_before_originalconstructor=True,separate_saved_source_cell=0xd798)
 b['memory']['new_MAIN_reservations']=[dict(name='currentBG',start=M.BUFFER,end_exclusive=M.CORE,bytes=M.MAX_BG_BYTES),dict(name='transitioncodeandstate',start=M.CORE,end_exclusive=M.CORE_END,capacity=M.CORE_END-M.CORE,actual_bytes=len(code)+camera_fix['code_and_state_bytes']+camera_fix['original_OS_save_bytes'],background_camera=camera_fix)]
 b['memory']['new_MAIN_reservations'][1]['actual_bytes']+=len(mirror_code)
 b['memory']['new_MAIN_reservations'][1]['mirror_cache']=mirror_fix
 b['memory']['new_MAIN_reservations'][1]['actual_bytes']+=len(owner_guard_code)
 b['memory']['new_MAIN_reservations'][1]['owner_cache_invalidator']=[OL['owner_cache_invalidate'],OL['owner_cache_invalidate_end']]
 (out/'RECEIPT_AUTHORITY.md').write_text('Current033 authority: BUILD.json, MULTILOAD_BUILD.json, LANGUAGE_BUILD.json and matching BOOT.json.\nCopied FRAMEID/REPAIR/COMPACT/SPRITE_VM receipts document upstream032/031/030/029 source stages, not current033 whole-image/native qualification.\nUse separately hashed CPU, actualKERNAL, art, C/native, Wine and performance receipts; no qualification is inherited automatically.\n')
 for n,d in(('BUILD.json',b),('labels.json',labels),('LANGUAGE_BUILD.json',lang),('MULTILOAD_BUILD.json',receipt)):(out/n).write_text(json.dumps(d,indent=2)+'\n')
 return receipt

def cold(repo,link,packets,out):
 repo,link,packets,out=[Path(x).resolve()for x in(repo,link,packets,out)]
 subprocess.run([sys.executable,str(HERE/'cold.py'),'--repo',str(repo),'--link',str(link),'--out',str(out)],check=True,stdout=subprocess.PIPE,text=True)
 sp=importlib.util.spec_from_file_location('multiload_d64',repo/'docs/developers/sdk-current/baseline/d64.py');d=importlib.util.module_from_spec(sp);sp.loader.exec_module(d)
 files=[(name,(out/(name+'.PRG')).read_bytes())for name in('USAGI','ASSETS','MAIN')]
 for scene in range(1,18):
  name=f'B{scene:02d}';data=M.BUFFER.to_bytes(2,'little')+(packets/f'scene{scene:02d}.p64z').read_bytes();(out/(name+'.PRG')).write_bytes(data);files.append((name,data))
 disk=d.pack(files,label='USAGI PLUS64',disk_id='UY');(out/'USAGI.D64').write_bytes(disk)
 b=json.loads((out/'BOOT.json').read_text());b['three_file_D64_sha256']=b['D64_sha256'];b['D64_sha256']=sha(disk);b.update(required_disk_files=[n for n,_ in files],background_scene_files=17,gameplay_disk_reads='Onconstructor1..17ifactiveassetdiffers;pausedtransition',BG_resident_capacity=M.MAX_BG_BYTES,status='BUILT033-20file-multiload-D64-needs-actualqualification')
 (out/'BOOT.json').write_text(json.dumps(b,indent=2)+'\n');return b

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--repo',type=Path,required=True);p.add_argument('--baseline',type=Path,required=True);p.add_argument('--packets',type=Path,required=True);p.add_argument('--scheduler',type=Path,required=True);p.add_argument('--out',type=Path,required=True);p.add_argument('--boot-out',type=Path);a=p.parse_args();r=build(a.repo,a.baseline,a.packets,a.scheduler,a.out)
 print(json.dumps({k:r[k]for k in('status','native_main_sha256','loader_code','ROM_stub','BG_capacity')},indent=2))
 if a.boot_out:
  r=cold(a.repo,a.out,a.packets,a.boot_out);print(json.dumps({k:r[k]for k in('status','D64_sha256','main_compressed_bytes','required_disk_files')},indent=2))
