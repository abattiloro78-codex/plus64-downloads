"""Guarded physical-matrix camera publication, entirely within RAM80.

Each TED source matrix has its own coarse pixel-coordinate word. Preparing
the future word before the original BA flip makes IRQ preemption safe: the
old selection retains the old word, while the new word is complete before
BA can select it. The native FF14 selector publishes the node pointer using
the same D0/F0 value. Scenery23's generic native-origin flag supplies the
actual source fine scroll; neither A4, A8 nor a future BB value is used.
"""
from pathlib import Path
import hashlib

ORIGIN = 0xcf47
END = 0xcff2
OS_SAVE = (0xcfb3, 0xcfbf)
INPUT_MAIN_SHA256 = '4035fde92fcec99cce803a8fe9e739f31b6ae2d9b241994dfc143433c2a9a321'
CAMERA_POINTER = 0x4733
POINTER_BEFORE = bytes.fromhex('a400')
CAMERA_FLAGS = 0x473c
SELECTOR = 0x2af5
SELECTOR_BEFORE = bytes.fromhex('a5ba2910f004a9f0d002a9d08d14ff60')
# Carry from ASL is overwritten by SEC in the sole caller2B8A before use.
SELECTOR_AFTER = bytes.fromhex('a5ba29100a09d08d14ff8d334760eaea')
FLIP = 0x5e65
FLIP_BEFORE = bytes.fromhex('a5ba491085ba')

def source():
    return Path(__file__).with_name('background_camera.asm').read_text()

def apply(raw, code, labels):
    image = bytearray(raw)
    if len(image) != 65536 or hashlib.sha256(image).hexdigest() != INPUT_MAIN_SHA256:
        raise ValueError('R8 pre-camera MAIN guard failed')
    if len(code) != END - ORIGIN:
        raise ValueError('Physical-camera assembled span must end at CFF2')
    if not ORIGIN < labels['camera_code_end'] <= OS_SAVE[0]:
        raise ValueError('Physical-camera code overlaps original OS save')
    if labels['camera_d0'] != 0xcfd0 or labels['camera_f0'] != 0xcff0:
        raise ValueError('Camera word addresses must match physical FF14 bank values')
    if code[OS_SAVE[0]-ORIGIN:OS_SAVE[1]-ORIGIN] != bytes(OS_SAVE[1]-OS_SAVE[0]):
        raise ValueError('Assembled padding overwrites original OS save')
    if image[ORIGIN:END] != bytes(END - ORIGIN):
        raise ValueError('Transition tail guard failed')
    checks = ((0x2be6, bytes.fromhex('20135f')), (FLIP, FLIP_BEFORE),
              (SELECTOR, SELECTOR_BEFORE), (CAMERA_POINTER, POINTER_BEFORE),
              (CAMERA_FLAGS, bytes(3)))
    for address, expected in checks:
        if image[address:address+len(expected)] != expected:
            raise ValueError(f'Physical-camera hook guard failed at {address:04x}')
    patches = []
    def put(address, replacement):
        before = bytes(image[address:address+len(replacement)])
        image[address:address+len(replacement)] = replacement
        patches.append(dict(address=address, before=before.hex(), after=replacement.hex()))
    target = labels['camera_init']
    put(0x2be6, bytes((0x20,target&255,target>>8)))
    target = labels['camera_flip']
    put(FLIP, bytes((0x20,target&255,target>>8,0xea,0xea,0xea)))
    put(SELECTOR, SELECTOR_AFTER)
    put(CAMERA_POINTER, bytes.fromhex('d0cf'))
    put(CAMERA_FLAGS, bytes.fromhex('010000'))
    # Copy only actual code and explicit zero-initialized words. Padding is
    # assembler transport, not an allocation or a write to the OS-save slot.
    code_end = labels['camera_code_end']
    image[ORIGIN:code_end] = code[:code_end-ORIGIN]
    image[0xcfd0:0xcfd2] = bytes(2)
    image[0xcff0:0xcff2] = bytes(2)
    assert image[OS_SAVE[0]:OS_SAVE[1]] == raw[OS_SAVE[0]:OS_SAVE[1]]
    occupied = code_end - ORIGIN + 4
    report = dict(status='BUILT-game-only-buffer-epoch-camera-not-runtime-qualified',
        input_MAIN_sha256=INPUT_MAIN_SHA256, MAIN_sha256=hashlib.sha256(image).hexdigest(),
        code_allocation=[ORIGIN,code_end], state_allocations=[[0xcfd0,0xcfd2],[0xcff0,0xcff2]],
        reserved_lease=[ORIGIN,END], assembled_span_bytes=len(code),
        code_and_state_bytes=occupied, state_bytes=4, original_OS_save=list(OS_SAVE),
        original_OS_save_preserved=True, original_OS_save_bytes=OS_SAVE[1]-OS_SAVE[0],
        unused_reserved_tail_bytes=END-ORIGIN-occupied-(OS_SAVE[1]-OS_SAVE[0]),
        camera_pointer_address=CAMERA_POINTER, camera_pointer_before=POINTER_BEFORE.hex(),
        camera_pointer_after='d0cf', camera_flags_address=CAMERA_FLAGS,
        native_origin_flag=1, minimum_scenery_formats=23,
        formula='Selected buffer coarse pixel word minus actual native TED source-origin offset',
        future_word='Active word +8, completed before original BA flip', patches=patches,
        preserves_logical_camera_A4_A5=True, preserves_original_A8_A9=True,
        preserves_original_BB=True, preserves_actor_collision_and_map_inputs=True,
        flip_preserves_X_Y=True, flip_preserves_original_A_P_result=True,
        arithmetic_decimal_disabled_locally=True, no_long_compute_in_timed_callback=True,
        selector_cycles_before={'D0':20,'F0':23},selector_cycles_after=23,
        selector_carry_note='Changed locally by ASL, overwritten before use by sole caller2B8A SEC2B9D.',
        guest_MAIN_bytes=65536,guest_AUX_bytes=16384,additional_guest_backing_bytes=0,
        labels={name:labels[name] for name in ('camera_init','camera_flip','camera_code_end','camera_d0','camera_f0')})
    return image, report
