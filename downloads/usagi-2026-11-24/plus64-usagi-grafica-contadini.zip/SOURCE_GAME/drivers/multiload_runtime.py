"""Guest-only033 transition loader. Own sources; no installed baseline mutation.

RAM80allocation: sourcefree8825 splits into7376B activeBG +1449B loader;
lowROMstub138B is retired4715code, disjointscene51B+scheduler52B.
Transientworkspace3838B uses existingTEDplanes2848B +unassignedAUX990B.
"""
import scene_context as S
import re

def _long_branches(source):
 inverse={"beq":"bne","bne":"beq","bcs":"bcc","bcc":"bcs","bpl":"bmi","bmi":"bpl","bvs":"bvc","bvc":"bvs"};out=[];n=0
 for line in source.splitlines():
  if line.lstrip().startswith(";"):line=line.replace(":",",")
  m=re.fullmatch(r" (beq|bne|bcs|bcc|bpl|bmi|bvs|bvc) ([A-Za-z_][A-Za-z_0-9]*)",line)
  if m:
   label=f"ml_long_branch_{n}";n+=1;out.extend([f" {inverse[m[1]]} {label}",f" jmp {m[2]}",label+":"])
  else:out.append(line)
 return "\n".join(out)+"\n"

CORE=0xca49
CORE_END=0xcff2
ROM_STUB=0x4784
ROM_END=0x480e
BUFFER=0xad79
MAX_BG_BYTES=7376
AUX_BACKUP=0x1bc2
AUX_BACKUP_BYTES=990
IO_REGS=tuple(range(0xff00,0xff08))+tuple(range(0xff0a,0xff1c))+(0xfd90,0xfd30)

def rom_source(*,core_labels):
 L=core_labels
 return f'''*=${ROM_STUB:04x}
ml_rom_entry:
 lda #0
 sta $ff3e
 jsr $ff8a
 lda #0
 sta $f9
 jsr $ffe7
 ldx #11
ml_restore_OS_trampoline:
 lda $cfb3,x
 sta $07d9,x
 dex
 bpl ml_restore_OS_trampoline
 lda #$ff
 sta $91
 lda #0
 sta $f9
 jsr $ff90
 lda #3
 ldx #<ml_filename
 ldy #>ml_filename
 jsr $ffbd
 lda #1
 ldx #8
 ldy #1
 jsr $ffba
 lda #0
ml_before_KERNAL_LOAD:
 jsr $ffd5
ml_after_KERNAL_LOAD:
 sta ml_load_A
 stx ml_load_end
 sty ml_load_end+1
 php
 pla
 sta ml_load_P
 jsr $ffb7
 sta ml_load_ST
 sei
 lda #0
 sta $ff3f
ml_after_ROM_off:
 jmp ${L['ml_after_load']:04x}
ml_filename:
 .asc "B01"
ml_load_A:
 .byt 0
ml_load_end:
 .word 0
ml_load_P:
 .byt 0
ml_load_ST:
 .byt 0
'''

def core_source(*,rom_labels):
 R=rom_labels
 io_save=''.join(f' lda ${a:04x}\n sta ml_io+{i}\n'for i,a in enumerate(IO_REGS))
 # DEN,interruptmask andvirtualsprites remainoffuntilallworkspaceisrestored.
 io_restore=''.join(f' lda ml_io+{i}\n sta ${a:04x}\n'for i,a in enumerate(IO_REGS)if a not in(0xff06,0xff0a,0xfd90))
 den_i=IO_REGS.index(0xff06);irq_i=IO_REGS.index(0xff0a);sprite_i=IO_REGS.index(0xfd90)
 return _long_branches(f'''*=${CORE:04x}
ml_enter:
 ; EntryispostoriginalTAY/LDA78F1,Y,aftercaptureofrawsceneat4726.
 sta ml_saved_A
 stx ml_saved_X
 sty ml_saved_Y
 php
 pla
 sta ml_saved_P
 tsx
 stx ml_saved_SP
 sei
 cld
 lda #$fd
 sta ml_resume+1
 lda #$5a
 sta ml_resume+2
 lda ${S.STATE:04x}
 beq ml_no_scene
 cmp #18
 bcc ml_valid_scene
ml_no_scene:
 lda #0
 sta ml_ready
 sta ${S.BG_CONFIG+5:04x}
 sta ${S.BG_CONFIG+6:04x}
 jmp ml_restore_registers
ml_valid_scene:
 ; Onlythecurrentcompleteassetmaybereused;nohistorycacheexists.
 cmp ml_loaded_scene
 bne ml_need_load
 lda ml_ready
 beq ml_need_load
 jmp ml_restore_registers
ml_need_load:
 lda #0
 sta ml_ready
 sta ml_error
 sta ${S.BG_CONFIG+5:04x}
 sta ${S.BG_CONFIG+6:04x}
 lda $d798
 sta ml_saved_D798
 lda $00
 sta ml_saved_DDR
 lda $01
 sta ml_saved_port
 lda $0e64
 sta ml_saved_gate
 lda $fd97
 sta ml_saved_auxlo
 lda $fd98
 sta ml_saved_auxhi
{io_save} lda $ff06
 and #$ef
 sta $ff06
 lda #0
 sta $ff0a
 sta $fd90
 lda $e014
 and #$f0
 sta $fd58
 lda ${S.STATE:04x}
 cmp #10
 bcc ml_filename_single
 sec
 sbc #10
 ldx #49
 bne ml_filename_digit
ml_filename_single:
 ldx #48
ml_filename_digit:
 clc
 adc #48
 sta ${R['ml_filename']+2:04x}
 stx ${R['ml_filename']+1:04x}
 ldx #0
 jsr ml_copy_ram
 ldx #1
 jsr ml_copy_ram
 jsr ml_backup_aux
 ; Gatezeroonlyafteritssourceworkspacebytehasbeenbackedup.
 lda #0
 sta $0e64
 sta $ff09
 jmp ${ROM_STUB:04x}
ml_after_load:
 cld
 ; ROMisoffbeforeanyhighcode/readfromoutputplanes.
 jsr ml_restore_aux
 ldx #2
 jsr ml_copy_ram
 ; Lastrestoreincludesthehardwarestack:tail-jump,nopendingJSRreturn.
 ldx #3
 jmp ml_copy_ram
ml_restored_workspace:
 lda ml_saved_D798
 sta $d798
 lda ml_saved_port
 sta $01
 lda ml_saved_DDR
 sta $00
{io_restore} lda #$ff
 sta $ff08
 lda ml_saved_auxlo
 sta $fd97
 lda ml_saved_auxhi
 sta $fd98
 lda $e014
 sta $fd58
 lda ${R['ml_load_P']:04x}
 and #1
 bne ml_load_error
 lda ${R['ml_load_ST']:04x}
 and #$bf
 bne ml_load_error
 sec
 lda ${R['ml_load_end']:04x}
 sbc #${BUFFER&255:02x}
 sta ml_length
 lda ${R['ml_load_end']+1:04x}
 sbc #${BUFFER>>8:02x}
 sta ml_length+1
 bcc ml_bad_file
 cmp #${MAX_BG_BYTES>>8:02x}
 bcc ml_length_upper_ok
 bne ml_bad_file
 lda ml_length
 cmp #${(MAX_BG_BYTES&255)+1:02x}
 bcs ml_bad_file
ml_length_upper_ok:
 lda ml_length+1
 bne ml_length_min_ok
 lda ml_length
 cmp #12
 bcc ml_bad_file
ml_length_min_ok:
 ldx #3
ml_magic_loop:
 lda ${BUFFER:04x},x
 cmp ml_magic,x
 bne ml_bad_file
 dex
 bpl ml_magic_loop
 lda ${BUFFER+4:04x}
 cmp #1
 bne ml_bad_file
 lda ${BUFFER+5:04x}
 cmp #1
 beq ml_method_ok
 cmp #2
 bne ml_bad_file
ml_method_ok:
 lda ${BUFFER+10:04x}
 ora ${BUFFER+11:04x}
 bne ml_bad_file
 clc
 lda ${BUFFER+8:04x}
 adc #12
 sta ml_check_length
 lda ${BUFFER+9:04x}
 adc #0
 cmp ml_length+1
 bne ml_bad_file
 lda ml_check_length
 cmp ml_length
 bne ml_bad_file
 lda ml_length
 sta ${S.BG_CONFIG+5:04x}
 lda ml_length+1
 sta ${S.BG_CONFIG+6:04x}
 lda ${S.STATE:04x}
 sta ml_loaded_scene
 lda #1
 sta ml_ready
 ; PendingrasterIRQsarediscardedonlyforthedocumentedpausedtransition.
 lda #$ff
 sta $ff09
 lda ml_io+{sprite_i}
 sta $fd90
 lda ml_io+{irq_i}
 sta $ff0a
 lda ml_io+{den_i}
 sta $ff06
 jmp ml_restore_registers
ml_bad_file:
 lda #$7f
 bne ml_record_error
ml_load_error:
 lda ${R['ml_load_ST']:04x}
 ora #$80
ml_record_error:
 sta ml_error
 lda $e014
 and #$f0
 sta $fd58
 lda #0
 sta $0e64
 sta $fd90
 sta $ff0a
 sta ${S.BG_CONFIG+5:04x}
 sta ${S.BG_CONFIG+6:04x}
 lda ml_io+{den_i}
 and #$ef
 sta $ff06
 lda #$32
 sta $ff19
 ; Errorislatchedanddoesnotreturntotheoldscene.
ml_failed:
 lda #$7f
 sta $fd30
 lda #$ff
 sta $ff08
 lda $ff08
 and #$10
 bne ml_failed
 lda ml_io+{IO_REGS.index(0xfd30)}
 sta $fd30
 lda ml_saved_gate
 sta $0e64
 lda ml_io+{IO_REGS.index(0xff19)}
 sta $ff19
 lda ml_io+{den_i}
 sta $ff06
 lda ml_io+{irq_i}
 sta $ff0a
 lda ml_io+{sprite_i}
 sta $fd90
 lda $e014
 sta $fd58
 lda #<ml_enter
 sta ml_resume+1
 lda #>ml_enter
 sta ml_resume+2
 jmp ml_restore_registers
ml_restore_registers:
 ldx ml_saved_SP
 txs
 ldy ml_saved_Y
 ldx ml_saved_X
 lda ml_saved_P
 pha
 lda ml_saved_A
 plp
ml_resume:
 jmp $5afd
ml_copy_ram:
 stx ml_copy_index
 lda ml_src_lo,x
 sta ml_copy_read+1
 lda ml_src_hi,x
 sta ml_copy_read+2
 lda ml_dst_lo,x
 sta ml_copy_write+1
 lda ml_dst_hi,x
 sta ml_copy_write+2
 lda ml_tail,x
 sta ml_copy_tail+1
 ldx #5
 ldy #0
ml_copy_page:
ml_copy_read:
 lda $ffff,y
ml_copy_write:
 sta $ffff,y
 iny
 bne ml_copy_page
 inc ml_copy_read+2
 inc ml_copy_write+2
 dex
 bne ml_copy_page
ml_copy_last:
 lda ml_copy_read+1
 sta ml_tail_read+1
 lda ml_copy_read+2
 sta ml_tail_read+2
 lda ml_copy_write+1
 sta ml_tail_write+1
 lda ml_copy_write+2
 sta ml_tail_write+2
ml_tail_loop:
ml_tail_read:
 lda $ffff,y
ml_tail_write:
 sta $ffff,y
 iny
ml_copy_tail:
 cpy #0
 bne ml_tail_loop
 ldx ml_copy_index
 cpx #3
 beq ml_restored_workspace
 rts
ml_backup_aux:
 lda #${AUX_BACKUP&255:02x}
 sta $fd97
 lda #${AUX_BACKUP>>8:02x}
 sta $fd98
 lda #$0b
 sta ml_aux_read+2
 ldx #3
 ldy #0
ml_aux_backup_page:
ml_aux_read:
 lda $0b22,y
 sta $fd96
 iny
 bne ml_aux_backup_page
 inc ml_aux_read+2
 dex
 bne ml_aux_backup_page
ml_aux_backup_tail:
 lda $0e22,y
 sta $fd96
 iny
 cpy #222
 bne ml_aux_backup_tail
 rts
ml_restore_aux:
 lda #${AUX_BACKUP&255:02x}
 sta $fd97
 lda #${AUX_BACKUP>>8:02x}
 sta $fd98
 lda #$0b
 sta ml_aux_write+2
 ldx #3
 ldy #0
ml_aux_restore_page:
 lda $fd96
ml_aux_write:
 sta $0b22,y
 iny
 bne ml_aux_restore_page
 inc ml_aux_write+2
 dex
 bne ml_aux_restore_page
ml_aux_restore_tail:
 lda $fd96
 sta $0e22,y
 iny
 cpy #222
 bne ml_aux_restore_tail
 lda #${AUX_BACKUP&255:02x}
 sta $fd97
 lda #${AUX_BACKUP>>8:02x}
 sta $fd98
 lda #0
 ldx #3
 ldy #0
ml_aux_clear_page:
 sta $fd96
 iny
 bne ml_aux_clear_page
 dex
 bne ml_aux_clear_page
ml_aux_clear_tail:
 sta $fd96
 iny
 cpy #222
 bne ml_aux_clear_tail
 rts
ml_magic:
 .asc "P64Z"
ml_src_lo:
 .byt $02,$aa,$58,$58
ml_src_hi:
 .byt $00,$05,$f2,$d2
ml_dst_lo:
 .byt $58,$58,$aa,$02
ml_dst_hi:
 .byt $d2,$f2,$05,$00
ml_tail:
 .byt 168,120,120,168
ml_copy_index:
 .byt 0
ml_saved_A:
 .byt 0
ml_saved_X:
 .byt 0
ml_saved_Y:
 .byt 0
ml_saved_SP:
 .byt 0
ml_saved_P:
 .byt 0
ml_saved_D798:
 .byt 0
ml_saved_DDR:
 .byt 0
ml_saved_port:
 .byt 0
ml_saved_gate:
 .byt 0
ml_saved_auxlo:
 .byt 0
ml_saved_auxhi:
 .byt 0
ml_check_length:
 .byt 0
ml_length:
 .word 0
ml_loaded_scene:
 .byt 0
ml_ready:
 .byt 0
ml_error:
 .byt 0
ml_io:
 .dsb {len(IO_REGS)},0
ml_end:
''')
