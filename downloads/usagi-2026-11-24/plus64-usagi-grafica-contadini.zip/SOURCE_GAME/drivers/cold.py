#!/usr/bin/env python3
"""Work-only3fileD64 coldtransport, all81920guestbytes restored beforeplay.

USAGI loads ASSETS and MAIN viaordinaryKERNAL. Onlyduringboot are existing
native outputplanes/color shadow reused; no file/ROM/hostatlas is read inplay.
"""
from pathlib import Path
import sys,argparse,json,hashlib,importlib.util
sys.dont_write_bytecode=True
# --repo is explicit; no private workspace path is needed by this builder.
_bootstrap_parser=argparse.ArgumentParser(add_help=False)
_bootstrap_parser.add_argument('--repo',type=Path,required=True)
_bootstrap_args,_=_bootstrap_parser.parse_known_args()
ROOT=_bootstrap_args.repo.resolve();PORT=ROOT/'tools-game/usagi-port';HERE=Path(__file__).resolve().parent
if not(PORT/'boot.py').is_file():raise FileNotFoundError('Expected --repo/tools-game/usagi-port/boot.py')
sys.path[:0]=[str(PORT),str(PORT/'language')]
import boot,boot_materials,cold_codec
from native import compile_xa
sha=lambda b:hashlib.sha256(b).hexdigest()
TAIL_SOURCE,LOW_SOURCE,DECODER_SOURCE,FINAL_SOURCE,HEADER_END=0x1200,0x1500,0x2000,0x2300,0x2400

def finalizer(entry):
 src=boot.finalizer_source(entry,low_restore=True)
 old=f' ; Native entry must restore A00..AFF from aux0800..08FF before us_init.\n jmp ${entry:04x}'
 assert src.count(old)==1
 return src.replace(old,f''' ; Preserve thelastpersistentlowpagebeforeVMoverwritesaux0800.
 lda #0
 sta $fd97
 lda #8
 sta $fd98
 ldx #0
bf_backup_A00:
 lda $fd96
 sta $d800,x
 inx
 bne bf_backup_A00
 lda #$e0
 sta $fd97
 lda #2
 sta $fd98
 lda #$58
 sta $f7
 lda #$d2
 sta $f8
 ldx #0
 ldy #0
bf_late_VM:
 lda ($f7),y
 sta $fd96
 lda #0
 sta ($f7),y
 inc $f7
 bne bf_late_compare
 inc $f8
bf_late_compare:
 lda $f8
 cmp bf_late_end_hi,x
 bne bf_late_VM
 lda $f7
 cmp bf_late_end_lo,x
 bne bf_late_VM
 inx
 cpx #2
 beq bf_late_done
 lda #$58
 sta $f7
 lda #$f2
 sta $f8
 jmp bf_late_VM
bf_late_done:
 lda #0
 sta $f7
 sta $f8
 jmp ${entry:04x}
bf_late_end_lo:
 .byt $00,$d0
bf_late_end_hi:
 .byt $d8,$f7''')

def main_start():
 return f'''*=$1100
boot_start:
 sei
 cld
 ldx #$ff
 txs
 lda $fdec
 cmp #$64
 beq *+5
 jmp boot_fail
 lda $fded
 cmp #5
 beq *+5
 jmp boot_fail
 lda #0
 sta $fd90
 sta $fd9f
 sta $ff0a
 sta $ff11
 sta $ff3f
 lda $ff06
 and #$ef
 sta $ff06
 ldx #0
boot_copy_code:
 lda ${DECODER_SOURCE:04x},x
 sta $0400,x
 lda ${DECODER_SOURCE+256:04x},x
 sta $0500,x
 lda ${DECODER_SOURCE+512:04x},x
 sta $0600,x
 inx
 bne boot_copy_code
 lda #3
 sta $fdeb
 lda #0
 sta $fde8
 lda #$3d
 sta $fde9
 ldx #0
boot_tail0:
 lda $1200,x
 sta $fdea
 inx
 bne boot_tail0
boot_tail1:
 lda $1300,x
 sta $fdea
 inx
 bne boot_tail1
boot_tail2:
 lda $1400,x
 sta $fdea
 inx
 bne boot_tail2
 lda #0
 sta $fd97
 sta $fd98
 ldx #0
 ldy #14
boot_clear_low:
 sta $fd96
 inx
 bne boot_clear_low
 dey
 bne boot_clear_low
 jsr $0520
 ; Lowdecoderleavesauxpointer0D00;uploadonetemporaryfinalizerpage.
 lda #0
 sta $f7
 lda #$23
 sta $f8
 ldx #0
 ldy #0
boot_finalizer_page:
 lda ($f7),y
 sta $fd96
 iny
 bne boot_finalizer_page
 jmp $0400
boot_fail:
 lda #$32
 sta $ff19
boot_failed:
 jmp boot_failed
'''

def resident_loader():
 return '''*=$0a00
loader_entry:
 cli
 lda #6
 ldx #<name_assets
 ldy #>name_assets
 jsr $ffbd
 lda #1
 ldx #8
 ldy #1
 jsr $ffba
 lda #0
 jsr $ffd5
 bcs loader_fail
 sei
 lda #0
 sta $fd97
 lda #$20
 sta $fd98
 lda #0
 sta $f7
 lda #$20
 sta $f8
 ldx #32
 jsr loader_aux_pages
 lda #0
 sta $fd97
 lda #$0e
 sta $fd98
 lda #$40
 sta $f8
 ldx #18
 jsr loader_aux_pages
 cli
 lda #4
 ldx #<name_main
 ldy #>name_main
 jsr $ffbd
 lda #1
 ldx #8
 ldy #1
 jsr $ffba
 lda #0
 jsr $ffd5
 bcs loader_fail
 sei
 jmp $1100
loader_aux_pages:
 ldy #0
loader_aux_page:
 lda ($f7),y
 sta $fd96
 iny
 bne loader_aux_page
 inc $f8
 dex
 bne loader_aux_page
 rts
loader_fail:
 sei
 lda #$32
 sta $ff19
loader_stop:
 jmp loader_stop
name_assets:
 .byt $41,$53,$53,$45,$54,$53
name_main:
 .byt $4d,$41,$49,$4e
'''

def loader_start(size):
 return f'''*=$1100
loader_start:
 lda #0
 jsr $ff90
 lda #0
 sta $fd90
 sta $fd9f
 lda $ff06
 and #$ef
 sta $ff06
 ldx #0
loader_copy:
 lda $1200,x
 sta $0a00,x
 inx
 cpx #{size}
 bne loader_copy
 jmp $0a00
'''

def build(link,out):
 link=Path(link).resolve();out=Path(out).resolve()
 if out.exists():raise FileExistsError(out)
 out.mkdir(parents=True);main=(link/'native-main.bin').read_bytes();cold=(link/'cold-main.bin').read_bytes();high=(link/'materials.bin').read_bytes();banks=(link/'banked-assets.bin').read_bytes();manifest=json.loads((link/'BUILD.json').read_text());entry=manifest['native_entry']
 assert len(main)==len(cold)==65536 and len(high)==4608 and len(banks)==8192
 stream,stats=cold_codec.encode(cold[0xf00:0xfd00],origin=0xf00);assert boot.decode(stream,0xee00)==cold[0xf00:0xfd00];layout=boot.inplace_proof(stream,0xee00)
 low,lowstats=boot.encode(cold[0x200:0xf00]);assert boot.decode(low,0xd00)==cold[0x200:0xf00]
 assert LOW_SOURCE+len(low)<=DECODER_SOURCE and layout['stream_start']>=HEADER_END
 dec,dl=compile_xa(boot.decoder_source(layout['stream_start'],low_restore=True),out,'decode',xa=ROOT/'tools-game/bin/xa')
 low_source=boot_materials.decoder_source(LOW_SOURCE,len(low))
 for old,new in [('bm_dest_start:\n .byt $20,$0e','bm_dest_start:\n .byt $20,$00'),('bm_dest_end:\n .byt $40,$20','bm_dest_end:\n .byt $40,$0d'),('bm_history_delta:\n .byt $11,$ff','bm_history_delta:\n .byt $11,$f1')]:
  assert low_source.count(old)==1;low_source=low_source.replace(old,new)
 helper,hl=compile_xa(low_source,out,'low-decode',xa=ROOT/'tools-game/bin/xa')
 final,fl=compile_xa(finalizer(entry),out,'finalize',xa=ROOT/'tools-game/bin/xa')
 start,sl=compile_xa(main_start(),out,'start',xa=ROOT/'tools-game/bin/xa')
 assert len(start)<=256 and len(final)<=256 and len(dec)<=0x120 and 0x120+len(helper)<=0x300
 transport=bytearray(0xfd00-0x1001)
 ranges=[]
 def put(at,data,name):
  assert 0x1001<=at<at+len(data)<=0xfd00
  for a,z,n in ranges:assert not(a<at+len(data)and at<z),(name,n)
  ranges.append((at,at+len(data),name));transport[at-0x1001:at-0x1001+len(data)]=data
 put(0x1001,bytes.fromhex('0b10ea079e34333532000000'),'BASIC')
 put(0x1100,start,'start');put(TAIL_SOURCE,cold[0xfd00:],'tail');put(LOW_SOURCE,low,'low');put(DECODER_SOURCE,dec,'decoder');put(DECODER_SOURCE+0x120,helper,'lowhelper');put(FINAL_SOURCE,final,'finalizer');put(layout['stream_start'],stream,'mainstream')
 main_prg=b'\x01\x10'+transport
 res,rl=compile_xa(resident_loader(),out,'loader-resident',xa=ROOT/'tools-game/bin/xa');assert len(res)<=255
 first,fs=compile_xa(loader_start(len(res)),out,'loader-start',xa=ROOT/'tools-game/bin/xa');assert len(first)<=256
 front=bytearray(0x1200+len(res)-0x1001);front[:12]=bytes.fromhex('0b10ea079e34333532000000');front[0x1100-0x1001:0x1100-0x1001+len(first)]=first;front[0x1200-0x1001:]=res
 launch=b'\x01\x10'+front;assets=b'\x00\x20'+banks+high
 spec=importlib.util.spec_from_file_location('_staged_d64',ROOT/'docs/developers/sdk-current/baseline/d64.py');diskmod=importlib.util.module_from_spec(spec);spec.loader.exec_module(diskmod)
 disk=diskmod.pack([('USAGI',launch),('ASSETS',assets),('MAIN',main_prg)],label='USAGI PLUS64',disk_id='UY')
 for name,data in [('USAGI.PRG',launch),('ASSETS.PRG',assets),('MAIN.PRG',main_prg),('USAGI.D64',disk),('compressed-main.bin',stream),('compressed-low.bin',low),('runtime-main.bin',main),('cold-main.bin',cold)]: (out/name).write_bytes(data)
 report=dict(status='BUILT-three-file-ordinary-KERNAL-D64-needs-native-qualification',standalone_PRG=False,launch_file='USAGI',required_disk_files=['USAGI','ASSETS','MAIN'],gameplay_disk_reads=0,guest_main_bytes=65536,guest_internal_bytes=16384,guest_total_bytes=81920,additional_guest_RAM_bytes=0,native_entry=entry,boot_entry=0x1100,main_sha256=sha(main),cold_main_sha256=sha(cold),D64_sha256=sha(disk),PRG_sha256=sha(launch),main_program_sha256=sha(main_prg),ASSETS_sha256=sha(assets),main_compressed_bytes=len(stream),compressed_bytes=len(stream),low_compressed_bytes=len(low),stream=layout,cold_transport_ranges=[dict(start=a,end_exclusive=z,name=n)for a,z,n in ranges],labels=dict(start=sl,decoder=dl,finalizer=fl,resident_loader=rl,loader_start=fs,low_decoder=hl),code_bytes=dict(start=len(start),decoder=len(dec),low_decoder=len(helper),finalizer=len(final),resident_loader=len(res),loader_start=len(first)),early_auxiliary=[dict(sourceMain=[0x2000,0x4000],aux=[0x2000,0x4000]),dict(sourceMain=[0x4000,0x5200],aux=[0xe00,0x2000])],late_auxiliary_target=[0x2e0,0xe00],late_sources=[dict(main=[0xd258,0xd800],bytes=1448),dict(main=[0xf258,0xf7d0],bytes=1400)],A00_backup=[0xd800,0xd900],A00_restore='nativebootstrapfromD800thenzero',temporary_loader=[0xa00,0xa00+len(res)],signature_protocol=5,main_assets_target=dict(banks_sha256=sha(banks),high_aux_sha256=sha(high)),source=dict(builder=str(Path(__file__)),builder_sha256=sha(Path(__file__).read_bytes()),parent_boot_sha256=sha((PORT/'boot.py').read_bytes()),material_decoder_sha256=sha((PORT/'boot_materials.py').read_bytes()),DPcodec_sha256=sha((PORT/'language/cold_codec.py').read_bytes())),limits=['CPUphaseproofwithmockKERNALisnotactualdiskqualification','OrdinaryC16andPlus4autoloadandF1/dialogue/gameplaymustbequalifiedseparately','USAGI.PRGisbootstrapandrequiresASSETS+MAINonthedisk; itisnotstandalone'])
 (out/'BOOT.json').write_text(json.dumps(report,indent=2)+'\n');return report
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--repo',type=Path,required=True);p.add_argument('--link',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args();r=build(a.link,a.out);print(json.dumps({k:r[k]for k in('status','D64_sha256','main_compressed_bytes','low_compressed_bytes','code_bytes')},indent=2))
