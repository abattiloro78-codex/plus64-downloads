"""Private033 scene capture in the retired C8CPUdecoder lease.

No code or data is installed automatically. The caller supplies an image,
assembles source(), and explicitly applies the guarded header patch.
"""
HEADER=0x5af9
CONTINUATION=0x5afd
EXPECTED=bytes.fromhex('a8b9f178')
HELPER=0x471c
STATE=0x4726
BG_CONFIG=0x4727
PHASE_NODE=0x473f
LEASE_END=0x480e

def source(*,origin=HELPER,state=STATE,continuation=CONTINUATION):
 if not(0<=origin<=65526 and 0<=state<65536 and 0<=continuation<65536):raise ValueError('16bitrange')
 return f'''*=${origin:04x}
scene_capture:
 sta ${state:04x}
 tay
 lda $78f1,y
 jmp ${continuation:04x}
'''

def patch_header(image,*,helper=HELPER):
 if bytes(image[HEADER:CONTINUATION])!=EXPECTED:raise ValueError('Original5AF9headerguardfailed')
 if not 0<=helper<65536:raise ValueError('helper16bit')
 image[HEADER:CONTINUATION]=bytes([0x4c,helper&255,helper>>8,0xea])
 return dict(header=HEADER,before=EXPECTED.hex(),after=bytes(image[HEADER:CONTINUATION]).hex(),continuation=CONTINUATION,helper=helper)

def reservation(*,helper=HELPER,state=STATE,bg_config=BG_CONFIG,phase_node=PHASE_NODE):
 ranges=[dict(name='scene_capture',start=helper,end_exclusive=helper+10),dict(name='scene_state',start=state,end_exclusive=state+1),dict(name='P64B_config_type11',start=bg_config,end_exclusive=bg_config+24),dict(name='scene_phase_type12',start=phase_node,end_exclusive=phase_node+16)]
 ordered=sorted(ranges,key=lambda r:r['start'])
 for a,b in zip(ordered,ordered[1:]):
  if a['end_exclusive']>b['start']:raise ValueError('Overlappingreservation')
 if any(r['start']<0x471c or r['end_exclusive']>LEASE_END for r in ranges):raise ValueError('OutsideC8retiredlease')
 return dict(allocations=ranges,total_bytes=sum(r['end_exclusive']-r['start']for r in ranges),retired_lease=[0x471c,LEASE_END],unused_by_this_component_only_bytes=242-51,unused_global_lease_bytes=1,other_global_reservations=[dict(name='scheduler',range=[0x4750,0x4784],bytes=52),dict(name='ROM_stub',range=[0x4784,0x480e],reserved_bytes=138)],publication='Keep FD9D/E sky-game gate. Its true pointer selects type11 -> type12 -> former true head. False/menu branch unchanged. No prepend before owner gate.')
