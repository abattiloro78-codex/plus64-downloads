"""Patch the second original bridge template; no code, glyph or allocation changes.
The original constructor emits both intermediate scene01 bridges from F352.
Their r19 codes live at F35A+9*n. The first template F149+5*n and existing
C21 node already implement the approved geometry, shade and foreground layer.
"""
from pathlib import Path
import argparse,hashlib,json
OLD=bytes([0x0C,0x38]+[0]*10+[0x3E,0x38,0x0C])
NEW=bytes([0xFC,0xFF]+[0x18]*11+[0xFF,0xFD])
OFFSET=0x135A;STRIDE=9
BASE_SHA='0fe23a2013b4a4389f11e1633c0ab8be947254d228c99091aa89724b4d2d2e29'
def sha(b):return hashlib.sha256(b).hexdigest()
def patch(data):
 assert len(data)==8192 and sha(data)==BASE_SHA
 assert bytes(data[OFFSET+STRIDE*i] for i in range(15))==OLD
 out=bytearray(data)
 for i,v in enumerate(NEW):out[OFFSET+STRIDE*i]=v
 changed=[i for i,(a,b)in enumerate(zip(data,out))if a!=b]
 assert changed==[OFFSET+STRIDE*i for i in range(15)]
 assert bytes(out[0x1149+5*i]for i in range(15))==NEW
 return bytes(out),dict(status='BUILT-data-only-second-original-bridge-template',input_assets_sha256=sha(data),output_assets_sha256=sha(out),source_CPU_addresses=[0xF35A+9*i for i in range(15)],file_offsets=changed,before=OLD.hex(),after=NEW.hex(),bytes_replaced=15,added_code_bytes=0,added_guest_bytes=0,added_allocations=0,guest_total_bytes=81920,MAIN_unchanged=True,font_unchanged=True,existing_type10_node_unchanged=True,existing_three_rectangles_unchanged=True,deck_behind_actors=True,geometry='same approved FC/FF/18/FF/FD row19 on all5 bridge copies',template_read_PC=0x57c4,template_write_PC=0x57c4,constructor_source_record=0xF352)
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--input',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();out,proof=patch(a.input.read_bytes());assert not a.output.exists();a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_bytes(out);a.output.with_suffix('.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof,indent=2))
