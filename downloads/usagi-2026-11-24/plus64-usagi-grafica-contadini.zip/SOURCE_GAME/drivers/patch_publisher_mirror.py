"""Normalize C8 mirror flags at actor publication without changing frame IDs.

The original foreground controller can be interrupted between piece uploads.
This IRQ-owned publisher projects that native partial update with one mirror
for its composite, rather than letting the strict VM reject the whole actor.
"""
from pathlib import Path
import hashlib

INPUT_MAIN_SHA256 = 'b50304144fa5a2262d8cfc7f1afdd6b089e511a90fe2bb37714d0298ca4243ba'
ORIGIN, LIMIT = 0xf8fb, 0xfa20
VALIDATE, VALIDATE_LIMIT = 0x0b00, 0x0b40
HOOK = 0xfb00
UPLOAD_GUARD, UPLOAD_LIMIT = 0x47e5, 0x480e
OWNER_GUARD, OWNER_LIMIT = 0xcfd2, 0xcff0
OWNER_HOOK = 0x2eca
LEGACY_SHA256 = 'a5270e6a510d7cc8c3c98b19a01f76d3b8ad7a922dad9ee3946c9d64920206f5'

def source(name):
    return Path(__file__).with_name(name+'.asm').read_text()

def apply(raw, code, labels, validator, validator_labels, upload_code, upload_labels, owner_code, owner_labels):
    digest = hashlib.sha256(raw).hexdigest()
    if len(raw)!=65536 or digest!=INPUT_MAIN_SHA256:
        raise ValueError('Post-mirror MAIN publisher guard failed')
    if hashlib.sha256(raw[ORIGIN:LIMIT]).hexdigest()!=LEGACY_SHA256:
        raise ValueError('Retired generic publisher lease guard failed')
    if raw[0xf8f7:0xf8fb]!=bytes.fromhex('aa682860') or raw[0x2fea:0x2ff3]!=bytes.fromhex('4cf7f868a8684c0ef9'):
        raise ValueError('Live portrait/init exit guard failed')
    refs=[(i,int.from_bytes(raw[i+1:i+3],'little'))for i in range(65533)
          if raw[i]in(0x20,0x4c)and ORIGIN<=int.from_bytes(raw[i+1:i+3],'little')<LIMIT and not ORIGIN<=i<LIMIT]
    if refs!=[(0x2ff0,0xf90e)]:
        raise ValueError('Unexpected external generic publisher reference')
    if any(raw[i]in(0x20,0x4c)and 0x2fed<=int.from_bytes(raw[i+1:i+3],'little')<0x2ff3 for i in range(65533)):
        raise ValueError('Historical dead portrait tail acquired an entry')
    if len(code)!=labels['publisher_mirror_end']-ORIGIN or ORIGIN+len(code)>LIMIT:
        raise ValueError('Publisher helper code size guard failed')
    if len(validator)!=validator_labels['publisher_validate_end']-VALIDATE or VALIDATE+len(validator)>VALIDATE_LIMIT:
        raise ValueError('Publisher validator lease size guard failed')
    if raw[VALIDATE:VALIDATE_LIMIT]!=bytes(VALIDATE_LIMIT-VALIDATE):
        raise ValueError('Retired CPU staging lease guard failed')
    if raw[HOOK:HOOK+3]!=bytes.fromhex('201afc'):
        raise ValueError('Actor swap call guard failed')
    if len(upload_code)!=upload_labels['source_upload_guard_end']-UPLOAD_GUARD or UPLOAD_GUARD+len(upload_code)>UPLOAD_LIMIT or raw[UPLOAD_GUARD:UPLOAD_LIMIT]!=bytes(UPLOAD_LIMIT-UPLOAD_GUARD):
        raise ValueError('Source upload wrapper lease guard failed')
    if len(owner_code)!=owner_labels['owner_cache_invalidate_end']-OWNER_GUARD or OWNER_GUARD+len(owner_code)>OWNER_LIMIT or raw[OWNER_GUARD:OWNER_LIMIT]!=bytes(OWNER_LIMIT-OWNER_GUARD):
        raise ValueError('Owner cache invalidator camera-tail lease guard failed')
    if raw[OWNER_HOOK:OWNER_HOOK+5]!=bytes.fromhex('8d96fd1860'):
        raise ValueError('Original owner-change store/return guard failed')
    image=bytearray(raw)
    image[ORIGIN:ORIGIN+len(code)]=code
    image[VALIDATE:VALIDATE+len(validator)]=validator
    image[HOOK:HOOK+3]=bytes((0x20,ORIGIN&255,ORIGIN>>8))
    image[UPLOAD_GUARD:UPLOAD_GUARD+len(upload_code)]=upload_code
    image[OWNER_GUARD:OWNER_GUARD+len(owner_code)]=owner_code
    image[OWNER_HOOK:OWNER_HOOK+5]=bytes((0x4c,OWNER_GUARD&255,OWNER_GUARD>>8,0xea,0xea))
    for address in (0xcf94,0xcf9e,0xcfa8):
        if raw[address:address+3]!=bytes.fromhex('4c00f8'):
            raise ValueError('Mirror helper tail-call guard failed')
        image[address:address+3]=bytes((0x4c,UPLOAD_GUARD&255,UPLOAD_GUARD>>8))
    assert image[0xf800:ORIGIN]==raw[0xf800:ORIGIN]
    assert image[LIMIT:HOOK]==raw[LIMIT:HOOK]
    assert image[HOOK+3:0xfce7]==raw[HOOK+3:0xfce7]
    assert image[0xdfca:0xdfde]==raw[0xdfca:0xdfde]
    assert image[0xcfb3:0xcfbf]==raw[0xcfb3:0xcfbf]
    assert image[0xcfd0:0xcfd2]==raw[0xcfd0:0xcfd2]
    assert image[0xcff0:0xcff2]==raw[0xcff0:0xcff2]
    report=dict(status='BUILT-game-IRQ-composite-mirror-publication-correction',
        input_MAIN_sha256=digest,MAIN_sha256=hashlib.sha256(image).hexdigest(),
        publisher_code=[ORIGIN,ORIGIN+len(code)],retired_generic_publisher_lease=[ORIGIN,LIMIT],
        validator_code=[VALIDATE,validator_labels['publisher_validate_code_end']],
        private_IRQ_scratch=[0x0b30,validator_labels['publisher_validate_end']],
        retired_CPU_staging_lease=[VALIDATE,VALIDATE_LIMIT],
        code_bytes=len(code)+validator_labels['publisher_validate_code_end']-VALIDATE,
        scratch_bytes=11,direction_cache_bytes=4,hook_address=HOOK,hook_before='201afc',hook_after=image[HOOK:HOOK+3].hex(),
        authoritative_mirror='original actor direction bit MAIN62[owner] and physical-owner map0,3,1,2',
        context_selection='1B76+8*physical actor pair; does not select a borrowed context from mutable source headers',
        write_guard='C8 flags with only bit0 variable, exact binding pointer and mode2',
        only_source_mirror_bit0_changed=True,frame_IDs_directories_keys_widths_art_AI_spawn_unchanged=True,
        normalization_policy='cache tag is2*flags+widthParity; blank-key255, source upload, and owner changes invalidate; guard failure or active source upload never stamps cache',
        source_upload_guard=[UPLOAD_GUARD,UPLOAD_GUARD+len(upload_code)],
        owner_cache_invalidator=[OWNER_GUARD,OWNER_GUARD+len(owner_code)],
        owner_hook_address=OWNER_HOOK,source_busy_byte=0x0b3d,expected_cache_byte=0x0b3e,
        source_upload_guard_sets_busy_before_invalidation=True,
        source_upload_guard_extra_cycles_per_actual_upload=68,
        owner_change_invalidator_extra_cycles=21,
        additional_helper_code_bytes=len(upload_code)+len(owner_code),
        stable_direction_width_cache_hit_cycles=193,
        upload_guard_lease_audit='upload_guard_lease_PROOF.json',
        all_sky_descriptors_and_DFCA_DFDE_preserved=True,
        preserves_helper_AXYP_and_FD97_FD98=True,foreground_source_helper_temps_not_used=True,
        no_long_IRQ_masking=True,borrow_policy_unchanged=True,
        controlled_borrow_case_not_claimed_fixed=True,
        legacy_lease_audit='publisher_lease_PROOF.json',
        historical_dead_reference=[0x2ff0,0xf90e],historical_dead_tail_unreachable_after=[0x2fea,0xf8f7],
        additional_guest_bytes=0,guest_MAIN_bytes=65536,guest_AUX_bytes=16384,guest_total_bytes=81920,
        labels={k:v for k,v in labels.items()if k.startswith(('publisher_','pm_'))})
    return image, report
