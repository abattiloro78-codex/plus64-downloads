*=$0b00
pm_validate:
 ; Only bit0 can be normalized. The C8 codec flag8 stays unchanged.
 lda $0b36
 and #$fe
 cmp #8
 bne pm_invalid
 ; Aligned source header flag and binding are in the same page.
 clc
 lda $0b33
 adc #5
 sta $fd97
 lda $fd96
 cmp $0b30
 bne pm_invalid
 lda $fd96
 cmp #$1b
 bne pm_invalid
 lda $fd96
 cmp #2
 bne pm_invalid
 sec
 rts
pm_invalid:
 clc
 rts
publisher_validate_code_end:
 .dsb $0b30-*,0
pm_binding: .byt 0
pm_directory: .byt 0
pm_columns: .byt 0
pm_at: .byt 0,0
pm_parts: .byt 0
pm_current_flags: .byt 0
pm_flags: .byt 0
pm_actor: .byt 0
pm_cached_direction: .byt 0,0,0,0
pm_source_busy: .byt 0
pm_expected_cache: .byt 0
publisher_validate_end:
