"""Synchronize the original per-piece mirror cache on every actual upload.

The C64 controller's ID-miss branches skip its mirror-cache store. Pixel
caches can consequently retain mixed orientations; the strict VM composite
validator then rejects an entire actor. These guest-only trampolines update
the mirror cache before the unchanged source decoder, without new RAM.
"""
from pathlib import Path
import hashlib

INPUT_MAIN_SHA256 = '6bca3abb18a8e939f7b57e6a840534730280effbbcfad7f7296d1bb51237488d'
ORIGIN = 0xcf8d
CODE_BYTES = 30
HOOKS = ((0x4671, 'mirror_top'), (0x4696, 'mirror_middle'), (0x46e6, 'mirror_bottom'))

def source():
    return Path(__file__).with_name('mirror_cache.asm').read_text()

def apply(raw, code, labels):
    digest = hashlib.sha256(raw).hexdigest()
    if len(raw) != 65536 or digest != INPUT_MAIN_SHA256:
        raise ValueError('R8 post-grass MAIN mirror-cache guard failed')
    if len(code) != CODE_BYTES or labels['mirror_code_end'] != ORIGIN + CODE_BYTES:
        raise ValueError('Mirror helper size guard failed')
    if ORIGIN + len(code) > 0xcfb3 or raw[ORIGIN:ORIGIN+len(code)] != bytes(len(code)):
        raise ValueError('Mirror helper MAIN lease guard failed')
    image = bytearray(raw)
    patches = []
    for address, label in HOOKS:
        before = bytes(raw[address:address+3])
        if before != bytes.fromhex('2000f8'):
            raise ValueError(f'Mirror decoder call guard failed at {address:04x}')
        after = bytes((0x20, labels[label] & 255, labels[label] >> 8))
        image[address:address+3] = after
        patches.append(dict(address=address,before=before.hex(),after=after.hex()))
    image[ORIGIN:ORIGIN+len(code)] = code
    assert image[0xcfb3:0xcfbf] == raw[0xcfb3:0xcfbf]
    assert image[0xcfd0:0xcfd2] == raw[0xcfd0:0xcfd2]
    assert image[0xcff0:0xcff2] == raw[0xcff0:0xcff2]
    report = dict(status='BUILT-game-only-mirror-cache-miss-correction',
        input_MAIN_sha256=digest,MAIN_sha256=hashlib.sha256(image).hexdigest(),
        code_allocation=[ORIGIN,ORIGIN+len(code)],code_bytes=len(code),
        original_mirror_cache_addresses=[0x48b8,0x48c2,0x48cc],
        patches=patches,additional_cycles_per_actual_piece_upload=14,
        extra_cycles_on_piece_cache_hits=0,
        original_source_decoder_preserved=True,source_A_X_preserved=True,
        C_V_I_D_preserved=True,original_OS_save_preserved=True,
        background_camera_state_preserved=True,
        source_art_VM_AUX_and_original_spawn_AI_unchanged=True,
        borrowed_column_policy_unchanged=True,
        natural_borrow_visibility_not_qualified=True,
        additional_guest_bytes=0,guest_MAIN_bytes=65536,
        guest_AUX_bytes=16384,guest_total_bytes=81920,
        labels={k: labels[k] for k in ('mirror_top','mirror_middle','mirror_bottom','mirror_code_end')})
    return image, report
