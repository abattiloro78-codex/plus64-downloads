*=$df40
mu_start=$0deb
mu_width=$0dec
mu_column=$0ded
mu_part=$0dee
mu_cachecol=$0def
mu_recipe_lo=$0df0
mu_recipe_hi=$0df1
mu_dir_lo=$0df2
mu_mode=$0dfc
mu_origin_x=$0dfd
mu_binding_lo=$0dfe
mu_logical=$0dff

mu_record:
 ldy mu_logical
 clc
 lda $fc74,y
 adc #8
 sta $fd97
 lda $fca2,y
 adc #0
 sta $fd98
 lda mu_recipe_lo
 sta $fd96
 lda mu_recipe_hi
 sta $fd96
 lda #2
 sta $fd96
 rts
mu_load_recipe:
 ; Shared8Bcontext chosenbyoriginalactorcachepair0/2/4/6.
 lda mu_start
 asl
 asl
 clc
 adc #$76
 sta mu_recipe_lo
 lda #$1b
 adc #0
 sta mu_recipe_hi
 ; Onlywidth,key,selector change; othercontextfields arebootinitialized.
 clc
 lda mu_recipe_lo
 adc #4
 sta $fd97
 lda mu_recipe_hi
 adc #0
 sta $fd98
 lda #2
 ldx $39
 beq vm_width_ready
 lda #3
vm_width_ready:
 sta $fd96
 lda $fd96
 lda $35
 ldx $3a
 beq vm_key_family0
 clc
 adc #2
 bne vm_key_ready
vm_key_family0:
 cmp #126
 bcc vm_key_ready
 lda #255
vm_key_ready:
 sta $fd96
 ; Original actor index follows cache pairs 0 4 6 2.
 ; Preserve this fixed lease and downstream labels with three NOP bytes.
 ldx $43
 nop
 nop
 nop
 lda $2724,x
 cmp #$ce
 bne vm_selector_ordinary
 lda $2728,x
 cmp #$77
 bne vm_selector_ordinary
 lda #255
 bne vm_selector_ready
vm_selector_ordinary:
 lda $dfeb,x
vm_selector_ready:
 sta $fd96
 rts
