"""Guarded data-only correction of the existing C21 keyed grass ramp.

Keep the existing six-stage band geometry and use six actual TED luminances
of the same green hue, darkest at the top. Raise every stage by one luminance
from the approved L0..L5 preview without changing band positions or widths.
No runtime instructions, RAM allocations, or frozen032 inputs are changed.
"""
import hashlib

INPUT_MAIN_SHA256 = '4c1ef7d7025c230acc194117c4a0a53c82d06890e5ab0fc02fc9d39a972a0a3e'
PALETTE_ADDRESS = 0x1ff5
BEFORE = bytes((35, 57, 50, 65, 75, 80))
AFTER = bytes((20, 35, 50, 65, 80, 95))
NODES = {
    0x2a60: bytes.fromhex('000000112806f61f05557f0900300000'),
    0x2a70: bytes.fromhex('602a000d2804f51f01557f0900200000'),
}

def apply(raw):
    image = bytearray(raw)
    digest = hashlib.sha256(image).hexdigest()
    if len(image) != 65536 or digest != INPUT_MAIN_SHA256:
        raise ValueError('R8 post-camera MAIN grass guard failed')
    if image.count(BEFORE) != 1 or image[PALETTE_ADDRESS:PALETTE_ADDRESS+6] != BEFORE:
        raise ValueError('C21 unique six-colour grass palette guard failed')
    for address, expected in NODES.items():
        if image[address:address+len(expected)] != expected:
            raise ValueError(f'C21 keyed grass node guard failed at {address:04x}')
    image[PALETTE_ADDRESS:PALETTE_ADDRESS+len(AFTER)] = AFTER
    changed = [i for i, (a, b) in enumerate(zip(raw, image)) if a != b]
    assert changed == [0x1ff5, 0x1ff6, 0x1ff9, 0x1ffa]
    report = dict(status='BUILT-data-only-six-distinct-TED-luminance-green-grass-ramp',
        input_MAIN_sha256=digest, MAIN_sha256=hashlib.sha256(image).hexdigest(),
        palette_address=PALETTE_ADDRESS, palette_before=list(BEFORE), palette_after=list(AFTER),
        native_TED_before=['25','3c','35','45','4f','55'],
        native_TED_after=['15','25','35','45','55','65'],
        changed_addresses=changed, patches=[dict(address=PALETTE_ADDRESS+i,before=a,after=b)
            for i,(a,b) in enumerate(zip(BEFORE,AFTER)) if a != b],
        C21_nodes=list(NODES), keyed_native_colour='55', ramp_native_rows=[104,184],
        ramp_native_rows_end_exclusive=True, changed_stage_indices=[0,1,4,5],
        TED_luminance_indices=[1,2,3,4,5,6], same_native_green_hue=5,
        six_distinct_tonal_stages=True, previous_compact_palette=[5,20,35,50,65,80],
        luminance_increment_from_previous_for_all_six_stages=1,
        changed_addresses_from_previous=list(range(0x1ff5,0x1ffb)),
        no_runtime_code_changes=True, additional_guest_bytes=0,
        guest_MAIN_bytes=65536, guest_AUX_bytes=16384, guest_total_bytes=81920)
    return image, report
