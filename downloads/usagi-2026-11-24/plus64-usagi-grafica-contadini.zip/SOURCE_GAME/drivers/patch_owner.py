"""Correct the VM actor selector in the fixed-size R7 game image.

Cache pairs are assigned by original table4CB4 (0,4,6,2), whereas43 is
original scheduler actor index. Context storage continues to use cachepair.
No source-art, RAM allocation, memory addresses or original mechanics change.
"""
from pathlib import Path
import hashlib,json
ADDRESS=0xDFAB
BEFORE=bytes.fromhex('ad eb 0d 4a aa')
AFTER=bytes.fromhex('a6 43 ea ea ea')

def apply(image):
    assert len(image)==65536
    assert image[0x4cb4:0x4cb8]==bytes([0,4,6,2])
    assert image[0x4923:0x4925]==bytes.fromhex('86 43')
    assert image[0x4ba1:0x4baf]==bytes.fromhex('bd b4 4c aa b1 41 a4 02 20 a9 45 a6 43 60')
    assert image[ADDRESS:ADDRESS+5]==BEFORE
    result=bytearray(image);result[ADDRESS:ADDRESS+5]=AFTER
    assert [i for i,(a,b)in enumerate(zip(image,result))if a!=b]==list(range(ADDRESS,ADDRESS+5))
    return bytes(result)

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('input',type=Path);p.add_argument('output',type=Path);a=p.parse_args()
    old=a.input.read_bytes();new=apply(old);a.output.write_bytes(new)
    print(json.dumps(dict(status='PASS-fixed-size-actor-selector-patch',address=ADDRESS,before=BEFORE.hex(),after=AFTER.hex(),bytes_changed=5,guest_RAM_added=0,metadata_bytes_changed=0,cycles_per_actual_actor_reconstruction_delta=1,sha256=hashlib.sha256(new).hexdigest())))
