*=$cf8d
; Original piece-ID misses bypass the mirror-cache store. Keep each
; cache orientation synchronized with every actual source upload.
; The caller's piece A and column X remain the source decoder inputs.
mirror_top:
 lda $37
 sta $48b8,x
 lda $32
 jmp $f800
mirror_middle:
 lda $37
 sta $48c2,x
 lda $33
 jmp $f800
mirror_bottom:
 lda $37
 sta $48cc,x
 lda $34
 jmp $f800
mirror_code_end:
