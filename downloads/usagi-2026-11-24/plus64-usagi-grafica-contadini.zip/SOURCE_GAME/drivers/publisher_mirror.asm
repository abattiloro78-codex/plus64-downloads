*=$f8fb
pm_validate=$0b00
pm_binding=$0b30
pm_directory=$0b31
pm_columns=$0b32
pm_at=$0b33
pm_parts=$0b35
pm_current_flags=$0b36
pm_flags=$0b37
pm_actor=$0b38
pm_cached_direction=$0b39
pm_source_busy=$0b3d
pm_expected_cache=$0b3e
; The current bridge no longer calls the legacy generic publisher in this
; lease. Keep us_init before F8FB and us_set_colours at FA20 unchanged.
; Entry replaces only the JSR to the original us_swap_actor.
publisher_mirror:
 php
 cld
 pha
 txa
 pha
 tya
 pha
 lda $fd97
 pha
 lda $fd98
 pha
 stx pm_actor
 ; Physical pairs map to original actor indices 0,3,1,2.
 lda pm_original_actor,x
 tay
 lda $62,y
 and #1
 ora #8
 sta pm_flags
 ; Each physical pair has its own immutable-address VM context.
 txa
 asl
 asl
 asl
 clc
 adc #$76
 sta pm_binding
pm_read_context:
 lda pm_binding
 clc
 adc #2
 sta $fd97
 lda #$1b
 sta $fd98
 lda $fd96
 sta pm_directory
 lda $fd96
 cmp #$1b
 bne pm_bad_context
 lda $fd96
 sta pm_columns
 lda $fd96
 lda $fd96
 cmp #255
 bne pm_ready_context
 ldx pm_actor
 lda #255
 sta pm_cached_direction,x
pm_bad_context:
 jmp pm_restore
pm_ready_context:
 ldx pm_actor
 lda pm_columns
 lsr
 lda pm_flags
 rol
 sta pm_expected_cache
 cmp pm_cached_direction,x
 bne pm_check_width
 jmp pm_restore
pm_check_width:
 lda pm_columns
 cmp #2
 beq pm_columns_valid
 cmp #3
 bne pm_bad_context
pm_columns_valid:
pm_column:
 lda pm_directory
 sta $fd97
 lda #$1b
 sta $fd98
 lda $fd96
 clc
 adc #3
 sta pm_at
 lda $fd96
 adc #0
 sta pm_at+1
 cmp #2
 bcs pm_bad_context
 sta $fd98
 lda pm_directory
 clc
 adc #2
 sta pm_directory
 lda #3
 sta pm_parts
pm_part:
 lda pm_at
 sta $fd97
 lda $fd96
 sta pm_current_flags
 cmp pm_flags
 beq pm_next_part
 jsr pm_validate
 bcc pm_abort
 lda pm_at
 sta $fd97
 lda pm_flags
 sta $fd96
pm_next_part:
 clc
 lda pm_at
 adc #16
 sta pm_at
 bcc pm_no_carry
 inc pm_at+1
 lda pm_at+1
 sta $fd98
pm_no_carry:
 dec pm_parts
 bne pm_part
 dec pm_columns
 beq pm_commit
 jmp pm_column
pm_commit:
 lda pm_source_busy
 bne pm_abort
 ldx pm_actor
 lda pm_expected_cache
 sta pm_cached_direction,x
pm_abort:
pm_restore:
 pla
 sta $fd98
 pla
 sta $fd97
 pla
 tay
 pla
 tax
 pla
 plp
 jmp $fc1a
publisher_mirror_code_end:
pm_original_actor:
 .byt 0,3,1,2
publisher_mirror_end:
