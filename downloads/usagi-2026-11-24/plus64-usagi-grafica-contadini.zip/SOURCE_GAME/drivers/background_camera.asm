; Physical source matrix epochs. Generic scenery23 subtracts the actual TED
; source-origin fine scroll from each selected coarse pixel coordinate.
; CFD0 corresponds to attribute bank D0; CFF0 to attribute bank F0.
; CFB3..CFBE is the ORIGINAL loader OS trampoline save, keep it untouched.
*=$cf47
camera_init:
 lda #0
 sta camera_d0
 sta camera_d0+1
 sta camera_f0
 sta camera_f0+1
 lda #$d0
 sta $4733
 jmp $5f13
camera_flip:
 php
 pha
 txa
 pha
 tya
 pha
 cld
 lda $ba
 and #$10
 asl
 ora #$d0
 tax
 eor #$20
 tay
 lda $cf00,x
 clc
 adc #8
 sta $cf00,y
 lda $cf01,x
 adc #0
 sta $cf01,y
 pla
 tay
 pla
 tax
 pla
 plp
 ; Publish BA only after both bytes of its future camera word are ready.
 lda $ba
 eor #$10
 sta $ba
 rts
camera_code_end:
 .dsb $cfd0-*,0
camera_d0:
 .word 0
 .dsb $cff0-*,0
camera_f0:
 .word 0
