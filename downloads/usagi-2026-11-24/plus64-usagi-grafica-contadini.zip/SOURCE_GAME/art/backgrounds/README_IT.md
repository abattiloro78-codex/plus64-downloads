# Sorgenti degli sfondi Usagi per plus/64

I 17 file `recipes/sceneNN.json` sono i sorgenti modificabili dei pacchetti P64B. Contengono palette TED, selettori dei glyph originali, profili di luce, maschere di dettaglio, oggetti e loro posizioni. Il packer richiede soltanto Python 3; non legge vecchie gallerie, screenshot, file NPZ o database host.

## Ricostruzione

```sh
python3 build_backgrounds.py --output build --check-baseline
```

Il risultato è identico byte per byte ai 17 pacchetti qualificati. Il programma produce `sceneNN.p64b` e `sceneNN.p64z`, oltre al rapporto delle dimensioni. Un file `.p64z` contiene l'intestazione P64Z e il payload zlib, senza indirizzo di caricamento PRG. Il costruttore del disco aggiunge i 2 byte dell'indirizzo previsto dal loader e i nomi B01…B17.

Dopo una modifica intenzionale ai JSON, omettere `--check-baseline`:

```sh
python3 build_backgrounds.py --output build
```

Il limite predefinito è 7376 byte per il singolo pacchetto compresso, inclusi i 12 byte di intestazione. È il massimo della baseline fornita; il limite effettivo del buffer deve sempre corrispondere alla build del gioco. Il packer rifiuta un pacchetto oltre il limite configurato. Il gioco carica il pacchetto della scena corrente dal disco al cambio di ambiente: gli altri 16 pacchetti non sono residenti. Il vincolo totale resta 64+16 KiB condivisi con codice, sprite e audio.

## Modifica dei colori e della luce

Le voci `palette` elencano colori TED nativi: 0 è nero; gli altri sono `16*luminanza + tinta`, con luminanza 0…7 e tinta 1…15. I 121 colori distinguibili comprendono il nero e 15 tinte per 8 luminanze. Cambiare una palette modifica i materiali che la referenziano.

Le voci `field` e `global` specificano il materiale. `pair_mask` seleziona le coppie di bit originali: 1=P0, 2=P1, 4=P2, 8=P3; i valori si sommano. `source_colour` e `source_ink` pari a 255 accettano qualunque valore. `glyph_selector` e `clip` pari a 0 non restringono la selezione.

`shader.operation` identifica la formula. Per esempio, `periodic_columns` ripete una sequenza di indici di palette; `vertical_ramp` usa una rampa verticale; `quadratic_volume` e `nearest_quadratic_volume` espongono posizione della luce, pesi, luminanze e miscela della microtexture. `row_envelope_ramp` e `power_envelope` usano contorni forniti dal programma per ombreggiare montagne e acqua. Le coordinate si riferiscono ai pixel nativi del campo; quelle esplicitamente chiamate `lighting_*` sono gli ancoraggi del rilievo. I campi `*_twice` rappresentano mezzi pixel mediante interi.

Le maschere `glyph_phase_set` hanno 8 righe di bit: il bit 0 corrisponde al pixel fisico X0 del glyph. Le clip sono intervalli per riga. Conservare questi selettori quando si desidera modificare soltanto il colore. Il packer conserva ordine dei record e riferimenti numerici; non rinumerare gli ID senza aggiornare tutti i riferimenti.

Per estrarre o ricostruire un singolo pacchetto:

```sh
python3 p64b_json.py unpack build/scene01.p64b prova.json
python3 p64b_json.py pack prova.json prova.p64b --wrapped prova.p64z
```

La qualifica dei pacchetti forniti confronta tutti i 7.588.800 pixel originali dei 17 ambienti e il decoder C con l'adattatore TED. Modificare i sorgenti produce nuovi dati da verificare; la qualifica della baseline non si trasferisce automaticamente alle modifiche. Il microbenchmark host non equivale alla cadenza del gioco completo o a una prova su hardware fisico.
