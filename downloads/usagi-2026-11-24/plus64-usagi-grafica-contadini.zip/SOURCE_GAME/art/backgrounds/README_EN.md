# Usagi background sources for plus/64

The 17 `recipes/sceneNN.json` files are editable P64B packet sources. They contain TED palettes, original glyph selectors, lighting profiles, detail masks, objects and positions. The packer needs only Python 3; it does not read old galleries, screenshots, NPZ files or a host asset database.

## Rebuilding

```sh
python3 build_backgrounds.py --output build --check-baseline
```

This rebuilds all 17 qualified packets byte for byte. Outputs are `sceneNN.p64b`, `sceneNN.p64z` and a size report. A `.p64z` file contains the P64Z header and zlib payload, without a PRG load address. The disk builder adds the 2-byte address required by the loader and names B01…B17.

After intentionally editing the JSON, omit `--check-baseline`:

```sh
python3 build_backgrounds.py --output build
```

The default limit is 7376 bytes per compressed packet, including its 12-byte header. This is the largest supplied baseline packet; the actual buffer limit must match the game build. The packer rejects packets exceeding the configured limit. The game loads the current scene's packet from disk when the environment changes; the other 16 packets are not resident. The total budget remains 64+16 KiB, shared with code, sprites and audio.

## Editing colour and light

`palette` records list native TED colours: 0 is black; other colours use `16*luminance + hue`, with luminance 0…7 and hue 1…15. The 121 distinguishable colours comprise black plus 15 hues at 8 luminances. Changing a palette changes the materials referencing it.

`field` and `global` records describe materials. `pair_mask` selects original bit pairs: 1=P0, 2=P1, 4=P2, 8=P3; add values to select several. `source_colour` and `source_ink` values of 255 match any value. A `glyph_selector` or `clip` of 0 adds no restriction.

`shader.operation` selects the formula. For example, `periodic_columns` repeats palette indices; `vertical_ramp` uses a vertical ramp; `quadratic_volume` and `nearest_quadratic_volume` expose light position, weights, luminances and microtexture mixing. `row_envelope_ramp` and `power_envelope` use program-supplied contours for mountains and water. Coordinates refer to native field pixels; explicitly named `lighting_*` values anchor the relief. `*_twice` fields represent half-pixel values using integers.

`glyph_phase_set` masks have 8 rows of bits; bit 0 corresponds to physical glyph pixel X0. Clips contain row intervals. Preserve these selectors when changing colour alone. The packer preserves record order and numeric references; do not renumber IDs without updating all references.

To extract or rebuild one packet:

```sh
python3 p64b_json.py unpack build/scene01.p64b test.json
python3 p64b_json.py pack test.json test.p64b --wrapped test.p64z
```

Qualification of the supplied packets compares all 7,588,800 original pixels across 17 environments and the C decoder with the TED adapter. Editing sources creates new data to verify; baseline qualification does not automatically cover edits. The host microbenchmark is not the full game's cadence or a physical hardware test.
