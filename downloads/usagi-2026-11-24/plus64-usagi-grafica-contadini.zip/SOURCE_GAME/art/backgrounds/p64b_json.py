#!/usr/bin/env python3
"""Lossless editable P64B recipes. Python3 standard library only.

unpack input.p64b output.json
pack input.json output.p64b [--wrapped output.p64z] [--level 0..9]
"""
import argparse,hashlib,json,struct,zlib
from pathlib import Path
HEADER=b'P64B\x01\0'
SHADERS=['constant','two_tone_light','cylindrical_wood','legacy_ranked_rle','vertical_ramp','row_palette','coordinate_rle','radial_light','vertical_endpoints','row_envelope_ramp','glyph_row_palette','periodic_columns','parametric_radial','quadratic_volume','power_envelope','nearest_quadratic_volume']
KIND={1:'palette',2:'glyph_set',3:'row_clip',4:'template',5:'instance',6:'global',7:'field',12:'wide_row_clip',13:'row_envelope',14:'global_field',15:'glyph_phase_set',16:'early_global_field',17:'nearest_volume_table'}

def number(v):return int(v,0)if isinstance(v,str)else int(v)
def byte(v):
 v=number(v)
 if not 0<=v<=255:raise ValueError(('byte',v))
 return v

def shader_decode(op,p,palettes):
 d={'operation':SHADERS[op]}
 if op==0:d['colour']=p[0]
 elif op==1:d['palette']=p[0]
 elif op==2:d.update(palette=p[0],centre_x_twice=p[1])
 elif op in[3,6]:
  pid,step=p[:2];bits=max(1,(len(palettes[pid])-1).bit_length());rb=8-bits;rows=[];at=2
  while at<len(p):
   n=p[at];at+=1;tokens=p[at:at+n];at+=n;rows.append([{'index':v>>rb,'repeat':(v&((1<<rb)-1))+1}for v in tokens])
  d.update(palette=pid,step=step,rows=rows)
 elif op==4:d.update(palette=p[0],span=p[1])
 elif op in[5,8]:
  d['palette']=p[0]
  if op==5:d['row_indices']=list(p[1:])
 elif op==7:
  keys=['hue','low_luminance','high_luminance','lighting_left','lighting_top','lighting_width','lighting_height'];d.update(zip(keys,struct.unpack('<BBBhhHH',p)))
 elif op==9:d.update(palette=p[0],envelope=p[1])
 elif op==10:
  d.update(palette=p[0],glyph_rows=[dict(glyph=p[2+9*i],indices=list(p[3+9*i:11+9*i]))for i in range(p[1])])
 elif op==11:d.update(palette=p[0],indices=list(p[2:]));assert len(d['indices'])==p[1]
 elif op==12:
  keys=['hue','low_luminance','high_luminance','luminance_offset','coefficient_u_percent','coefficient_v_percent','coefficient_sqrt_percent','centre_x_twice','centre_y_twice','scale_x_twice','scale_y_twice'];d.update(zip(keys,struct.unpack('<BBBbbbBhhHH',p)))
 elif op==13:
  keys=['hue','low_luminance','high_luminance','lighting_left','lighting_top','lighting_width','lighting_height','centre_x_percent','centre_y_percent','weight_x_percent','weight_y_percent','old_luminance_mix_percent','old_low_luminance','old_high_luminance'];d.update(zip(keys,struct.unpack('<BBBhhHHBBBBBBB',p)))
 elif op==14:d.update(palette=p[0],envelope=p[1],exponent_numerator=p[2],exponent_denominator=p[3],symmetric=bool(p[4]&1),half_pair_centre=bool(p[4]&2),envelope_scale_power=p[4]>>2)
 elif op==15:
  keys=['hue','low_luminance','high_luminance','volume_table','centre_x_percent','centre_y_percent','weight_x_percent','weight_y_percent','old_luminance_mix_percent','old_low_luminance','old_high_luminance'];d.update(zip(keys,p))
 else:raise ValueError(op)
 return d

def shader_encode(d,palettes):
 op=SHADERS.index(d['operation']);b=lambda key:byte(d[key]);values=lambda keys:[number(d[k])for k in keys]
 if op==0:p=bytes([b('colour')])
 elif op in[1,8]:p=bytes([b('palette')])
 elif op==2:p=bytes([b('palette'),b('centre_x_twice')])
 elif op in[3,6]:
  pid=b('palette');bits=max(1,(len(palettes[pid])-1).bit_length());rb=8-bits;out=bytearray([pid,b('step')])
  for row in d['rows']:
   out.append(len(row))
   for run in row:
    index,repeat=byte(run['index']),number(run['repeat'])
    if not 0<=index<len(palettes[pid])or not 1<=repeat<=1<<rb:raise ValueError('invalidRLEtoken')
    out.append((index<<rb)|(repeat-1))
  p=bytes(out)
 elif op==4:p=bytes([b('palette'),b('span')])
 elif op==5:p=bytes([b('palette')]+list(map(byte,d['row_indices'])))
 elif op==7:p=struct.pack('<BBBhhHH',*values(['hue','low_luminance','high_luminance','lighting_left','lighting_top','lighting_width','lighting_height']))
 elif op==9:p=bytes([b('palette'),b('envelope')])
 elif op==10:p=bytes([b('palette'),len(d['glyph_rows'])])+b''.join(bytes([byte(e['glyph'])]+list(map(byte,e['indices'])))for e in d['glyph_rows'])
 elif op==11:p=bytes([b('palette'),len(d['indices'])]+list(map(byte,d['indices'])))
 elif op==12:p=struct.pack('<BBBbbbBhhHH',*values(['hue','low_luminance','high_luminance','luminance_offset','coefficient_u_percent','coefficient_v_percent','coefficient_sqrt_percent','centre_x_twice','centre_y_twice','scale_x_twice','scale_y_twice']))
 elif op==13:p=struct.pack('<BBBhhHHBBBBBBB',*values(['hue','low_luminance','high_luminance','lighting_left','lighting_top','lighting_width','lighting_height','centre_x_percent','centre_y_percent','weight_x_percent','weight_y_percent','old_luminance_mix_percent','old_low_luminance','old_high_luminance']))
 elif op==14:p=bytes([b('palette'),b('envelope'),b('exponent_numerator'),b('exponent_denominator'),int(bool(d['symmetric']))|(int(bool(d['half_pair_centre']))<<1)|(b('envelope_scale_power')<<2)])
 elif op==15:p=bytes(values(['hue','low_luminance','high_luminance','volume_table','centre_x_percent','centre_y_percent','weight_x_percent','weight_y_percent','old_luminance_mix_percent','old_low_luminance','old_high_luminance']))
 return op,p

def field_decode(p,palettes):
 w,h,pm,key,ink,gs,clip,op=p[:8];n=int.from_bytes(p[8:10],'little');assert n==len(p)-10
 return dict(width=w,height=h,pair_mask=pm,source_colour=key,source_ink=ink,glyph_selector=gs,clip=clip,shader=shader_decode(op,p[10:],palettes))
def field_encode(d,palettes):
 op,p=shader_encode(d['shader'],palettes);return bytes(byte(d[k])for k in['width','height','pair_mask','source_colour','source_ink','glyph_selector','clip'])+bytes([op])+struct.pack('<H',len(p))+p

def unpack(blob):
 if blob[:4]==b'P64Z':
  if blob[4:6]!=b'\x01\x01':raise ValueError('OnlyzlibP64Zsupportedbythissourcepacker')
  n,stored,reserved=struct.unpack_from('<HHH',blob,6);assert not reserved and len(blob)==12+stored;blob=zlib.decompress(blob[12:]);assert len(blob)==n
 assert blob[:6]==HEADER;at=6;parts=[]
 while at<len(blob):
  k=blob[at];n=int.from_bytes(blob[at+1:at+3],'little');parts.append((k,blob[at+3:at+3+n]));at+=3+n
 assert at==len(blob);palettes={p[0]:list(p[2:])for k,p in parts if k==1};records=[]
 for k,p in parts:
  d={'kind':KIND[k]}
  if k==1:d.update(id=p[0],colours=list(p[2:]));assert p[1]==len(d['colours'])
  elif k==2:d.update(id=p[0],glyphs=[g for g in range(256)if(p[1+g//8]>>(g&7))&1])
  elif k==3:d.update(id=p[0],height=p[1],runs=[dict(repeat=p[3+3*i],left=p[4+3*i],width=p[5+3*i])for i in range(p[2])])
  elif k==4:d.update(id=p[0],width=p[1],height=p[2],fields=[dict(field=p[4+3*i],offset_x=p[5+3*i],offset_y=p[6+3*i])for i in range(p[3])])
  elif k==5:d.update(scene=p[0],template=p[1],x=int.from_bytes(p[2:4],'little'),y=p[4])
  elif k==6:d.update(scene=p[0],x=int.from_bytes(p[1:3],'little'),y=p[3],width=int.from_bytes(p[4:6],'little'),height=p[6],offset_x=p[7],offset_y=p[8],field=field_decode(p[9:],palettes))
  elif k==7:d.update(id=p[0],field=field_decode(p[1:],palettes))
  elif k==12:
   d.update(id=p[0],height=p[1],runs=[]);at=3
   for i in range(p[2]):
    repeat,count=p[at:at+2];at+=2;spans=[]
    for j in range(count):left,width=struct.unpack_from('<HH',p,at);at+=4;spans.append(dict(left=left,width=width))
    d['runs'].append(dict(repeat=repeat,spans=spans))
   assert at==len(p)
  elif k==13:
   left,right,count=struct.unpack_from('<hhB',p,2);d.update(id=p[0],height=p[1],initial_left=left,initial_right=right,segments=[]);at=7
   for i in range(count):
    steps,mode=p[at:at+2];at+=2;wide=bool(mode&128);period=mode&127;deltas=[]
    for j in range(period):dl,dr=struct.unpack_from('<hh'if wide else'<bb',p,at);at+=4 if wide else 2;deltas.append([dl,dr])
    d['segments'].append(dict(steps=steps,wide_deltas=wide,deltas=deltas))
   assert at==len(p)
  elif k in[14,16]:d.update(scene=p[0],x=int.from_bytes(p[1:3],'little'),y=p[3],width=int.from_bytes(p[4:6],'little'),height=p[6],field=p[7])
  elif k==15:d.update(id=p[0],entries=[dict(glyph=p[2+9*i],rows=list(p[3+9*i:11+9*i]))for i in range(p[1])])
  elif k==17:
   sx,sy=struct.unpack_from('<HH',p,2);keys=['distance_x','distance_y','force_left','force_top','force_width','force_height','lighting_left','lighting_top','lighting_width','lighting_height'];d.update(id=p[0],scale_x=sx,scale_y=sy,entries=[dict(zip(keys,struct.unpack_from('<hhhhBBhhHH',p,6+18*i)))for i in range(p[1])])
  records.append(d)
 return dict(format='P64B',version=1,source_sha256=hashlib.sha256(blob).hexdigest(),notes=['Native TED colour0 is black; other colours = luminance(0..7)*16 + hue(1..15).','Source colour/ink255 and selector/clip0 mean wildcard.','Glyph phase row bits are LSB first: bit0 = physical source X0.','Record order and resource IDs are preserved for a lossless rebuild.'],records=records)

def pack(document):
 assert document['format']=='P64B'and document['version']==1;parts=[];palettes={number(d['id']):list(map(byte,d['colours']))for d in document['records']if d['kind']=='palette'};inv={v:k for k,v in KIND.items()}
 for d in document['records']:
  k=inv[d['kind']];b=lambda key:byte(d[key]);n=lambda key:number(d[key])
  if k==1:p=bytes([b('id'),len(d['colours'])]+list(map(byte,d['colours'])))
  elif k==2:
   bits=bytearray(32)
   for g in d['glyphs']:g=byte(g);bits[g//8]|=1<<(g&7)
   p=bytes([b('id')])+bits
  elif k==3:p=bytes([b('id'),b('height'),len(d['runs'])])+b''.join(bytes(byte(r[a])for a in['repeat','left','width'])for r in d['runs'])
  elif k==4:p=bytes([b('id'),b('width'),b('height'),len(d['fields'])])+b''.join(bytes(byte(r[a])for a in['field','offset_x','offset_y'])for r in d['fields'])
  elif k==5:p=bytes([b('scene'),b('template')])+struct.pack('<H',n('x'))+bytes([b('y')])
  elif k==6:p=bytes([b('scene')])+struct.pack('<H',n('x'))+bytes([b('y')])+struct.pack('<H',n('width'))+bytes([b('height'),b('offset_x'),b('offset_y')])+field_encode(d['field'],palettes)
  elif k==7:p=bytes([b('id')])+field_encode(d['field'],palettes)
  elif k==12:p=bytes([b('id'),b('height'),len(d['runs'])])+b''.join(bytes([byte(r['repeat']),len(r['spans'])])+b''.join(struct.pack('<HH',number(a['left']),number(a['width']))for a in r['spans'])for r in d['runs'])
  elif k==13:p=bytes([b('id'),b('height')])+struct.pack('<hhB',n('initial_left'),n('initial_right'),len(d['segments']))+b''.join(bytes([byte(s['steps']),len(s['deltas'])|(128 if s['wide_deltas']else 0)])+b''.join(struct.pack('<hh'if s['wide_deltas']else'<bb',*map(number,a))for a in s['deltas'])for s in d['segments'])
  elif k in[14,16]:p=bytes([b('scene')])+struct.pack('<H',n('x'))+bytes([b('y')])+struct.pack('<H',n('width'))+bytes([b('height'),b('field')])
  elif k==15:p=bytes([b('id'),len(d['entries'])])+b''.join(bytes([byte(e['glyph'])]+list(map(byte,e['rows'])))for e in d['entries'])
  elif k==17:
   keys=['distance_x','distance_y','force_left','force_top','force_width','force_height','lighting_left','lighting_top','lighting_width','lighting_height'];p=bytes([b('id'),len(d['entries'])])+struct.pack('<HH',n('scale_x'),n('scale_y'))+b''.join(struct.pack('<hhhhBBhhHH',*(number(e[a])for a in keys))for e in d['entries'])
  parts.append(bytes([k])+struct.pack('<H',len(p))+p)
 return HEADER+b''.join(parts)

def wrap(raw,level=9):
 data=zlib.compress(raw,level)
 if not 0<len(raw)<=65535 or not 0<len(data)<=65535:raise ValueError('P64Zlengthlimit')
 return b'P64Z\x01\x01'+struct.pack('<HHH',len(raw),len(data),0)+data

def main():
 a=argparse.ArgumentParser(description=__doc__);sub=a.add_subparsers(dest='command',required=True);u=sub.add_parser('unpack');u.add_argument('input',type=Path);u.add_argument('output',type=Path);p=sub.add_parser('pack');p.add_argument('input',type=Path);p.add_argument('output',type=Path);p.add_argument('--wrapped',type=Path);p.add_argument('--level',type=int,choices=range(10),default=9);args=a.parse_args()
 if args.command=='unpack':args.output.write_text(json.dumps(unpack(args.input.read_bytes()),indent=2)+'\n')
 else:
  raw=pack(json.loads(args.input.read_text()));args.output.write_bytes(raw)
  if args.wrapped:args.wrapped.write_bytes(wrap(raw,args.level))
if __name__=='__main__':main()
