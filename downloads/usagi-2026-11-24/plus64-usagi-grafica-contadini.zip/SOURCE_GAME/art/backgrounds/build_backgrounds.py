#!/usr/bin/env python3
"""Build all 17 editable background recipes using only Python's standard library."""
from pathlib import Path
import argparse,hashlib,json
import p64b_json

def main():
 here=Path(__file__).resolve().parent;a=argparse.ArgumentParser(description=__doc__);a.add_argument('--source',type=Path,default=here/'recipes');a.add_argument('--output',type=Path,required=True);a.add_argument('--capacity',type=int,default=7376,help='Current guest packet slot, including the 12-byte P64Z header');a.add_argument('--check-baseline',action='store_true');a.add_argument('--level',type=int,choices=range(10),default=9);args=a.parse_args();baseline=json.loads((here/'SOURCE_ROUNDTRIP_PROOF.json').read_text());expected={r['scene']:r for r in baseline['scenes']};items=[]
 for scene in range(1,18):
  source=args.source/f'scene{scene:02d}.json';doc=json.loads(source.read_text());raw=p64b_json.pack(doc);wrapped=p64b_json.wrap(raw,args.level);rawsha=hashlib.sha256(raw).hexdigest();sha=hashlib.sha256(wrapped).hexdigest()
  if len(wrapped)>args.capacity:raise SystemExit(f'Scene {scene:02d}: packet {len(wrapped)} exceeds capacity {args.capacity}')
  if args.check_baseline and(rawsha!=expected[scene]['raw_sha256']or sha!=expected[scene]['packet_sha256']):raise SystemExit(f'Scene {scene:02d}: differs from the supplied baseline')
  items.append((scene,raw,wrapped,dict(scene=scene,source=source.name,raw_bytes=len(raw),packet_bytes=len(wrapped),raw_sha256=rawsha,packet_sha256=sha)))
 args.output.mkdir(parents=True,exist_ok=True)
 for scene,raw,wrapped,r in items:(args.output/f'scene{scene:02d}.p64b').write_bytes(raw);(args.output/f'scene{scene:02d}.p64z').write_bytes(wrapped)
 proof=dict(format='P64B/P64Z',method=1,capacity=args.capacity,max_packet_bytes=max(r['packet_bytes']for *_,r in items),baseline_identical=args.check_baseline,records=[r for *_,r in items]);(args.output/'BACKGROUND_BUILD.json').write_text(json.dumps(proof,indent=2)+'\n');print(f'Built 17 backgrounds; maximum packet {proof["max_packet_bytes"]}/{args.capacity} bytes')
if __name__=='__main__':main()
