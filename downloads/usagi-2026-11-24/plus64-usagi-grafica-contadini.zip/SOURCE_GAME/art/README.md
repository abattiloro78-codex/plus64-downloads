# Editable sprite artwork and source bank

This directory rebuilds the reviewed **SVM4 sprite material metadata** and
**P64F version4 source bank** without the historical workspace, screenshots,
shared libraries, emulator installation, or network access. Paths resolve from
this directory. It supplements the engine/game sources in the enclosing source
kit; it is not a standalone game launcher.

## Rebuild

Python3 standard library, including `zlib` and `lzma`:

```sh
python3 build_art.py --output build
```

The default build checks every resulting byte against `compiled/`, the frozen
inputs used by the C8 master. Use `--allow-art-edits` after intentionally editing
the JSON; that option does not claim new artwork has passed the review tests.

For the offline complete colour/alpha check, install NumPy and provide a C11
compiler (`CC` may select it), then run:

```sh
python3 verify_art.py --output build
```

That check rebuilds the assets, reconstructs all207 source poses from the342
source pieces and512 aliases, and renders all804 material contexts in both
directions through the included generic C VM. It compares exact native colour
indices and transparency with `sprites/approved-reference.npz`.

## Editable inputs

- `sprites/sprite_vm.json`: all251 source-pair/rectangle selectors,
  18 formula programs,69 scalar constants,184 paint programs,28 routing tables,
  and87 original material profiles. Operator and parameter names are readable.
  Formula expressions use reverse Polish notation; constants are IEEE double
  values. Dictionary order and IDs are preserved so rebuilding is byte exact.
- `sprites/contexts.json` and `sprites/program-index.json`: context names,
  source family/pose, local colour and the program selected for each context.
  Historical review paths are provenance labels, not build dependencies.
- `sprites/palette.csv`: compact colour index, native TED byte and exact RGB.
- `framebank/source-pieces.json`:342 original encoded RLE streams, all512
  family/piece aliases,207 nine-piece pose compositions and explicit block
  ordering. Two already accepted blood-selector remaps are shown separately as
  `approved_rle`; all original RLE tokens remain available for comparison.
- `input/Usagi Yojimbo.d64`: the user's unchanged input, SHA256
  `68e476cadac7160abdb290fc6d1636d9e52e14e4f0027bc7f04f752fa6325808`.
  It is the supplied modified/crack disk, not a publisher-master image. The
  compiler verifies it and extracts the source PRGs before checking every
  original stream. This does not assign a new licence to the original game.
- `svm4.py` and `framebank.py`: portable assemblers, source extraction and
  compression. These tools have no dependency on game-specific host caches.
- `sprites/runtime/`: generic C VM reference and small offline test fixture.
  The engine's source decoder and platform integration are in the enclosing
  source kit, not duplicated here.

Mask and legacy rectangle X coordinates are multicolour cells (two native
pixels); Y coordinates are native pixels. Rectangle endpoints are inclusive.
The9 source pieces are ordered top-to-bottom bands, then left-to-right columns.
Compact colour0 is opaque black;255 is transparent. Pair0 source holes remain
transparent. The separately approved ground-Ryo antenna removal lives in the
material program and removes four native pixels; it does not rewrite the
original RLE source.

The artwork references are offline authoring/test data. Runtime guest memory
holds only the compiled data: **SVM4 P64Z7197 bytes** and **P64F method2
10409 bytes** (method1 alternative11017 bytes). These figures describe those
components, not the complete64+16KiB game allocation. No NPZ, JSON, coloured
atlas or permanent expanded source bank is opened by the running game. Source
blocks decode into bounded2016-byte temporary storage; material metadata is
expanded only within the generic draw call.

## Sorgenti grafici modificabili

I JSON contengono maschere, formule, comandi di colore e composizioni originali;
non sono una cartella di immagini che il gioco carica dal computer ospite.
`python3 build_art.py --output build` ricostruisce esattamente gli input grafici
approvati. `verify_art.py` controlla804 contesti in entrambe le direzioni con la
VM C e confronta colori/trasparenza pixel per pixel. I percorsi delle vecchie
revisioni sono soltanto riferimenti di provenienza; tutti gli input necessari
alla ricostruzione sono locali. I dati NPZ servono alle verifiche dell'autore e
non occupano memoria aggiuntiva del gioco.

## VM usata dalla versione RAM80 corrente / Current RAM80 VM

`compiled/sprite_vm.method2.p64z` è il payload reale da **6.294 byte**,
metodo2 LZMA, ricostruito da `sprites/sprite_vm.json` da `build_art.py`.
Il file `sprite_vm.p64z` da7.197 byte conserva il metodo1 zlib di compatibilità.
Entrambi espandono gli stessi14.180 byte SVM4.

`compiled/sprite_vm.method2.p64z` is the actual **6,294-byte** method2 LZMA
payload rebuilt from the readable sprite source. The7,197-byte
` sprite_vm.p64z` remains the method1 compatibility output. Both expand
to exactly the same14,180-byte SVM4 program.
