/* Generic guest-owned sprite material VM reference. All art-specific selectors,
 * formula constants, context routing and colours are supplied in the guest blob.
 * The only working storage is bounded scalar/expression-stack/rectangle state.
 */
#include "sprite_vm.h"
#include <math.h>
#include <string.h>
#include <stdlib.h>
#define SVM_STACK 96u
#define SVM_MAX_OPS 256u
static unsigned u16(const p64_svm *v,unsigned p){return p+1u<v->size ? v->data[p]|((unsigned)v->data[p+1u]<<8):0u;}
static unsigned u32(const p64_svm *v,unsigned p){return u16(v,p)|u16(v,p+2u)<<16;}
static unsigned vu(const p64_svm *v,unsigned *p,unsigned end){
 unsigned out=0u,shift=0u;
 for(unsigned n=0;n<3u&&*p<end;n++){
  unsigned b=v->data[(*p)++];out|=(b&127u)<<shift;if(!(b&128u))return out;shift+=7u;
 }
 *p=end;return 65535u;
}
static unsigned source(const p64_svm *v,int x,int y,uint8_t *ink){
 *ink=255u;if(x<0||y<0||(unsigned)x>=v->width||(unsigned)y>=v->height)return 0u;
 unsigned pair=v->sample(v->user,x,y,ink);return pair<=3u?pair:0u;
}
static int dictionary(const p64_svm *v,unsigned section,unsigned id,unsigned *begin,unsigned *end){
 if(section>=6u||id>=v->count[section])return 0;
 unsigned b=v->section[section],n=v->count[section];
 *begin=b+2u*(n+1u)+u16(v,b+2u*id);
 *end=b+2u*(n+1u)+u16(v,b+2u*(id+1u));
 return *begin<=*end&&*end<=b+v->length[section];
}
static int selected(const p64_svm *v,unsigned mask,int x,int y){
 unsigned at,end;uint8_t ink;unsigned pair=source(v,x,y,&ink);
 if(!pair||!dictionary(v,0u,mask,&at,&end)||at>=end)return 0;
 unsigned header=v->data[at++];if(header&128u)return (header&(1u<<(pair-1u)))!=0u;
 for(unsigned i=0;i<header&&at+1u<end;i++){
  unsigned match=v->data[at++],n=v->data[at++];
  for(unsigned j=0;j<n&&at+2u<end;j++,at+=3u){
   unsigned r=(unsigned)v->data[at]|((unsigned)v->data[at+1u]<<8)|((unsigned)v->data[at+2u]<<16);
   unsigned x0=(r&63u)*2u,y0=(r>>6)&63u,x1=((r>>12)&63u)*2u+1u,y1=(r>>18)&63u;
   if(pair==match&&(unsigned)x>=x0&&(unsigned)x<=x1&&(unsigned)y>=y0&&(unsigned)y<=y1)return 1;
  }
 }
 return 0;
}
static unsigned distance_black(const p64_svm *v,int x,int y){
 unsigned best=19u;uint8_t ink;
 for(int yy=y-3;yy<=y+3;yy++)for(int xx=x-3;xx<=x+3;xx++)if(source(v,xx,yy,&ink)==3u){
  unsigned d=(unsigned)((x-xx)*(x-xx)+(y-yy)*(y-yy));if(d<best)best=d;
 }
 return best;
}
static unsigned distance_level(const p64_svm *v,int x,int y,unsigned kind,unsigned base){
 static const unsigned thresholds[6]={2u,4u,5u,8u,9u,10u};
 unsigned d=distance_black(v,x,y),level=0u;
 for(unsigned i=0;i<6u;i++)if(d>=thresholds[i])level++;
 if(kind==6u||kind==7u)level=1u+(level+1u)/2u;
 if(kind==7u){int n=(int)((base-1u)/15u)+(int)level-3;level=n<0?0u:n>7?7u:(unsigned)n;}
 return level;
}
static uint8_t shade_row(unsigned kind,unsigned base,int x,int lo,int hi){
 unsigned span=(unsigned)(hi-lo+1),level=0u;
 if(kind==2u||kind==3u){
  if(span<=(kind==3u?4u:2u))level=7u;
  else {
   unsigned depth=(kind==3u||span<=4u)?1u:2u;
   unsigned edge=(unsigned)((x-lo<hi-x)?x-lo:hi-x);
   unsigned numerator=2u*depth*edge;
   level=7u-depth+(numerator+span-2u)/(span-1u);if(level>7u)level=7u;
  }
  return (uint8_t)(1u+(base-1u)%15u+15u*level);
 }
 unsigned n=span+1u,edge=(unsigned)abs(2*x-lo-hi);
 unsigned gn=kind==4u?16u:72u,gd=kind==4u?5u:25u;
 level=gn*(n*n-edge*edge)/(gd*n*n);return (uint8_t)(1u+15u*level);
}
static uint8_t profile(const p64_svm *v,unsigned mask,unsigned kind,unsigned base,int x,int y){
 if(base==254u)base=v->local;
 if(kind==1u||kind==6u||kind==7u)return base?(uint8_t)(1u+(base-1u)%15u+15u*distance_level(v,x,y,kind,base)):0u;
 if((kind==2u||kind==3u)&&!base)return 0u;
 int lo=-1,hi=-1;
 for(unsigned xx=0;xx<v->width;xx++)if(selected(v,mask,(int)xx,y)){if(lo<0)lo=(int)xx;hi=(int)xx;}
 return lo>=0?shade_row(kind,base,x,lo,hi):0u;
}
typedef struct {unsigned x0,y0,x1,y1,pair,profile,component;} rect;
static void getrect(const p64_svm *v,unsigned recipe,unsigned i,rect *r){
 unsigned p=recipe+1u+4u*i,q=u32(v,p);
 r->x0=(q&63u)*2u;r->y0=(q>>6)&63u;r->x1=((q>>12)&63u)*2u+1u;
 r->y1=(q>>18)&63u;r->pair=(q>>24)&3u;r->profile=(q>>26)&7u;r->component=(q>>29)&7u;
}
static int win(const p64_svm *v,int x,int y,unsigned pair,rect *r){
 int found=-1;unsigned n=v->data[v->recipe]&63u;
 for(unsigned i=0;i<n;i++){
  rect q;getrect(v,v->recipe,i,&q);
  if((unsigned)x>=q.x0&&(unsigned)x<=q.x1&&(unsigned)y>=q.y0&&(unsigned)y<=q.y1&&(!q.pair||q.pair==pair)){*r=q;found=(int)i;}
 }
 return found;
}
static uint8_t legacy(const p64_svm *v,int x,int y,unsigned local){
 uint8_t ink;unsigned pair=source(v,x,y,&ink);if(!pair)return 255u;if(pair==2u)ink=(uint8_t)local;
 rect r;int index=win(v,x,y,pair,&r);if(index<0||ink>120u)return ink;
 unsigned header=v->data[v->recipe],kind=r.profile;
 if(kind==0u){
  if(!(header&64u)||!r.component||!ink)return ink;
  unsigned rx=(r.x1-r.x0)/2u,ry=(r.y1-r.y0)/2u;if(!rx)rx=1u;if(!ry)ry=1u;
  unsigned ex=(unsigned)x-r.x0<r.x1-(unsigned)x?(unsigned)x-r.x0:r.x1-(unsigned)x;
  unsigned ey=(unsigned)y-r.y0<r.y1-(unsigned)y?(unsigned)y-r.y0:r.y1-(unsigned)y;
  unsigned edge=ex*ry<ey*rx?ex*ry:ey*rx,level=r.component-1u+(8u-r.component)*edge/(rx*ry);
  if(level>7u)level=7u;
  return (uint8_t)(1u+(ink-1u)%15u+15u*level);
 }
 if(kind==1u||kind==6u||kind==7u){
  if(!ink)return 0u;
  unsigned base=ink;
  if(kind==7u){
   base=v->data[v->recipe+1u+4u*(header&63u)+r.component];
   if((header&64u)&&(base&128u))return (uint8_t)(base&127u);
   if(!base)return 0u;
  }
  return (uint8_t)(1u+(base-1u)%15u+15u*distance_level(v,x,y,kind,base));
 }
 if((kind==2u||kind==3u)&&!ink)return 0u;
 int lo=-1,hi=-1;
 for(unsigned xx=0;xx<v->width;xx++){
  uint8_t other_ink;unsigned other=source(v,(int)xx,y,&other_ink);if(!other)continue;
  rect q;int j=win(v,(int)xx,y,other,&q);if(j<0)continue;
  if(j==index||(r.component&&r.component==q.component&&r.profile==q.profile&&r.pair==q.pair)){if(lo<0)lo=(int)xx;hi=(int)xx;}
 }
 return lo>=0?shade_row(kind,ink,x,lo,hi):ink;
}
static double feature(const p64_svm *v,unsigned op,int x,int y){
 if(op==0x40u)return x;
 if(op==0x41u)return y;
 if(op==0x42u)return x/2;
 if(op==0x43u){uint8_t ink;return source(v,x,y,&ink);}
 if(op==0x44u||op==0x45u){
  int lo=-1,hi=-1;uint8_t ink;
  for(unsigned xx=0;xx<v->width;xx+=2u)if(source(v,(int)xx,y,&ink)){if(lo<0)lo=(int)xx/2;hi=(int)xx/2;}
  return op==0x44u?lo:hi;
 }
 if(op==0x46u){
  int best=5;uint8_t ink,mx=x/2;
  for(int dy=-4;dy<=4;dy++)for(int dx=-4;dx<=4;dx++){
   int d=abs(dx)+abs(dy);if(d>=best)continue;
   if(source(v,2*((int)mx+dx),y+dy,&ink)==1u)best=d;
  }
  return best;
 }
 return NAN;
}
static double expression(const p64_svm *v,unsigned id,int x,int y){
 unsigned p,end;if(!dictionary(v,1u,id,&p,&end))return NAN;
 double stack[SVM_STACK];unsigned sp=0u;
 while(p<end){
  unsigned op=v->data[p++];
  if(op<=31u){if(sp>=SVM_STACK)return NAN;stack[sp++]=(double)op;continue;}
  if(op==0x3fu){
   if(p>=end||sp>=SVM_STACK)return NAN;
   unsigned index=v->data[p++];if(index>=v->count[2])return NAN;
   double c;uint64_t bits=0u;unsigned at=v->section[2]+8u*index;
   for(unsigned k=0;k<8u;k++)bits|=(uint64_t)v->data[at+k]<<(8u*k);
   memcpy(&c,&bits,8u);stack[sp++]=c;continue;
  }
  if(op>=0x40u&&op<=0x46u){if(sp>=SVM_STACK)return NAN;stack[sp++]=feature(v,op,x,y);continue;}
  if(op>=0x8au&&op<=0x8du){
   if(!sp)return NAN;
   double a=stack[sp-1u];
   stack[sp-1u]=op==0x8au?fabs(a):op==0x8bu?sqrt(a):op==0x8cu?floor(a):nearbyint(a);continue;
  }
  if(op==0x8eu){if(sp<3u)return NAN;double c=stack[--sp],b=stack[--sp],a=stack[sp-1u];stack[sp-1u]=a!=0.0?b:c;continue;}
  if(sp<2u)return NAN;
  double b=stack[--sp],a=stack[sp-1u],q=NAN;
  switch(op){
   case 0x80u:q=a+b;break;case 0x81u:q=a-b;break;case 0x82u:q=a*b;break;case 0x83u:q=a/b;break;
   case 0x84u:q=a<b;break;case 0x85u:q=a<=b;break;case 0x86u:q=a>b;break;case 0x87u:q=a>=b;break;
   case 0x88u:q=fmin(a,b);break;case 0x89u:q=fmax(a,b);break;default:return NAN;
  }
  stack[sp-1u]=q;
 }
 return sp==1u?stack[0]:NAN;
}
static unsigned parameter_count(unsigned op){
 static const unsigned n[12]={0u,1u,2u,4u,4u,3u,2u,6u,0u,3u,1u,2u};return op<12u?n[op]:0u;
}
uint8_t p64_svm_colour(const p64_svm *v,unsigned x,unsigned y){
 if(!v||!v->valid||x>=v->width||y>=v->height)return 255u;
 uint8_t source_ink;unsigned pair=source(v,(int)x,(int)y,&source_ink);if(!pair)return 255u;
 uint8_t value=legacy(v,(int)x,(int)y,v->local);unsigned at=v->program_begin,guard=0u;
 while(at<v->program_end&&guard++<SVM_MAX_OPS){
  unsigned op=v->data[at++],mask=vu(v,&at,v->program_end),par[8]={0};
  if(op==8u)par[0]=vu(v,&at,v->program_end);
  else {
   unsigned n=parameter_count(op);if(!n||at+n>v->program_end)return 255u;
   for(unsigned i=0;i<n;i++)par[i]=v->data[at++];
  }
  if(!selected(v,mask,(int)x,(int)y))continue;
  switch(op){
   case 1u:value=(uint8_t)par[0];break;
   case 2u:value=profile(v,mask,par[0],par[1],(int)x,(int)y);break;
   case 3u:{unsigned axis=par[1]?x:x/2u,lo=par[2],hi=par[3],d=hi>lo?hi-lo:1u;
    int index=3-(int)(3u*(axis-lo)/d);if(index<0)index=0;if(index>3)index=3;value=(uint8_t)((int)par[0]-45+15*index);break;}
   case 4u:{
    unsigned dx=par[1]>par[0]?par[1]-par[0]:1u,dy=par[3]>par[2]?par[3]-par[2]:1u;
    double score=.8*(x-par[0])/dx+.2*(y-par[2])/dy;value=score<.45?106u:score<.95?91u:76u;break;}
   case 5u:{unsigned old=legacy(v,(int)x,(int)y,par[0]);int shift=(int8_t)par[2];
    int level=(int)floor(((double)old-1.0)/15.0)+shift;value=(uint8_t)((int)par[1]+15*level);break;}
   case 6u:{int level=(int)floor(((double)value-1.0)/15.0)+(int8_t)par[1];value=(uint8_t)((int)par[0]+15*level);break;}
   case 7u:{unsigned h=par[1]-par[0]+1u,n=par[3]*(y-par[0])/h;if(n>=par[3])n=par[3]-1u;
    int lv=7-(int)n-(int)par[5];if(lv<(int)par[4])lv=(int)par[4];value=(uint8_t)(par[2]+15u*(unsigned)lv);break;}
   case 8u:{double q=expression(v,par[0],(int)x,(int)y);if(!isfinite(q)||q<0.0||q>255.0)return 255u;value=(uint8_t)q;break;}
   case 9u:value=(uint8_t)par[pair-1u];break;
   case 10u:value=legacy(v,(int)x,(int)y,par[0]);break;
   case 11u:value=(uint8_t)par[x&1u];break;
   default:return 255u;
  }
 }
 return value;
}
static int validate_dictionary(const p64_svm *v,unsigned section){
 unsigned n=v->count[section],at=v->section[section],bytes=v->length[section];
 if(bytes<2u*(n+1u))return 0;
 unsigned body=2u*(n+1u),last=0u;
 for(unsigned i=0;i<=n;i++){unsigned off=u16(v,at+2u*i);if((i==0u&&off!=0u)||off<last||off>bytes-body)return 0;last=off;}
 return last==bytes-body;
}
static int validate_vm(const p64_svm *v){
 if(!v->count[0]||!v->count[1]||!v->count[3]||!v->count[5]||v->count[0]>4096u||v->count[1]>256u||v->count[2]>256u||v->count[3]>4096u||v->count[4]>256u||v->count[5]>256u)return 0;
 if(!validate_dictionary(v,0u)||!validate_dictionary(v,1u)||!validate_dictionary(v,3u))return 0;
 for(unsigned id=0;id<v->count[0];id++){
  unsigned p,end;if(!dictionary(v,0u,id,&p,&end)||p>=end)return 0;
  unsigned head=v->data[p++];
  if(head&128u){if(head&120u||p!=end)return 0;continue;}
  if(head>3u)return 0;
  for(unsigned i=0;i<head;i++){
   if(p+2u>end)return 0;
   unsigned pair=v->data[p++],n=v->data[p++];if(!pair||pair>3u||3u*n>end-p)return 0;
   for(unsigned j=0;j<n;j++,p+=3u){unsigned q=(unsigned)v->data[p]|((unsigned)v->data[p+1u]<<8)|((unsigned)v->data[p+2u]<<16);
    unsigned x0=q&63u,y0=(q>>6)&63u,x1=(q>>12)&63u,y1=(q>>18)&63u;if(x0>x1||x1>=36u||y0>y1||y1>=63u)return 0;}
  }
  if(p!=end)return 0;
 }
 for(unsigned id=0;id<v->count[1];id++){
  unsigned p,end,sp=0u;if(!dictionary(v,1u,id,&p,&end))return 0;
  while(p<end){unsigned op=v->data[p++];
   if(op<=31u||(op>=0x40u&&op<=0x46u)){if(++sp>SVM_STACK)return 0;}
   else if(op==0x3fu){if(p>=end||v->data[p++]>=v->count[2]||++sp>SVM_STACK)return 0;}
   else if(op>=0x80u&&op<=0x89u){if(sp<2u)return 0;sp--;}
   else if(op>=0x8au&&op<=0x8du){if(!sp)return 0;}
   else if(op==0x8eu){if(sp<3u)return 0;sp-=2u;}else return 0;
  }
  if(sp!=1u)return 0;
 }
 for(unsigned id=0;id<v->count[3];id++){
  unsigned p,end,nops=0u;if(!dictionary(v,3u,id,&p,&end))return 0;
  while(p<end){if(++nops>SVM_MAX_OPS)return 0;unsigned op=v->data[p++];if(op<1u||op>11u)return 0;
   if(vu(v,&p,end)>=v->count[0])return 0;
   if(op==8u){if(vu(v,&p,end)>=v->count[1])return 0;}
   else {unsigned n=parameter_count(op);if(n>end-p)return 0;p+=n;}
  }
 }
 return 1;
}
int p64_svm_init(p64_svm *v,const uint8_t *data,size_t size,p64_svm_source sample,void *user,
 unsigned selector,unsigned key,unsigned local,unsigned base_variant,unsigned width,unsigned height){
 memset(v,0,sizeof(*v));if(!data||size<28u||size>65535u||memcmp(data,"SVM4",4u)||!sample||selector>255u||key>255u||local>120u||width<1u||width>72u||height<1u||height>63u)return 0;
 v->data=data;v->size=size;v->sample=sample;v->user=user;v->width=width;v->height=height;
 v->selector=selector;v->key=key;v->local=local;v->base_variant=base_variant;
 unsigned p=28u;
 for(unsigned i=0;i<6u;i++){v->length[i]=u16(v,4u+2u*i);v->count[i]=u16(v,16u+2u*i);v->section[i]=p;p+=v->length[i];if(p>size)return 0;}
 if(p!=size||!validate_vm(v)||v->length[2]!=8u*v->count[2]||v->length[5]<257u+2u*(v->count[5]+1u))return 0;
 unsigned baseat=v->section[5],alternates=data[baseat++];
 if(base_variant>alternates||v->length[5]<257u+alternates+2u*(v->count[5]+1u))return 0;
 unsigned recipeid=base_variant?data[baseat+base_variant-1u]:data[baseat+alternates+key];
 if(recipeid>=v->count[5])return 0;
 unsigned dir=baseat+alternates+256u,body=dir+2u*(v->count[5]+1u);
 v->recipe=body+u16(v,dir+2u*recipeid);unsigned recipeend=body+u16(v,dir+2u*(recipeid+1u));
 if(v->recipe>=recipeend||recipeend>v->section[5]+v->length[5])return 0;
 unsigned header=data[v->recipe],n=header&63u;if((header&128u)==0u||v->recipe+1u+4u*n>recipeend)return 0;
 unsigned palettes=0u;
 for(unsigned i=0;i<n;i++){
  rect r;getrect(v,v->recipe,i,&r);if(r.x0>r.x1||r.x1>=72u||r.y0>r.y1||r.y1>=63u)return 0;
  if(r.profile==7u&&palettes<=r.component)palettes=r.component+1u;
 }
 if(v->recipe+1u+4u*n+palettes>recipeend)return 0;
 unsigned route=v->section[4],routeend=route+v->length[4];if(route>=routeend)return 0;
 unsigned routes=data[route++],table=65535u;
 for(unsigned i=0;i<routes;i++){
  if(route+3u>routeend)return 0;
  unsigned a=data[route++],ink=data[route++],t=data[route++];
  if(a==selector&&(ink==255u||ink==local))table=t;
 }
 unsigned program=0u;
 if(table!=65535u){
  if(table>=v->count[4])return 0;
  unsigned body2=route+2u*(v->count[4]+1u);
  unsigned q=body2+u16(v,route+2u*table),end=body2+u16(v,route+2u*(table+1u));if(q>end||q<body2||end>routeend)return 0;
  unsigned context_key=key;
  while(q<end){unsigned k=data[q++],id=vu(v,&q,end);if(k==context_key)program=id;}
 }
 if(!dictionary(v,3u,program,&v->program_begin,&v->program_end))return 0;
 v->valid=1;return 1;
}
