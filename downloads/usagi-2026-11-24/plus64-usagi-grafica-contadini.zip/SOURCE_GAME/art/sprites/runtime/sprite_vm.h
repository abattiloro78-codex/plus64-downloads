#ifndef P64_GENERIC_SPRITE_VM_H
#define P64_GENERIC_SPRITE_VM_H
#include <stddef.h>
#include <stdint.h>
/* Source callback samples ORIGINAL source pairs/inks, never shaded output.
 * Coordinates are native pixels in the complete composite, without mirroring.
 * Return0 outside the actual source domain; set*ink for opaque source pairs.
 */
typedef unsigned (*p64_svm_source)(void *user,int x,int y,uint8_t *ink);
typedef struct {
 const uint8_t *data;
 size_t size;
 unsigned section[6],length[6],count[6];
 unsigned recipe,program_begin,program_end;
 unsigned width,height,selector,key,local,base_variant;
 p64_svm_source sample;
 void *user;
 int valid;
} p64_svm;
/* data is borrowed decoded guest METADATA and lives only within the draw call.
 * This decoder stores no source image, coloured frame, persistent asset cache,
 * hidden archive or game-specific actor catalogue.
 */
int p64_svm_init(p64_svm *vm,const uint8_t *data,size_t size,
 p64_svm_source source,void *user,unsigned selector,unsigned key,unsigned local,unsigned base_variant,unsigned width,unsigned height);
uint8_t p64_svm_colour(const p64_svm *vm,unsigned x,unsigned y);
#endif
