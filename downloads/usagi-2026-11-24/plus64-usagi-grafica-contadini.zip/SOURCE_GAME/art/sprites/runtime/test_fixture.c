#include "sprite_vm.h"
#include <string.h>
typedef struct {const uint8_t *pairs;unsigned local,width,height;} source_fixture;
static unsigned sample(void *u,int x,int y,uint8_t *ink){
 source_fixture *s=(source_fixture *)u;
 if(x<0||y<0||(unsigned)x>=s->width||(unsigned)y>=s->height){*ink=255;return 0;}
 unsigned pair=s->pairs[(unsigned)y*72u+(unsigned)x];*ink=pair==1u?106u:pair==2u?(uint8_t)s->local:pair==3u?0u:255u;return pair;
}
int p64_svm_test_render(const uint8_t *data,unsigned length,const uint8_t *pairs,unsigned selector,unsigned key,unsigned local,unsigned variant,unsigned width,unsigned height,unsigned mirror,uint8_t *out){
 p64_svm vm;source_fixture input={pairs,local,width,height};
 if(!p64_svm_init(&vm,data,length,sample,&input,selector,key,local,variant,width,height))return 0;
 memset(out,255,63u*72u);
 for(unsigned y=0;y<height;y++)for(unsigned x=0;x<width;x++)out[y*72u+(mirror?width-1u-x:x)]=p64_svm_colour(&vm,x,y);
 return 1;
}
unsigned p64_svm_sizeof_context(void){return (unsigned)sizeof(p64_svm);}
