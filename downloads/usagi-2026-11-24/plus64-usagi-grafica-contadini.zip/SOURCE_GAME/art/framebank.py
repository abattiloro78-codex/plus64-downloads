#!/usr/bin/env python3
"""Portable P64Fv4 source-bank compiler. All data comes from the local source JSON.

Only the342 original63-byte pieces are block-compressed. There is no coloured
sprite bitmap in this bank. RLE adjustments are explicit, provenance-labelled
source-token patches; source-pair silhouettes remain original except separately
authorized Ryo transparency in SVM4.
"""
from pathlib import Path
import hashlib,json,lzma,struct,zlib

def sha(data):return hashlib.sha256(data).hexdigest()
def extract_d64(image):
 sectors=[0]+[21]*17+[19]*7+[18]*6+[17]*5
 assert len(image)==sum(sectors)*256
 def sector(t,s):
  assert 1<=t<=35 and 0<=s<sectors[t];a=256*(sum(sectors[1:t])+s);return image[a:a+256]
 def walk(t,s):
  seen=set();data=bytearray()
  while t:
   assert(t,s)not in seen;seen.add((t,s));q=sector(t,s);data+=q[2:]if q[0]else q[2:q[1]+1];t,s=q[:2]
  return bytes(data)
 prgs=[];t,s=sector(18,0)[:2];seen=set()
 while t:
  assert(t,s)not in seen;seen.add((t,s));q=sector(t,s)
  for k in range(8):
   e=q[32*k:32*(k+1)]
   if e[2]&7==2:prgs.append(walk(e[3],e[4]))
  t,s=q[:2]
 memory=bytearray(65536)
 for k in(2,3,4):
  b=prgs[k];a=int.from_bytes(b[:2],'little');memory[a:a+len(b)-2]=b[2:]
 for k,a in[(5,0x8000),(6,0xa000),(7,0xc000)]:b=prgs[k];memory[a:a+len(b)-2]=b[2:]
 return bytes(memory),prgs

def tokens_from_bytes(data):
 out=[];p=0;decoded=bytearray()
 while len(decoded)<63:
  b=data[p];p+=1;n=b&127;assert n and len(decoded)+n<=63
  if b&128:
   v=data[p];p+=1;out.append({'repeat':n,'value':v});decoded+=bytes([v])*n
  else:
   v=data[p:p+n];p+=n;out.append({'literal_hex':v.hex()});decoded+=v
 return out,bytes(decoded),p

def encode_tokens(tokens):
 out=bytearray();raw=bytearray()
 for t in tokens:
  if'repeat'in t:n=t['repeat'];v=t['value'];assert 1<=n<=127;out+=bytes([n|128,v]);raw+=bytes([v])*n
  else:b=bytes.fromhex(t['literal_hex']);assert 1<=len(b)<=127;out+=bytes([len(b)])+b;raw+=b
 assert len(raw)==63
 return bytes(out),bytes(raw)

def source_frames(doc,verify_d64=None):
 memory=None
 if verify_d64 is not None:
  image=Path(verify_d64).read_bytes();assert sha(image)==doc['original_d64']['sha256'];memory,prgs=extract_d64(image)
  assert[sha(b)for b in prgs]==doc['original_d64']['prg_sha256']
 frames=[]
 for r in doc['streams']:
  original,clean=encode_tokens(r['original_rle'])
  assert sha(clean)==r['original_raw63_sha256']
  if memory is not None:assert memory[r['original_pointer']:r['original_pointer']+len(original)]==original
  encoded,raw=encode_tokens(r.get('approved_rle',r['original_rle']))
  assert sha(raw)==r['approved_raw63_sha256'];frames.append(raw)
 return frames

def packet(raw,method):
 if method==1:stored=zlib.compress(raw,9)
 else:
  f=[dict(id=lzma.FILTER_LZMA1,dict_size=65536,lc=0,lp=1,pb=0,mode=lzma.MODE_NORMAL,nice_len=273,mf=lzma.MF_BT4)]
  alone=lzma.compress(raw,format=lzma.FORMAT_ALONE,filters=f);stored=alone[:5]+alone[13:]+struct.pack('<I',zlib.crc32(raw))
 return b'P64Z'+bytes([1,method])+struct.pack('<HHH',len(raw),len(stored),0)+stored

def build(doc,method=2,base=None,verify_d64=None):
 assert doc['format']=='P64F-source-v4';frames=source_frames(doc,verify_d64);base=doc['root_address']if base is None else base;order=doc['frame_order'];assert sorted(order)==list(range(len(frames)))
 raw=b''.join(frames[i]for i in order);groups=doc['frames_per_block'];chunks=[raw[i:i+groups*63]for i in range(0,len(raw),groups*63)];packed=[packet(b,method)for b in chunks]
 cursor=base+12+4*len(chunks);directory=[]
 for b in packed:directory.append((cursor,len(b)));cursor+=len(b)
 root=b'P64F'+bytes([4,groups,63,0])+struct.pack('<HH',len(frames),len(chunks))+b''.join(struct.pack('<HH',*r)for r in directory)
 return root+b''.join(packed),raw

if __name__=='__main__':
 import argparse
 p=argparse.ArgumentParser();p.add_argument('source',type=Path);p.add_argument('output',type=Path);p.add_argument('--method',type=int,choices=(1,2),default=2);p.add_argument('--d64',type=Path);a=p.parse_args();data,raw=build(json.loads(a.source.read_text()),a.method,verify_d64=a.d64);a.output.write_bytes(data);print(len(data),sha(data))
