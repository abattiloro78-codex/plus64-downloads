#!/usr/bin/env python3
"""Portable, standard-library SVM4 assembler/disassembler.

JSON stores editable source predicates, rectangles, formulas and commands;
no image atlas is generated or sampled by the guest VM.
"""
import json,struct,zlib
from pathlib import Path
SECTIONS=('masks','expressions','constants','programs','routing','legacy')
OPS={1:('literal',('colour',)),2:('profile',('kind','base')),3:('xramp',('base','native_x','axis_min','axis_max')),4:('weighted3',('x_min','x_max','y_min','y_max')),5:('retint_base',('base','hue','level_shift')),6:('retint_current',('hue','level_shift')),7:('ygradient',('y_min','y_max','hue','bands','minimum_level','source_pair_level_offset')),8:('expr',()),9:('pairliteral',('pair1','pair2','pair3')),10:('copy_base',('base',)),11:('halfliteral',('even_colour','odd_colour'))}
VARS={0x40:'x',0x41:'y',0x42:'mx',0x43:'pair',0x44:'rowlo',0x45:'rowhi',0x46:'near1'}
EXPR={0x80:'add',0x81:'sub',0x82:'mul',0x83:'div',0x84:'lt',0x85:'le',0x86:'gt',0x87:'ge',0x88:'min',0x89:'max',0x8a:'abs',0x8b:'sqrt',0x8c:'floor',0x8d:'round',0x8e:'choose'}
def vu(n):
 b=bytearray()
 while n>=128:b.append((n&127)|128);n>>=7
 b.append(n);return bytes(b)
def take_vu(b,p):
 v=s=0
 while True:
  q=b[p];p+=1;v|=(q&127)<<s
  if q<128:return v,p
  s+=7;assert s<21

def dictionary(items):
 offsets=[0]
 for b in items:offsets.append(offsets[-1]+len(b))
 return struct.pack('<'+'H'*len(offsets),*offsets)+b''.join(items)
def split_dict(blob,count):
 off=struct.unpack('<'+'H'*(count+1),blob[:2*(count+1)]);body=blob[2*(count+1):]
 assert off[0]==0 and off[-1]==len(body)
 return [body[a:b]for a,b in zip(off,off[1:])]
def unpack(raw):
 assert raw[:4]==b'SVM4';lengths=struct.unpack('<6H',raw[4:16]);counts=struct.unpack('<6H',raw[16:28]);p=28;sec=[]
 for n in lengths:sec.append(raw[p:p+n]);p+=n
 assert p==len(raw)
 doc={'format':'SVM4','schema_version':1,'coordinate_units':'Mask/legacy rectangle X is MCM cells (two native pixels); Y is native pixels. Inclusive endpoints.','colour_encoding':'compact121: black0, hue1..15 plus15*luminance0..7;255transparent','masks':[],'expressions':[],'constants':list(struct.unpack('<'+'d'*counts[2],sec[2])),'programs':[]}
 for data in split_dict(sec[0],counts[0]):
  if data[0]&128:doc['masks'].append({'source_pairs':[p for p in(1,2,3)if data[0]&(1<<(p-1))]});continue
  row={'groups':[]};p=1
  for _ in range(data[0]):
   pair,n=data[p:p+2];p+=2;rects=[]
   for _ in range(n):
    v=int.from_bytes(data[p:p+3],'little');p+=3;rects.append([v&63,(v>>6)&63,(v>>12)&63,(v>>18)&63])
   row['groups'].append({'source_pair':pair,'rects':rects})
  assert p==len(data);doc['masks'].append(row)
 for data in split_dict(sec[1],counts[1]):
  tokens=[];p=0
  while p<len(data):
   q=data[p];p+=1
   if q<=31:tokens.append(q)
   elif q==0x3f:tokens.append({'constant':data[p]});p+=1
   elif q in VARS:tokens.append({'var':VARS[q]})
   else:tokens.append(EXPR[q])
  doc['expressions'].append({'rpn':tokens})
 for data in split_dict(sec[3],counts[3]):
  cmds=[];p=0
  while p<len(data):
   op=data[p];p+=1;mask,p=take_vu(data,p);name,params=OPS[op];cmd={'op':name,'mask':mask}
   if op==8:cmd['expression'],p=take_vu(data,p)
   else:
    cmd.update(zip(params,data[p:p+len(params)]));p+=len(params)
    if 'level_shift'in cmd and cmd['level_shift']>=128:cmd['level_shift']-=256
   cmds.append(cmd)
  doc['programs'].append(cmds)
 n=sec[4][0];bindings=[list(sec[4][1+3*i:4+3*i])for i in range(n)];tables=[]
 for data in split_dict(sec[4][1+3*n:],counts[4]):
  rows=[];p=0
  while p<len(data):key=data[p];p+=1;program,p=take_vu(data,p);rows.append({'key':key,'family':key>>7,'pose':key&127,'program':program})
  tables.append(rows)
 doc['routing']={'bindings':[dict(zip(('selector','local_or255','table'),r))for r in bindings],'tables':tables}
 n=sec[5][0];alternate=list(sec[5][1:1+n]);primary=list(sec[5][1+n:257+n]);recipes=[]
 for data in split_dict(sec[5][257+n:],counts[5]):
  h=data[0];rects=[];p=1
  for _ in range(h&63):
   q=int.from_bytes(data[p:p+4],'little');p+=4;rects.append({'x0':q&63,'y0':(q>>6)&63,'x1':(q>>12)&63,'y1':(q>>18)&63,'source_pair':(q>>24)&3,'profile':(q>>26)&7,'component':q>>29})
  recipes.append({'enabled':bool(h&128),'rectangular':bool(h&64),'rects':rects,'palette':list(data[p:])})
 doc['legacy']={'alternate_recipes':alternate,'primary_key_to_recipe':primary,'recipes':recipes};return doc

def assemble(doc):
 assert doc['format']=='SVM4'and doc['schema_version']==1;masks=[]
 for m in doc['masks']:
  if 'source_pairs'in m:masks.append(bytes([128|sum(1<<(p-1)for p in m['source_pairs'])]));continue
  b=bytearray([len(m['groups'])])
  for g in m['groups']:
   b+=bytes([g['source_pair'],len(g['rects'])])
   for x0,y0,x1,y1 in g['rects']:b+=(x0|(y0<<6)|(x1<<12)|(y1<<18)).to_bytes(3,'little')
  masks.append(bytes(b))
 expressions=[];vnames={v:k for k,v in VARS.items()};enames={v:k for k,v in EXPR.items()}
 for e in doc['expressions']:
  b=bytearray()
  for token in e['rpn']:
   if isinstance(token,int):b.append(token)
   elif isinstance(token,str):b.append(enames[token])
   elif 'var'in token:b.append(vnames[token['var']])
   else:b+=bytes([0x3f,token['constant']])
  expressions.append(bytes(b))
 programs=[];onames={v[0]:(k,v[1])for k,v in OPS.items()}
 for program in doc['programs']:
  b=bytearray()
  for c in program:
   op,params=onames[c['op']];b+=bytes([op])+vu(c['mask'])
   b+=vu(c['expression'])if op==8 else bytes(c[p]&255 for p in params)
  programs.append(bytes(b))
 r=doc['routing'];tables=[b''.join(bytes([q['key']])+vu(q['program'])for q in t)for t in r['tables']]
 routing=bytes([len(r['bindings'])])+b''.join(bytes([q['selector'],q['local_or255'],q['table']])for q in r['bindings'])+dictionary(tables)
 legacy=doc['legacy'];recipes=[]
 for recipe in legacy['recipes']:
  b=bytearray([(128 if recipe['enabled']else 0)|(64 if recipe['rectangular']else 0)|len(recipe['rects'])])
  for r in recipe['rects']:
   q=r['x0']|(r['y0']<<6)|(r['x1']<<12)|(r['y1']<<18)|(r['source_pair']<<24)|(r['profile']<<26)|(r['component']<<29);b+=q.to_bytes(4,'little')
  recipes.append(bytes(b)+bytes(recipe['palette']))
 legacyraw=bytes([len(legacy['alternate_recipes'])])+bytes(legacy['alternate_recipes'])+bytes(legacy['primary_key_to_recipe'])+dictionary(recipes)
 sections=[dictionary(masks),dictionary(expressions),struct.pack('<'+'d'*len(doc['constants']),*doc['constants']),dictionary(programs),routing,legacyraw]
 counts=[len(masks),len(expressions),len(doc['constants']),len(programs),len(tables),len(recipes)]
 return b'SVM4'+struct.pack('<6H6H',*[len(b)for b in sections],*counts)+b''.join(sections)
def wrap(raw):
 stored=zlib.compress(raw,9);return b'P64Z'+struct.pack('<BBHHH',1,1,len(raw),len(stored),0)+stored
if __name__=='__main__':
 import argparse
 p=argparse.ArgumentParser();p.add_argument('mode',choices=['assemble','disassemble']);p.add_argument('input',type=Path);p.add_argument('output',type=Path);a=p.parse_args()
 if a.mode=='assemble':a.output.write_bytes(assemble(json.loads(a.input.read_text())))
 else:a.output.write_text(json.dumps(unpack(a.input.read_bytes()),indent=2)+'\n')
