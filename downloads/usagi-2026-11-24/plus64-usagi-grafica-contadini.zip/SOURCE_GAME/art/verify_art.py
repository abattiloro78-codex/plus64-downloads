#!/usr/bin/env python3
"""Verify portable source reconstruction and all804 approved VM contexts.

Requires NumPy and a C11 compiler for this offline authoring check only.
The game runtime never opens authoring NPZ/JSON or a host asset catalogue.
"""
from pathlib import Path
import argparse,ctypes as T,hashlib,json,os,subprocess,tempfile,time
import numpy as np
import build_art,framebank
ROOT=Path(__file__).resolve().parent

def verify(output):
 output=Path(output);build=build_art.build(output,True);source=json.loads((ROOT/'framebank/source-pieces.json').read_text());frames=framebank.source_frames(source,ROOT/source['original_d64']['file']);lookup={(r['family'],r['piece']):frames[r['stream']]for r in source['aliases']};planes=[]
 for p in source['poses']:
  plane=np.zeros((63,72),np.uint8)
  for n,piece in enumerate(p['pieces']):
   raw=lookup[p['family'],piece];band,column=divmod(n,3)
   for y in range(21):
    for x in range(24):plane[band*21+y,column*24+x]=(raw[y*3+x//8]>>(6-2*((x&7)//2)))&3
  planes.append(plane)
 ref=np.load(ROOT/'sprites/approved-reference.npz');assert np.array_equal(planes,ref['source_pairs']);records=json.loads((ROOT/'sprites/contexts.json').read_text())['records'];targets=ref['colours'];assert len(records)==len(targets)==804
 libpath=output/'sprite_vm_check.so';runtime=ROOT/'sprites/runtime';subprocess.run([os.environ.get('CC','cc'),'-shared','-fPIC','-O2','-std=c11','-Wall','-Wextra','-Werror','-o',str(libpath),str(runtime/'sprite_vm.c'),str(runtime/'test_fixture.c'),'-lm'],check=True)
 lib=T.CDLL(str(libpath.resolve()));fn=lib.p64_svm_test_render;U=T.POINTER(T.c_uint8);fn.argtypes=[U,T.c_uint,U]+[T.c_uint]*7+[U];fn.restype=T.c_int;raw=(output/'sprite_vm.bin').read_bytes();a=(T.c_uint8*len(raw)).from_buffer_copy(raw);start=time.perf_counter();count=0
 for r,target in zip(records,targets):
  index=r['pose']+126*r['family'];plane=planes[index];b=(T.c_uint8*plane.size).from_buffer_copy(plane.tobytes());width=48 if r.get('base_mode')=='portrait'else 72
  for mirror in(0,1):
   out=(T.c_uint8*target.size)();assert fn(a,len(raw),b,r['actor'],r['family']*128+r['pose'],r['local'],int(r.get('base_mode')=='portrait'),width,63,mirror,out)
   got=np.frombuffer(out,np.uint8).reshape(63,72);want=target.copy()
   if mirror:want[:,:width]=target[:,:width][:,::-1]
   assert np.array_equal(got,want),(r['name'],mirror,int((got!=want).sum()));count+=1
 proof={'status':'PASS','portable_rebuild':build,'source_streams_exact':342,'source_aliases':512,'canonical_source_poses_exact':207,'approved_contexts':804,'C_render_checks_with_mirrors':count,'native_pixels_compared':count*63*72,'all_colours_and_alpha_exact':True,'elapsed_C_seconds':time.perf_counter()-start,'external_historical_inputs_required':0,'host_authoring_reference_only':'approved-reference.npz is an offline test oracle, never a runtime asset.','no_gameplay_or_native_Windows_claim':True};(output/'VERIFY.json').write_text(json.dumps(proof,indent=2)+'\n');return proof
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=ROOT/'build');a=p.parse_args();print(json.dumps(verify(a.output),indent=2))
