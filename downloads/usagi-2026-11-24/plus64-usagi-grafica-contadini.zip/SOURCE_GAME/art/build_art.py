#!/usr/bin/env python3
"""Rebuild the reviewed sprite metadata and bounded source bank, offline."""
from pathlib import Path
import argparse,hashlib,json
import svm4,framebank
ROOT=Path(__file__).resolve().parent

def build(output,check=True):
 output=Path(output);output.mkdir(parents=True,exist_ok=True);vm=json.loads((ROOT/'sprites/sprite_vm.json').read_text());raw=svm4.assemble(vm)
 files={'sprite_vm.bin':raw,'sprite_vm.p64z':svm4.wrap(raw),'sprite_vm.method2.p64z':framebank.packet(raw,2)};source=json.loads((ROOT/'framebank/source-pieces.json').read_text())
 for method in(1,2):files[f'framebank-method{method}.bin']=framebank.build(source,method,verify_d64=ROOT/source['original_d64']['file'])[0]
 result=[]
 for name,data in files.items():
  if check:assert data==(ROOT/'compiled'/name).read_bytes(),(name,'rebuild differs from reviewed master')
  (output/name).write_bytes(data);result.append({'file':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'reviewed_master_exact':check})
 proof={'status':'PASS','sources':'Readable sprite_vm.json and source-pieces.json; included original D64 verified before source compilation.','files':result,'original_D64_unchanged':True,'external_workspace_dependencies':0,'runtime_persistent_asset_cache_bytes':0}
 (output/'BUILD.json').write_text(json.dumps(proof,indent=2)+'\n');return proof
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=ROOT/'build');p.add_argument('--allow-art-edits',action='store_true',help='Build edited authoring JSON without requiring the old reviewed hashes.');a=p.parse_args();print(json.dumps(build(a.output,not a.allow_art_edits),indent=2))
