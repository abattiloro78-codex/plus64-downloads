USAGI YOJIMBO - GRAPHICS AND FARMER UPDATE

Requires the extracted R8 runtime with the 23 November 2026 path correction
already applied. This ZIP updates the game and uses your existing xplus4.exe.

1. Close the game.
2. Extract the complete ZIP into the folder containing xplus4.exe and
   USAGI.D64. Allow USAGI.D64 to replace the previous file.
3. Run AVVIA_USAGI_FLUIDO.cmd. Press F1 to select GAME in the menu,
   wait a moment, then press F7.
   For the Plus/4 model use AVVIA_USAGI_PLUS4_FLUIDO.cmd.

Start a new game. Old snapshots still contain the previous program and
its graphics cache.

The disk includes coloured tree shadows and corrected canopy corners,
six green grass luminance levels brightened by one level, and the sprite
mirror-state correction during partial sprite reconstruction described in
the attached evidence.
Guest memory remains 64 KiB MAIN + 16 KiB AUX = 81,920 bytes.
The disk starts an ordinary game and does not include a trainer.

For developers: reproducible game sources are in
SOURCE_GAME. They require CPython 3.12+ and xa 2.4.1;
Italian and English rebuild instructions are included. Corresponding
emulator sources for the unchanged executable remain those supplied with
the path correction. The licence is retained in COPYING.

VERSIONE_USAGI_GRAFICA_CONTADINI.json identifies this version.
MANIFEST_USAGI_GRAFICA_CONTADINI.json and SHA256SUMS_USAGI_GRAFICA_CONTADINI.txt
cover this update; previous inventories remain historical records for
their respective versions. PROVE_GRAFICA_CONTADINI contains the checks
performed and their limits.
