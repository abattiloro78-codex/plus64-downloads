Solo sviluppo/QA: build Linux headless senza GUI. Per giocare usare gli avviatori principali Windows o Linux/Wine.
Development/QA only: headless Linux build without GUI. Play through the main Windows or Linux/Wine launchers.
