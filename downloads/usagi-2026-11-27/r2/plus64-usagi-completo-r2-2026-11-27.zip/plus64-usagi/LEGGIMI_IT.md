# Usagi Yojimbo plus/64 — pacchetto completo R2, 27 novembre 2026

Questo ZIP contiene tutto l'occorrente per Windows: emulatore plus/64, ROM, librerie, ultimo USAGI.D64, manuale tecnico per programmare plus/64 in italiano e inglese e sorgenti completi corrispondenti.

Estrai tutto lo ZIP in una nuova cartella scrivibile. Apri plus64-usagi e fai doppio clic su AVVIA_USAGI.cmd. AVVIA_USAGI_PLUS4.cmd seleziona l'ospite Plus/4; entrambi eseguono lo stesso gioco. Gli aggiornamenti precedenti sono già inclusi; gli avviatori FLUIDO sono alias dello stesso profilo.

La R2 corregge il blocco durante l'ingresso nella taverna, mantiene i colori concordati dei samurai conigli quando estraggono la spada e ripristina il nero dei tronchi dei peschi con fiori bianchi nel bosco. Conserva tutte le precedenti modifiche a scorrimento, alberi, contadini e colori, compresi gli sfondi09/10. L'eseguibile dell'emulatore rimane quello già distribuito.

Nel menu: F1 seleziona GAME, F3 joystick/tastiera, F5 English/Italian, F7 o FIRE avvia. Joystick da tastiera: frecce e Spazio. In gioco F7 mette in pausa/riprende (rilascia il tasto fra le pressioni), F1 torna al menu. Comandi originali in modalità tastiera: Q su, P destra, I sinistra, Z giù, Spazio fire.

DOCUMENTAZIONE contiene i manuali tecnici IT/EN e gli addenda in AGGIORNAMENTI. SORGENTI contiene un unico archivio completo dei sorgenti attuali di emulatore e gioco; game-final/rebuild_final.py ricostruisce il disco. PROVE contiene le verifiche della R2; STORICO_R8 conserva rapporti storici. Sono state eseguite prove mirate di ingresso, uscita e rientro nella taverna su C16 e Plus/4 sotto Linux, oltre a verifiche C dei colori, ricostruzione dei sorgenti e una prova causale indipendente tramite Wine. I rapporti specificano le fixture di test, assenti dalla distribuzione. Non sono dichiarate prove Windows native, su hardware fisico o di una campagna completa.

Il budget rimane64KiB MAIN +16KiB AUX =81920byte, inclusi sprite/cache/audio. I file del disco non sono tutti residenti contemporaneamente. Nessuno snapshot o trainer di test è incluso.

Linux: AVVIA_USAGI_LINUX.sh e AVVIA_USAGI_PLUS4_LINUX.sh usano Wine64, da installare separatamente. STRUMENTI_SVILUPPO_LINUX conserva strumenti storici di sviluppo/QA, distinti dall'avviatore per giocare. Licenze e crediti originali sono conservati.
