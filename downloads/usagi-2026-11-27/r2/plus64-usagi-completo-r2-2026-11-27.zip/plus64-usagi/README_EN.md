# Usagi Yojimbo plus/64 — complete R2 package, 27 November 2026

Everything required for Windows is included: plus/64 emulator, ROMs, libraries, current USAGI.D64, Italian/English plus/64 programming manuals and complete corresponding sources.

Extract the entire ZIP into a new writable folder. Open plus64-usagi and double-click AVVIA_USAGI.cmd. AVVIA_USAGI_PLUS4.cmd selects the Plus/4 host; both run the same game. All previous updates are already included. FLUIDO launchers are aliases for the same settings.

R2 fixes the tavern-entry loading freeze, preserves the agreed rabbit-samurai colours when drawing a sword, and restores black trunks for white-blossom peach trees in the forest. All earlier scrolling, tree, farmer and colour changes remain included, including scenery09/10. The emulator executable is the previously distributed build.

Menu: F1 selects GAME, F3 joystick/keyboard, F5 English/Italian, F7 or FIRE starts. Keyboard joystick: arrows and Space. In game F7 pauses/resumes (release between presses), F1 returns to the menu. Original keyboard mode: Q up, P right, I left, Z down, Space fire.

DOCUMENTAZIONE contains IT/EN technical manuals and addenda under AGGIORNAMENTI. SORGENTI contains one complete current emulator/game source archive; game-final/rebuild_final.py rebuilds the disk. PROVE contains R2 checks and historical R8 reports. Focused tavern entry/exit/re-entry tests were run on C16 and Plus/4 hosts under Linux, alongside C artwork checks, source rebuilds and an independent causal check through Wine. Reports identify the test fixtures, which are absent from the distribution. No Windows-native, physical-hardware or full-campaign claim is made.

Guest memory remains64KiB MAIN +16KiB AUX =81920bytes, including sprites/cache/audio. Disk files are not all resident simultaneously. No test snapshots or trainers are included.

Linux launchers use Wine64, installed separately. STRUMENTI_SVILUPPO_LINUX contains historical development/QA tools, separate from the game launcher. Original licences and credits are retained.
