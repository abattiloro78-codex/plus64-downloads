Manuale tecnico completo plus/64 in italiano e inglese. Tutti i capitoli originali ed esempi sono conservati; il capitolo8 aggiunge il lavoro P64B entro il frame e l’avvio KERNAL. Identità e copertura delle prove: capitolo9 e RELEASE_STATUS.json.

Complete plus/64 technical manuals in Italian and English. All original chapters and examples are retained; chapter8 adds frame-bounded P64B work and KERNAL startup. Identities and test coverage: chapter9 and RELEASE_STATUS.json.
