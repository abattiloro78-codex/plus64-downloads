#!/usr/bin/env python3
"""Offline HTML/PDF renderer retained from Meck's supplied developer manual."""
import base64,hashlib,html,json,os,re,shutil,subprocess
from pathlib import Path
EDITION="2.0 RAM80"
DATE="2026-11-14"
RUNTIME="08d3e87f84140fe13014213beb32bf7635de12b715769d995efc0658bf08ddfa"
LANG="it"
TITLE="Manuale sviluppatore plus/64 RAM80"
QUICK="Riferimento rapido plus/64 RAM80"
def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

def prose_spaces(text: str) -> str:
    """Editorial spacing in prose only; preserve fenced and inline code."""
    result = []
    fenced = False
    for line in text.splitlines(keepends=True):
        if line.lstrip().startswith("```"):
            fenced = not fenced
        if not fenced and not line.lstrip().startswith("```"):
            pieces = re.split(r"(`[^`]*`|\]\([^)]*\))", line)
            for i in range(0, len(pieces), 2):
                p = pieces[i]
                p = re.sub(r"(\d)(KiB|byte|bit|Hz|pixel|colori|linee|righe|colonne|frame|campioni|valori|record|banchi|combinazioni|indici|cicli|volte|glifi|codici|opcode)\b", r"\1 \2", p)
                p = re.sub(r"\b(di|da|a|con|nei|i|per|soltanto|tutti|solo|sui|almeno|primi|sono|entro|circa|fra|CPU|ROM|BASIC|linea|slot|banco|modello|indici|bit|valore|valori|offset|formato|luminanza|tinta|pattern|record|uno|un|palette|registri|bitmap)(?=\d)", r"\1 ", p)
                p = re.sub(r"\b(di|da|a|con|per|via|su)(?=FD[0-9A-F]{2}\b)", r"\1 ", p)
                p = re.sub(r"\b(di|da|a|per|con|su|via|sotto|oltre|banco|offset|base|bitmap|luminanza|crominanza|passi)(?=\$)", r"\1 ", p)
                pieces[i] = p
            line = "".join(pieces)
        result.append(line)
    return "".join(result)

def generate_palette(source: Path, dest: Path) -> None:
    rows = []
    for line in (source / "assets/colodore_ted.vpl").read_text().splitlines():
        words = line.split()
        if len(words) >= 3 and all(re.fullmatch(r"[0-9a-fA-F]{2}", w) for w in words[:3]):
            rows.append(tuple(int(w, 16) for w in words[:3]))
    assert len(rows) >= 128
    from PIL import Image, ImageDraw, ImageFont
    fontdir = Path("/usr/share/fonts/truetype/dejavu")
    font = ImageFont.truetype(str(fontdir / "DejaVuSansMono.ttf"), 17)
    small = ImageFont.truetype(str(fontdir / "DejaVuSans.ttf"), 16)
    canvas = Image.new("RGB", (1200, 548), "white")
    draw = ImageDraw.Draw(canvas)
    draw.text((18, 12), "INDICI SPRITE PLUS/64 — TINTA 1..15, LUMINANZA 0..7", fill="#164a73", font=small)
    for lum in range(8):
        draw.text((8, 64 + lum * 54), str(lum), fill="#172436", font=font)
        for hue in range(1, 16):
            x, y = 36 + (hue - 1) * 77, 46 + lum * 54
            rgb = rows[lum * 16 + hue]
            draw.rectangle((x, y, x + 71, y + 48), fill=rgb)
            ink = "white" if sum(rgb) < 370 else "black"
            draw.text((x + 9, y + 13), f"{lum * 15 + hue:3d}", fill=ink, font=font)
    draw.rectangle((36, 493, 105, 535), fill="black")
    draw.text((60, 503), "0", fill="white", font=font)
    draw.text((122, 501), "0 = nero opaco     121..255 = trasparenti (raw8bpp); usare $FF", fill="#172436", font=small)
    canvas.save(dest)

def render(source: Path, package: Path, name: str, text: str, cover: bool) -> dict:
    md = package / f"{name}.md"
    md.write_text(text, encoding="utf-8")
    template_args = ["pandoc", str(md), "--from=gfm-tex_math_dollars", "--to=html5", "--standalone", "--toc", "--toc-depth=2",
                     "--metadata", f"title={TITLE if cover else QUICK}", "--metadata", f"lang={LANG}",
                     "--css=manual.css", "--output", str(package / f"{name}.html")]
    subprocess.run(template_args, check=True)
    page = package / f"{name}.html"
    page_text = page.read_text(encoding="utf-8")
    page_text = re.sub(r'<link rel="stylesheet" href="manual.css"[^>]*>', '<style>\n' + (package / 'manual.css').read_text() + '\n</style>', page_text)
    page_text = re.sub(r'<header id="title-block-header">.*?</header>', '', page_text, flags=re.S)
    if not cover:
        custom = re.search(r'<section class="cover">.*?</section>', page_text, flags=re.S)
        if custom:
            cover_html = custom.group(0)
            page_text = page_text[:custom.start()] + page_text[custom.end():]
            page_text = page_text.replace('<nav id="TOC"', cover_html + '\n<nav id="TOC"', 1)
    if cover:
        cover_title="Manuale per<br>sviluppatori" if LANG=="it" else "Developer<br>manual"
        subtitle="Memoria · TED e sprite · SID · modem<br>API, formati ed esempi 6502" if LANG=="it" else "Memory · TED and sprites · SID · modem<br>API, formats and 6502 examples"
        platform="Piattaforma software comune per C16 e Plus/4" if LANG=="it" else "Common software platform for C16 and Plus/4"
        cover_html=f'<section class="cover"><div class="brand">PLUS/64 RAM80 · MECK</div><h1>{cover_title}</h1><p class="subtitle">{subtitle}</p><img src="sdk/evidence/demo.png" alt="SDK demo"><p class="metadata">{EDITION} · {DATE}<br>{platform}<br>64 KiB + 16 KiB = 81,920 bytes<br>Runtime SHA256 {RUNTIME[:8]}…{RUNTIME[-8:]}</p></section>'
        page_text = page_text.replace('<nav id="TOC"', cover_html + '\n<nav id="TOC"', 1)
    # One portable HTML file, with all visual resources embedded locally.
    def embed_image(match):
        path = package / match.group(1)
        assert path.is_file(), path
        return 'src="data:image/png;base64,' + base64.b64encode(path.read_bytes()).decode('ascii') + '"'
    page_text = re.sub(r'src="([^"]+\.png)"', embed_image, page_text)
    page.write_text(page_text, encoding="utf-8")
    chromium = shutil.which("chromium") or shutil.which("chromium-browser")
    assert chromium, "Chromium is required to render the printable PDF"
    from playwright.sync_api import sync_playwright
    with sync_playwright() as playwright:
        browser = playwright.chromium.launch(executable_path=chromium, headless=True,
                    args=['--no-sandbox', '--disable-dev-shm-usage', '--disable-background-networking'])
        tab = browser.new_page()
        # Render the document from memory; no file navigation, HTTP or remote fonts.
        tab.route('**/*', lambda route: route.abort())
        tab.set_content(page_text, wait_until='load', timeout=15000)
        tab.pdf(path=str(package / (name + '.pdf')), prefer_css_page_size=True,
                print_background=True)
        browser.close()
    from pypdf import PdfReader
    reader = PdfReader(package / f"{name}.pdf")
    pdf_text = "\n".join(p.extract_text() for p in reader.pages)
    for term in ["FD90", "FDE8", "FDF0", "FD40", "FD5D", "64 KiB"]:
        assert term in pdf_text, f"Missing searchable text in PDF: {term}"
    assert len(reader.pages) >= (15 if cover else 2)
    return dict(file=name + ".pdf", pages=len(reader.pages), searchable_text=True, sha256=sha(package / (name + ".pdf")))