#!/usr/bin/env python3
"""Render the full staged Italian/English technical manual without network."""
from pathlib import Path
import re,json,hashlib,importlib.util,argparse,datetime
W=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def table(rows):return '| Field | Value |\n|---|---|\n'+'\n'.join('| '+str(k)+' | '+str(v)+' |'for k,v in rows)+'\n'
def memory_chapter(f,lang):
 it=lang=='it';s=f['intermediate_FRAMEID'];boot=f['intermediate_BOOT'];rows=[('Candidate','032-frameid — INTERMEDIATE / INTERMEDIO'),('MAIN SHA256',s['native_main_sha256']),('D64 SHA256',boot['D64_sha256']),('P64Fv4 source',str(s['source_archive_bytes'])+' bytes; SHA256 '+s['source_archive_sha256']),('SVM4/P64Z method2',str(s['VM_archive_bytes'])+' bytes; SHA256 '+s['VM_archive_sha256'])]
 title='# 9. Build, memoria e stato delle prove'if it else'# 9. Build, memory and evidence status'
 note=('**Preparazione documentale: non è una qualifica della consegna finale.** I campi finali sotto sono intenzionalmente pendenti. La032 è una build intermedia con prove CPU e avvii reali KERNAL su C16/Plus4; il rapporto indipendente conserva un ritardo iniziale di un fotogramma ancora in correzione. Nessuna qualifica032 viene trasferita automaticamente a033 o successive.'if it else'**Document preparation: this is not final-release qualification.** The final fields below are intentionally pending.032 is an intermediate build with CPU proofs and actual KERNAL cold starts on C16/Plus4; its independent report retains an initial extra-frame delay still under correction. No032 qualification automatically transfers to033 or later builds.')
 finalrows=[('Final candidate',f.get('final_candidate')or'PENDING'),('Final MAIN SHA256',f.get('final_main_sha256')or'PENDING'),('Final D64 SHA256',f.get('final_D64_sha256')or'PENDING'),('Final Windows SHA256',f.get('final_runtime_windows_sha256')or'PENDING'),('Final Linux SHA256',f.get('final_runtime_linux_sha256')or'PENDING'),('Final memory receipt',f.get('final_memory_receipt')or'PENDING'),('Final qualification',f.get('final_qualification')or'PENDING')]
 if it:
  text='''Il contratto è **65.536byte MAIN +16.384byte AUX =81.920byte**, con zero backing guest aggiuntivo. Non sono80KiB lineari e non esiste una RAM sprite separata. La tabella seguente descrive soltanto l’intermedio032, prima dell’installazione completa degli sfondi.

|AUX032, intervallo semiaperto|Byte|Uso|
|---|---:|---|
|0..736|736|46 record source16|
|736..7030|6294|Archivio SVM4 metodo2|
|7030..7070|40|Contesti|
|7070..7098|28|Directory|
|7098..7106|8|Proprietari|
|7106..8192|1086|Non assegnati in032|
|8192..12288|4096|Banco D originale|
|12288..16384|4096|Banco F originale|
|**Totale AUX**|**16384**|Già incluso negli81920|

L’archivio sorgente MAIN in032 inizia a34000 e conta10409byte. Il successivo intervallo semiaperto44409..53234 libera8825byte rispetto all’archivio precedente. Non è una misura finale del gioco con sfondi. Codice, audio, font, matrici TED, loader e scratch hanno ulteriori intervalli e durate di vita: il linker finale deve verificare sovrapposizioni, alias e picco simultaneo, non sommare indiscriminatamente gli stadi del caricamento.

La proposta pendente usa un solo pacchetto `B01`..`B17` nello slot MAIN da8825byte, caricato al cambio scena/livello con una pausa. I dati potati delle17scene sono esatti nel riferimento Python: massimo7376byte per pacchetto,51906byte complessivi sul disco. Questi numeri non provano ancora LOAD reale, residenza finale, errori disco o prestazioni. Il totale su disco non è memoria guest simultanea. Nessun dato viene letto da un catalogo o file host durante il rendering.

Il rapporto `reference/receipts/INDEPENDENT_NATIVE_032_AUDIT.json` separa avvii reali, controlli, snapshot e limite temporale. La qualifica isolata C8/SVM e i test P64Z non sono una partita completa. Le prove del parser P64B confermano solo il bytecode congelato confrontato; i nuovi pacchetti richiedono hash e confronti propri. Wine non è Windows nativo; né Wine né Linux sono hardware fisico.
'''
 else:
  text='''The contract is **65,536 MAIN bytes +16,384 AUX bytes =81,920 bytes**, with zero additional guest backing. It is not80KiB of linear CPU memory and there is no separate sprite RAM. This table describes only intermediate032, before complete background installation.

|AUX032 half-open interval|Bytes|Use|
|---|---:|---|
|0..736|736|46 source16 records|
|736..7030|6294|Method2 SVM4 archive|
|7030..7070|40|Contexts|
|7070..7098|28|Directories|
|7098..7106|8|Owners|
|7106..8192|1086|Unassigned in032|
|8192..12288|4096|Original D bank|
|12288..16384|4096|Original F bank|
|**AUX total**|**16384**|Already included in81920|

The032 MAIN source archive starts at34000 and occupies10409 bytes. The following half-open interval44409..53234 frees8825 bytes relative to the earlier archive. This is not a final measurement of the background-enabled game. Code, audio, fonts, TED matrices, loader and scratch have further ranges and lifetimes: the final linker must check overlaps, aliases and simultaneous peak use rather than indiscriminately summing loader stages.

The pending design uses one `B01`..`B17` packet in the8825-byte MAIN slot, loaded at a scene/level change with a pause. The17 pruned reference scenes are Python-exact: maximum7376 bytes per packet,51906 bytes total on disk. Those numbers do not yet prove real LOADs, final residence, disk failures or performance. Disk total is not simultaneous guest memory. Rendering never reads an asset catalogue or file from the host.

`reference/receipts/INDEPENDENT_NATIVE_032_AUDIT.json` separates actual cold starts, controls, snapshots and the timing limitation. Isolated C8/SVM qualification and P64Z tests are not a completed game. P64B parser tests establish only the frozen compared bytecode; new packets need their own hashes and comparisons. Wine is not native Windows; neither Wine nor Linux is physical hardware.
'''
 return title+'\n\n'+note+'\n\n'+table(finalrows)+'\n'+('## Intermedio032: identità conservate'if it else'## Intermediate032: retained identities')+'\n\n'+table(rows)+'\n'+text

from editorial import editorial_prose

def clean_prose(text):
 text=editorial_prose(text)
 result=[];fenced=False
 for line in text.splitlines(keepends=True):
  if line.lstrip().startswith('```'):
   fenced=not fenced;result.append(line);continue
  if fenced:result.append(line);continue
  pieces=re.split(r'(`[^`]*`|\]\([^)]*\))',line)
  for i in range(0,len(pieces),2):
   pieces[i]=re.sub(r'\b([A-Za-zÀ-ÿ]{2,})(?=\d)',lambda m:m[1] if m[1].isupper()or m[1].lower()in('source','dense','binary','uint','int')else m[1]+' ',pieces[i])
   pieces[i]=re.sub(r'\b([Aa])(?=\d)',r'\1 ',pieces[i])
   pieces[i]=re.sub(r'(?<=[A-Za-zÀ-ÿ]),(?=\S)',', ',pieces[i])
   pieces[i]=re.sub(r';(?=\S)','; ',pieces[i])
   pieces[i]=re.sub(r'(?<=\d)(bytes|bits|pixels|rows|frames|chapters|pages|offsets|tokens|entries|sections|groups|nodes|colours|modes|values|scenes|tables|programs|packets|righe|pagine|capitoli|colori|modi)\b',r' \1',pieces[i])
  result.append(''.join(pieces))
 return ''.join(result)

from final_memory import memory as final_memory

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--facts',type=Path);a=ap.parse_args();facts=json.loads((a.facts or W/'RELEASE_STATUS.json').read_text())
 # Final qualification is not inferred from a caller-supplied word alone.
 if facts.get('status')=='FORBIDDEN-unreviewed-automatic-promotion':
  for k in ('final_candidate','final_D64_sha256','final_main_sha256','final_runtime_windows_sha256','final_runtime_linux_sha256','final_memory_receipt','final_qualification'):assert facts.get(k),k
  assert facts['guest_total_bytes']==81920 and facts['additional_guest_backing_bytes']==0
  raise SystemExit('Final-release editorial promotion requires the integrating owner to update the intermediate-only chapter9; this tool will not turn a draft into a PASS automatically.')
 spec=importlib.util.spec_from_file_location('manual_renderer',W/'manual_html_renderer.py');r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r);r.DATE='2026-11-23';r.EDITION='Technical edition / Edizione tecnica';r.RUNTIME=facts['final_candidate']
 documents=[];links=[];chapter_counts={}
 notices=(W/'THIRD_PARTY_NOTICES_IT_EN.md').read_text()
 for lang in ('it','en'):
  files=sorted((W/'chapters'/lang).glob('*.md'));assert len(files)==7;chapter_counts[lang]=len(files);chunks=[]
  for i,p in enumerate(files,1):
   t=re.sub(r'^# (?:[0-9]+\. )?',f'# {i}. ',p.read_text(),count=1)
   t=t.replace('../../reference/','reference/').replace('../../FORMATI_GRAFICI.md','FORMATI_GRAFICI.md')
   if i==1:t=t.replace('# Avvio rapido','## Avvio rapido').replace('# Quick start','## Quick start')
   chunks.append(t.strip())
  api=(W/('API_FORMATS_'+lang.upper()+'.md')).read_text();memory=editorial_prose(final_memory(facts,lang));(W/('BUILD_MEMORY_'+lang.upper()+'.md')).write_text(memory)
  notice=notices.split('## Italiano\n',1)[1].split('## English\n',1)[0]if lang=='it'else notices.split('## English\n',1)[1];notice=('# 10. Sorgenti, licenze e ricostruzione\n\n'if lang=='it'else'# 10. Source, licences and rebuilding\n\n')+notice.strip()
  title='Manuale sviluppatore plus/64 RAM80'if lang=='it'else'plus/64 RAM80 Developer Manual';pending='Manuale tecnico di programmazione — edizione della consegna'if lang=='it'else'Technical programming manual — release edition'
  date='23 novembre2026'if lang=='it'else'23 November2026'
  ramtext='64 KiB +16 KiB =81.920 byte'if lang=='it'else'64 KiB +16 KiB =81,920 bytes'
  language='Edizione italiana · copia inglese integrale inclusa'if lang=='it'else'Full English edition · Italian copy included'
  cover=f'<section class="cover"><div class="brand">PLUS/64 RAM80 · MECK</div><h1>{title}</h1><p class="subtitle">{pending}</p><p class="metadata">{date}<br>{ramtext}<br>API C8 / SVM4 / P64Z / scenery22<br>{language}</p></section>'
  full=clean_prose(r.prose_spaces(cover+'\n\n'+'\n\n'.join(chunks)+'\n\n'+api+'\n\n'+memory+'\n\n'+notice))
  for target in re.findall(r'!?\[[^\]]*\]\(([^)]+)\)',full):
   if not re.match(r'(?:https?://|#|mailto:)',target):assert (W/target.split('#')[0]).exists(),target
   links.append(dict(language=lang,target=target))
  r.LANG=lang;r.TITLE=title;r.QUICK=title
  name='Manuale_Sviluppatore_PLUS64_RAM80_IT'if lang=='it'else'PLUS64_RAM80_Developer_Manual_EN';documents.append(r.render(W,W,name,full,False))
  quick=chunks[6]+'\n\n'+('## Aggiornamento C8 e scenery22\n\n'if lang=='it'else'## C8 and scenery22 update\n\n')+('Record source16=16byte/tagC000; flag8=P64Fv4/IDdiretti. SVM4 usa contesto8byte, P64Zmetodo1/2. Nodo11=24byte, MODE_FILTER19bit0/mask20; nodo12=16byte/fase0..319. Totaleguest81920byte; stato finale in RELEASE_STATUS.json. Vedere il capitolo8 integrale.'if lang=='it'else'Source16=16bytes/tagC000; flag8=P64Fv4/directIDs. SVM4 uses an8-byte context, P64Zmethod1/2. Node11=24bytes, MODE_FILTER19bit0/mask20; node12=16bytes/phase0..319. Guesttotal81920bytes; final status in RELEASE_STATUS.json. See full chapter8.')
  r.QUICK='Riferimento rapido plus/64 RAM80'if lang=='it'else'plus/64 RAM80 Quick Reference';name='Riferimento_Rapido_PLUS64_RAM80_IT'if lang=='it'else'PLUS64_RAM80_Quick_Reference_EN';documents.append(r.render(W,W,name,clean_prose(r.prose_spaces(quick)),False))
 # The document verification does not qualify a game/runtime.
 from pypdf import PdfReader
 checks=[]
 for d in documents:
  q=W/d['file'];reader=PdfReader(q);text='\n'.join(p.extract_text()or''for p in reader.pages)
  for term in ('FD90','FDE8','FDF0','FD40','FD5D','64 KiB'):assert term in text,(q.name,term)
  if'Quick'not in q.name and'Rapido'not in q.name:
   for term in ('P64F','SVM4','P64Z','MODE_FILTER','81920','B01'):
    assert term in text.replace(',','').replace('.',''),(q.name,term)
   assert len(reader.pages)>=30
  checks.append(dict(file=q.name,pages=len(reader.pages),searchable_chars=len(text)))
 proof=dict(status='PASS-final-technical-documents-bound-to-qualified-artifacts',date_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),complete_languages=['it','en'],original_chapters_per_language=chapter_counts,source_chapters_not_modified=True,documents=documents,PDF_checks=checks,local_links=links,self_contained_HTML=True,network_used_for_render=False,final_runtime_and_BG_qualified=True,no_game_ZIP_created=True,release_status_sha256=sha(W/'RELEASE_STATUS.json'),source_inventory_sha256=sha(W/'SOURCE_INVENTORY.json'))
 (W/'VALIDATION.json').write_text(json.dumps(proof,indent=2)+'\n');(W/'SHA256SUMS.txt').write_text(''.join(sha(p)+'  '+str(p.relative_to(W))+'\n'for p in sorted(W.rglob('*'))if p.is_file()and p.name!='SHA256SUMS.txt'and'__pycache__'not in p.parts));print(json.dumps({'status':proof['status'],'documents':documents},indent=2))
if __name__=='__main__':main()
