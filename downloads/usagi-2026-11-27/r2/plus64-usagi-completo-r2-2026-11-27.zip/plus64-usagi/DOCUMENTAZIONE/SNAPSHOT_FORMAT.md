# Snapshot RAM80: formato e ordine di ripristino

Questa directory contiene un'estensione del codice RAM80 già qualificato.
La qualifica del formato va letta insieme ai rapporti delle nuove prove:
la semplice presenza dei moduli non certifica una partita ripristinata.
I sorgenti, gli eseguibili e i risultati RAM80 precedenti sono conservati.

## Memoria del programma

Il modello mantiene esattamente due backing: `mem_ram[65536]` di VICE e
`p64_aux_ram[16384]`. Sono 81920 byte complessivi. SRAM, dati degli sprite e
payload modem sono viste di quei backing, con gli stessi alias del modello
RAM80. Lo snapshot salva il primo backing nel modulo standard `PLUS4MEM` e
il secondo in `PLUS64`; non introduce nuovi banchi o registri per il gioco.

Il lettore del modulo plus/64 usa temporaneamente 210312 byte dell'host: 144776 byte del modulo
`PLUS64` più una copia di convalida dei 65536 byte di `PLUS4MEM`. Questi dati
non sono accessibili alla CPU emulata, al TED o alle porte della cartuccia.
Vengono liberati dopo il caricamento o il rifiuto. I buffer del compositore
conservati nel file sono stato video dell'emulatore già esistente, non RAM
aggiuntiva disponibile al programma.

## Versione del contenitore VSF

Con plus/64 attivo lo scrittore usa la versione contenitore Plus/4 **2.1**.
Questa versione richiede il modulo `PLUS64` completo anche quando il lettore
parte con la cartuccia disattivata: una coda mancante viene rifiutata prima
di cambiare CPU, RAM, risorse o programmare un reset. Il lettore accetta anche
il contenitore storico 2.0; la scrittura con plus/64 disattivato resta 2.0.
Con plus/64 disattivato vengono omessi anche `PLUS64` e i tre nuovi moduli
TED: i normali snapshot di espansioni Hannes/Csory mantengono il percorso
VICE storico. Il modulo SIDcart resta indipendente dalla cartuccia.
La versione del contenitore e quella dei singoli moduli sono distinte.

## Modulo PLUS64 1.0

Il nome di modulo VICE è `PLUS64`, versione maggiore 1 e minore 0. Il payload
ha dimensione fissa **144776 byte**; con l'intestazione standard VICE di
22 byte il modulo misura **144798 byte**. Gli interi multibyte sono little
endian. Non viene serializzata direttamente alcuna struct C o puntatore.

| Offset nel payload | Dimensione | Contenuto |
| --- | ---: | --- |
| 0 | 4 | Firma ASCII `P64S` |
| 4 | 4 | Lunghezza payload, 144776 |
| 8 | 4 | CRC32 dei byte da 12 alla fine |
| 12 | 1 | `Plus64Enabled` |
| 13 | 1 | `Plus64MainRAM` |
| 14 | 1 | `Plus64PackedCache` |
| 15 | 1 | `Plus64LeftMCM` |
| 16 | 1 | `Plus64RasterCollisions` |
| 17 | 1 | Stato `overlay_ready` |
| 18 | 1 | Latch collisioni sprite |
| 19 | 1 | Proprietà SIDcart acquisita automaticamente da plus/64 |
| 20 | 1 | Banco della porta SRAM, 0..3 |
| 21 | 1 | Proprietà espansione acquisita dal profilo MainRAM |
| 22 | 2 | Offset SRAM, 0..16383 |
| 24 | 4 | Risorsa `RamSize` |
| 28 | 4 | `RamSize` precedente all'attivazione della cartuccia |
| 32, 36, 40 | 4 ciascuno | Testa, coda e conteggio RX |
| 44, 48, 52 | 4 ciascuno | Testa, coda e conteggio TX |
| 56 | 4 | Lunghezza comando AT parziale |
| 60 | 1 | Stato parser Telnet |
| 61 | 1 | Verbo Telnet |
| 62 | 1 | Echo modem |
| 63 | 1 | Latch overrun modem |
| 64, 65 | 1 ciascuno | Connected e dialing; devono essere zero |
| 66 | 2 | Riservati, zero |
| 68 | 4 | CRC32 dei 65536 byte RAM nel modulo `PLUS4MEM` |
| 72 | 1 | Formati sprite misti, booleano |
| 73 | 1 | Materiali con tavolozza completa, booleano |
| 74 | 1 | Maschere sparse, booleano |
| 75 | 1 | Direzioni della luce, booleano |
| 76 | 1 | Luce frontale basata sulla maschera, booleano |
| 77 | 1 | Illuminazione dello sfondo, booleano |
| 78 | 1 | Sfumatura diagonale per ciascun colore sprite, booleano |
| 79 | 1 | Versione dei formati di scenario; attualmente fino a21. La21 aggiunge nodi di primo piano esplicitamente ancorati a caratteri della matrice video |
| 80 | 1 | Record MCM densi da70 byte e priorità FD95 per tali record, booleano |
| 81 | 1 | Altezza concatenata dei record MCM densi, booleano |
| 82 | 1 | Versione materiali composti:0..3 |
| 83 | 45 | Riservati, zero |
| 128 | 64 | Registri sprite |
| 192 | 16384 | Backing `p64_aux_ram` |
| 16576 | 64000 | Pixel sprite latched del compositore, 320x200 |
| 80576 | 64000 | Maschere/occupazione latched del compositore |
| 144576 | 200 | Collisioni latched per linea |

La capacità scenario21 non modifica questo formato: modulo1.0, payload144776
byte, offset e CRC restano uguali. Un lettore precedente che supporta al
massimo20 rifiuta uno snapshot21 prima di applicarlo. Il nuovo lettore
conserva la versione registrata negli snapshot0,1,3..20 e le relative regole;
il nodo di primo piano richiede21 ed è attivato da dati espliciti del gioco.
I pixel salvati temporaneamente durante la composizione di una linea non
sono RAM del guest e non sono stato persistente da serializzare.

Il CRC32 usa il polinomio IEEE riflesso `0xedb88320`, inizializzazione a
`0xffffffff` e complemento finale; corrisponde a `zlib.crc32`.
La definizione compilata degli offset è in `source/plus64_snapshot_format.h`.

La versione18 aggiunge il ritaglio nativo opzionale dei bordi, controllato dal
bit4 di FD9F (`P64_SIDE_BORDER_CLIP=16`). Dopo composizione e maschere di
presentazione, i bordi TED chiusi riprendono il loro colore nativo entro il
canvas320×200; bordi aperti e disabilitati restano rispettati. La geometria e
i flag laterali sono catturati prima che `raster_line_emulate` li azzeri; il
flip-flop verticale è quello della riga appena disegnata. Una riga nativa
blank è interamente bordo salvo bordo sinistro aperto. È una semantica per
stato stabile di riga, non una qualifica degli effetti interni alla singola
riga. Le collisioni precedono il ritaglio e non cambiano. Versione18 richiede
formati misti e illuminazione dei livelli, come le versioni precedenti dello
scenario; i lettori anteriori rifiutano18. Ripristinare0,1,3..17 lascia il
bit4 inattivo. Il prototipo2 resta rifiutato. Nessun byte riservato, dimensione
del payload o backing RAM viene aggiunto.

La versione19 aggiunge il bit3 opzionale dello stile dei nodi di tinta5/7:
con bit acceso viene usata una sagoma ellittica entro la stessa geometria.
I profili supportati fino a18 ignorano questo bit e mantengono la sagoma
rettangolare. Il bit spento conserva il rettangolo anche con19. I lettori
correnti accettano0,1,3..20;2 resta rifiutato. I lettori fino a18 rifiutano19
prima del ripristino. Non cambiano modulo1.0, dimensione del payload,
registri, tavole di colore o backing64+16KiB. Questo bit del descrittore è
distinto dal bit3 FD9F delle finestre successive agli sprite. Vedere il
[formato grafico](FORMATI_GRAFICI.md) e l'[addendum ellisse](reference/addenda/ADDENDUM_ELLIPSE_TINT_IT.md).

La versione20 aggiunge il nodo9 da16byte, rampa verticale di una palette
compatta nella RAM principale, filtrata da chiave/maschera TED. Start e span
sono pixel locali nel rettangolo a celle; un flag opzionale mantiene l'ultima
voce sotto la rampa. I profili precedenti fino a19 ignorano questo nodo e
proseguono nella lista. I lettori fino a19 rifiutano uno snapshot20 prima
del ripristino. Non cambiano formato o dimensione del payload, protocollo05,
byte80/81/82 e limite64+16KiB. Le ellissi introdotte da19 conservano le
proprie regole. Vedere l'[addendum sulla rampa](reference/addenda/ADDENDUM_PALETTE_RAMP_IT.md).

Il campo80 abilita il puntatore MCM con tag`$8000` soltanto insieme ai formati
misti e alla cache compatta. È indipendente dai campi72..79: uno snapshot
precedente, con80=0, conserva l'interpretazione precedente anche se72=1.
I lettori anteriori all'estensione rifiutano80=1 attraverso la convalida dei
byte allora riservati. Il payload, i due backing da64+16KiB e gli otto slot
hardware restano delle stesse dimensioni. Il formato è descritto in
[`sprite-formats/FORMAT.md`](FORMATI_GRAFICI.md).

Il campo81 abilita separatamente l'altezza concatenata: nel record MCM denso,
byte$40 della testa vale0 per21righe oppure1..252 per l'altezza richiesta.
Occorrono `ceil(altezza/21)` parti consecutive da70byte, ciascuna con tipo1
e marcatore$A5; l'intera catena deve rientrare nella vista senza wrap.
81=1 richiede80=1, formati misti e cache compatta. Con81=0 resta il precedente
vincolo byte$40=0; i lettori anteriori alla funzione rifiutano81=1.
Il byte82 versiona separatamente i materiali composti (0..3, con palette inline nella versione3); i byte83..127 restano riservati e nulli.

I pixel e le maschere video vengono conservati perché i registri sprite
possono essere stati aggiornati dopo l'ultima pubblicazione dell'overlay.
Ricostruire soltanto dai registri correnti cambierebbe il primo fotogramma
o le collisioni di un programma che multiplexa gli sprite.

## Convalida prima di cambiare la macchina

Prima del caricamento viene eseguita una scansione limitata dalle dimensioni
reali del file. Ogni modulo deve avere almeno i 22 byte di intestazione e
rientrare nel file; moduli critici duplicati sono rifiutati. Se è presente
`PLUS64`, devono esserci anche `MAINCPU`, `PLUS4MEM` e `TED`.

Il lettore verifica versione e dimensione esatte di `PLUS64`, entrambi i CRC,
booleani, indici e coerenza delle code, banco/offset SRAM, stato del parser e
campi riservati. RX e TX ammettono fino a 128 byte ciascuna; il comando AT
parziale deve avere meno di 256 byte. Gli indici colore dell'overlay devono
essere compresi tra 0 e 127. Le maschere possono usare tutti gli otto bit.
Il profilo attivo ammette solo il decoder nativo 16 KiB o MainRAM 64 KiB.
Una risorsa `MemoryHack` attiva viene rifiutata prima della riconfigurazione.

Il preflight dei moduli aggiuntivi SID, timer/audio TED e `TEDPIPE80`
avviene anch'esso prima di
caricare CPU, RAM o periferiche. I loro formati e controlli sono definiti nei
rispettivi sorgenti. Un vecchio VSF privo di `PLUS64`, caricato mentre plus/64
è attivo, viene rifiutato: non contiene i dati necessari per ricostruire lo
stato della cartuccia. Il SAVE originale del gioco su D64 è un'altra funzione.

I rifiuti di questo preflight non programmano un reset e non applicano lo
stato caricato. Gli errori successivi dei moduli VICE tradizionali conservano
la gestione d'errore VICE: non viene promessa una transazione completa per
qualsiasi possibile corruzione di ogni vecchio modulo standard.

## Ordine di scrittura e ripristino

La scrittura mantiene i moduli standard e aggiunge gli stati TED e SID.
`PLUS64` viene scritto per ultimo, affinché un file interrotto in coda non
possa sembrare completo mentre manca lo stato della cartuccia.

Dopo il preflight vengono configurati gli alias del profilo salvato senza
rotazioni o azzeramenti della RAM ripristinata e senza programmare un power
cycle. Seguono i moduli VICE standard, il ripristino dei due backing e delle
periferiche plus/64, i latch e gli allarmi della pipeline TED, i timer TED,
il SID e infine la fase audio TED. L'audio TED
segue il SID perché l'apertura del motore sonoro può reinizializzare tutti i
chip audio. `sound_snapshot_finish()` termina il caricamento. Non viene
aggiunto un reset per sincronizzare una ripresa valida.

## Connessioni modem

Uno snapshot non può riavvolgere il server remoto o una connessione TCP reale.
Il salvataggio e il caricamento sono quindi rifiutati se il modem corrente
è connesso o sta chiamando. Il controllo di salvataggio avviene prima di
creare o sostituire il file. Il caricamento non disconnette la sessione viva
e non tenta una riconnessione automatica.

Lo stato offline è conservabile: code locali, comando AT parziale, parser,
echo e overrun. I loro payload condividono già i 512 byte riservabili dentro
gli 80 KiB. Un fixture con TX/Telnet offline modificato direttamente nel file
rimane un test sintetico del serializzatore, distinto da un collegamento reale.

## Stato digitale e calendario dei campioni SID

`SIDCARTP64` 1.0 integra i moduli VICE `SID` 1.5 e `SIDEXTENDED` 1.4, che
restano invariati. Il payload della nuova metainformazione misura 313 byte.
Oltre alle impostazioni, al clock razionale e ai registri già descritti nei
sorgenti, conserva il calendario dei campioni reSID e i latch digitali che
il formato storico VICE non registra. La posizione del campione determina
anche quanti campioni vengono passati al generatore audio TED.

| Offset SIDCARTP64 | Contenuto |
| --- | --- |
| 113 | Sample rate, u32 |
| 117 | `sample_offset`, i32 |
| 121 | `cycles_per_sample`, u32 |
| 125 | Risorsa `Speed` in percentuale, i32 |
| 129 | 45 latch u32: 15 per ciascuna delle tre voci |
| 309 | CRC32 dei 309 byte precedenti |

Per ogni voce i 15 latch, nell'ordine, sono `env3`,
`new_exponential_counter_period`, `exponential_pipeline`, `state_pipeline`,
`reset_rate_counter`, `next_state`, `msb_rising`, `ring_msb_mask`, `no_noise`,
`noise_output`, `no_noise_or_noise_output`, `no_pulse`, `tri_saw_pipeline`,
`osc3` e `waveform_output`. La loro convalida precede qualsiasi cambiamento
della macchina. Vengono ripristinati dopo il lettore standard SID, che
altrimenti genera nuove pipeline durante le scritture ai registri.

Il sample rate e la velocità percentuale del profilo SID attivo vengono
ripristinati prima dell'apertura del motore. Il periodo è ricontrollato
contro clock, sample rate e velocità, e la fase è limitata all'intervallo
ammesso dal metodo di campionamento. La modalità `Speed` negativa, che
specifica fotogrammi al secondo, e il backend DTVSID attivo vengono rifiutati
nel preflight di questo profilo per SID fisico. Il kit usa il normale
`Speed=100` e reSID. Con `Sound=0` i latch del motore assente sono canonici
zero e il caricamento non apre un dispositivo audio.

Questa estensione conserva lo stato digitale e il numero dei campioni.
Non serializza la storia del filtro analogico, il ring FIR o il buffer già
inviato al dispositivo audio dell'host. Non implica una promessa di identità
PCM bit per bit con un'uscita audio già in corso prima del caricamento.
