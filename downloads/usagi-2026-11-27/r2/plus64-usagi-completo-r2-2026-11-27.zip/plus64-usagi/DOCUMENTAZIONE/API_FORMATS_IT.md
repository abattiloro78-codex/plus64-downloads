# 8. Formati correnti di sorgenti e materiali

Questo è un **riferimento per programmatori** del modello software. Integra tutti i sette capitoli originali; non è una guida al gioco. Le prove di sorgente/API, le identità finali e i collaudi effettivi della consegna sono nel capitolo 9 e in `RELEASE_STATUS.json`. Protocollo memoria `$05`, modulo snapshot PLUS64 `1.0`, capacità scenery al byte HOST **79** e capacità materiali al byte **82** sono selettori indipendenti. I byte dell'intestazione non sono registri6502.

|Capacità|Significato|
|---|---|
|Materiali0..4|Versioni precedenti dense70/materiali autoriali, conservate con la propria semantica versionata|
|Materiali5|Record source16, compreso accesso in prestito alla MAIN fisica|
|Materiali6|Grammatica condivisa aciclica opzionale, flag sorgente `$04`|
|Materiali7|Contesti materiali condivisi e programmi generici SVM4, modi sorgente 2/3|
|Materiali8|Sorgenti opzionali a gruppi limitati, flag `$08`; gli ID diretti finali usano P64F versione4|
|Scenery22|Nodo sfondo guest11 e nodo fase di luce12, con abilitazioni indipendenti|

Un lettore precedente deve rifiutare combinazioni snapshot non supportate prima di ripristinare lo stato. Abilitare una risorsa non sostituisce la validazione del record. Formati e registri originali conservano il proprio significato quando le nuove capacità sono disabilitate. Dimensione dello snapshot e proprietà dei backing non implicano più RAM.

## Record source16 e ID diretti C8

In modo packed/mixed, con il bit FD92 dello slot impostato, il tag descrittore `$C000` indirizza un **record da16byte nella AUX16K esistente**. I14bit bassi sono l'offset AUX. `$8000` seleziona ancora dense70; `$4000` conserva RAW8. I tag non allocano nuova memoria.

|Offset|Byte|Significato|
|---|---:|---|
|0|2|Indirizzo sorgente RLE/grammatica; con P64Fv4, ID fotogramma opaco senza segno, compreso ID0|
|2|1|Lunghezza software della sorgente; esattamente2 con P64Fv4, non lunghezza del flusso|
|3|1|Bit0 specchio; bit1 backing sorgente/root AUX invece di MAIN; bit2 grammatica; bit3 frame bank|
|4..6|3|Inchiostri sprite compatti delle coppie1/2/3, ciascuno0..120|
|7|1|Altezza testa:0 indica21, altrimenti1..252; la catena usa `ceil(height/21)` record|
|8..9|2|Puntatore AUX a binding/contesto materiale|
|10|1|0 semplice;1 binding autoriale precedente;2 base SVM primaria;3 prima base SVM alternativa|
|11|1|Byte del software; ignorato dalla decodifica sorgente finale P64Fv4|
|12|1|Marcatore passo16|
|13..14|2|Dizionario grammatica o root P64F nello stesso backing della sorgente|
|15|1|Marcatore validità `$A6`|

I bit4..7 sono riservati. Grammatica e frame bank non possono essere selezionati insieme. Senza questi codec, i byte13/14 devono essere zero. Le capacità5/6 non accettano i campi esclusivi di C8. MAIN mancante, limiti violati, inchiostri/marcatori errati o codec malformati rifiutano l'intera sorgente. La coppia0 è trasparente; l'inchiostro compatto0 è nero opaco. Geometria, alpha, espansione, priorità e collisioni sono indipendenti dal colore.

Una colonna da63righe usa tre parti source16, 48byte di record. Sono descrittori, non archivio sorgente né programmi materiali: le tre occupazioni vanno conteggiate separatamente. L'API di disegno con MAIN in prestito riceve la vista fisica64KiB del chiamante; non ne conserva una copia. I wrapper C precedenti senza MAIN non risolvono sorgenti collocate in MAIN.

## Sorgenti RLE e grammatica condivisa precedenti

Senza flag codec, la sorgente è RLE originale: i sette bit bassi del controllo danno una lunghezza non nulla; il bit alto ripete il byte seguente, altrimenti seguono quel numero di byte letterali. Il flusso dichiarato viene consumato esattamente e deve produrre63byte. Con capacità6/flag4, la sorgente inizia con lunghezza software e numero token1..63, poi gruppi di un bitmap dei bit alti e fino a otto byte bassi. Il bit0 del bitmap appartiene al primo token. I token0..255 sono letterali;256..511 indicano regole. Il dizionario esplicito ha tre piani da256byte: bassi del figlio sinistro, bassi del destro e flag dei bit alti nei bit0/1. Gli altri flag sono zero e ogni figlio è inferiore al token padre: la grammatica è aciclica. Limiti, bit alti inutilizzati, conteggio token e output esatto vengono verificati. C8 non reinterpreta questi record quando il flag8 è spento.

## Frame bank P64F versione4

|Offset root|Byte|Significato|
|---|---:|---|
|0|4|ASCII `P64F`|
|4|1|Versione4; le precedenti private1/2 restano compatibili,3 è rifiutata|
|5|1|Fotogrammi per gruppo,1..32|
|6|1|Byte espansi per fotogramma, esattamente63|
|7|1|Riservato0|
|8|2|Numero logico positivo di fotogrammi|
|10|2|Gruppi, esattamente `ceil(frame_count/frames_per_group)`|
|12|4 per gruppo|Indirizzo assoluto nel backing u16 e lunghezza completa pacchetto P64Z u16|

`group=frameID/group_size`; `within=frameID%group_size`. Gli ID sono confrontati con il numero logico, non con la capacità RAM. Il decoder espande solo il gruppo selezionato, al massimo32×63=**2.016byte**, copia un fotogramma da63byte e libera la vista temporanea. Intestazione/tabella/pacchetto, lunghezza espansa esatta, membro codec completo e checksum sono verificati prima di confermare l'output. Non viene conservato un atlante sprite completo. La sorgente resta MCM originale, tre byte per riga; lo specchio inverte i pixel senza cambiare l'occupazione.

## Contesto materiale condiviso da8byte e SVM4

I modi2/3 fanno puntare ogni record coinvolto allo stesso contesto AUX guest:

|Offset contesto|Significato|
|---|---|
|0..1|Root AUX dell'archivio metadata|
|2..3|Directory AUX delle teste di colonna esplicite|
|4|Colonne 1..3|
|5|Altezza composita1..63|
|6|Chiave materiale opaca|
|7|Selettore opaco|

Ogni parte concorda su contesto e modo. La directory può essere non contigua; il passo delle parti è 16byte. Significato di selettori/chiavi e geometria sono dati dal guest. Il circuito non contiene ID dei personaggi o un catalogo anatomico.

SVM4 inizia con `SVM4`, sei lunghezze u16 little-endian e sei conteggi u16: **28byte d'intestazione**. Le sezioni sono selettori di maschera, espressioni postfix, costanti binary64, programmi di pittura, routing sparso e ricette base legacy. Le maschere selezionano coppie sorgente originali e rettangoli; le coordinate sono MCM-X/Y native. Le espressioni leggono coppia/inchiostro, limiti occupati della riga e distanza limitata. I programmi applicano colori letterali, profili, rampe, ritinte ed espressioni. Offset dei dizionari, stack, indici, programmi e percorsi vengono validati dal decoder generico. Codifica esatta delle istruzioni ed esempi sono nei `sprite_vm.c/.h` forniti e nell'inventario tecnico. Un programma può produrre esplicitamente una sentinella trasparente: occorre quindi verificare alpha e collisioni della ricetta, senza presumere che ogni pittura rimanga opaca.

Il renderer prepara al massimo otto contesti materiali entro una singola operazione di disegno. Parti ripetute possono riutilizzare stato sorgente/metadata già validato in quell'operazione. Tutte le viste e le sorgenti temporanee vengono distrutte prima del ritorno; nessuna cache sopravvive al disegno, allo snapshot o nella memoria guest. I test C controllati hanno misurato nove aperture sorgente per un composito ordinario e sei per un composito HUD; non sono FPS del gioco.

## Rappresentazione residente compressa P64Z

|Offset|Byte|Significato|
|---|---:|---|
|0|4|ASCII `P64Z`|
|4|1|Versione wrapper1|
|5|1|Metodo1 zlib o metodo2 LZMA1|
|6|2|Lunghezza espansa1..65.535|
|8|2|Lunghezza payload memorizzato, esattamente lunghezza regione meno12|
|10|2|Riservato0|

Il metodo1 contiene un solo membro zlib completo con checksum Adler. Il metodo2 contiene cinque proprietà LZMA1, flusso terminato da EOS e CRC32 finale little-endian dei byte espansi. La proprietà dizionario è 4.096..65.536; `lc+lp<=4`. Lunghezze esatte di input/output, EOS, proprietà, checksum e assenza di byte finali estranei sono obbligatori. I metadata grezzi sono presi in prestito; quelli compressi possiedono un'allocazione temporanea limitata. L'API comune `p64_metadata_open/close` trasferisce esplicitamente `bytes`, `size`, `owned` e svuota la vista in caso di errore/chiusura.

Sorgenti codificate, tabelle, contesti e programmi persistenti restano residenti nel guest e contano negli81.920byte. Espansione metadata, gruppo sorgente decodificato, stack espressioni, alpha e righe sono lavoro HOST temporaneo, mai un pool asset indirizzabile. Il decoder LZMA usa il proprio output limitato come dizionario e libera i dati probabilistici; non aggiunge altri64KiB guest. Questa soluzione software non dimostra banda o circuiti di una cartuccia fisica.

## Nodo scenery 22 tipo11: sfondo guest generico

Il nodo occupa24byte nella MAIN fisica e resta nella lista scenery esistente.

|Offset|Significato|
|---|---|
|0..1|Prossimo nodo u16|
|2|Backing blob0 MAIN /1 AUX|
|3..4,5..6|Indirizzo blob u16, lunghezza completa regione u16|
|7..8|Indirizzo MAIN del byte selettore scena|
|9..10|Indirizzo MAIN del byte gate|
|11|Tipo nodo11|
|12..13|Indirizzo MAIN della camera-X u16|
|14,15|Valore/mask gate: `(MAIN[gate]&mask)==value`|
|16..17,18|Larghezza mondo u16, altezza mondo u8|
|19|Flag: bit0 MODE_FILTER; tutti gli altri0|
|20|Con flag0 deve essere0. MODE_FILTER richiede mask modi native non nulla, solo bit0..4|
|21..23|Riservati0|

Per esempio, flag1/mask2 seleziona il testo multicolore modo1 e lascia intatto il testo modo0. Il circuito non contiene indirizzi font, coordinate HUD o ID di gioco. Flag0 conserva tutti i cinque modi sorgente nativi. Una riga esclusa lascia i pixel invariati e azzera la maschera di selezione opzionale. Flag/mask/indirizzi invalidi vengono rifiutati.

Il decoder campiona coppia TED nativa, glifo grezzo di matrice, attributo `cbuf&127` e colore nativo originale immutabili, prima della ricolorazione. Camera e origine del fine scroll individuano la sorgente visibile; non esiste bitmap dell'intero mondo. La pittura sfondo si applica dopo le tinte scenery precedenti, prima di salvare i colori finali di primo piano e comporre gli attori. Collisioni, priorità sorgente, bordi nativi finali, blanking e gate UI restano indipendenti.

## Bytecode P64B e operatori materiali

L'intestazione è `P64B`, versione1, riservato0. Ogni TLV contiene tipo u8, lunghezza payload u16, poi payload. Gli ID sono del guest; duplicati e riferimenti invalidi rifiutano il programma. La palette usa **codici TED nativi0..127**, non indici sprite compatti0..120. Il bit0 della mask coppie autorizza esplicitamente lo sfondo sorgente; non è trasparenza sprite.

|TLV|Significato|
|---|---|
|1/2/3|Palette, insieme glifi, clip di riga stretto|
|4/5/6/7|Template, istanza, campo globale inline, definizione campo condiviso|
|12|Righe ripetute di intervalli u16 `(left,width)` ordinati senza sovrapposizioni|
|13|Inviluppo di riga con segno: L/R iniziali e segmenti delta periodici limitati|
|14/16|Riferimento campo condiviso da8byte: scena,x16,y8,width16,height8,fieldID;16 viene eseguito prima|
|15|Selettore glifo/sottocella: glifo più8bitmap di riga LSB-first; fase worldX/Y modulo8|
|17|Tabella volumi vicini: scale X/Y positive, ancore esplicite, rettangoli di forzatura opzionali e di luce|

L'ordine è **16 →5 →6 →14**, conservando l'ordine dei record in ogni gruppo. Le definizioni contengono selettori di coppia/colore nativo/attributo/glifo originali e clip, poi l'operatore. Le dimensioni globali esterne sostituiscono quelle positive della definizione. Le codifiche esatte sono in `reference/formats/` e nelle copie sorgenti corrispondenti.

|Shader|Operazione|
|---|---|
|0/1/2|Costante, selezione affine a due colori, cilindro a tre colori|
|3/4/5/6|Run legacy per rango sorgente, rampa verticale, indici espliciti per riga, run per coordinata|
|7/8/9|Rettangolo di luce radiale, rampa Y con estremi, palette su inviluppo guest|
|10/11/12|LUT glifo-riga originale, LUT X periodica, campo radiale parametrico|
|13|Superficie quadratica, con miscela opzionale della luminanza codificata corrente|
|14|Inviluppo power simmetrico con palette/esponente guest e scala fissa opzionale|
|15|Volume guest più vicino, poi luce dello shader13|

I nuovi operatori non richiedono sorgenti fuori schermo. Il legacy3 richiede il prefisso sorgente selezionato; il6 lo sostituisce per l'uso limitato al viewport. Le percentuali quadratiche sono0..100; tinta1..15, luminanze0..7, dimensioni positive. La distanza usa i pixel locali fisici: vince il primo minimo stretto; le forzature vengono applicate in ordine, vince l'ultima corrispondenza. Dove previsto l'arrotondamento è al più vicino con parità. Il codice va compilato senza fast-math o contrazione floating-point.

## Nodo scenery 22 tipo12: fase esterna della luce

Questo **nodo scenery tipo12 è distinto dal TLV12 P64B**. Occupa16byte: next u16 a0, fase-X u16 a2 (0..319), indirizzo gate MAIN u16 a4, valore/mask a6/7, riservati0 a8..10, tipo12 a11 e riservati0 a12..15. Vince il primo proprietario di fase valido con gate vero nel ramo attivo, compresa la fase0. Il percorso limitato segue al massimo32nodi; sostituire un ramo materiali può sostituirne anche la fase.

La fase ruota soltanto il viewport di luce esistente da320pixel. Non scorre i glifi sorgente né cambia la classificazione del primo piano. Una fase non nulla usa una riga temporanea da320byte; gate falsi, fase0 e versioni scenery precedenti conservano il percorso precedente. Il riferimento intermedio della scena04 usa fase280: è dato della ricetta guest, non una regola del circuito dedicata alla scena.

## Caricamento di un gioco a stadi e verifica del port

Il disco Usagi contiene 20 file ordinari: `USAGI` avvia, quindi carica `ASSETS` e `MAIN` con KERNAL. I 17 pacchetti `B01`..`B17` vengono caricati al cambio scena, con una pausa in quel punto. La somma dei pacchetti sul disco e il massimo residente effettivo sono nel capitolo 9. Gli 8825 byte recuperati nella MAIN comprendono 7376 byte per lo sfondo attivo, 1278 byte di codice residente del loader e 171 byte di riserva; queste occupazioni si contano una sola volta. Non esiste una RAM aggiuntiva per gli sfondi.

`USAGI.PRG` è soltanto un bootstrap interno al disco, non un programma autonomo; `MAIN.PRG` non è un avviatore. Conservare il D64 completo e i nomi dei file. Usare la prima voce grezza/indice1; evitare un suffisso testuale maiuscolo `:USAGI`, che VICE può convertire in un nome PETSCII diverso.

Un solo gioco/D64 mantiene lo stesso contratto64+16KiB su C16 e Plus/4. I rapporti del capitolo 9 separano loader reale, tasti PC, sorgenti/materiali, pixel presentati, esclusione HUD/dialoghi, snapshot e prestazioni. Fixture C, stub CPU, Linux, Wine e campagne complete restano prove diverse; leggere la copertura dichiarata di ogni ricevuta.


## Lavoro P64B temporaneo entro il fotogramma

Il runtime può preparare una sola volta per fotogramma il programma P64B residente nel guest, usando `p64b_native_scanline_work()` e un `p64b_frame_work_t` inizializzato a zero. Il lavoro comprende una copia integrale dell'input codificato, l'eventuale espansione P64Z e l'indice convalidato del programma. Input ed espansione hanno ciascuno un limite di 65.535 byte; gli ulteriori limiti dell'implementazione sono registrati nel capitolo 9 e in `RELEASE_STATUS.json`. Si tratta di memoria temporanea del renderer host, distinta dagli **81.920 byte accessibili al gioco**.

Prima di ogni riuso, l'adattatore confronta tutti i byte dell'input guest; una scrittura durante il fotogramma fa scartare e ricostruire il lavoro prima della riga successiva. Banco, indirizzo e lunghezza devono coincidere. Un indirizzo, una lunghezza o un input codificato diverso sostituisce il lavoro precedente: non si accumulano contesti. Nodi diversi possono riusare lo stesso indice quando leggono esattamente il medesimo programma. Gate, scena, camera, colori e fatti sorgente TED vengono comunque letti per ogni riga.

`p64b_frame_work_discard()` libera input, espansione e indice. Il runtime lo richiama a fine fotogramma, reset, riconfigurazione e caricamento snapshot; lo stato temporaneo non viene serializzato. Non conserva pixel sorgente, immagini degli scenari o un catalogo di oggetti del gioco fra fotogrammi. Le API precedenti restano disponibili e mantengono la durata entro la singola chiamata quando non viene fornito un contesto esplicito.

Le API di base sono `p64b_prepare()`, `p64b_apply_prepared()` e `p64b_prepared_discard()`: il chiamante mantiene immutabile il blob fino allo scarto dell'indice. L'adattatore nativo gestisce questa proprietà mediante la propria copia e il confronto integrale. Vedere [p64_background.h](reference/api-current/p64_background.h) e [p64_background_native.h](reference/api-current/p64_background_native.h).

Questa ottimizzazione non cambia i byte P64B/P64Z del disco, i registri del guest, il protocollo RAM `$05`, il modulo snapshot PLUS64 `1.0`, scenery **22** o materiali **8**. Non aggiunge RAM guest né dimostra i tempi o i circuiti di una cartuccia fisica. I tempi di un confronto isolato del renderer non sono gli FPS di una partita.

## Avvio Usagi con caricamento KERNAL

Gli avviatori di questa consegna selezionano `-drive8type 1541 +drive8truedrive -trapdevice8 -busdevice8`. In VICE, il prefisso `+` disattiva l'emulazione completa del drive: consente alle trap KERNAL di caricare i file successivi al bootstrap. Con l'emulazione completa ancora attiva, il bootstrap poteva lasciare visibile per molto tempo soltanto lo sfondo viola durante il caricamento. Il comando non attiva il warp permanente e non cambia la memoria del gioco. Gli script Linux convertono il percorso assoluto di `usagi.vkm` con `winepath.exe` prima di passarlo a `-symkeymap`, così Wine/VICE può trovare la mappa anche in una cartella con spazi.

Le correzioni del gioco riguardano anche i riferimenti del disegno dei ponti intermedi, così che pali e corrimano anteriori usino lo stesso livello davanti agli attori, lasciando la pedana dietro; il selettore dei materiali degli attori, compresa la posa di morte del ninja. Gli sfondi mantengono i disegni concordati, confrontati con i pixel effettivi durante lo scorrimento. Il capitolo 9 riporta quali casi sono stati verificati nella build identificata, distinguendo il percorso naturale dalle fixture controllate.
