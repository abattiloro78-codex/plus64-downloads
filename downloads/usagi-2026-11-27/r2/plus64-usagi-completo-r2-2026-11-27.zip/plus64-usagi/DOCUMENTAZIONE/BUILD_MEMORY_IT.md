# 9. Build, memoria e prove della consegna

| Campo|Valore |
|---|---|
| Candidato | `033-approved178-r8` |
| MAIN SHA256 | `4035fde92fcec99cce803a8fe9e739f31b6ae2d9b241994dfc143433c2a9a321` |
| D64 SHA256 | `e7378e4e0d85588b300d668d62de675fa7d1a8fe165635fc3da2c096d9daa3a8` |
| Windows PE SHA256 | `8c3903f1b473034a174a8f6bd81af855a2d7830040998c863dbda45dc3634b40` |
| Linux headless SHA256 | `ea718e51a8b1b01972808ded9cd00cfc2bbb4ed0ec7d288efb40e01f498c3c2c` |
| Capacità scenery / materiali sprite | 22 / 8 |
| MAIN / AUX / total | 65536 / 16384 / 81920 |
| RAM guest aggiuntiva | 0 |
| Archivio sorgenti P64Fv4 | 10409 byte, MAIN84D0..AD78 |
| SVM4 / P64Z method2 | 6294 byte, AUX02E0..1B75 |
| Capacità pacchetto sfondo attivo | 7376 byte |
| Pacchetto più grande | 7376 byte |
| Totale dei 17 pacchetti sul disco | 53802 byte |
| Intervallo MAIN sfondo (estremo finale escluso) | [44409, 51785] |
| Intervallo loader (estremo finale escluso) | [51785, 53063] |
| Intervallo stub chiamata ROM (estremo finale escluso) | [18308, 18405] |
| Workspace LOAD salvato | 3838 byte |
| Area temporanea nelle matrici di output MAIN | 2848 byte |
| Area temporanea nella AUX esistente | 990 byte |

Il contratto resta **64 KiB MAIN +16 KiB AUX =81.920 byte**, con zero backing guest aggiuntivo. Codice, musica, font, matrici TED, descrittori, sorgenti compressi e materiali condividono questi byte. Le viste di memoria sono alias, non ulteriori pool.

Gli sfondi `B01`..`B17` risiedono sul disco, ma soltanto il pacchetto della scena attiva viene caricato nello slot MAIN. Il cambio scena può avere una pausa di caricamento; il rendering non consulta un catalogo o file host. Gli 8825 byte recuperati nella build 032 comprendono 7376 byte per lo sfondo attivo, 1278 byte di codice residente del loader e 171 byte di riserva; queste occupazioni si contano una sola volta. Durante LOAD il workspace KERNAL viene salvato temporaneamente nelle matrici di output e nell’area AUX dichiarata; dopo il ripristino, il costruttore ricrea le matrici e conserva il byte sorgente D798 richiesto dallo scorrimento. Contano la capacità del contenitore e il suo picco simultaneo, non la somma dei file del disco o le dimensioni di ZIP/EXE.

La correzione del timer verifica nuovamente il fascio TED dopo l’armamento IRQ, evitando l’attesa di un frame se la scadenza è già trascorsa. Il formato P64Z1 e i suoi byte restano invariati; libdeflate 1.26 accelera la decompressione zlib nel runtime. Le viste sprite restano limitate alla singola chiamata. Il lavoro P64B esplicito può durare fino alla fine del fotogramma, con confronto integrale dell’input a ogni riuso; viene scartato a fine frame, reset, riconfigurazione o caricamento snapshot. Non conserva immagini o un catalogo del gioco fra fotogrammi. Input codificato, espansione e indice sono lavoro host temporaneo, non RAM guest.

I rapporti sotto vincolano questi hash e separano prove isolate, avvii D64, input PC reali e limiti di copertura. Il runtime Linux nativo è headless per sviluppo/QA; la GUI Linux degli avviatori usa lo stesso PE tramite Wine64. Wine non è Windows nativo né hardware fisico. Non viene dichiarata una campagna completa.

## Lavoro temporaneo del renderer host

Misure e limiti x86_64; esclusi header dell’allocatore e stack C. Le matrici di riga dichiarate occupano inoltre960byte. Questi byte sono scratch dell’emulatore host e non sono accessibili al gioco; vengono liberati entro il frame. Non sono RAM guest né prova di realizzabilità elettrica.

| Campo|Byte |
|---|---:|
| Input massimo | 65535 |
| Espansione massima | 65535 |
| Indice convalidato | 7184 |
| Contesto | 56 |
| Limite heap M1 | 142694 |
| Limite heap M2 conservativo | 196662 |
| Picco heap misurato nei17pacchetti | 39198 |
| Heap trattenuto entro il frame, massimo misurato | 34814 |

- `reference/receipts/fix-00-QUALIFICATION_FINAL.json` — SHA256 `17d9acd1d0d6c5ec5d3958a25a4d39b8b12f7650c06ce6a8161444f9f5689819`
- `reference/receipts/fix-01-MULTILOAD_BUILD.json` — SHA256 `b4325e153db9afcb1e615969be6c65f268a86fe3ea3bd6fd33ba3e3d3c153e71`
- `reference/receipts/fix-02-MEMORY.json` — SHA256 `68cda8589b5e939b111cdda7398b4e17dc3fc1b81b9f5248fe88d00d922d021e`
- `reference/receipts/fix-03-NEW_CORE_NATURAL_L1_PROOF.json` — SHA256 `8127412a7e6e0d13d90528073d32dcea83e1877fe0a148e32502105c5beab914`
- `reference/receipts/fix-04-PROOF.json` — SHA256 `3543da1cc15f8aceedf1b4604f98f0cbcb5430c191a48f935c497acdd6a9717d`
- `reference/receipts/fix-05-LIFECYCLE.json` — SHA256 `98dbe5ba8c9a454983719882ab9b7db55566fa55102d5be8827faa75a7184ade`
- `reference/receipts/fix-06-PROOF.json` — SHA256 `0fcd8443634c0ad6d9b41c48590d27ae95175d2d7bf40954a52b0f490a6d1da8`
- `reference/receipts/fix-07-PROOF.json` — SHA256 `4bd91005feb90b14414f691be2260de990c17adaa7299afa49d39fa53f525deb`
- `reference/receipts/fix-08-REBUILD_PROOF.json` — SHA256 `fc2086a3e8ab10b8e07c1de6fa4b754375243114b45a1de95798adc3b1379c66`
- `reference/receipts/fix-09-VISIBLE_BLOOD_PROOF.json` — SHA256 `125855732e382b0dc5591acbd1a938e0404131c1b7a1071d314a06c5d6723e17`
- `reference/receipts/fix-10-ACTUAL_VS_PUBLISHED_COMPARISON.json` — SHA256 `7ee8a24f12ac43f4687f34f3dd57a70cf4d47d0470dcbbdc6bdf7dcbaf097db4`
- `reference/receipts/fix-11-LITERAL_PUBLISHED_PNG_PROOF.json` — SHA256 `99b2747a2ea83f86dc2b5f9aaac1cc3a6e296290befb4129cf0c27461c7281cd`
