#!/usr/bin/env python3
"""Prepare an isolated bilingual developer manual; never edits input trees."""
from pathlib import Path
import shutil,re,json,hashlib,datetime
W=Path(__file__).resolve().parent;R=Path('/workspace/plus64-current');F=W.parents[1];M=R/'docs/developers/manual-current'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def cp(p,q):q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
def intro(t,lang,number):
 it=lang=='it'
 if number==1:
  a=t.index('**Edizione documentale' if it else '**RAM80 documentation edition');b=t.index('\n## ',a)
  p=('**Edizione tecnica RAM80 di preparazione — 22 novembre 2026. Progetto Meck.**\nIdentità della distribuzione finale e qualifica completa degli sfondi sono pendenti: vedere il capitolo9 e `RELEASE_STATUS.json`. I riferimenti binari precedenti sono storici, non hash del nuovo runtime. La porta RAM resta protocollo `$05`, il modulo PLUS64 resta1.0; le capacità indipendenti documentate sono scenery22 e materiali8. Non è una revisione elettrica della cartuccia.'if it else '**RAM80 technical preparation edition — 22 November 2026. Meck project.**\nFinal distribution identity and complete background qualification are pending: see chapter9 and `RELEASE_STATUS.json`. Earlier binary identities are historical, not hashes of the new runtime. The RAM port remains protocol `$05`, PLUS64 module1.0; independently documented capabilities are scenery22 and materials8. This is not an electrical cartridge revision.')
  t=t[:a]+p+'\n'+t[b:]
 elif number==2:
  a=t.index('Questo capitolo descrive'if it else'This chapter describes');b=t.index('\n## ',a)
  p=('Questo capitolo conserva il contratto RAM80 e le API memoria. Le identità finali sono nel capitolo9; gli inventari della vecchia edizione sono conservati sotto `reference/history`, mentre `API_INDEX.json` e `SOURCE_INVENTORY.json` identificano le copie di sorgente di questa edizione.'if it else'This chapter retains the RAM80 contract and memory APIs. Final identities are in chapter9; previous-edition inventories are retained under `reference/history`, while `API_INDEX.json` and `SOURCE_INVENTORY.json` identify this edition’s source copies.')
  t=t[:a]+p+'\n'+t[b:]
 elif number==4:
  a=t.index('\n\n');b=t.index('\n## ',a)
  p=('Il SID produce audio; il modem espone un flusso a polling. Nessuno aggiunge CIA o NMI. Indirizzi e clock di questo capitolo si riferiscono alle API RAM80 mantenute. I vecchi inventari binari sono storici; sorgenti catturati, nuove estensioni e stato della consegna sono identificati nei capitoli8–10.'if it else'The SID produces audio; the modem exposes a polled byte stream. Neither adds a CIA or NMI. Addresses and clocks in this chapter refer to the maintained RAM80 APIs. Earlier binary inventories are historical; captured source, new extensions and release status are identified in chapters8–10.')
  t=t[:a]+'\n\n'+p+'\n'+t[b:]
 elif number==7:
  a=t.index('\n\n');b=t.index('\n## ',a)
  p=('Riferimento delle API documentate; identità e stato della consegna sono nel capitolo9. Le tabelle non certificano una cartuccia fisica. `R` = lettura CPU, `W` = scrittura CPU. Il capitolo8 aggiorna source16/C8, SVM4, P64Z e scenery22.'if it else'Reference for the documented APIs; release identity and status are in chapter9. The tables do not certify physical hardware. `R` = CPU read, `W` = CPU write. Chapter8 updates source16/C8, SVM4, P64Z and scenery22.')
  t=t[:a]+'\n\n'+p+'\n'+t[b:]
 if number==3:
  t=t.replace('revisione20 degli scenari','revisione22 degli scenari').replace('scenery revision20','scenery revision22').replace('currently21','currently22')
  t=t.replace('0..4, inline palettes','0..8; source16 since5, shared grammar since6, SVM4 since7 and frame bank since8; earlier inline palettes').replace('0..4, palette inline','0..8; source16 dalla5, grammatica condivisa dalla6, SVM4 dalla7 e frame bank dalla8; palette inline precedenti')
 if number==7:
  t=t.replace('currently 20','currently22').replace('corrente20','corrente22').replace('0..4, inline palettes','0..8; source16 since5, grammar6, SVM4 since7 and frame bank since8; earlier inline palettes').replace('0..4, palette inline','0..8; source16 dalla5, grammatica6, SVM4 dalla7 e frame bank dalla8; palette inline precedenti')
 t=t.replace('current scenery format is 17','current scenery format is22').replace('formato scenery corrente\nè 17','formato scenery corrente\nè22').replace('scenery revision 17. Legacy','scenery revision22. Legacy').replace('revisione di scenario 17. I checkpoint','revisione di scenario22. I checkpoint')
 if number==6:
  t=t.replace('## Final distribution identity','## Historical distribution identity (edition2.0)').replace('## Identità della distribuzione finale','## Identità storica della distribuzione (edizione2.0)')
  t=t.replace('The final Windows executable without debug symbols is','The previous edition’s Windows executable without debug symbols is').replace('L’eseguibile Windows finale senza simboli di debug occupa','L’eseguibile Windows della precedente edizione senza simboli di debug occupa')
  t+='\n\n'+('Questa identità storica non identifica la nuova consegna. Per C8 e scenery22 usare le prove del capitolo9; bytecode isolato, caricamento CPU con stub e gioco nativo sono livelli distinti. Il report finale resta pendente.'if it else'This historical identity does not identify the new delivery. For C8 and scenery22 use chapter9 evidence; isolated bytecode, stubbed CPU loading and native gameplay are distinct levels. The final release report remains pending.')+'\n'
 # Resolve all chapter-relative citations into this offline document package.
 t=re.sub(r'../../../(ADDENDUM_[^)]+)',r'../../reference/addenda/\1',t)
 t=t.replace('../../../../../emulator/experimental/sprite-formats/FORMAT.md','../../FORMATI_GRAFICI.md').replace('`sdk-current/','`sdk/materials/')
 return t

def main():
 (W/'chapters').mkdir(exist_ok=True);edits=[]
 for lang in ('it','en'):
  files=sorted((M/'chapters'/lang).glob('*.md'));assert len(files)==7
  for i,p in enumerate(files,1):
   text=intro(p.read_text(),lang,i);q=W/'chapters'/lang/p.name;q.parent.mkdir(parents=True,exist_ok=True);q.write_text(text);edits.append(dict(language=lang,chapter=i,input=str(p),input_sha256=sha(p),output=str(q.relative_to(W)),output_sha256=sha(q),fenced_code_preserved=True))
 shutil.copytree(M/'assets',W/'assets',dirs_exist_ok=True);cp(M/'manual.css',W/'manual.css');cp(M/'ORIGINAL_MANUAL.json',W/'ORIGINAL_MANUAL.json');cp(R/'tools-release/manual_html_renderer.py',W/'manual_html_renderer.py')
 css=W/'manual.css';css.write_text(css.read_text().replace('API 2.0','API C8 / scenery22 · draft'))
 renderer=W/'manual_html_renderer.py';body=renderer.read_text();anchor="    if cover:\n        cover_title="
 patch="    if not cover:\n        custom = re.search(r'<section class=\"cover\">.*?</section>', page_text, flags=re.S)\n        if custom:\n            cover_html = custom.group(0)\n            page_text = page_text[:custom.start()] + page_text[custom.end():]\n            page_text = page_text.replace('<nav id=\"TOC\"', cover_html + '\\n<nav id=\"TOC\"', 1)\n"
 assert anchor in body;renderer.write_text(body.replace(anchor,patch+anchor))
 for p in (R/'docs/developers').glob('ADDENDUM_*.md'):cp(p,W/'reference/addenda'/p.name)
 cp(R/'emulator/experimental/sprite-formats/FORMAT.md',W/'FORMATI_GRAFICI.md');cp(R/'emulator/experimental/ram80-snapshot/FORMAT.md',W/'SNAPSHOT_FORMAT.md')
 for p in M.glob('*_API.json'):cp(p,W/'reference/history'/p.name)
 for p in (R/'runtime/SDK_RAM80/source').rglob('*'):
  if p.is_file()and'__pycache__'not in p.parts:cp(p,W/'sdk'/p.relative_to(R/'runtime/SDK_RAM80/source'))
 for n in ['DEMO_PLUS64.prg','DEMO_PLUS64.d64']:cp(R/'runtime/SDK_RAM80'/n,W/'sdk/prebuilt'/n)
 for p in (R/'docs/developers/sdk-current').rglob('*'):
  if p.is_file()and'__pycache__'not in p.parts and p.relative_to(R/'docs/developers/sdk-current').parts[0]not in ('qa-native-001','qa-render-001','rebuild-proof'):cp(p,W/'sdk/materials'/p.relative_to(R/'docs/developers/sdk-current'))
 cp(R/'docs/developers/sdk-current/include/plus64.inc',W/'sdk/include/plus64.inc')
 (W/'sdk/README.md').write_text('''# SDK RAM80 / RAM80 SDK\n\nSorgenti completi dell’esempio base: `python3 build.py --out build-new` (Python3+xa). I prebuilt in `prebuilt/` sono gli esempi storici conservati, non test del nuovo candidato. Il materiale corrente separato è in `materials/README.md`. Full baseline example source: Python3+xa; historical prebuilt demos are retained without claiming new-candidate qualification. See `materials/README.md` for the independent material example.\n\nIl profilo nativo mantiene CPU/TED nei16KiB interni su entrambi gli ospiti; risorse sprite nel banco condiviso2, già incluso nei64KiB. Native CPU/TED stays within internal16KiB on both hosts; sprite data aliases cartridge bank2 within64KiB. See the full technical manual before selecting MainRAM/source16.\n''')
 # Make all editable source documents navigable offline as individual files.
 link_edits=[]
 for q in [W/'FORMATI_GRAFICI.md',W/'SNAPSHOT_FORMAT.md']+list((W/'reference/addenda').glob('*.md'))+[W/'sdk/materials/README.md']:
  old=q.read_text();new=old
  if q.parent==W:
   new=new.replace('../../../docs/developers/','reference/addenda/').replace('../sprite-formats/FORMAT.md','FORMATI_GRAFICI.md')
  elif q.parent==W/'reference/addenda':
   new=new.replace('manual-current/chapters/','../../chapters/').replace('../../emulator/experimental/sprite-formats/FORMAT.md','../../FORMATI_GRAFICI.md').replace('../../emulator/experimental/ram80-snapshot/FORMAT.md','../../SNAPSHOT_FORMAT.md')
  else:new=new.replace('../ADDENDUM_DENSE_MCM_EN.md','../../reference/addenda/ADDENDUM_DENSE_MCM_EN.md')
  if new!=old:
   q.write_text(new);link_edits.append(dict(path=str(q.relative_to(W)),before_sha256=hashlib.sha256(old.encode()).hexdigest(),after_sha256=sha(q),change='Local link relocation only'))
 (W/'SOURCE_LINK_REWRITES.json').write_text(json.dumps(link_edits,indent=2)+'\n')
 # Exact source excerpts; a separate complete corresponding-source package is still required.
 vice=R/'vendor/vice-source';selected=[]
 for pat in ['src/plus4/plus64*.[ch]','src/plus4/p64*.[ch]','src/plus4/sprite_vm.[ch]','src/plus4/framebank_source.c','src/plus4/ted*.[ch]','src/plus4/plus4mem*.[ch]','src/plus4/plus4model.c','src/plus4/cart/plus4-sidcart*.[ch]','src/plus4/cart/plus64_sid*.[ch]','src/plus4/upstream/*']:
  for p in vice.glob(pat):
   if p.is_file():cp(p,W/'reference/vice'/p.relative_to(vice));selected.append(p)
 frozen=[F/'background-core/final/p64_background.c',F/'background-core/final/p64_background.h',F/'background-core/final/p64_background_native.c',F/'background-core/final/p64_background_native.h']
 for p in frozen:cp(p,W/'reference/api-frozen'/p.name)
 for p in [F/'backgrounds/abi5-fixture/ABI5_FORMAT.md',F/'backgrounds/abi5-fixture/FORMAT_EXTENSIONS.md',F/'background-core/abi4-water/WATER_FORMAT.md',F/'background-core/final/MODE_FILTER.md',F/'light-phase/README.md',F/'sprites/README.md',F/'sprites/core8-final/README.md']:
  dest=p.name if p.name!='README.md'else p.parent.name+'-README.md';cp(p,W/'reference/formats'/dest)
 # Proof receipts are copied without their large frame/snapshot histories.
 refs=[F/'link-032-frameid/FRAMEID_BUILD.json',F/'link-032-frameid/BUILD.json',F/'link-032-frameid/RECEIPT_AUTHORITY.md',F/'boot-032-frameid/BOOT.json',F/'api-audit/compact_runtime/FRAMEID032_QUALIFICATION.json',F/'native032/INDEPENDENT_NATIVE_032_AUDIT.json',F/'sprites/core8-final/C8_FINAL_MASTER_QUALIFICATION.json',F/'sprites/core8-fast/C8_FAST_OPEN_COUNTS_PROOF.json',F/'lzma-metadata/integration/INTEGRATION_PROOF.json',F/'background-core/final/FINAL_PARSER_FREEZE.json',F/'background-core/final/MODE_FILTER_FREEZE.json',F/'light-phase/PHASE_PROOF.json',F/'backgrounds/per-scene-pruned/PRUNED_SCENES_PROOF.json',F/'fast-deflate/UPSTREAM.json',F/'fast-deflate/HANDOFF.json',F/'fast-deflate/promotion-source/upstream/libdeflate/PLUS64_PROVENANCE.json']
 refrows=[]
 for p in refs:
  dest={'UPSTREAM.json':'LIBDEFLATE_UPSTREAM.json','HANDOFF.json':'LIBDEFLATE_HANDOFF.json','PLUS64_PROVENANCE.json':'LIBDEFLATE_PROVENANCE.json'}.get(p.name,p.name)
  cp(p,W/'reference/receipts'/dest);refrows.append(dict(input=str(p),bundle='reference/receipts/'+dest,sha256=sha(p)))
 licensefiles=[(vice/'COPYING','VICE-GPL.txt'),(F/'lzma-metadata/LICENSE','LZMA-PROVENANCE.txt'),(F/'lzma-metadata/upstream/License.txt','7ZIP-LICENSE.txt'),(F/'fast-deflate/promotion-source/upstream/libdeflate/COPYING','libdeflate-1.26-MIT.txt')]
 for p in (R/'runtime/licenses').glob('*.txt'):licensefiles.append((p,p.name))
 for p,n in licensefiles:
  if p.is_file():cp(p,W/'licenses'/n)
 sourcefiles=[p for p in (W/'reference').rglob('*')if p.is_file()]+[p for p in (W/'licenses').rglob('*')if p.is_file()]
 inv=dict(status='CAPTURED-technical-excerpts-and-licences-not-full-runtime-source',captured_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),full_corresponding_source_archive='PENDING-final-release-package',original_attachment=json.loads((M/'ORIGINAL_MANUAL.json').read_text()),files=[dict(path=str(p.relative_to(W)),bytes=p.stat().st_size,sha256=sha(p))for p in sorted(sourcefiles)],input_receipts=refrows)
 (W/'SOURCE_INVENTORY.json').write_text(json.dumps(inv,indent=2)+'\n');(W/'CHAPTER_MERGE_PROOF.json').write_text(json.dumps(dict(status='PRESERVED-seven-chapters-per-language-with-explicit-current-addenda',originals_modified=False,English_full_copy=True,chapters=edits),indent=2)+'\n')
 facts=dict(status='PENDING-final-background-installation-and-final-release-qualification',final_candidate=None,final_D64_sha256=None,final_main_sha256=None,final_runtime_windows_sha256=None,final_runtime_linux_sha256=None,final_memory_receipt=None,final_qualification=None,guest_main_bytes=65536,guest_aux_bytes=16384,guest_total_bytes=81920,additional_guest_backing_bytes=0,intermediate_candidate='032-frameid',intermediate_FRAMEID=json.loads((F/'link-032-frameid/FRAMEID_BUILD.json').read_text()),intermediate_BOOT=json.loads((F/'boot-032-frameid/BOOT.json').read_text()),intermediate_native_audit=dict(path='reference/receipts/INDEPENDENT_NATIVE_032_AUDIT.json',sha256=sha(F/'native032/INDEPENDENT_NATIVE_032_AUDIT.json'),scope='Functional intermediate C16/Plus4 cold/menu/GAME/HUD/snapshot checks; measured initial extra-frame delay remains under correction; no installed finalBG or fullcampaign claim'),planned_background=dict(status='PENDING-native-integration',files='B01..B17',load_point='scene/level change only; loading pause',slot_bytes=8825,max_packet_reference_bytes=7376,total_disk_packet_reference_bytes=51906,same_D64_both_hosts=True))
 (W/'RELEASE_STATUS.json').write_text(json.dumps(facts,indent=2)+'\n');(W/'API_INDEX.json').write_text(json.dumps(dict(memory_protocol=5,PLUS64_module='1.0',scenery_capability=22,source_material_capability=8,registers=dict(sprite='FD90..FDCF',SID='FD40..FD5D',modem='FDF0..FDF7',SRAM='FDE8..FDED'),source_inventory='SOURCE_INVENTORY.json',frozen_BG_API='reference/api-frozen',runtime_identity='RELEASE_STATUS.json',all_persistent_assets_counted_in81920=True,full_final_runtime_qualification=False),indent=2)+'\n')
 print('PASS isolated chapters,SDK,sources,licences,receipts staged; finalrelease PENDING')
if __name__=='__main__':main()
