; plus/64 existing emulated I/O - xa syntax. No hardware registers invented.
P64_SPR_ENABLE   = $fd90
P64_SPR_COLLISION= $fd91
P64_SPR_RAW8     = $fd92
P64_SPR_EXPAND_X = $fd93
P64_SPR_EXPAND_Y = $fd94
; FD95 priority is defined only for enabled tagged dense MCM; older formats ignore it.
P64_SPR_BEHIND   = $fd95
P64_SPR_DATA     = $fd96
P64_SPR_ADDR_LO  = $fd97
P64_SPR_ADDR_HI  = $fd98
P64_SPR_DESC     = $fda0
P64_SPR_IO_END   = $fdcf
P64_SPR_COUNT    = 8
P64_SPR_DESC_SIZE= 6
P64_SPR_WIDTH    = 24
P64_SPR_HEIGHT   = 21
P64_SPR_RAW_BYTES= 504
P64_SPR_RAM_BYTES= 16384
; Scenery19 opt-in pixel-centred elliptical tint footprint (nodes5/7).
P64_TINT_ELLIPSE = $08
P64_SCENERY_ELLIPSE_VERSION = 19
P64_SNAPSHOT_SCENERY_CAP_OFFSET = 79
; Scenery20 keyed vertical palette-ramp node9 (16-byte descriptor).
P64_NODE_PALETTE_RAMP = 9
P64_SCENERY_PALETTE_RAMP_VERSION = 20
P64_RAMP_HOLD_BOTTOM = 1
; Scenery21 node10 glyph-anchored tint/front rectangles, all sprite formats.
; Explicit guest data only; FD95/collision inputs unchanged, no extra guest RAM.
P64_NODE_ANCHORED_FOREGROUND = 10
P64_SCENERY_ANCHORED_FOREGROUND_VERSION = 21
P64_ANCHORED_FOREGROUND_NODE_BYTES = 16
P64_ANCHORED_FOREGROUND_RECT_BYTES = 6
; Dense record constants use existing memory/ports, without extra registers or RAM.
; Requires current dense-capable runtime, packedcache and mixedsprites.
; SRAM protocol05 alone does not discover this decoder capability.
P64_DENSE_MCM_TAG  = $8000
P64_DENSE_MCM_BYTES= 70
; Last start for one70-byte part only; a chain requires base+parts*70<=16384.
P64_DENSE_MCM_LAST = $3fba
P64_DENSE_SHIFT    = $40
; With snapshot capability81, head40 is height0=21 or1..252, not shift.
P64_DENSE_HEIGHT   = $40
P64_DENSE_HEIGHT_MAX=252
P64_DENSE_PART_ROWS=21
P64_DENSE_MODE     = $41
P64_DENSE_INK_3    = $42
P64_DENSE_INK_2    = $43
P64_DENSE_INK_1    = $44
P64_DENSE_VALID    = $45
P64_DENSE_VALID_VALUE = $a5
P64_SNAPSHOT_DENSE_CAP_OFFSET = 80
P64_SNAPSHOT_DENSE_HEIGHT_CAP_OFFSET = 81
P64_COLOR_BLACK = 0
P64_COLOR_LAST  = 120
P64_TRANSPARENT = 255

P64_SRAM_ADDR_LO = $fde8
P64_SRAM_ADDR_HI = $fde9
P64_SRAM_DATA    = $fdea
P64_SRAM_BANK    = $fdeb
P64_SRAM_SIG_LO  = $fdec
P64_SRAM_SIG_HI  = $fded
P64_SRAM_BANK_BYTES=16384
P64_SRAM_BANKS   = 4
P64_SRAM_BYTES   = 65536

P64_SID_BASE     = $fd40
P64_SID_FREQ_LO  = $fd40
P64_SID_FREQ_HI  = $fd41
P64_SID_CTRL     = $fd44
P64_SID_AD       = $fd45
P64_SID_SR       = $fd46
P64_SID_VOLUME   = $fd58
P64_SID_POT_X    = $fd59
P64_SID_POT_Y    = $fd5a
P64_SID_OSC3     = $fd5b
P64_SID_ENV3     = $fd5c
P64_SID_IO_END   = $fd5d
; $FD5E/$FD5F are outside the SIDcart decoder in this runtime.
P64_SID_PAL_CLOCK= 985248

P64_MODEM_DATA   = $fdf0
P64_MODEM_STATUS = $fdf1
P64_MODEM_CONTROL= $fdf2
P64_MODEM_BAUD_DISPLAY=$fdf3
P64_MODEM_RX_COUNT=$fdf4
P64_MODEM_TX_COUNT=$fdf5
P64_MODEM_SIG_LO = $fdf6
P64_MODEM_SIG_HI = $fdf7
P64_MODEM_RX_READY=1
P64_MODEM_TX_ROOM=2
P64_MODEM_CONNECTED=4
P64_MODEM_DIALING=8
P64_MODEM_OVERRUN=16
P64_MODEM_IDLE=32

TED_CTRL1       = $ff06
TED_CTRL2       = $ff07
TED_KEY_LATCH   = $ff08
TED_IRQ_MASK    = $ff0a
TED_SOUND_VOLUME= $ff11
TED_BITMAP_BASE = $ff12
TED_SCREEN_BASE = $ff14
TED_BACKGROUND  = $ff15
TED_BACKGROUND3 = $ff16
TED_BORDER      = $ff19
TED_RASTER_LO   = $ff1d
KEYBOARD_ROWS   = $fd30

; Current opt-in graphics registers, already within the existing64-byte block.
; Set packedcache,leftmcm,mixedsprites before enabling sprites.
P64_LIGHT_01      = $fd99
P64_LIGHT_23      = $fd9a
P64_LIGHT_45      = $fd9b
P64_LIGHT_67      = $fd9c
P64_LAYER_HEAD_LO = $fd9d
P64_LAYER_HEAD_HI = $fd9e
P64_LAYER_FLAGS   = $fd9f
P64_LAYER_ENABLE  = 1
P64_PRESENT_HOLD_1= 2
P64_PRESENT_HOLD_2= 4
P64_WINDOW_ENABLE= 8
; Scenery capability18; ignored by earlier profiles, no additional RAM.
P64_SIDE_BORDER_CLIP = 16
P64_LIGHT_LEGACY = 0
P64_LIGHT_N      = 1
P64_LIGHT_NE     = 2
P64_LIGHT_E      = 3
P64_LIGHT_SE     = 4
P64_LIGHT_S      = 5
P64_LIGHT_SW     = 6
P64_LIGHT_W      = 7
P64_LIGHT_NW     = 8
P64_LIGHT_FRONT  = 9
P64_LIGHT_DIAGONAL_INKS = 10
P64_MATERIAL_BIT = $80
P64_MIXED_RAW8_TAG = $4000
P64_SRAM_PROTOCOL = 5
P64_MODEM_PROTOCOL = 3
