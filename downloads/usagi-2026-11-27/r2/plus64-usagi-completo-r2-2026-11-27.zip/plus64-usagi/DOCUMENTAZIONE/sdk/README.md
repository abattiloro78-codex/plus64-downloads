# SDK RAM80 / RAM80 SDK

Sorgenti completi dell’esempio base: `python3 build.py --out build-new` (Python3+xa). I prebuilt in `prebuilt/` sono gli esempi storici conservati, non test del nuovo candidato. Il materiale corrente separato è in `materials/README.md`. Full baseline example source: Python3+xa; historical prebuilt demos are retained without claiming new-candidate qualification. See `materials/README.md` for the independent material example.

Il profilo nativo mantiene CPU/TED nei16KiB interni su entrambi gli ospiti; risorse sprite nel banco condiviso2, già incluso nei64KiB. Native CPU/TED stays within internal16KiB on both hosts; sprite data aliases cartridge bank2 within64KiB. See the full technical manual before selecting MainRAM/source16.
