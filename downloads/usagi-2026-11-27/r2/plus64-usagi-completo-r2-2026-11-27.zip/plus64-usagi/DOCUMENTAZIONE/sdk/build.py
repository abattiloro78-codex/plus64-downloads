#!/usr/bin/env python3
"""Build the independent SDK demo with Python3 and xa6502 only."""
import argparse,hashlib,json,os,re,shutil,subprocess
from pathlib import Path
from d64 import pack
HERE=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
def table(name,data):
    return name+'\n'+'\n'.join(' .byt '+','.join('$%02x'%v for v in data[i:i+16])for i in range(0,len(data),16))+'\n'
def assets():
    codes=[0]+[(n//15)*16+n%15+1 for n in range(120)]
    luma=[((c>>4)&7)|(c&0x70)for c in codes]
    chroma=[((c&15)<<4)|(c&15)for c in codes]
    pixels=bytearray([255]*504)
    for y in range(16):
        for x in range(16):
            if (x<2 or x>13)and(y<2 or y>13):continue
            if x in(0,15)or y in(0,15):value=0
            else:value=1+((y-1)*14+x-1)%120
            pixels[y*24+x]=value
    assert set(pixels)==set(range(121))|{255}
    return codes,luma,chroma,bytes(pixels)
def labels(path):
    answer={}
    for line in path.read_text().splitlines():
        parts=line.split(',')
        if len(parts)>1:
            try:answer[parts[0].strip()]=int(parts[1].strip().replace('$','0x'),0)
            except ValueError:pass
    return answer
def assemble(out,xa):
    lines=(HERE/'examples/demo.asm').read_text().splitlines();serial=0
    inv={'beq':'bne','bne':'beq','bcc':'bcs','bcs':'bcc','bmi':'bpl','bpl':'bmi','bvc':'bvs','bvs':'bvc'}
    for attempt in range(64):
        path=out/'demo-assembled.asm';path.write_text('\n'.join(lines)+'\n')
        run=subprocess.run([xa,'-C','-I'+str(HERE/'include'),'-I'+str(out),'-o',str(out/'demo.bin'),'-l',str(out/'labels.txt'),str(path)],capture_output=True,text=True)
        if run.returncode==0:return(out/'demo.bin').read_bytes(),labels(out/'labels.txt')
        hit=re.search(r'line\s+(\d+)[^\n]*Branch out of range',run.stderr)
        if not hit:raise RuntimeError(run.stderr+run.stdout)
        n=int(hit[1])-1;m=re.fullmatch(r'\s*(beq|bne|bcc|bcs|bmi|bpl|bvc|bvs)\s+(\w+)\s*',lines[n])
        assert m,(n,lines[n]);end='far_branch_%d'%serial;serial+=1;lines[n:n+1]=[' '+inv[m[1]]+' '+end,' jmp '+m[2],end]
    raise RuntimeError('branch relaxation failed')
def build(out,xa):
    assert not out.exists(),'Choose a fresh --out directory'
    out.mkdir(parents=True);codes,luma,chroma,pixels=assets()
    # Tables are appended to the end of the program, not before its origin.
    (out/'tables.inc').write_text('BEEP_FREQ=%d\n'%round(440*16777216/985248))
    (out/'sprite.inc').write_text(table('',pixels).lstrip()+table('palette_luma',luma)+table('palette_chroma',chroma))
    core,l=assemble(out,xa);assert l['entry']==0x1100
    assert 0x1100+len(core)<=0x1800,('code/sprite exceeds video base',hex(0x1100+len(core)))
    prefix=bytearray(b'\x01\x10\x0c\x10\x0a\x00\x9e 4352\x00\x00\x00');prefix+=bytes(0x1100-(0x1001+len(prefix)-2));prg=bytes(prefix)+core
    assert prg[2:4]==b'\x0c\x10' and len(prg)-2+0x1001<=0x1800
    (out/'DEMO_PLUS64.prg').write_bytes(prg);(out/'DEMO_PLUS64.d64').write_bytes(pack([('PLUS64 SDK DEMO',prg)]));(out/'sprite.bin').write_bytes(pixels)
    (out/'labels.json').write_text(json.dumps(l,indent=2)+'\n')
    meta=dict(title='plus64 native16K SDK example',PRG_bytes=len(prg),PRG_sha256=sha(prg),D64_sha256=sha((out/'DEMO_PLUS64.d64').read_bytes()),load_address=0x1001,entry=0x1100,code_end=0x1100+len(core),native_host_RAM_limit=16384,video=[0x1800,0x3f40],ZP=[0x80,0x8d],CPU_test_scratch=[0x400,0x500],status=[0x3f0,0x400],SRAM_scratch={'bank0':[0,0x3fff],'bank1':[0],'bank3':[0,0x3fff]},native_TED_color_codes=codes,sprite_visible_canvas=[16,16],hardware_record=[24,21],sprite_upload_bytes=len(pixels),sprite_color_indices=list(range(121)),opaque_black_index=0,transparent_index=255,SID_frequency_register=round(440*16777216/985248),SID_clock_Hz=985248,uses_mainram_or_packedcache=False,new_generic_artwork=True,game_assets_imported=False,emulator_runs=0)
    meta['source_sha256']={str(p.relative_to(HERE)):sha(p.read_bytes())for p in [HERE/'build.py',HERE/'d64.py',HERE/'examples/demo.asm',HERE/'include/plus64.inc']}
    (out/'BUILD.json').write_text(json.dumps(meta,indent=2)+'\n');print(json.dumps({k:meta[k]for k in ['PRG_bytes','code_end','PRG_sha256']},indent=2));return meta
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--out',type=Path,required=True);p.add_argument('--xa',default=os.environ.get('XA')or shutil.which('xa'));a=p.parse_args()
    if not a.xa:p.error('xa not found; install xa6502, set XA or use --xa /path/to/xa')
    build(a.out.resolve(),a.xa)
