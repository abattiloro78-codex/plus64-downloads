; Data labels are defined at the end of material-example.asm.
