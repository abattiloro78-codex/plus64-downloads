#!/usr/bin/env python3
"""Optional maintained-checkout verification; does not edit game or runtime."""
from pathlib import Path
import argparse,sys,json
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2]
sys.path[:0]=[str(ROOT/'tools-game/sphere-colors')]
from verify_game import Session,at,modules

def run(vice,runtime,out):
 out.mkdir(parents=True,exist_ok=False);rows=[];disk=(HERE/'prebuilt/MATERIAL.d64').read_bytes();mask=(HERE/'prebuilt/mask.bin').read_bytes()
 for model in ['c16','plus4']:
  s=Session(vice,runtime,out/model,model,'sdk',disk)
  try:
   s.send(['resourceset "Plus64PackedCache" "1"','resourceset "Plus64LeftMCM" "1"','resourceset "Plus64MixedSprites" "1"']);at(s,0x1100);at(s,0x1135);seen=set();dirs=set()
   for i in range(500):
    r=s.payload();assert r[0x3f0]==1,(model,r[0x3f0]);assert r[0x3f1]<=120 and r[0x3f2]in (1,3,9);seen.add(r[0x3f1]);dirs.add(r[0x3f2]);assert r[0xc200:0xc240]==bytes([0])+bytes(reversed(mask));assert r[0xc240:0xc246]==bytes([0,0,1,1,1,0xa5])
    if i in [128,256,480]:s.capture('frame-'+str(i))
    s.send(['g'])
   assert seen==set(range(121)) and dirs=={1,3,9};s.capture('final');p=modules(out/model/'final.vsf')['PLUS64']['payload'];assert p[79]==17;assert p[72:78]==bytes([1])*6
   rows.append(dict(model=model,actual_frames=500,all121_highlights_observed=True,directions=sorted(dirs),native_CPU_TED_16K=True,cache_alias_cartridge_bank2_exact=True,source_mask_and_metadata_exact=True));print('PASS',model,flush=True)
  finally:s.close()
 proof=dict(status='PASS-native16K-material-example-two-hosts',rows=rows,guest_RAM_bytes=81920,extra_sprite_RAM=0,Windows_runs=0,physical_runs=0);(out/'PROOF.json').write_text(json.dumps(proof,indent=2)+'\n')
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--vice',type=Path,required=True);p.add_argument('--runtime',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args();run(a.vice.resolve(),a.runtime.resolve(),a.out.resolve())
