# Validation of the current material sample

`prebuilt/BUILD.json` records the assembled PRG/D64 and its memory boundaries.
The PRG is921 bytes, loads at1001 hex, and its code/data end at1398 hex.
`RAM_total=81920` describes the platform budget, not an allocation made by
this sample. Its existing sprite-port storage is one1 KiB cartridge-bank2
cache reservation within that budget.

The retained checks are:

- `qa-render-001/PROOF.json`:363 colour/direction combinations of the actual
  maintained `plus64_sprite.c`,182952 pixel cases,124872 occupied cases.
  Mask alpha is exact, source backing is read-only and colour0 is opaque.
- `qa-native-001/PROOF.json`:500 original loop boundaries on C16 and500 on
  Plus/4, with no state/code assignments after the normal initial entry.
  Both observe all121 selected highlights and directions1,3,9. The uploaded
  source mask and validity metadata are byte-exact in the native sprite
  alias of cartridge bank2.

The native test uses `build/native/20261114-144559-a631ef/source/src/xplus4`.
This identifies the tested software build, not a hardware test. There were
zero native Windows and physical runs for this new SDK sample.

In the maintained development checkout, repeat with new output paths:

```sh
python3 docs/developers/sdk-current/build_material.py --xa cloud/native/deps/root/usr/bin/xa --out docs/developers/sdk-current/build-new
python3 docs/developers/sdk-current/verify_material.py --out docs/developers/sdk-current/qa-render-new
python3 docs/developers/sdk-current/verify_native.py --vice build/native/20261114-144559-a631ef/source/src/xplus4 --runtime runtime --out docs/developers/sdk-current/qa-native-new
```

The first command is standalone apart from xa6502. The two validators use
the maintained checkout's C source/compiler or read-only emulator harness;
they are not prerequisites for building or running the SDK example. The
validators check `prebuilt/` inputs. Copy or rebuild a reviewed new sample
there deliberately before changing that qualification input.

Only proof JSON and selected preview PNG files need distribution. Raw QA
snapshots, audio and monitor traces are retained in the workspace as evidence
and are not required in an end-user SDK ZIP.
