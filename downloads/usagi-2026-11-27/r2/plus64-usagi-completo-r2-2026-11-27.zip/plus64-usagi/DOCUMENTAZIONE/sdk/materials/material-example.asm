; Current RAM80 native16K material example, xa6502 syntax.
; Requires -plus64packedcache -plus64leftmcm -plus64mixedsprites.
; Owns cartridge bank2 offset0000..03FF through the sprite port.
#include "plus64.inc"
#include "palette_tables.inc"
*=$1100
colour=$80
direction_index=$81
frame=$82
ptr=$83
ptrhi=$84
ptr2=$85
ptr2hi=$86
pages=$87
STATUS=$03f0
entry
 sei
 cld
 ldx #$ff
 txs
 lda #0
 sta P64_SPR_ENABLE
 sta TED_IRQ_MASK
 sta TED_SOUND_VOLUME
 sta colour
 sta direction_index
 sta frame
 sta STATUS
 lda P64_SRAM_SIG_LO
 cmp #$64
 bne incompatible
 lda P64_SRAM_SIG_HI
 cmp #P64_SRAM_PROTOCOL
 bne incompatible
 jsr video_init
 jsr upload_mask
 lda #1
 sta STATUS
 jsr publish
main
 jsr wait_frame
 inc frame
 lda frame
 and #3
 bne colour_done
 inc colour
 lda colour
 cmp #121
 bcc colour_done
 lda #0
 sta colour
colour_done
 lda frame
 and #127
 bne direction_done
 inc direction_index
 lda direction_index
 cmp #3
 bcc direction_done
 lda #0
 sta direction_index
direction_done
 jsr publish
 jmp main
incompatible
 lda #$ff
 sta STATUS
failed
 jmp failed
wait_frame
 lda TED_RASTER_LO
 cmp #240
 beq wait_frame
wait240
 lda TED_RASTER_LO
 cmp #240
 bne wait240
 rts
upload_mask
 lda #0
 sta P64_SPR_RAW8
 sta P64_SPR_EXPAND_X
 sta P64_SPR_EXPAND_Y
 sta P64_LAYER_FLAGS
 sta P64_SPR_ADDR_LO
 lda #2
 sta P64_SPR_ADDR_HI
 ldx #0
mask_copy
 lda inverse_mask,x
 sta P64_SPR_DATA
 inx
 cpx #64
 bne mask_copy
 ; Metadata240=shift0,241=HIRES0,242..244=fallback ink1,245=validA5.
 lda #0
 sta P64_SPR_DATA
 sta P64_SPR_DATA
 lda #1
 sta P64_SPR_DATA
 sta P64_SPR_DATA
 sta P64_SPR_DATA
 lda #$a5
 sta P64_SPR_DATA
 rts
publish
 lda #0
 sta P64_SPR_ENABLE
 sta P64_SPR_DESC+2
 sta P64_SPR_DESC+4
 sta P64_SPR_DESC+5
 lda #148
 sta P64_SPR_DESC
 lda #90
 sta P64_SPR_DESC+1
 lda colour
 sta STATUS+1
 ora #P64_MATERIAL_BIT
 sta P64_SPR_DESC+3
 ldx direction_index
 lda directions,x
 sta P64_LIGHT_01
 sta STATUS+2
 lda frame
 sta STATUS+3
 lda #1
 sta P64_SPR_ENABLE
 rts
directions
 .byt P64_LIGHT_N,P64_LIGHT_E,P64_LIGHT_FRONT
video_init
 lda #$3b
 sta TED_CTRL1
 lda #$18
 sta TED_CTRL2
 lda TED_BITMAP_BASE
 and #$c3
 ora #8
 sta TED_BITMAP_BASE
 lda #$18
 sta TED_SCREEN_BASE
 lda #0
 sta TED_BACKGROUND
 sta TED_BACKGROUND3
 sta TED_BORDER
 sta ptr
 sta ptr2
 lda #$18
 sta ptrhi
 lda #$1c
 sta ptr2hi
 lda #4
 sta pages
 ldx #0
 ldy #0
attribute_loop
 lda palette_luma,x
 sta (ptr),y
 lda palette_chroma,x
 sta (ptr2),y
 inx
 cpx #121
 bcc palette_next
 ldx #0
palette_next
 iny
 bne attribute_loop
 inc ptrhi
 inc ptr2hi
 dec pages
 bne attribute_loop
 lda #0
 sta ptr
 lda #$20
 sta ptrhi
 ldx #31
 ldy #0
 lda #$55
bitmap_page
 sta (ptr),y
 iny
 bne bitmap_page
 inc ptrhi
 dex
 bne bitmap_page
bitmap_tail
 sta (ptr),y
 iny
 cpy #64
 bne bitmap_tail
 rts

inverse_mask
#include "mask_inverse.inc"
#include "palette_pixels.inc"
