 .byt $00,$00,$00,$00,$00,$ff,$00,$c0,$ff,$03,$f0,$ff,$0f,$f8,$ff,$1f
 .byt $fc,$ff,$3f,$fc,$ff,$3f,$fe,$ff,$7f,$fe,$ff,$7f,$fe,$ff,$7f,$ff
 .byt $ff,$ff,$fe,$ff,$7f,$fe,$ff,$7f,$fe,$ff,$7f,$fc,$ff,$3f,$fc,$ff
 .byt $3f,$f8,$ff,$1f,$f0,$ff,$0f,$c0,$ff,$03,$00,$ff,$00,$00,$00,$00
