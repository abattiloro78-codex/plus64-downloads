#!/usr/bin/env python3
"""Compile the maintained C renderer and check all121 colours/directions1,3,9."""
from pathlib import Path
import argparse,ctypes,json,subprocess
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2]
class Sprite(ctypes.Structure):
 _fields_=[('regs',ctypes.c_uint8*64),('ram',ctypes.POINTER(ctypes.c_uint8)),*[(n,ctypes.c_uint8)for n in ['collision','collision_only_formats','material_full_palette','diagonal_lighting','tile_lighting','front_mask_profile','light_directions','sparse_formats','extended_formats']]]
def run(out):
 out.mkdir(parents=True,exist_ok=False);so=out/'material.so';subprocess.run(['cc','-shared','-fPIC','-O2','-std=c99',str(ROOT/'vendor/vice-source/src/plus4/plus64_sprite.c'),'-o',str(so)],check=True);lib=ctypes.CDLL(str(so));lib.plus64_bind_ram.argtypes=[ctypes.POINTER(Sprite),ctypes.c_void_p];lib.plus64_set_extended_formats.argtypes=[ctypes.POINTER(Sprite),ctypes.c_int];lib.plus64_draw_masked_left_mcm.argtypes=[ctypes.POINTER(Sprite),ctypes.c_void_p,ctypes.c_void_p,ctypes.c_size_t,ctypes.c_int,ctypes.c_int,ctypes.c_void_p]
 p=Sprite();ram=bytearray(16384);mask=(HERE/'prebuilt/mask.bin').read_bytes();ram[0x200:0x240]=bytes([0])+bytes(reversed(mask));ram[0x240:0x246]=bytes([0,0,1,1,1,0xa5]);data=(ctypes.c_uint8*16384).from_buffer(ram);lib.plus64_bind_ram(ctypes.byref(p),data);assert lib.plus64_set_extended_formats(ctypes.byref(p),1)==0
 p.regs[0]=1;p.regs[16]=148;p.regs[17]=90;checked=0;opaque=0;before=bytes(ram)
 for direction,centre in [(1,(12,0)),(3,(23,10)),(9,(12,10))]:
  p.regs[9]=direction
  for colour in range(121):
   p.regs[19]=128|colour;frame=bytearray([255])*64000;alpha=bytearray(64000);pixels=(ctypes.c_uint8*64000).from_buffer(frame);a=(ctypes.c_uint8*64000).from_buffer(alpha);lib.plus64_draw_masked_left_mcm(ctypes.byref(p),pixels,a,320,1,1,None)
   for y in range(21):
    for x in range(24):
     i=(90+y)*320+148+x;occupied=bool(mask[y*3+x//8]&(128>>(x&7)));assert bool(alpha[i])==occupied
     if occupied:
      if not colour:expected=0
      else:
       luma=max(0,7-((x-centre[0])**2+(y-centre[1])**2)//40);luma=luma*((colour-1)//15)//7;expected=15*luma+1+(colour-1)%15
      assert frame[i]==expected,(direction,colour,x,y,frame[i],expected);opaque+=1
     checked+=1
   assert bytes(ram)==before
 proof=dict(status='PASS-121-colours-three-light-directions-actual-C-renderer',colour_direction_cases=363,pixel_cases=checked,opaque_pixel_cases=opaque,opaque_black_verified=True,original_mask_opacity_exact=True,read_only_source_backing=True,extra_emulated_RAM=0,physical_runs=0);(out/'PROOF.json').write_text(json.dumps(proof,indent=2)+'\n');print(proof)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);a=p.parse_args();run(a.out.resolve())
