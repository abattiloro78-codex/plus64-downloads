#!/usr/bin/env python3
"""Build the current native16K material sample, using Python3 and xa6502."""
from pathlib import Path
import argparse,hashlib,json,shutil,subprocess,sys
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'baseline'))
from d64 import pack
sha=lambda b:hashlib.sha256(b).hexdigest()
def emit(data):return '\n'.join(' .byt '+','.join(f'${v:02x}'for v in data[i:i+16])for i in range(0,len(data),16))+'\n'
def build(out,xa):
 out.mkdir(parents=True,exist_ok=False)
 codes=[0]+[16*(n//15)+n%15+1 for n in range(120)]
 luma=[((c>>4)&7)|(c&0x70)for c in codes];chroma=[((c&15)<<4)|(c&15)for c in codes]
 # A new generic ellipse; no game resource or commercial sprite is used.
 mask=bytearray(63)
 for y in range(21):
  for x in range(24):
   if (2*x-23)**2*100+(2*y-20)**2*144<=23**2*100:mask[3*y+x//8]|=128>>(x&7)
 inverse=bytes([0])+bytes(reversed(mask))
 (out/'mask.bin').write_bytes(mask);(out/'mask_inverse.inc').write_text(emit(inverse))
 (out/'palette_tables.inc').write_text('; Data labels are defined at the end of material-example.asm.\n')
 (out/'palette_pixels.inc').write_text('palette_luma\n'+emit(luma)+'palette_chroma\n'+emit(chroma))
 cmd=[xa,'-C','-I'+str(HERE/'include'),'-I'+str(out),'-o',str(out/'MATERIAL.bin'),'-l',str(out/'labels.txt'),str(HERE/'material-example.asm')]
 subprocess.run(cmd,check=True)
 core=(out/'MATERIAL.bin').read_bytes();assert 0x1100+len(core)<=0x1800
 prefix=bytearray(b'\x01\x10\x0c\x10\x0a\x00\x9e 4352\x00\x00\x00');prefix+=bytes(0x1100-(0x1001+len(prefix)-2));prg=bytes(prefix)+core
 disk=pack([('PLUS64 MATERIAL',prg)]);(out/'MATERIAL.prg').write_bytes(prg);(out/'MATERIAL.d64').write_bytes(disk)
 result=dict(status='PASS-material-example-assembly',PRG_bytes=len(prg),PRG_sha256=sha(prg),D64_sha256=sha(disk),entry=0x1100,code_end=0x1100+len(core),RAM_total=81920,CPU_TED_profile='native16K',sprite_backing='alias of cartridge bank2',sprite_reserved_offset=[0,1024],no_extra_payload_RAM=True,highlight_colours=list(range(121)),light_directions=[1,3,9],emulator_runs=0,physical_runs=0)
 result['source_sha256']={str(p.relative_to(HERE)):sha(p.read_bytes())for p in [HERE/'material-example.asm',HERE/'include/plus64.inc',HERE/'build_material.py',HERE/'baseline/d64.py']}
 (out/'BUILD.json').write_text(json.dumps(result,indent=2)+'\n');print(result)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);p.add_argument('--xa',default=shutil.which('xa'));a=p.parse_args()
 if not a.xa:p.error('Pass --xa /path/to/xa6502')
 build(a.out.resolve(),a.xa)
