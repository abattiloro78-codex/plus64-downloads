; RAM80 edition, same SDK 1.0 sample. SRAM protocol operand changes from 4 to 5.
; New generic SDK sample. Native16K, SRAM port, one raw8 sprite and SID.
; IRQs disabled. No KERNAL calls or disk I/O after SYS4352.
#include "plus64.inc"
#include "tables.inc"
*=$1100
px=$80
pxhi=$81
py=$82
controls=$83
playing=$84
cooldown=$85
frame=$86
ptr=$87
ptrhi=$88
ptr2=$89
ptr2hi=$8a
pages=$8b
keyrow=$8c
STATUS=$03f0

entry
 sei
 cld
 ldx #$ff
 txs
 lda #0
 sta P64_SPR_ENABLE
 sta TED_IRQ_MASK
 sta TED_SOUND_VOLUME
 ldx #15
clearstate
 sta $80,x
 sta STATUS,x
 dex
 bpl clearstate
 lda #$53
 sta STATUS
 lda #$44
 sta STATUS+1
 lda #$4b
 sta STATUS+2
 lda #1
 sta STATUS+3
 jsr memory_checks
 jsr video_init
 jsr sprite_upload
 jsr sid_init
 lda #148
 sta px
 lda #92
 sta py
 jsr publish
main
 jsr wait_frame
 inc frame
 jsr input
 jsr movement
 jsr sound
 jsr publish
 jmp main

wait_frame
 lda TED_RASTER_LO
 cmp #240
 beq wait_frame
wait240
 lda TED_RASTER_LO
 cmp #240
 bne wait240
 rts

memory_checks
 ldx #0
ram_write
 txa
 eor #$5a
 sta $0400,x
 inx
 bne ram_write
ram_read
 txa
 eor #$5a
 cmp $0400,x
 bne native_failed
 inx
 bne ram_read
 lda #1
 sta STATUS+6
 lda P64_SRAM_SIG_LO
 sta STATUS+4
 cmp #$64
 bne signature_failed
 lda P64_SRAM_SIG_HI
 sta STATUS+5
 cmp #5
 bne signature_failed
 ; Bank0 offset3FFF ->0000 must wrap in the SAME bank.
 lda #0
 sta P64_SRAM_BANK
 jsr last_address
 lda #$a6
 sta P64_SRAM_DATA
 lda #$59
 sta P64_SRAM_DATA
 lda #1
 sta P64_SRAM_BANK
 jsr zero_address
 lda #$3c
 sta P64_SRAM_DATA
 lda #0
 sta P64_SRAM_BANK
 jsr last_address
 lda P64_SRAM_DATA
 cmp #$a6
 bne sram_failed
 lda P64_SRAM_DATA
 cmp #$59
 bne sram_failed
 lda #1
 sta P64_SRAM_BANK
 jsr zero_address
 lda P64_SRAM_DATA
 cmp #$3c
 bne sram_failed
 ; Last address of the full64K SRAM is bank3 offset3FFF.
 lda #3
 sta P64_SRAM_BANK
 jsr last_address
 lda #$5a
 sta P64_SRAM_DATA
 lda #$c3
 sta P64_SRAM_DATA
 jsr last_address
 lda P64_SRAM_DATA
 cmp #$5a
 bne sram_failed
 lda P64_SRAM_DATA
 cmp #$c3
 bne sram_failed
 lda #1
 sta STATUS+7
 rts
native_failed
 lda #1
 jmp failed
signature_failed
 lda #2
 jmp failed
sram_failed
 lda #3
failed
 sta STATUS+8
 lda #$32
 sta TED_BORDER
failed_loop
 jmp failed_loop
last_address
 lda #$ff
 sta P64_SRAM_ADDR_LO
 lda #$3f
 sta P64_SRAM_ADDR_HI
 rts
zero_address
 lda #0
 sta P64_SRAM_ADDR_LO
 sta P64_SRAM_ADDR_HI
 rts

video_init
 lda #$3b
 sta TED_CTRL1
 lda #$18
 sta TED_CTRL2
 lda TED_BITMAP_BASE
 and #$c3
 ora #8
 sta TED_BITMAP_BASE
 lda #$18
 sta TED_SCREEN_BASE
 lda #0
 sta TED_BACKGROUND
 sta TED_BACKGROUND3
 sta TED_BORDER
 sta ptr
 sta ptr2
 lda #$18
 sta ptrhi
 lda #$1c
 sta ptr2hi
 lda #4
 sta pages
 ldx #0
 ldy #0
attribute_loop
 lda palette_luma,x
 sta (ptr),y
 lda palette_chroma,x
 sta (ptr2),y
 inx
 cpx #121
 bcc palette_next
 ldx #0
palette_next
 iny
 bne attribute_loop
 inc ptrhi
 inc ptr2hi
 dec pages
 bne attribute_loop
 lda #0
 sta ptr
 lda #$20
 sta ptrhi
 ldx #31
 ldy #0
 lda #$55
bitmap_page
 sta (ptr),y
 iny
 bne bitmap_page
 inc ptrhi
 dex
 bne bitmap_page
bitmap_tail
 sta (ptr),y
 iny
 cpy #64
 bne bitmap_tail
 rts

sprite_upload
 lda #0
 sta P64_SPR_ADDR_LO
 sta P64_SPR_ADDR_HI
 sta P64_SPR_EXPAND_X
 sta P64_SPR_EXPAND_Y
 lda #1
 sta P64_SPR_RAW8
 ldx #0
sprite_first_page
 lda sprite_pixels,x
 sta P64_SPR_DATA
 inx
 bne sprite_first_page
sprite_tail
 lda sprite_pixels+256,x
 sta P64_SPR_DATA
 inx
 cpx #248
 bne sprite_tail
 rts

sid_init
 lda #0
 ldx #24
sid_clear
 sta P64_SID_BASE,x
 dex
 bpl sid_clear
 lda #$11
 sta P64_SID_AD
 lda #$61
 sta P64_SID_SR
 lda #8
 sta P64_SID_VOLUME
 rts
sound
 lda cooldown
 beq cooldown_done
 dec cooldown
cooldown_done
 lda controls
 and #16
 beq released
 lda playing
 bne sound_done
 lda cooldown
 bne sound_done
 lda #<BEEP_FREQ
 sta P64_SID_FREQ_LO
 lda #>BEEP_FREQ
 sta P64_SID_FREQ_HI
 lda #$11
 sta P64_SID_CTRL
 lda #1
 sta playing
 rts
released
 lda playing
 beq sound_done
 lda #$10
 sta P64_SID_CTRL
 lda #0
 sta playing
 lda #2
 sta cooldown
sound_done
 rts

; A is the active-low keyboard row mask, result pressed bits active-high.
read_row
 sta KEYBOARD_ROWS
 lda #$ff
 sta TED_KEY_LATCH
 lda TED_KEY_LATCH
 eor #$ff
 rts
input
 lda #$ff
 sta KEYBOARD_ROWS
 lda #$fd
 sta TED_KEY_LATCH
 lda TED_KEY_LATCH
 eor #$ff
 sta keyrow
 and #15
 sta controls
 lda keyrow
 and #$80
 beq no_joy_fire
 lda controls
 ora #16
 sta controls
no_joy_fire
 lda #$fd
 jsr read_row
 sta keyrow
 and #4
 beq no_a
 lda controls
 ora #4
 sta controls
no_a
 lda keyrow
 and #2
 beq no_w
 lda controls
 ora #1
 sta controls
no_w
 lda keyrow
 and #$20
 beq no_s
 lda controls
 ora #2
 sta controls
no_s
 lda #$fb
 jsr read_row
 and #4
 beq no_d
 lda controls
 ora #8
 sta controls
no_d
 lda #$bf
 jsr read_row
 sta keyrow
 and #1
 beq no_left
 lda controls
 ora #4
 sta controls
no_left
 lda keyrow
 and #8
 beq no_right
 lda controls
 ora #8
 sta controls
no_right
 lda #$df
 jsr read_row
 sta keyrow
 and #8
 beq no_up
 lda controls
 ora #1
 sta controls
no_up
 lda keyrow
 and #1
 beq no_down
 lda controls
 ora #2
 sta controls
no_down
 lda #$7f
 jsr read_row
 and #16
 beq no_space
 lda controls
 ora #16
 sta controls
no_space
 lda #$ff
 sta KEYBOARD_ROWS
 rts

movement
 lda controls
 and #4
 beq not_left
 lda pxhi
 bne move_left
 lda px
 beq not_left
move_left
 sec
 lda px
 sbc #2
 sta px
 lda pxhi
 sbc #0
 sta pxhi
not_left
 lda controls
 and #8
 beq not_right
 lda pxhi
 beq move_right
 lda px
 cmp #48
 bcs not_right
move_right
 clc
 lda px
 adc #2
 sta px
 lda pxhi
 adc #0
 sta pxhi
not_right
 lda controls
 and #1
 beq not_up
 lda py
 beq not_up
 sec
 sbc #2
 sta py
not_up
 lda controls
 and #2
 beq not_down
 lda py
 cmp #184
 bcs not_down
 clc
 adc #2
 sta py
not_down
 rts

publish
 ; Disable output while the multi-byte descriptor is edited.
 lda #0
 sta P64_SPR_ENABLE
 sta P64_SPR_DESC+3
 sta P64_SPR_DESC+4
 sta P64_SPR_DESC+5
 lda px
 sta P64_SPR_DESC
 sta STATUS+11
 lda pxhi
 and #1
 sta P64_SPR_DESC+2
 sta STATUS+12
 lda py
 sta P64_SPR_DESC+1
 sta STATUS+13
 lda #1
 sta P64_SPR_ENABLE
 lda frame
 sta STATUS+9
 lda controls
 sta STATUS+10
 lda playing
 sta STATUS+14
 lda P64_SPR_COLLISION
 sta STATUS+15
 rts

sprite_pixels
#include "sprite.inc"
code_end
