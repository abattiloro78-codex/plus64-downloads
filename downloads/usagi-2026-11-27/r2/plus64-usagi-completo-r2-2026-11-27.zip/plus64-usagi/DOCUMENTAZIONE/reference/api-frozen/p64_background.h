/* SPDX-License-Identifier: GPL-2.0-or-later */
/* Generic guest-owned P64B background material decoder. No game data. */
#ifndef P64_BACKGROUND_H
#define P64_BACKGROUND_H
#include <stddef.h>
#include <stdint.h>
#define P64B_SCANLINE_MAX 320u
#define P64B_BLOB_MAX 65535u
#define P64B_FORMAT_ERROR (-1)
#define P64B_CONTEXT_ERROR (-2)
#define P64B_SOURCE_ERROR (-3)
/* Immutable source facts, before any material/sky pass or actor composition. */
typedef struct p64b_source_s {
    uint8_t pair, glyph, ink, native_colour;
} p64b_source_t;
/* Return1 for an available original world pixel,0 otherwise. For source-ranked
 * runs the callback must also resolve the offscreen prefix of the same field.
 * Legacy opcode3 requires an offscreen source prefix; viewport-safe opcode6
 * never does. It may reconstruct from guest glyph/tile data; a host world-image cache is
 * neither supplied nor required by this decoder. */
typedef int (*p64b_source_fn)(void *opaque,int32_t x,int32_t y,p64b_source_t *out);
typedef struct p64b_context_s {
    uint32_t world_width,world_height;
    int32_t world_x,world_y; /* source world position of output pixel0 */
    uint8_t scene;          /* guest-selected table key; no built-in IDs */
    p64b_source_fn source;
    void *opaque;
} p64b_context_t;
/* Structural validation, including every ID/payload/opcode/reference. Zero is
 * success; negative is malformed. No allocation or persistent parsed cache. */
int p64b_validate(const uint8_t *blob,size_t size);
/* Apply to an existing native-TED row (for example after older scenery passes).
 * Returns selected union pixel count or a negative error. Maximum320 output
 * pixels. Output line and selected must not overlap (invalid alias leaves both
 * unchanged). Malformed metadata/source leaves line unchanged and clears selected.
 * Only bounded transient stack state is used; blob/source remain unchanged. */
int p64b_apply_scanline(uint8_t *line,uint8_t *selected,size_t width,
                        const uint8_t *blob,size_t size,const p64b_context_t *ctx);
#endif
