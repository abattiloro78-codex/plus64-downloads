/* SPDX-License-Identifier: GPL-2.0-or-later */
#include "p64_background_native.h"
#include "p64_metadata.h"
#include <string.h>
static unsigned le16(const uint8_t *p){return(unsigned)p[0]|((unsigned)p[1]<<8);}
int p64b_ted_source_pixel(const p64_ted_row_t *r,const uint8_t bg[4],int native,p64b_source_t *out){
 if(!r||!bg||!out||!r->active||r->mode>4||r->ycounter>7)return 0;
 int64_t source=(int64_t)native-r->source_origin;
 if(native<r->clip_start||native>=r->clip_stop||source<0||source>=320)return 0;
 if(!r->vbuf||!r->cbuf||((r->mode==2||r->mode==3)?!r->bitmap:!r->font))return 0;
 unsigned cell=(unsigned)source/8,px=(unsigned)source&7,code=r->vbuf[cell],attr=r->cbuf[cell];
 unsigned glyph=code,bits,pair,colour;
 out->glyph=(uint8_t)glyph;out->ink=(uint8_t)(attr&127);
 if(r->mode==2||r->mode==3)bits=r->bitmap[((r->memptr+cell)*8u+r->ycounter)&8191u];
 else{
  unsigned fontcode=code;
  if(r->mode==4)fontcode&=63;
  else if(!r->reverse_mode)fontcode&=127;
  bits=r->font[fontcode*8u+r->ycounter];
  if(r->mode==0){
   if((attr&128)&&!r->cursor_visible)bits=0;
   if(!r->reverse_mode&&(code&128))bits^=255;
   if(r->cursor_visible&&r->cursor_cell==(int)cell)bits^=255;
  }
 }
 if(r->mode==1&&(attr&8)){
  pair=(bits>>(6-2*(px/2)))&3;
  colour=pair==0?(bg[0]&127):pair==1?(bg[1]&127):pair==2?(bg[2]&127):(attr&0x77);
 }else if(r->mode==3){
  pair=(bits>>(6-2*(px/2)))&3;
  colour=pair==0?(bg[0]&127):pair==1?((code>>4)|((attr&7)<<4)):pair==2?((code&15)|(attr&0x70)):(bg[1]&127);
 }else{
  pair=(bits&(128u>>px))?3:0;
  if(r->mode==2)colour=pair?((code>>4)|((attr&7)<<4)):((code&15)|(attr&0x70));
  else if(r->mode==4)colour=pair?(attr&127):(bg[code>>6]&127);
  else if(r->mode==1)colour=pair?(attr&0x77):(bg[0]&127);
  else colour=pair?(attr&127):(bg[0]&127);
 }
 out->pair=(uint8_t)pair;out->native_colour=(uint8_t)colour;return 1;
}
typedef struct {const p64_ted_row_t *row;const uint8_t *bg;int gx;unsigned camera;int y;} native_t;
static int native_source(void *opaque,int32_t x,int32_t y,p64b_source_t *out){
 native_t *s=(native_t*)opaque;if(y!=s->y)return 0;
 int64_t native=(int64_t)x-s->camera+s->gx;
 if(native<-2147483647LL||native>2147483647LL)return 0;
 return p64b_ted_source_pixel(s->row,s->bg,(int)native,out);
}
int p64b_native_scanline(uint8_t *line,size_t width,int y,int gx,uint8_t mask320[320],
                         const uint8_t main_ram[65536],const uint8_t aux[16384],unsigned at,
                         const p64_ted_row_t *row,const uint8_t bg[4],unsigned version){
 if(mask320)memset(mask320,0,320);
 if(version<P64B_NATIVE_CAPABILITY)return 0;
 if(!line||!main_ram||!row||!bg||at>65536-P64B_NATIVE_NODE_BYTES)return P64B_CONTEXT_ERROR;
 const uint8_t *n=main_ram+at;
 if(n[11]!=P64B_NATIVE_NODE_TYPE||n[2]>1||n[19]>1||n[21]||n[22]||n[23])return P64B_FORMAT_ERROR;
 if((n[19]==0&&n[20])||(n[19]==P64B_NATIVE_MODE_FILTER&&(!n[20]||(n[20]&224))))return P64B_FORMAT_ERROR;
 if((main_ram[le16(n+9)]&n[15])!=n[14])return 0;
 unsigned camera_at=le16(n+12);if(camera_at>65534)return P64B_CONTEXT_ERROR;
 unsigned worldwidth=le16(n+16),height=n[18];
 if(!worldwidth||!height)return P64B_CONTEXT_ERROR;
 if(!row->active||row->mode>4||y<0||(unsigned)y>=height)return 0;
 if((n[19]&P64B_NATIVE_MODE_FILTER)&&!(n[20]&(1u<<row->mode)))return 0;
 unsigned bank=n[2],address=le16(n+3),bytes=le16(n+5),capacity=bank?16384:65536;
 const uint8_t *ram=bank?aux:main_ram;
 if(!ram||address>capacity||bytes>capacity-address)return P64B_CONTEXT_ERROR;
 /* Only actual TED pixels have immutable source facts. Closed borders and
  * the fine-scroll gap stay under the native final border/blank machinery. */
 int64_t start=gx,stop=(int64_t)gx+320;
 if(start<0)start=0;
 if(start<row->source_origin)start=row->source_origin;
 if(start<row->clip_start)start=row->clip_start;
 if(stop>(int64_t)width)stop=(int64_t)width;
 if(stop>(int64_t)row->source_origin+320)stop=(int64_t)row->source_origin+320;
 if(stop>row->clip_stop)stop=row->clip_stop;
 if(start>=stop)return 0;
 native_t source={row,bg,gx,le16(main_ram+camera_at),y};
 p64b_context_t context={worldwidth,height,(int32_t)((int64_t)source.camera+start-gx),y,main_ram[le16(n+7)],native_source,&source};
 uint8_t selected[320];size_t count=(size_t)(stop-start);
 p64_metadata_view_t view;int opened=p64_metadata_open(ram+address,bytes,&view);
 if(opened<0){p64_metadata_close(&view);return opened;}
 int result=p64b_apply_scanline(line+(size_t)start,selected,count,view.bytes,view.size,&context);
 p64_metadata_close(&view);
 if(result<0)return result;
 if(mask320){
  int64_t local=start-gx;if(local<0||local+(int64_t)count>320)return P64B_CONTEXT_ERROR;
  memcpy(mask320+(size_t)local,selected,count);
 }
 return result;
}
