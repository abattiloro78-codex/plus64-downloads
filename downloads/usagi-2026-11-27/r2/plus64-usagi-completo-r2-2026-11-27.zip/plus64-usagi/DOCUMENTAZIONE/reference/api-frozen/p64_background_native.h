/* SPDX-License-Identifier: GPL-2.0-or-later */
/* Generic scenery22 guest configuration and immutable TED-row adapter. */
#ifndef P64_BACKGROUND_NATIVE_H
#define P64_BACKGROUND_NATIVE_H
#include "p64_background.h"
#include "plus64_overlay.h"
#define P64B_NATIVE_NODE_BYTES 24u
#define P64B_NATIVE_NODE_TYPE 11u
#define P64B_NATIVE_CAPABILITY 22u
#define P64B_NATIVE_MODE_FILTER 1u
/* Derive original pair/glyph/ink/native colour directly from source bits.
 * background_colours are FF15,FF16,FF17,FF18 native colour values. Matrix
 * glyph remains the original byte; only font addressing normalizes it. */
int p64b_ted_source_pixel(const p64_ted_row_t *row,
                          const uint8_t background_colours[4],int native_x,
                          p64b_source_t *out);
/* Node in physical MAIN: next16,blobbank8,blobaddr16,bloblen16,sceneaddr16,
 * gateaddr16,type11,cameraaddr16,gatevalue8,gatemask8,worldwidth16,
 * worldheight8,flags8,mode_mask8,reserved[3]0. Bank0=MAIN64K,1=AUX16K.
 * flags0 keeps legacy behavior and requires mode_mask0. Flag bit0 enables
 * MODE_FILTER with nonzero mode_mask bits0..4; other flag/mask bits invalid.
 * A filtered-out row is a no-op, leaving its native pixels unchanged.
 * camera is worldX of logical screen pixel0 at gx. logical_y is worldY.
 * No game addresses, source palette, constructors or scene IDs are built in.
 * Returns selected count or negative error; legacy/gated/blank rows are no-op.
 * mask320 may be NULL, otherwise receives logical screen selection. */
int p64b_native_scanline(uint8_t *line,size_t width,int logical_y,int gx,
                         uint8_t mask320[320],const uint8_t main_ram[65536],
                         const uint8_t auxiliary[16384],unsigned node_address,
                         const p64_ted_row_t *row,const uint8_t background_colours[4],
                         unsigned scenery_version);
#endif
