Current032data: BUILD.json, FRAMEID_BUILD.json, SPRITE_VM_BUILD.json, LANGUAGE_BUILD.json.
Copied COMPACT_SOURCE_BUILD/REPAIR_SOURCE_BUILD and componentdirectories are preserved source history from029/030/031, not current032codec assertions.
CPUproofs reside in api-audit/compact_runtime/FRAMEID032_*; native qualification is separate.
