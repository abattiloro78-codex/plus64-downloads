#include "plus64_overlay.h"
#include "p64_background_native.h"
#include <string.h>
#define P64_W 320
#define P64_H 200
uint8_t p64_ted_color(uint8_t index) {
    if (index == 0 || index > 120) return 0;
    /* 15 nonblack hues times 8 luminance levels. */
    return (uint8_t)((((unsigned)index - 1u) / 15u) * 16u
                   + ((((unsigned)index - 1u) % 15u) + 1u));
}
void p64_side_border_clip_scanline(uint8_t *line,size_t width,int y,int gx,
                                  unsigned profile,uint8_t flags,
                                  const p64_native_border_t *border) {
    if (!line || !border || profile<18u || !(flags&16u) ||
        y<0 || y>=P64_H || border->disabled) return;
    for (int x=0;x<P64_W;x++) {
        int64_t at=(int64_t)gx+x;
        if (at<0 || (uint64_t)at>=width) continue;
        if ((border->blank && !border->open_left) ||
            (!border->open_left && at<border->display_start) ||
            (!border->open_right && at>=border->display_stop))
            line[(size_t)at]=border->color;
    }
}
void p64_overlay_scanline(uint8_t *ted_line, size_t ted_width, int line,
                          int gfx_x, int gfx_y, const uint8_t *overlay,
                          const uint8_t *alpha) {
    int y = line - gfx_y;
    int x;
    if (!ted_line || !overlay || !alpha || y < 0 || y >= P64_H) return;
    for (x = 0; x < P64_W; x++) {
        int screen_x = gfx_x + x;
        size_t source = (size_t)y * P64_W + (size_t)x;
        if (screen_x >= 0 && (size_t)screen_x < ted_width && alpha[source]) {
            ted_line[screen_x] = p64_ted_color(overlay[source]);
        }
    }
}

void p64_ted_foreground_row(uint8_t foreground[320],const p64_ted_row_t *row) {
    if (!foreground) return;
    for (unsigned x=0;x<P64_W;x++) foreground[x]=0;
    if (!row || !row->active || row->mode>4u || row->ycounter>7u) return;
    if ((row->mode==2u || row->mode==3u) ? !row->bitmap :
        (!row->vbuf || !row->cbuf || !row->font)) return;
    for (int x=0;x<P64_W;x++) {
        int native=row->overlay_origin+x,source=native-row->source_origin;
        unsigned cell,px,bits,multi=0;
        if (native<row->clip_start || native>=row->clip_stop || source<0 || source>=P64_W) continue;
        cell=(unsigned)source/8u;px=(unsigned)source&7u;
        if (row->mode==2u || row->mode==3u) {
            unsigned at=((row->memptr+cell)*8u+row->ycounter)&0x1fffu;
            bits=row->bitmap[at];multi=row->mode==3u;
        } else {
            unsigned code=row->vbuf[cell],attr=row->cbuf[cell];
            if (row->mode==0u) {
                unsigned inverse=!row->reverse_mode && (code&128u);
                if (!row->reverse_mode) code&=127u;
                bits=(attr&128u) && !row->cursor_visible ? 0u : row->font[code*8u+row->ycounter];
                if (inverse) bits^=255u;
                if (row->cursor_visible && row->cursor_cell==(int)cell) bits^=255u;
            } else if (row->mode==1u) {
                if (!row->reverse_mode) code&=127u;
                bits=row->font[code*8u+row->ycounter];multi=(attr&8u)!=0;
            } else {
                bits=row->font[(code&63u)*8u+row->ycounter];
            }
        }
        /* Multicolour01 is a background pair,10/11 are foreground, matching
           the source priority convention independently of the ink's colour. */
        foreground[x]=(uint8_t)(multi ?
            ((bits>>(6u-2u*(px/2u)))&3u)>=2u : (bits&(128u>>px))!=0);
    }
}

void p64_overlay_scanline_priority(uint8_t *ted_line,size_t ted_width,int line,
                                  int gfx_x,int gfx_y,const uint8_t *overlay,
                                  const uint8_t *alpha,const uint8_t foreground[320],
                                  uint8_t behind_mask) {
    int y=line-gfx_y;
    if (!foreground || !behind_mask) {
        p64_overlay_scanline(ted_line,ted_width,line,gfx_x,gfx_y,overlay,alpha);
        return;
    }
    if (!ted_line || !overlay || !alpha || y<0 || y>=P64_H) return;
    for (int x=0;x<P64_W;x++) {
        int screen_x=gfx_x+x;
        size_t source=(size_t)y*P64_W+(size_t)x;
        unsigned visible=alpha[source],top=visible&(0u-visible);
        if (screen_x<0 || (size_t)screen_x>=ted_width || !visible) continue;
        if ((top&behind_mask) && foreground[x]) continue;
        ted_line[screen_x]=p64_ted_color(overlay[source]);
    }
}

static void p64_ui_scanline(uint8_t *line,size_t width,int y,int gx,
                            const uint8_t *ram,const uint8_t *n);

/* Conditional links and indexed tint materials are wholly guest-authored.
 * Tables contain compact colours0..120,255 means preserve the native pixel.
 * Bit6 selects16-entry dark/bright banks; bit7 limits the table to native hues0..7.
 * Low three bits choose diagonal depth; bit5 chooses frontal illumination. */
static unsigned material_next(const uint8_t *ram,const uint8_t *n) {
    unsigned next=(unsigned)n[0]|((unsigned)n[1]<<8);
    if(n[11]==6u) {
        unsigned p=(unsigned)n[4]|((unsigned)n[5]<<8);
        if((ram[p]&n[7])==n[6])next=(unsigned)n[2]|((unsigned)n[3]<<8);
    }
    return next;
}
/* An active conditional owner replaces earlier linked scene layers, while
 * its false branch keeps the existing owner intact. Traversal is bounded. */
static unsigned material_head(const uint8_t *ram,unsigned head,unsigned protect) {
    unsigned at=head,visible=1u;
    for(unsigned i=0;at&&i<32u;i++) {
        const uint8_t *n;unsigned next;
        if(at>65536u-12u)break;n=ram+at;next=(unsigned)n[0]|((unsigned)n[1]<<8);
        if(protect&&n[11]==8u) {
            unsigned control;
            if(at>65536u-24u)visible=0u;
            else {
                control=(unsigned)n[20]|((unsigned)n[21]<<8);
                if(control<3u||((ram[control]>>1)&7u)!=(n[12]&7u)||!ram[control-3u])visible=0u;
            }
        }
        if(n[11]==6u&&(n[8]&1u)&&material_next(ram,n)!=next)return material_next(ram,n);
        at=next;
    }
    return visible?head:0u;
}

/* All configuration, selectors and programs remain in guest MAIN/AUX.
 * Native source facts are refreshed for each row; prepared decoder work is
 * optional and explicitly bounded to the current frame. */
int p64_guest_material_scanline_work(uint8_t *line,size_t width,int y,int gx,
                               const uint8_t *ram,const uint8_t *aux,
                               const uint8_t *regs,const p64_ted_row_t *row,
                               const uint8_t background[4],unsigned version,p64b_frame_work_t *work) {
    unsigned head;int selected=0;
    if(version<22u||!line||!ram||!aux||!regs||!row||!background||
       !(regs[15]&1u)||y<0||y>=200)return 0;
    head=material_head(ram,(unsigned)regs[13]|((unsigned)regs[14]<<8),
                       (regs[15]&8u)?0u:1u);
    for(unsigned count=0;head&&count<32u;count++) {
        if(head>65536u-12u)break;
        const uint8_t *node=ram+head;
        unsigned next=material_next(ram,node);
        if(node[11]==11u) {
            int result=p64b_native_scanline_work(line,width,y,gx,NULL,ram,aux,head,
                                            row,background,version,work);
            if(result>0)selected+=result;
        }
        head=next;
    }
    return selected;
}

int p64_guest_material_scanline(uint8_t *line,size_t width,int y,int gx,
                               const uint8_t *ram,const uint8_t *aux,
                               const uint8_t *regs,const p64_ted_row_t *row,
                               const uint8_t background[4],unsigned version) {
 return p64_guest_material_scanline_work(line,width,y,gx,ram,aux,regs,row,background,version,NULL);
}

static int native_text_font_active(const uint8_t *ram,const uint8_t *n) {
    unsigned control=(unsigned)n[20]|((unsigned)n[21]<<8);
    unsigned bank=(ram[control]>>1)&7u,font=((unsigned)n[13]<<8)+bank*2048u;
    unsigned bytes=((n[12]>>3)+1u)*8u;
    if(bank!=(n[12]&7u)||font>65536u-bytes)return 0;
    /* Puzzle fragments can begin with a blank byte or an empty glyph. */
    for(unsigned i=0;i<bytes;i++)if(ram[font+i])return 1;
    return 0;
}
static const uint8_t *native_text_node(const uint8_t *ram,unsigned head) {
    for(unsigned i=0;head&&i<32u;i++) {
        const uint8_t *n;
        if(head>65536u-12u)return 0;n=ram+head;
        if(n[11]==8u&&head<=65536u-24u) {
            if(native_text_font_active(ram,n))return n;
        }
        head=(unsigned)n[0]|((unsigned)n[1]<<8);
    }
    return 0;
}
static int native_text_cell(const uint8_t *ram,const uint8_t *n,unsigned x,unsigned y) {
    unsigned cell=(y/8u)*40u+x/8u;
    unsigned chars=(unsigned)n[14]|((unsigned)n[15]<<8),attrs=(unsigned)n[16]|((unsigned)n[17]<<8);
    unsigned glyph,ink=n[22]>>4;
    if(chars+cell>=65536u||attrs+cell>=65536u||(ram[attrs+cell]&15u)!=ink)return 0;
    glyph=ram[chars+cell];if(glyph<=(n[12]>>3))return 1;if(glyph!=n[23])return 0;
    /* Include the complete one-cell frame, including sides and corners.
     * Neighbouring furniture without a native text cell keeps its lighting. */
    for(int dy=-1;dy<=1;dy++)for(int dx=-1;dx<=1;dx++) {
        int cx=(int)(cell%40u)+dx,cy=(int)(cell/40u)+dy;
        unsigned adjacent;
        if(cx<0||cx>=40||cy<0||cy>=25)continue;
        adjacent=(unsigned)(cy*40+cx);
        if(chars+adjacent<65536u&&attrs+adjacent<65536u&&
           ram[chars+adjacent]<=(n[12]>>3)&&(ram[attrs+adjacent]&15u)==ink)return 1;
    }
    return 0;
}
static void tint_scanline(uint8_t *line,size_t width,int y,int gx,
                          const uint8_t *ram,const uint8_t *n,unsigned version) {
    unsigned x0=n[2]*8u,y0=n[3]*8u,w=n[4]*8u,h=n[5]*8u;
    unsigned ellipse=version>=19u && (n[10]&8u);
    uint64_t ww,hh,vertical;
    if(w<2u||h<2u||x0+w>320u||y0+h>200u||(unsigned)y<y0||(unsigned)y>=y0+h)return;
    if(n[11]==7u) {
        unsigned p=(unsigned)n[12]|((unsigned)n[13]<<8),v=ram[p]&n[14];
        unsigned q=(unsigned)n[17]|((unsigned)n[18]<<8);
        if((v!=n[15]&&v!=n[16])||ram[q]!=n[19])return;
    }
    ww=(uint64_t)w*w;hh=(uint64_t)h*h;vertical=0;
    if(ellipse) {
        int64_t dy=2*((int64_t)y-y0)+1-(int64_t)h;
        vertical=(uint64_t)(dy*dy)*ww;
    }
    for(unsigned x=x0;x<x0+w;x++) {
        int screen=gx+(int)x,level;unsigned old,key,table,c,relative,depth=n[10]&7u,shade;
        if(screen<0||(size_t)screen>=width)continue;
        old=line[screen];key=old&15u;
        if(!key||((n[10]&128u)&&key>=8u))continue;
        if(ellipse) {
            int64_t dx=2*(int64_t)(x-x0)+1-(int64_t)w;
            if((uint64_t)(dx*dx)*hh+vertical>ww*hh)continue;
        }
        if(n[10]&64u) {
            unsigned bank=(old>>4)>=5u?8u:6u;
            table=(unsigned)n[bank]|((unsigned)n[bank+1u]<<8);
        } else {table=(unsigned)n[key<8u?6:8]|((unsigned)n[key<8u?7:9]<<8);key&=7u;}
        if(!table||table+key>=65536u)continue;
        c=ram[table+key];if(c==255u)continue;relative=c&128u;c&=127u;if(c>120u)continue;
        if(!c){line[screen]=0;continue;}
        if(n[10]&32u) {
            unsigned dx=x-x0,dy=(unsigned)y-y0;
            dx=dx>w/2u?dx-w/2u:w/2u-dx;dy=dy>h/2u?dy-h/2u:h/2u-dy;
            dx=dx*256u/w;dy=dy*256u/h;
            shade=depth*(dx*dx+dy*dy)/32768u;
        } else shade=depth*((x-x0)*(h-1u)+((unsigned)y-y0)*(w-1u))/(2u*(w-1u)*(h-1u));
        if(relative&&shade>2u)shade=2u;
        level=(int)((c-1u)/15u)-(int)shade+(relative?(int)(old>>4)-7:0);if(level<0)level=0;
        line[screen]=(uint8_t)((level<<4)|((c-1u)%15u+1u));
    }
}

/* Scenery20: a guest palette sampled vertically over explicit local pixels.
 * Native source-key matching is independent of font/fine-scroll geometry. */
static void palette_ramp_scanline(uint8_t *line,size_t width,int y,int gx,
                                  const uint8_t *ram,const uint8_t *n) {
    unsigned x0=n[2]*8u,y0=n[3]*8u,w=n[4]*8u,h=n[5]*8u;
    unsigned palette=(unsigned)n[6]|((unsigned)n[7]<<8),count=n[8];
    unsigned start=n[12],span=n[13],local,index,c;
    if(!w||!h||x0+w>320u||y0+h>200u||(unsigned)y<y0||
       (unsigned)y>=y0+h||!count||count>32u||palette+count>65536u||
       n[9]>127u||n[10]>127u||!span||start+span>h||
       (n[14]&254u)||n[15])return;
    local=(unsigned)y-y0;
    if(local<start)return;
    if(local>=start+span) {
        if(!(n[14]&1u))return;
        index=count-1u;
    } else index=(local-start)*count/span;
    c=ram[palette+index];if(c==255u||c>120u)return;
    for(unsigned x=x0;x<x0+w;x++) {
        int screen=gx+(int)x;
        if(screen<0||(size_t)screen>=width)continue;
        if((line[screen]&n[10])==(n[9]&n[10]))line[screen]=p64_ted_color((uint8_t)c);
    }
}

/* Stateless, bounded traversal of guest-owned descriptors. No private RAM
 * pool or game-specific addresses, glyphs, room IDs or colour substitutions. */
static void p64_light_scanline_unshifted(uint8_t *line, size_t width, int y, int gx,
                         const uint8_t *ram, const uint8_t *regs,unsigned version) {
    unsigned head, count;const uint8_t *text;uint8_t native[320];
    if (!line || !ram || !regs || !(regs[15]&1u) || y<0 || y>=200) return;
    head=material_head(ram,(unsigned)regs[13]|((unsigned)regs[14]<<8),(regs[15]&8u)?0u:1u);
    text=(regs[15]&8u)?0:native_text_node(ram,head);
    if(text)for(unsigned x=0;x<320u;x++){int px=gx+(int)x;native[x]=px>=0&&(size_t)px<width?line[px]:0;}
    for (count=0;head && count<32;count++) {
        const uint8_t *n;
        unsigned next, x0,y0,w,h,dx,dy;
        int lx,ly;
        if (head>65536u-12u) return;
        n=ram+head;next=material_next(ram,n);
        if(n[11]==6u){head=next;continue;}
        if(n[11]==9u){
            if(version>=20u&&head<=65536u-16u)palette_ramp_scanline(line,width,y,gx,ram,n);
            head=next;continue;
        }
        if(n[11]==5u||n[11]==7u){
            if(n[11]!=7u||head<=65536u-20u)tint_scanline(line,width,y,gx,ram,n,version);
            head=next;continue;
        }
        if(n[11]==3u){p64_ui_scanline(line,width,y,gx,ram,n);head=next;continue;}
        x0=n[2]*8u;y0=n[3]*8u;w=n[4]*8u;h=n[5]*8u;
        if (!w || !h || x0+w>320u || y0+h>200u ||
            n[6]>n[8] || n[7]>n[9] || n[8]>=w || n[9]>=h ||
            n[10]>120 || n[11]>1 || (n[11] && head>65536u-20u)) { head=next;continue; }
        ly=y-(int)y0;
        if (ly<0 || (unsigned)ly>=h) {head=next;continue;}
        dx=n[8]-n[6];dy=n[9]-n[7];if(!dx)dx=1;if(!dy)dy=1;
        for (lx=0;(unsigned)lx<w;lx++) {
            int screen=gx+(int)x0+lx, level, offset;
            unsigned px,py,shade;uint8_t old;
            if(screen<0 || (size_t)screen>=width)continue;
            old=line[screen];
            if(!(old&15u))continue;
            if (n[11]) {
                unsigned font=(unsigned)n[12]|((unsigned)n[13]<<8);
                unsigned chars=(unsigned)n[14]|((unsigned)n[15]<<8);
                unsigned attrs=(unsigned)n[16]|((unsigned)n[17]<<8);
                unsigned expected=(unsigned)n[18]|((unsigned)n[19]<<8);
                unsigned cell=(y0/8u+(unsigned)ly/8u)*40u+x0/8u+(unsigned)lx/8u;
                unsigned tile=(unsigned)ly/8u*n[4]+(unsigned)lx/8u;
                unsigned glyph,ink,bits,fx=(unsigned)lx&7u;
                if(chars+cell>=65536u || attrs+cell>=65536u || expected+tile>=65536u)continue;
                glyph=ram[chars+cell];ink=ram[attrs+cell];
                if(glyph!=ram[expected+tile] || font+glyph*8u+((unsigned)ly&7u)>=65536u)continue;
                bits=ram[font+glyph*8u+((unsigned)ly&7u)];
                if(ink&8u) {if(!((bits>>(6u-2u*(fx/2u)))&3u))continue;}
                else if(!(bits&(128u>>fx)))continue;
            } else if(old==p64_ted_color(n[10]))continue;
            px=lx<(int)n[6]?0u:(unsigned)(lx-n[6]);
            py=ly<(int)n[7]?0u:(unsigned)(ly-n[7]);
            if(px>dx)px=dx;if(py>dy)py=dy;
            shade=5u*(px*dy+py*dx)/(2u*dx*dy);
            offset=2-(int)shade;level=(old>>4)+offset;
            if(level<0)level=0;if(level>7)level=7;
            line[screen]=(uint8_t)((level<<4)|(old&15u));
        }
        head=next;
    }
    if(text)for(unsigned x=0;x<320u;x++) {
        int px=gx+(int)x;
        if(px>=0&&(size_t)px<width&&native_text_cell(ram,text,x,(unsigned)y))line[px]=native[x];
    }

}

/* Scenery22 external phase owner. As with other linked materials, owners
 * live inside the active branch selected by material_head; an earlier node
 * replaced by a conditional owner is intentionally not visible here. */
static int light_phase(const uint8_t *ram,const uint8_t *regs,unsigned *phase) {
    unsigned head=material_head(ram,(unsigned)regs[13]|((unsigned)regs[14]<<8),
                               (regs[15]&8u)?0u:1u);
    for(unsigned count=0;head&&count<32u;count++) {
        if(head>65536u-12u)break;
        const uint8_t *n=ram+head;unsigned next=material_next(ram,n);
        if(n[11]==12u&&head<=65536u-16u&&!n[8]&&!n[9]&&!n[10]&&
           !n[12]&&!n[13]&&!n[14]&&!n[15]) {
            unsigned p=(unsigned)n[2]|((unsigned)n[3]<<8);
            unsigned gate=(unsigned)n[4]|((unsigned)n[5]<<8);
            if(p<320u&&(ram[gate]&n[7])==n[6]){*phase=p;return 1;}
        }
        head=next;
    }
    return 0;
}

void p64_light_scanline_versioned(uint8_t *line,size_t width,int y,int gx,
                                const uint8_t *ram,const uint8_t *regs,unsigned version) {
    unsigned phase=0u;
    if(version>=22u&&line&&ram&&regs&&(regs[15]&1u)&&y>=0&&y<200&&
       light_phase(ram,regs,&phase)&&phase) {
        uint8_t temporary[320];
        for(unsigned x=0;x<320u;x++) {
            int64_t at=(int64_t)gx+x;
            temporary[x]=at>=0&&(uint64_t)at<width?line[(size_t)at]:0u;
        }
        /* Two disjoint pieces of one320-pixel period, with unchanged C21
         * material equations and no write to the physical side borders. */
        p64_light_scanline_unshifted(temporary,320u,y,-(int)phase,ram,regs,version);
        p64_light_scanline_unshifted(temporary,320u,y,320-(int)phase,ram,regs,version);
        for(unsigned x=0;x<320u;x++) {
            int64_t at=(int64_t)gx+x;
            if(at>=0&&(uint64_t)at<width)line[(size_t)at]=temporary[x];
        }
        return;
    }
    p64_light_scanline_unshifted(line,width,y,gx,ram,regs,version);
}

/* Preserve the original six-argument C entry point and pre-19 behaviour. */
void p64_light_scanline(uint8_t *line,size_t width,int y,int gx,
                         const uint8_t *ram,const uint8_t *regs) {
    p64_light_scanline_versioned(line,width,y,gx,ram,regs,18u);
}

/* Lossless row-RLE image stream in guest RAM. Segments: nextLE16,length8,
 * payload. Image: widthLE16,heightLE16; bands: repeat8,token_count8,tokens.
 * Token: luminance in bits7..5, run length minus1 in bits4..0. */
typedef struct {
    const uint8_t *ram;
    unsigned head,at,left,hops;
} p64_scene_reader;
static int scene_byte(p64_scene_reader *r,unsigned *value) {
    if(!r->left) {
        unsigned n=r->head,len;
        if(!n || n>65536u-3u || r->hops++>=64u)return -1;
        len=r->ram[n+2u];
        if(!len || n+3u+len>65536u)return -1;
        r->head=(unsigned)r->ram[n]|((unsigned)r->ram[n+1u]<<8);
        r->at=n+3u;r->left=len;
    }
    *value=r->ram[r->at++];r->left--;return 0;
}

/* Anchors follow the actual native matrix and fine-scroll origin. Decode a
 * complete node before changing any output: a malformed later record must
 * not leave a partial tint or occluder behind. */
int p64_front_layer_scanline(uint8_t mask[320],uint8_t *line,size_t width,
                            int y,int gx,const uint8_t *ram,const uint8_t *regs,
                            const p64_ted_row_t *row,const uint8_t *chars,
                            unsigned version) {
    unsigned head,active=0u,native_ready=0u;
    uint8_t native[320];
    if(!mask)return 0;
    for(unsigned x=0;x<320u;x++)mask[x]=0;
    if(version<21u||!line||!ram||!regs||!row||!chars||!width||
       !(regs[15]&1u)||y<0||y>=200||!row->active||row->mode!=1u||
       row->ycounter>7u||!row->vbuf||!row->cbuf||!row->font)return 0;
    head=material_head(ram,(unsigned)regs[13]|((unsigned)regs[14]<<8),
                       (regs[15]&8u)?0u:1u);
    for(unsigned node=0;head&&node<32u;node++) {
        const uint8_t *n;unsigned next,column=40u,pixel_width,base_level,hue;
        uint8_t rectangles[16][6];int valid=1;int64_t anchor_x;
        if(head>65536u-12u)break;
        n=ram+head;next=material_next(ram,n);
        if(n[11]!=10u||head>65536u-16u){head=next;continue;}
        if(n[2]==n[3]||n[4]>=25u||!n[5]||n[5]>=40u||
           !n[8]||n[8]>16u||n[9]>7u||!n[10]||n[10]>120u||
           n[12]>=n[13]||n[13]>200u||!n[14]||n[14]>15u||n[15]) {
            head=next;continue;
        }
        base_level=((unsigned)n[10]-1u)/15u;
        hue=((unsigned)n[10]-1u)%15u+1u;
        if(n[9]>base_level){head=next;continue;}
        pixel_width=((unsigned)n[5]+1u)*8u;
        for(unsigned x=0;x<40u;x++)
            if(chars[(unsigned)n[4]*40u+x]==n[2]){column=x;break;}
        if(column<40u)anchor_x=(int64_t)column*8;
        else {
            for(unsigned x=0;x<40u;x++)
                if(chars[(unsigned)n[4]*40u+x]==n[3]){column=x;break;}
            if(column==40u){head=next;continue;}
            anchor_x=((int64_t)column-(int64_t)n[5])*8;
        }
        anchor_x+=(int64_t)row->source_origin-(int64_t)row->overlay_origin;
        {
            p64_scene_reader stream={ram,(unsigned)n[6]|((unsigned)n[7]<<8),0,0,0};
            for(unsigned i=0;i<n[8]&&valid;i++) {
                unsigned relative_x;
                for(unsigned field=0;field<6u;field++) {
                    unsigned value;
                    if(scene_byte(&stream,&value)){valid=0;break;}
                    rectangles[i][field]=(uint8_t)value;
                }
                if(!valid)break;
                relative_x=(unsigned)rectangles[i][0]|((unsigned)rectangles[i][1]<<8);
                if(!rectangles[i][3]||!rectangles[i][4]||rectangles[i][5]||
                   relative_x+rectangles[i][3]>pixel_width||
                   (unsigned)rectangles[i][2]+rectangles[i][4]>200u)valid=0;
            }
        }
        if(!valid){head=next;continue;}
        active=1u;
        if(!native_ready){p64_ted_foreground_row(native,row);native_ready=1u;}
        for(unsigned x=0;x<320u;x++) {
            int64_t screen=(int64_t)gx+x,local=(int64_t)x-anchor_x;
            if(screen<0||(uint64_t)screen>=width)continue;
            if(local>=0&&(uint64_t)local<pixel_width&&
               (unsigned)y>=n[12]&&(unsigned)y<n[13]&&
               (line[(size_t)screen]&15u)==n[14]) {
                unsigned shade=(unsigned)local*((unsigned)n[9]+1u)/pixel_width;
                if(shade>n[9])shade=n[9];
                line[(size_t)screen]=(uint8_t)(((base_level-shade)<<4)|hue);
            }
            if(!native[x])continue;
            for(unsigned i=0;i<n[8];i++) {
                const uint8_t *r=rectangles[i];
                unsigned relative_x=(unsigned)r[0]|((unsigned)r[1]<<8);
                int64_t left=anchor_x+relative_x;
                if((int64_t)x>=left&&(int64_t)x<left+r[3]&&
                   (unsigned)y>=r[2]&&(unsigned)y<(unsigned)r[2]+r[4]) {
                    mask[x]=1u;break;
                }
            }
        }
        head=next;
    }
    return active?1:0;
}
/* Compact guest rectangle grids; native glyphs and other hues are retained. */
static void p64_ui_scanline(uint8_t *line,size_t width,int y,int gx,
                            const uint8_t *ram,const uint8_t *n) {
    p64_scene_reader r={ram,(unsigned)n[6]|((unsigned)n[7]<<8),0,0,0};
    unsigned count=n[8],bevel=n[9],hue1=n[10]&15u,hue2=n[10]>>4,instances=0;
    uint8_t native[320];
    if(count>32u||!bevel||bevel>8u||!n[4]||!n[5]||n[2]+n[4]>40u||n[3]+n[5]>25u||y<(int)n[3]*8||y>=(int)(n[3]+n[5])*8)return;
    for(unsigned x=0;x<320u;x++) {
        int screen=gx+(int)x;native[x]=screen>=0&&(size_t)screen<width?line[screen]:0;
    }
    for(unsigned i=0;i<count;i++) {
        unsigned cx,cy,cw,ch,grid,step,nx,ny,dx,dy,protect;
        if(scene_byte(&r,&cx)||scene_byte(&r,&cy)||scene_byte(&r,&cw)||scene_byte(&r,&ch)||scene_byte(&r,&grid)||scene_byte(&r,&step))return;
        protect=ch&128u;ch&=127u;
        nx=grid&15u;ny=grid>>4;dx=step&15u;dy=step>>4;
        if(!cw||!ch||!nx||!ny||nx>8u||ny>8u||cx+(nx-1u)*dx+cw>40u||cy+(ny-1u)*dy+ch>25u)continue;
        instances+=nx*ny;if(instances>64u)return;
        for(unsigned ry=0;ry<ny;ry++)for(unsigned rx=0;rx<nx;rx++) {
            unsigned x0=(cx+rx*dx)*8u,y0=(cy+ry*dy)*8u,w=cw*8u,h=ch*8u,fy;
            if((unsigned)y<y0||(unsigned)y>=y0+h)continue;
            fy=(unsigned)y-y0;
            for(unsigned fx=0;fx<w;fx++) {
                int screen=gx+(int)x0+(int)fx,level;unsigned hue,left=fx,top=fy,right=w-1u-fx,bottom=h-1u-fy,a,b,dist;
                if(screen<0||(size_t)screen>=width)continue;
                if(protect && (native[x0+fx]&15u)==hue1) {
                    line[screen]=native[x0+fx];continue;
                }
                hue=line[screen]&15u;if(!hue||(hue!=hue1&&hue!=hue2))continue;
                level=6-(int)(3u*fx/(w-1u))-(int)(3u*fy/(h-1u));
                a=left<top?left:top;b=right<bottom?right:bottom;dist=a<b?a:b;
                if(dist<bevel)level=a<=b?7-(int)dist:(int)dist;
                line[screen]=(uint8_t)((level<<4)|hue);
            }
        }
    }
}

static unsigned scene_row(const uint8_t *ram,unsigned head,unsigned y,
                           unsigned scale_height,uint8_t row[320],unsigned *height) {
    p64_scene_reader r={ram,head,0,0,0};
    unsigned lo,hi,w,h,top=0;
    if(scene_byte(&r,&lo)||scene_byte(&r,&hi))return 0;w=lo+(hi<<8);
    if(scene_byte(&r,&lo)||scene_byte(&r,&hi))return 0;h=lo+(hi<<8);
    if(!w || w>320u || !h || h>200u)return 0;
    y=scale_height ? y*h/scale_height : y%h;*height=h;
    while(top<h) {
        unsigned repeat,count,x=0;
        if(scene_byte(&r,&repeat)||scene_byte(&r,&count)||!repeat||!count||top+repeat>h)return 0;
        for(unsigned i=0;i<count;i++) {
            unsigned token,len;
            if(scene_byte(&r,&token))return 0;len=(token&31u)+1u;
            if(x+len>w)return 0;
            if(y>=top && y<top+repeat)for(unsigned j=0;j<len;j++)row[x+j]=(uint8_t)(token>>5);
            x+=len;
        }
        if(x!=w)return 0;
        if(y>=top && y<top+repeat)return w;
        top+=repeat;
    }
    return 0;
}
/* Material families are selected by guest data, independently of glyph IDs. */
static unsigned scene_kind(const uint8_t *ram,unsigned selector,unsigned count,
                           unsigned bank,unsigned glyph) {
    for(unsigned i=0;i<count;i++) {
        const uint8_t *k=ram+selector+1u+4u*i;
        if(k[0]==bank && glyph>=k[1] && glyph<=k[2])return k[3];
    }
    return 0;
}
void p64_scene_scanline(uint8_t *line,size_t width,int y,int gx,
                         const uint8_t *ram,const uint8_t *regs) {
    unsigned head,count;
    if(!line||!ram||!regs||!(regs[15]&1u)||y<0||y>=200)return;
    head=material_head(ram,(unsigned)regs[13]|((unsigned)regs[14]<<8),(regs[15]&8u)?0u:1u);
    for(count=0;head && count<32u;count++) {
        const uint8_t *n;unsigned next,x0,y0,w,h,font,chars,attrs,selector,control,kind_count,mcm,text_active;
        unsigned bgw,stonew,bgh,stoneh,scroll;int panel_top=0;unsigned panel_height=1;uint8_t bg[320],stone[320];
        if(head>65536u-12u)return;
        n=ram+head;next=material_next(ram,n);
        if(n[11]!=2u&&n[11]!=8u){head=next;continue;}
        if(head>65536u-24u)return;
        x0=n[2]*8u;y0=n[3]*8u;w=n[4]*8u;h=n[5]*8u;
        if(!w||!h||x0+w>320u||y0+h>200u||n[10]>15u||(n[11]!=8u&&n[22]>15u)){head=next;continue;}
        if((unsigned)y<y0 || (unsigned)y>=y0+h){head=next;continue;}
        chars=(unsigned)n[14]|((unsigned)n[15]<<8);attrs=(unsigned)n[16]|((unsigned)n[17]<<8);
        selector=(unsigned)n[18]|((unsigned)n[19]<<8);control=(unsigned)n[20]|((unsigned)n[21]<<8);
        mcm=control>=2u && (ram[control-2u]&16u);
        scroll=(n[11]!=8u&&(n[23]&128u))?8u*ram[(unsigned)n[12]|((unsigned)n[13]<<8)]:0u;
        control=(ram[control]>>1)&7u;
        font=n[11]==8u?((unsigned)n[13]<<8)+control*2048u:((n[23]&128u)?((unsigned)(n[13]&192u)<<8):((unsigned)n[12]|((unsigned)n[13]<<8)))+control*2048u;
        text_active=n[11]==8u && native_text_font_active(ram,n);
        kind_count=ram[selector];
        if(kind_count>16u||selector+1u+4u*kind_count>65536u){head=next;continue;}
        bgw=scene_row(ram,(unsigned)n[6]|((unsigned)n[7]<<8),
            kind_count==1u && (ram[selector+4u]==23u||ram[selector+4u]==24u)?n[22]*8u+((unsigned)y&7u):(unsigned)y-y0,h,bg,&bgh);
        stonew=scene_row(ram,(unsigned)n[8]|((unsigned)n[9]<<8),(unsigned)y+scroll,0,stone,&stoneh);
        if(!bgw||!stonew){head=next;continue;}
        for(unsigned x=x0;x<x0+w;x++) {
            int screen=gx+(int)x;unsigned cell=((unsigned)y/8u)*40u+x/8u,glyph,ink,bits,kind=0;
            unsigned row=(unsigned)y&7u,fx=x&7u,opaque;
            uint8_t old;
            if(screen<0||(size_t)screen>=width||chars+cell>=65536u||attrs+cell>=65536u)continue;
            glyph=ram[chars+cell];ink=ram[attrs+cell];
            if(font+glyph*8u+row>=65536u)continue;
            bits=ram[font+glyph*8u+row];
            opaque=(mcm && (ink&8u))?((bits>>(6u-2u*(fx/2u)))&3u):!!(bits&(128u>>fx));
            kind=scene_kind(ram,selector,kind_count,control,glyph);
            if(!(regs[15]&8u) && text_active && native_text_cell(ram,n,x,(unsigned)y))continue;
            if(n[11]!=8u&&(n[23]&1u)&&!kind)continue;
            old=line[screen];
            if(kind==15u || kind==16u) {
                unsigned mask=n[10],hue=ink&15u;
                if((ink&mask)==n[22]) {line[screen]=0;continue;}
                if(x==x0 || !fx) {
                    unsigned cy=(unsigned)y/8u,top=cy,end=cy+1u;
                    while(top>y0/8u) {
                        unsigned c=(top-1u)*40u+x/8u,k;
                        if(chars+c>=65536u||attrs+c>=65536u||(ram[attrs+c]&mask)!=(ink&mask))break;
                        k=scene_kind(ram,selector,kind_count,control,ram[chars+c]);
                        if(k!=15u&&k!=16u)break;top--;
                    }
                    while(end<(y0+h)/8u) {
                        unsigned c=end*40u+x/8u,k;
                        if(chars+c>=65536u||attrs+c>=65536u||(ram[attrs+c]&mask)!=(ink&mask))break;
                        k=scene_kind(ram,selector,kind_count,control,ram[chars+c]);
                        if(k!=15u&&k!=16u)break;end++;
                    }
                    panel_height=(n[23]>>1)&63u;
                    if(!panel_height)panel_height=end-top;
                    panel_top=(int)top;
                    if(top==y0/8u && end-top<panel_height && end<(y0+h)/8u)
                        panel_top=(int)end-(int)panel_height;
                }
                int pos=y-panel_top*8,level=7-pos/(int)panel_height;
                if(level<0)level=0;if(level>7)level=7;
                if(mcm&&(ink&8u))hue&=7u;
                if(kind==16u) {
                    unsigned mirrored=!(bits&3u)&&(bits&192u),edge=mirrored?7u-fx:fx;
                    if(edge==0u)level=level>2?level-3:0;
                    else if(edge==1u){line[screen]=0;continue;}
                    else if(edge==2u)level=level<6?level+2:7;
                }
                line[screen]=(uint8_t)((level<<4)|hue);
            } else if(kind>=17u && kind<=21u) {
                unsigned code=(bits>>(6u-2u*(fx/2u)))&3u,hue,level,local=x-x0;
                if(!(mcm&&(ink&8u)))continue;
                if(code!=1u&&code!=2u) {
                    line[screen]=code==3u && (ink&7u)?(uint8_t)(112u|(ink&7u)):0;
                    continue;
                }
                hue=code==1u?n[22]:n[10];
                if(kind==19u) {
                    unsigned gap=((n[23]>>1)&63u)*8u,span,pos;
                    if(gap>=w)continue;span=(w-gap)/2u;
                    if(local<span)pos=span-1u-local;
                    else if(local>=span+gap)pos=local-span-gap;
                    else continue;
                    level=pos*8u/span;
                } else {
                    level=kind>=20u?fx:local*8u/w;
                    if(kind==18u||kind==21u)level=7u-level;
                }
                line[screen]=(uint8_t)((level<<4)|hue);
            } else if((kind==23u||kind==24u) && kind_count==1u) {
                /* Reuse the shared bitmap profile at a guest-selected logical
                   character row, so the approved surface moves with its mask. */
                unsigned level=opaque?7u:bg[(x-x0)*bgw/w];
                if(kind==24u && row<3u) {
                    unsigned gap=((n[23]>>1)&63u)*8u,local=x-x0;
                    if(gap<w) {
                        unsigned span=(w-gap)/2u;
                        if(span && local<span)level=(span-1u-local)*8u/span;
                        else if(span && local>=span+gap)level=(local-span-gap)*8u/span;
                    }
                }
                line[screen]=(uint8_t)((level<<4)|n[10]);
            } else if(kind==13u || kind==22u) {
                /* A local eight-level bevel follows the source floor/ceiling. */
                unsigned gap=((n[23]>>1)&63u)*8u,local=x-x0,level=7u-row;
                if(gap && gap<w && local>=(w-gap)/2u && local<(w+gap)/2u)continue;
                unsigned hue=n[22]?n[22]:(ink&((mcm&&(ink&8u))?7u:15u));
                if(kind==22u) {
                    unsigned span=(w-gap)/2u,pos;
                    if(!span || gap>=w)continue;
                    if(local<span)pos=span-1u-local;
                    else if(local>=span+gap)pos=local-span-gap;
                    else continue;
                    level=pos*8u/span;
                }
                line[screen]=opaque && hue?(uint8_t)((level<<4)|hue):0;
            } else if(kind==14u) {
                if(!opaque)line[screen]=0;
            } else if(kind==6u) {
                line[screen]=0;
            } else if(kind==11u || kind==12u) {
                unsigned hue=old&15u,gap=((n[23]>>1)&63u)*8u,span,pos,local=x-x0;
                if((hue!=n[10]&&hue!=n[22])||gap>=w)continue;
                span=(w-gap)/2u;
                if(local<span)pos=span-1u-local;
                else if(local>=span+gap)pos=local-span-gap;
                else continue;
                line[screen]=kind==12u?(uint8_t)((3u<<4)|n[10]):(uint8_t)(((pos*8u/span)<<4)|hue);
            } else if(kind==7u || kind==8u || kind==9u || kind==10u) {
                unsigned hue=old&15u,level=kind>=9u?fx:(x-x0)*8u/w;
                if(hue!=n[10]&&hue!=n[22])continue;
                if(kind==8u || kind==10u)level=7u-level;
                line[screen]=(uint8_t)((level<<4)|hue);
            } else if(kind==4u || kind==5u) {
                unsigned hue=old&15u,level=7u-((unsigned)y-y0)*8u/h;
                if(kind==5u) {
                    unsigned mirrored=!(bits&3u)&&(bits&192u),edge=mirrored?7u-fx:fx;
                    int sample=gx+(int)(x&~7u)+(mirrored?5:2);
                    if(sample>=0&&(size_t)sample<width)hue=line[sample]&15u;
                    if(edge==0u)level=level>2u?level-3u:0u;
                    else if(edge==1u){line[screen]=0;continue;}
                    else if(edge==2u)level=level<6u?level+2u:7u;
                }
                if(!hue)hue=(n[22]&15u)?(n[22]&15u):1u;
                line[screen]=(uint8_t)((level<<4)|hue);
            } else if(kind==1u || kind==25u) {
                /* Guest-selected masonry with a framed central shaft. */
                if(kind==25u) {
                    unsigned gap=((n[23]>>1)&63u)*8u,local=x-x0;
                    if(gap>=16u && gap<w) {
                        unsigned left=(w-gap)/2u;
                        if(local>=left && local<left+gap) {
                            if(local<left+8u)line[screen]=(uint8_t)(((local-left)<<4)|n[22]);
                            else if(local>=left+gap-8u)line[screen]=(uint8_t)(((left+gap-1u-local)<<4)|n[22]);
                            else line[screen]=0;
                            continue;
                        }
                    }
                }
                unsigned tx=(x+((((unsigned)y+scroll)/stoneh)&1u)*(stonew/2u))%stonew;
                line[screen]=(uint8_t)((stone[tx]<<4)|(n[10]?n[10]:1u));
            } else if(kind==2u && opaque) {
                int level,offset;
                if(!(old&15u))continue;
                offset=2-(int)(5u*(fx+row)/14u);
                if(!fx||!row)offset++;if(fx==7u||row==7u)offset--;
                level=(old>>4)+offset;if(level<0)level=0;if(level>7)level=7;
                line[screen]=(uint8_t)((level<<4)|(old&15u));
            } else if(!opaque || kind==3u) {
                unsigned hue=old&15u;if(!hue)hue=(n[22]&15u)?(n[22]&15u):1u;
                line[screen]=(uint8_t)((bg[(x-x0)*bgw/w]<<4)|hue);
            }
        }
        head=next;
    }
}

/* The guest supplies the source bounds; the compositor has no game address. */
void p64_window_scanline(uint8_t *line,size_t width,int y,int gx,
                         const uint8_t *ram,const uint8_t *regs) {
    unsigned head,count;
    if(!line||!ram||!regs||!(regs[15]&8u)||y<0||y>=200)return;
    head=material_head(ram,(unsigned)regs[13]|((unsigned)regs[14]<<8),0u);
    for(count=0;head && count<32u;count++) {
        const uint8_t *n;unsigned next,x0,y0,w,h,top,bottom;
        if(head>65536u-12u)return;n=ram+head;
        next=material_next(ram,n);
        if(n[11]!=4u){head=next;continue;}
        x0=n[2]*8u;y0=n[3]*8u;w=n[4]*8u;h=n[5]*8u;
        if(!w||!h||x0+w>320u||y0+h>200u||n[10]>127u){head=next;continue;}
        top=ram[(unsigned)n[6]|((unsigned)n[7]<<8)];
        bottom=ram[(unsigned)n[8]|((unsigned)n[9]<<8)];
        if((unsigned)y>=y0 && (unsigned)y<y0+h && (unsigned)y>=top && (unsigned)y<bottom) {
            for(unsigned x=x0;x<x0+w;x++) {
                int px=gx+(int)x;if(px>=0&&(size_t)px<width)line[px]=n[10];
            }
        }
        head=next;
    }
}
