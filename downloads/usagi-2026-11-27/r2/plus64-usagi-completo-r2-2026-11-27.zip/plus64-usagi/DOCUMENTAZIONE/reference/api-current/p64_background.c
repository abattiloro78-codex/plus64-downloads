/* SPDX-License-Identifier: GPL-2.0-or-later */
#include "p64_background.h"
#include <math.h>
#include <string.h>
#include <stdlib.h>

/* Offset indexes are explicit temporary work; no source pixels are stored. */
typedef struct p64b_prepared_s {
 const uint8_t *b;size_t n;
 uint32_t pal[256],glyph[256],clip[256],field[256],templ[256],envelope[256],volume[256];
} db_t;
typedef struct {unsigned w,h,pm,key,ink,glyph,clip,op;const uint8_t *p;size_t n;} field_t;
typedef struct {unsigned left,right,count;const uint8_t *spans;} clip_t;
static unsigned u16(const uint8_t *p){return(unsigned)p[0]|((unsigned)p[1]<<8);}
static int i16(const uint8_t *p){unsigned v=u16(p);return v<32768?(int)v:(int)v-65536;}
static int i8(unsigned v){return v<128?(int)v:(int)v-256;}
static unsigned bits(unsigned n){unsigned b=0;for(unsigned q=n-1;q;q>>=1)b++;return b?b:1;}
static int colour(unsigned c){return c<=127;}
static const uint8_t *record(const db_t *d,uint32_t at){return at?d->b+at:NULL;}
static unsigned record_length(const uint8_t *p){return u16(p-2);}
static unsigned record_type(const uint8_t *p){return p[-3];}
static const uint8_t *palette(const db_t *d,unsigned id,unsigned *n){
 const uint8_t *p=record(d,d->pal[id]);if(!p)return NULL;*n=p[1];return p+2;
}
static int unique_entries(const uint8_t *p,unsigned n,unsigned stride){
 uint8_t seen[32]={0};
 for(unsigned i=0;i<n;i++){
  unsigned g=p[i*stride];if(seen[g>>3]&(1u<<(g&7)))return 0;seen[g>>3]|=(uint8_t)(1u<<(g&7));
 }
 return 1;
}
static int field_parse(const uint8_t *p,size_t n,field_t *f){
 if(n<10||u16(p+8)!=n-10)return P64B_FORMAT_ERROR;
 f->w=p[0];f->h=p[1];f->pm=p[2];f->key=p[3];f->ink=p[4];f->glyph=p[5];f->clip=p[6];f->op=p[7];f->p=p+10;f->n=n-10;
 return f->h&&!(f->pm&240)&&(f->key==255||colour(f->key))?0:P64B_FORMAT_ERROR;
}
/* Validate all intervals, and obtain a view of the requested row. Width0 means
 * the caller has not yet bound a rest-of-world global field. */
static int clip_row(const db_t *d,unsigned id,unsigned w,unsigned h,unsigned fy,clip_t *out){
 out->left=0;out->right=w;out->count=0;out->spans=NULL;
 if(!id)return 0;
 const uint8_t *p=record(d,d->clip[id]);if(!p||p[1]!=h)return P64B_FORMAT_ERROR;
 unsigned row=0;size_t at=3;
 for(unsigned i=0;i<p[2];i++){
  unsigned repeat=p[at++];
  if(record_type(p)==3){
   unsigned left=p[at++],span=p[at++];
   if(w&&(left>w||span>w-left))return P64B_FORMAT_ERROR;
   if(fy>=row&&fy<row+repeat){out->left=left;out->right=left+span;}
  }else{
   unsigned count=p[at++],end=0;const uint8_t *spans=p+at;
   for(unsigned j=0;j<count;j++){
    unsigned left=u16(p+at),span=u16(p+at+2);at+=4;
    if(!span||left<end||(w&&(left>w||span>w-left)))return P64B_FORMAT_ERROR;
    end=left+span;
   }
   if(fy>=row&&fy<row+repeat){out->spans=spans;out->count=count;}
  }
  row+=repeat;
 }
 return row==h?0:P64B_FORMAT_ERROR;
}
static int field_valid(const db_t *d,const field_t *f){
 unsigned n=0;const uint8_t *p;clip_t clip;
 if(f->glyph&&!d->glyph[f->glyph])return P64B_FORMAT_ERROR;
 if(clip_row(d,f->clip,f->w,f->h,0,&clip))return P64B_FORMAT_ERROR;
 if(f->op==0)return f->n==1&&colour(f->p[0])?0:P64B_FORMAT_ERROR;
 if(f->op==7)return f->n==11&&f->p[0]<=15&&f->p[1]<=f->p[2]&&f->p[2]<=7?0:P64B_FORMAT_ERROR;
 if(f->op==12)return f->n==15&&f->p[0]<=15&&f->p[1]<=f->p[2]&&f->p[2]<=7&&u16(f->p+11)&&u16(f->p+13)?0:P64B_FORMAT_ERROR;
 if(f->op==13){
  if(f->n!=18||!f->p[0]||f->p[0]>15||f->p[1]>f->p[2]||f->p[2]>7||!u16(f->p+7)||!u16(f->p+9))return P64B_FORMAT_ERROR;
  for(unsigned i=11;i<=15;i++)if(f->p[i]>100)return P64B_FORMAT_ERROR;
  return f->p[16]<=7&&f->p[17]<=7&&(!f->p[15]||f->p[17]>f->p[16])?0:P64B_FORMAT_ERROR;
 }
 if(f->op==15){
  if(f->n!=11||!f->p[0]||f->p[0]>15||f->p[1]>f->p[2]||f->p[2]>7||!d->volume[f->p[3]])return P64B_FORMAT_ERROR;
  for(unsigned i=4;i<=8;i++)if(f->p[i]>100)return P64B_FORMAT_ERROR;
  return f->p[9]<=7&&f->p[10]<=7&&(!f->p[8]||f->p[10]>f->p[9])?0:P64B_FORMAT_ERROR;
 }
 if(!f->n)return P64B_FORMAT_ERROR;
 p=palette(d,f->p[0],&n);if(!p)return P64B_FORMAT_ERROR;
 switch(f->op){
 case 1:return f->n==1&&n>=2?0:P64B_FORMAT_ERROR;
 case 2:return f->n==2&&n>=3?0:P64B_FORMAT_ERROR;
 case 3:case 6:{
  if(f->n<2||(f->p[1]!=1&&f->p[1]!=2)||n>128)return P64B_FORMAT_ERROR;
  unsigned rb=8-bits(n);size_t at=2;
  for(unsigned y=0;y<f->h;y++){
   if(at>=f->n)return P64B_FORMAT_ERROR;
   unsigned count=f->p[at++];if(count>f->n-at)return P64B_FORMAT_ERROR;
   unsigned samples=0;
   for(unsigned x=0;x<count;x++){
    unsigned token=f->p[at+x];if((token>>rb)>=n)return P64B_FORMAT_ERROR;samples+=(token&((1u<<rb)-1u))+1;
   }
   if(f->op==6&&count&&f->w&&samples!=(f->w+f->p[1]-1)/f->p[1])return P64B_FORMAT_ERROR;
   at+=count;
  }
  return at==f->n?0:P64B_FORMAT_ERROR;
 }
 case 4:return f->n==2&&f->p[1]?0:P64B_FORMAT_ERROR;
 case 5:
  if(f->n!=1u+f->h)return P64B_FORMAT_ERROR;
  for(unsigned y=0;y<f->h;y++)if(f->p[y+1]>=n)return P64B_FORMAT_ERROR;
  return 0;
 case 8:return f->n==1?0:P64B_FORMAT_ERROR;
 case 14:
  if(f->n!=5||!f->p[2]||!f->p[3]||f->p[4]>31)return P64B_FORMAT_ERROR;
  p=record(d,d->envelope[f->p[1]]);return p&&p[1]==f->h?0:P64B_FORMAT_ERROR;
 case 9:
  if(f->n!=2)return P64B_FORMAT_ERROR;
  p=record(d,d->envelope[f->p[1]]);return p&&p[1]==f->h?0:P64B_FORMAT_ERROR;
 case 10:
  if(f->n<2||f->n!=2u+9u*f->p[1]||!unique_entries(f->p+2,f->p[1],9))return P64B_FORMAT_ERROR;
  for(unsigned i=0;i<f->p[1];i++)for(unsigned y=0;y<8;y++)if(f->p[3+9*i+y]>=n)return P64B_FORMAT_ERROR;
  return 0;
 case 11:
  if(f->n<2||!f->p[1]||f->n!=2u+f->p[1])return P64B_FORMAT_ERROR;
  for(unsigned x=0;x<f->p[1];x++)if(f->p[2+x]>=n)return P64B_FORMAT_ERROR;
  return 0;
 default:return P64B_FORMAT_ERROR;
 }
}
static int envelope_valid(const uint8_t *p,size_t n){
 if(n<7||!p[0]||!p[1])return P64B_FORMAT_ERROR;
 int64_t left=i16(p+2),right=i16(p+4);unsigned rows=0;size_t at=7;
 if(left>right||right-left+1>65535)return P64B_FORMAT_ERROR;
 for(unsigned i=0;i<p[6];i++){
  if(n-at<2)return P64B_FORMAT_ERROR;
  unsigned steps=p[at++],mode=p[at++],period=mode&127,stride=(mode&128)?4:2;
  if(!period||period>16||steps<period||steps>(unsigned)p[1]-1-rows||period>(n-at)/stride)return P64B_FORMAT_ERROR;
  for(unsigned j=0;j<steps;j++){
   const uint8_t *q=p+at+(j%period)*stride;
   left+=stride==4?i16(q):i8(q[0]);right+=stride==4?i16(q+2):i8(q[1]);
   if(left>right||right-left+1>65535)return P64B_FORMAT_ERROR;
  }
  at+=period*stride;rows+=steps;
 }
 return at==n&&rows+1==p[1]?0:P64B_FORMAT_ERROR;
}
static int index_blob(db_t *d,const uint8_t *b,size_t n){
 if(!d||!b||n<6||n>P64B_BLOB_MAX||memcmp(b,"P64B\1\0",6))return P64B_FORMAT_ERROR;
 memset(d,0,sizeof(*d));d->b=b;d->n=n;
 for(size_t at=6;at<n;){
  if(n-at<3)return P64B_FORMAT_ERROR;
  unsigned type=b[at],len=u16(b+at+1);size_t pos=at+3;
  if(len>n-pos)return P64B_FORMAT_ERROR;
  const uint8_t *v=b+pos;uint32_t *slot=NULL;
  switch(type){
  case 1:
   if(len<3||!v[0]||!v[1]||len!=2u+v[1])return P64B_FORMAT_ERROR;
   for(unsigned j=0;j<v[1];j++)if(!colour(v[j+2]))return P64B_FORMAT_ERROR;
   slot=&d->pal[v[0]];break;
  case 2:if(len!=33||!v[0])return P64B_FORMAT_ERROR;slot=&d->glyph[v[0]];break;
  case 3:{
   if(len<3||!v[0]||!v[1]||!v[2]||len!=3u+3u*v[2])return P64B_FORMAT_ERROR;
   unsigned rows=0;for(unsigned j=0;j<v[2];j++){unsigned repeat=v[3+3*j];if(!repeat)return P64B_FORMAT_ERROR;rows+=repeat;}
   if(rows!=v[1])return P64B_FORMAT_ERROR;
   slot=&d->clip[v[0]];break;
  }
  case 4:if(len<4||!v[0]||!v[1]||!v[2]||len!=4u+3u*v[3])return P64B_FORMAT_ERROR;slot=&d->templ[v[0]];break;
  case 5:if(len!=5||!v[1])return P64B_FORMAT_ERROR;break;
  case 6:if(len<19||!v[6])return P64B_FORMAT_ERROR;break;
  case 7:if(len<11||!v[0])return P64B_FORMAT_ERROR;slot=&d->field[v[0]];break;
  case 12:{
   if(len<3||!v[0]||!v[1]||!v[2])return P64B_FORMAT_ERROR;
   unsigned rows=0;size_t p=3;
   for(unsigned i=0;i<v[2];i++){
    if(len-p<2)return P64B_FORMAT_ERROR;
    unsigned repeat=v[p++],count=v[p++];if(!repeat||count>(len-p)/4)return P64B_FORMAT_ERROR;
    unsigned end=0;
    for(unsigned j=0;j<count;j++){unsigned l=u16(v+p),w=u16(v+p+2);p+=4;if(!w||l<end)return P64B_FORMAT_ERROR;end=l+w;}
    rows+=repeat;
   }
   if(rows!=v[1]||p!=len)return P64B_FORMAT_ERROR;
   slot=&d->clip[v[0]];break;
  }
  case 13:if(envelope_valid(v,len))return P64B_FORMAT_ERROR;slot=&d->envelope[v[0]];break;
  case 14:case 16:if(len!=8||!v[6]||!v[7])return P64B_FORMAT_ERROR;break;
  case 17:
   if(len<6||!v[0]||!v[1]||!u16(v+2)||!u16(v+4)||len!=6u+18u*v[1])return P64B_FORMAT_ERROR;
   for(unsigned i=0;i<v[1];i++){const uint8_t *e=v+6+18*i;if(!u16(e+14)||!u16(e+16))return P64B_FORMAT_ERROR;}
   slot=&d->volume[v[0]];break;
  case 15:if(len<2||!v[0]||len!=2u+9u*v[1]||!unique_entries(v+2,v[1],9))return P64B_FORMAT_ERROR;slot=&d->glyph[v[0]];break;
  default:return P64B_FORMAT_ERROR;
  }
  if(slot){if(*slot)return P64B_FORMAT_ERROR;*slot=(uint32_t)pos;}
  at=pos+len;
 }
 /* Forward references are resolved only after every bounded record is indexed. */
 for(size_t at=6;at<n;){
  unsigned type=b[at],len=u16(b+at+1);const uint8_t *v=b+at+3;field_t f;
  if(type==7){if(field_parse(v+1,len-1,&f)||field_valid(d,&f))return P64B_FORMAT_ERROR;}
  else if(type==4){
   for(unsigned i=0;i<v[3];i++){
    const uint8_t *r=record(d,d->field[v[4+3*i]]);if(!r)return P64B_FORMAT_ERROR;
    if(field_parse(r+1,record_length(r)-1,&f)||!f.w||v[5+3*i]+f.w>v[1]||v[6+3*i]+f.h>v[2])return P64B_FORMAT_ERROR;
   }
  }else if(type==5){if(!d->templ[v[1]])return P64B_FORMAT_ERROR;}
  else if(type==6||type==14||type==16){
   if(type==6){if(field_parse(v+9,len-9,&f))return P64B_FORMAT_ERROR;}
   else{const uint8_t *r=record(d,d->field[v[7]]);if(!r||field_parse(r+1,record_length(r)-1,&f))return P64B_FORMAT_ERROR;}
   f.w=u16(v+4);f.h=v[6];if(field_valid(d,&f))return P64B_FORMAT_ERROR;
  }
  at+=3+len;
 }
 return 0;
}
int p64b_validate(const uint8_t *blob,size_t n){db_t d;return index_blob(&d,blob,n);}
static int match(const db_t *d,const p64b_context_t *c,const field_t *f,int32_t x,int32_t y,unsigned fx,const clip_t *clip,p64b_source_t *found){
 if(fx<clip->left||fx>=clip->right)return 0;
 if(clip->spans){
  int inside=0;for(unsigned i=0;i<clip->count;i++){unsigned l=u16(clip->spans+4*i),w=u16(clip->spans+4*i+2);if(fx>=l&&fx-l<w){inside=1;break;}}
  if(!inside)return 0;
 }
 p64b_source_t s;
 if(x<0||y<0||(uint32_t)x>=c->world_width||(uint32_t)y>=c->world_height)return P64B_CONTEXT_ERROR;
 if(!c->source(c->opaque,x,y,&s)||s.pair>3||!colour(s.native_colour))return P64B_SOURCE_ERROR;
 if(!(f->pm&(1u<<s.pair))||(f->key!=255&&s.native_colour!=f->key)||(f->ink!=255&&s.ink!=f->ink))return 0;
 if(f->glyph){
  const uint8_t *g=record(d,d->glyph[f->glyph]);
  if(record_type(g)==2){if(!(g[1+(s.glyph>>3)]&(1u<<(s.glyph&7))))return 0;}
  else{
   int accepted=0;for(unsigned i=0;i<g[1];i++)if(g[2+9*i]==s.glyph){accepted=(g[3+9*i+((unsigned)y&7)]>>((unsigned)x&7))&1;break;}
   if(!accepted)return 0;
  }
 }
 if(found) *found=s;
 return 1;
}
static int round_even(double v){double low=floor(v),fraction=v-low;int n=(int)low;return fraction>.5||(fraction==.5&&(n&1))?n+1:n;}
static double clamp01(double v){return v<0?0:v>1?1:v;}
static void envelope_at(const uint8_t *p,unsigned y,int64_t *left,int64_t *right){
 *left=i16(p+2);*right=i16(p+4);size_t at=7;
 for(unsigned i=0;i<p[6]&&y;i++){
  unsigned steps=p[at++],mode=p[at++],period=mode&127,stride=(mode&128)?4:2,take=y<steps?y:steps;
  for(unsigned j=0;j<take;j++){const uint8_t *q=p+at+(j%period)*stride;*left+=stride==4?i16(q):i8(q[0]);*right+=stride==4?i16(q+2):i8(q[1]);}
  at+=period*stride;y-=take;
 }
}
static double quadratic_light(const uint8_t *p,unsigned x,unsigned y,unsigned fx,unsigned fy,
                                  int left,int top,unsigned w,unsigned h,unsigned prior){
 double gl=(double)x+left,gt=(double)y+top;
 double cx=(gl+gl+w)/2+(((double)p[0]-50)/100)*w,cy=gt+((double)p[1]/100)*h;
 double halfw=w/2.0,halfh=h/2.0;if(halfw<1)halfw=1;if(halfh<1)halfh=1;
 double pair=(double)(((uint64_t)x+fx)/2*2+1);
 double u=(pair-cx)/halfw,v=((double)y+fy-cy)/halfh;
 double light=clamp01(1-(((double)p[2]/100)*u*u+((double)p[3]/100)*v*v));
 if(p[4]){
  double previous=clamp01(((double)(prior>>4)-p[5])/(p[6]-p[5]));
  light=((double)(100-p[4])/100)*light+((double)p[4]/100)*previous;
 }
 return light;
}
static const uint8_t *nearest_volume(const uint8_t *table,unsigned fx,unsigned fy){
 const uint8_t *chosen=NULL;double best=0;unsigned count=table[1];
 for(unsigned i=0;i<count;i++){
  const uint8_t *e=table+6+18*i;
  double dx=((double)fx-i16(e))/(double)u16(table+2),dy=((double)fy-i16(e+2))/(double)u16(table+4);
  double distance=dx*dx+dy*dy;
  if(!chosen||distance<best){chosen=e;best=distance;}
 }
 /* Explicit guest rectangles override nearest ownership in wire order. */
 for(unsigned i=0;i<count;i++){
  const uint8_t *e=table+6+18*i;int64_t l=i16(e+4),t=i16(e+6);
  if((int64_t)fx>=l&&(int64_t)fx<l+e[8]&&(int64_t)fy>=t&&(int64_t)fy<t+e[9])chosen=e;
 }
 return chosen;
}
static int apply_field(const db_t *d,const p64b_context_t *c,const field_t *f,unsigned x,unsigned y,unsigned w,unsigned h,uint8_t *out,uint8_t *selected,size_t width){
 if(!w||!h||x>c->world_width||w>c->world_width-x||y>c->world_height||h>c->world_height-y)return P64B_CONTEXT_ERROR;
 if(c->world_y<(int32_t)y||(uint32_t)c->world_y>=y+h)return 0;
 if((int64_t)c->world_x+(int64_t)width<=(int64_t)x||(int64_t)c->world_x>=(int64_t)x+w)return 0;
 unsigned fy=(unsigned)c->world_y-y;clip_t clip;if(clip_row(d,f->clip,w,h,fy,&clip))return P64B_FORMAT_ERROR;
 unsigned pn=0;const uint8_t *pal=(f->op&&f->op!=7&&f->op!=12&&f->op!=13&&f->op!=15)?palette(d,f->p[0],&pn):NULL;
 if(f->op==3){
  unsigned step=f->p[1],rb=8-bits(pn),rm=(1u<<rb)-1;size_t pos=2;
  for(unsigned row=0;row<fy;row++)pos+=1u+f->p[pos];
  unsigned count=f->p[pos++];const uint8_t *tokens=f->p+pos;unsigned token=0,remaining=0,index=0;
  if(step==2&&(w&1))return P64B_FORMAT_ERROR;
  for(unsigned fx=0;fx<w;fx+=step){
   int yes=match(d,c,f,(int32_t)(x+fx),c->world_y,fx,&clip,NULL);if(yes<0)return yes;
   if(step==2){int other=match(d,c,f,(int32_t)(x+fx+1),c->world_y,fx+1,&clip,NULL);if(other<0)return other;if(other!=yes)return P64B_FORMAT_ERROR;}
   if(!yes)continue;
   if(!remaining){if(token>=count)return P64B_FORMAT_ERROR;unsigned t=tokens[token++];index=t>>rb;remaining=(t&rm)+1;}remaining--;
   for(unsigned dx=0;dx<step;dx++){int64_t at=(int64_t)x+fx+dx-c->world_x;if(at>=0&&(uint64_t)at<width){out[(size_t)at]=pal[index];selected[(size_t)at]=1;}}
  }
  return remaining||token!=count?P64B_FORMAT_ERROR:0;
 }
 const uint8_t *tokens=NULL;unsigned count=0,rb=0,rm=0,step=0;
 if(f->op==6){
  step=f->p[1];rb=8-bits(pn);rm=(1u<<rb)-1;if(step==2&&(w&1))return P64B_FORMAT_ERROR;
  size_t pos=2;for(unsigned row=0;row<fy;row++)pos+=1u+f->p[pos];count=f->p[pos++];tokens=f->p+pos;
  unsigned samples=0;for(unsigned i=0;i<count;i++)samples+=(tokens[i]&rm)+1;
  if(count&&samples!=(w+step-1)/step)return P64B_FORMAT_ERROR;
 }
 int64_t left=0,right=0;if(f->op==9||f->op==14)envelope_at(record(d,d->envelope[f->p[1]]),fy,&left,&right);
 for(size_t i=0;i<width;i++){
  int64_t wx=(int64_t)c->world_x+i;if(wx<(int64_t)x||wx>=(int64_t)x+w)continue;
  unsigned fx=(unsigned)wx-x;p64b_source_t source;int yes=match(d,c,f,(int32_t)wx,c->world_y,fx,&clip,&source);if(yes<0)return yes;if(!yes)continue;
  unsigned value=0,index=0;
  switch(f->op){
  case 0:value=f->p[0];break;
  case 1:{double light=.65*(double)fx/(double)(w>1?w-1:1)+.35*(1.0-(double)fy/(double)(h>1?h-1:1));value=pal[light>=.5];break;}
  case 2:{double distance=(double)fx-(double)f->p[1]/2.0;if(distance<0)distance=-distance;index=distance<=1.5?2:distance<=4?1:0;if(fy+2>=h&&index>1)index=1;value=pal[index];break;}
  case 4:index=(unsigned)((uint64_t)fy*pn/f->p[1]);if(index>=pn)index=pn-1;value=pal[index];break;
  case 5:value=pal[f->p[fy+1]];break;
  case 6:{
   unsigned sample=fx/step,span=0;int found=0;
   for(unsigned t=0;t<count;t++){span+=(tokens[t]&rm)+1;if(sample<span){value=pal[tokens[t]>>rb];found=1;break;}}
   if(!found) return P64B_FORMAT_ERROR;
   break;
  }
  case 7:{
   double pair=(double)(((uint64_t)x+fx)/2*2+1)-(double)x;
   double lw=u16(f->p+7),lh=u16(f->p+9);
   double u=(pair-((double)i16(f->p+3)+lw/2))/(lw/2+4),v=((double)fy-((double)i16(f->p+5)+lh))/(lh+4);
   double inside=1-u*u-v*v;if(inside<0)inside=0;
   double light=clamp01(.65*u-.65*v+.70*sqrt(inside));unsigned level=f->p[1]+(unsigned)round_even((f->p[2]-f->p[1])*light);value=(level<<4)|f->p[0];break;
  }
  case 8:index=(unsigned)((uint64_t)fy*(pn-1)/(h>1?h-1:1));if(index>=pn)index=pn-1;value=pal[index];break;
  case 9:{
   int64_t dx=(int64_t)fx-left,span=right-left+1;
   if(dx<=0)index=0;else{uint64_t q=(uint64_t)dx*pn/(uint64_t)span;index=q>=pn?pn-1:(unsigned)q;}
   value=pal[index];break;
  }
  case 10:{
   int found=0;for(unsigned j=0;j<f->p[1];j++)if(f->p[2+9*j]==source.glyph){value=pal[f->p[3+9*j+((unsigned)c->world_y&7)]];found=1;break;}
   if(!found) return P64B_FORMAT_ERROR;
   break;
  }
  case 11:value=pal[f->p[2+fx%f->p[1]]];break;
  case 12:{
   double pair=(double)(((uint64_t)x+fx)/2*2+1)-(double)x;
   double u=(2*pair-i16(f->p+7))/(double)u16(f->p+11),v=(2*(double)fy-i16(f->p+9))/(double)u16(f->p+13);
   double inside=1-u*u-v*v;if(inside<0)inside=0;
   double light=clamp01(((double)i8(f->p[4])/100)*u+((double)i8(f->p[5])/100)*v+((double)f->p[6]/100)*sqrt(inside));
   int level=round_even(f->p[1]+(f->p[2]-f->p[1])*light)+i8(f->p[3]);if(level<f->p[1])level=f->p[1];if(level>f->p[2])level=f->p[2];value=((unsigned)level<<4)|f->p[0];break;
  }
  case 13:{
   double light=quadratic_light(f->p+11,x,y,fx,fy,i16(f->p+3),i16(f->p+5),u16(f->p+7),u16(f->p+9),out[i]);
   unsigned level=f->p[1]+(unsigned)round_even((f->p[2]-f->p[1])*light);value=(level<<4)|f->p[0];break;
  }
  case 15:{
   const uint8_t *e=nearest_volume(record(d,d->volume[f->p[3]]),fx,fy);
   double light=quadratic_light(f->p+4,x,y,fx,fy,i16(e+10),i16(e+12),u16(e+14),u16(e+16),out[i]);
   unsigned level=f->p[1]+(unsigned)round_even((f->p[2]-f->p[1])*light);value=(level<<4)|f->p[0];break;
  }
  case 14:{
   unsigned flags=f->p[4],scale=1u<<(flags>>2);
   double pair=(double)(((uint64_t)x+fx)/2*2)+(flags&2?.5:1.)-(double)x;
   double l=(double)left/scale,r=(double)right/scale,span=r-l-1;
   if(span<1)span=1;
   double cross=clamp01((pair-(l+.5))/span);
   double light=flags&1?1-fabs(2*cross-1):cross;
   double q=floor(pn*pow(light,(double)f->p[2]/f->p[3])+.5);
   index=q>=pn?pn-1:(unsigned)q;value=pal[index];break;
  }
  default:return P64B_FORMAT_ERROR;
  }
  out[i]=(uint8_t)value;selected[i]=1;
 }
 return 0;
}
static int apply_prepared(uint8_t *line,uint8_t *selected,size_t width,const db_t *d,const p64b_context_t *c){
 uint8_t out[P64B_SCANLINE_MAX],mask[P64B_SCANLINE_MAX];int status;
 if(line&&selected&&width<=P64B_SCANLINE_MAX){uintptr_t a=(uintptr_t)line,b=(uintptr_t)selected;if((a<=b&&b-a<width)||(b<a&&a-b<width))return P64B_CONTEXT_ERROR;}
 if(selected&&width<=P64B_SCANLINE_MAX)memset(selected,0,width);
 if(!line||!selected||!c||!c->source||!width||width>P64B_SCANLINE_MAX||!c->world_width||!c->world_height||c->world_width>65535)return P64B_CONTEXT_ERROR;
 if(!d)return P64B_FORMAT_ERROR;
 const uint8_t *blob=d->b;size_t size=d->n;
 memcpy(out,line,width);memset(mask,0,width);
 /* Reference order: early shared globals, instances, inline globals, late shared globals. */
 for(unsigned pass=0;pass<4;pass++)for(size_t at=6;at<size;){
  unsigned type=blob[at],len=u16(blob+at+1);const uint8_t *v=blob+at+3;
  if(type==5&&pass==1&&v[0]==c->scene){
   const uint8_t *t=record(d,d->templ[v[1]]);unsigned x=u16(v+2),y=v[4];
   if(x>c->world_width||t[1]>c->world_width-x||y>c->world_height||t[2]>c->world_height-y)return P64B_CONTEXT_ERROR;
   for(unsigned i=0;i<t[3];i++){
    const uint8_t *r=record(d,d->field[t[4+3*i]]);field_t f;if(field_parse(r+1,record_length(r)-1,&f))return P64B_FORMAT_ERROR;
    status=apply_field(d,c,&f,x+t[5+3*i],y+t[6+3*i],f.w,f.h,out,mask,width);if(status<0)return status;
   }
  }else if(((type==16&&pass==0)||(type==6&&pass==2)||(type==14&&pass==3))&&v[0]==c->scene){
   field_t f;unsigned x=u16(v+1),y=v[3],w=u16(v+4),h=v[6];
   if(x>c->world_width)return P64B_CONTEXT_ERROR;
   if(!w)w=c->world_width-x;
   if(type==6){if(field_parse(v+9,len-9,&f))return P64B_FORMAT_ERROR;}
   else{const uint8_t *r=record(d,d->field[v[7]]);if(field_parse(r+1,record_length(r)-1,&f))return P64B_FORMAT_ERROR;}
   status=apply_field(d,c,&f,x,y,w,h,out,mask,width);if(status<0)return status;
  }
  at+=3+len;
 }
 memcpy(line,out,width);memcpy(selected,mask,width);unsigned count=0;for(size_t i=0;i<width;i++)count+=mask[i]!=0;return(int)count;
}

int p64b_prepare(const uint8_t *blob,size_t size,p64b_prepared_t **prepared){
 if(!prepared)return P64B_CONTEXT_ERROR;
 *prepared=NULL;
 db_t *d=(db_t*)malloc(sizeof(*d));if(!d)return P64B_MEMORY_ERROR;
 int status=index_blob(d,blob,size);if(status<0){free(d);return status;}
 *prepared=d;return 0;
}
void p64b_prepared_discard(p64b_prepared_t *prepared){free(prepared);}
int p64b_apply_prepared(uint8_t *line,uint8_t *selected,size_t width,const p64b_prepared_t *prepared,const p64b_context_t *c){
 return apply_prepared(line,selected,width,prepared,c);
}
int p64b_apply_scanline(uint8_t *line,uint8_t *selected,size_t width,const uint8_t *blob,size_t size,const p64b_context_t *c){
 /* Keep the legacy per-call API and its argument/error precedence. */
 db_t d;
 if(line&&selected&&width<=P64B_SCANLINE_MAX){uintptr_t a=(uintptr_t)line,b=(uintptr_t)selected;if((a<=b&&b-a<width)||(b<a&&a-b<width))return P64B_CONTEXT_ERROR;}
 if(selected&&width<=P64B_SCANLINE_MAX)memset(selected,0,width);
 if(!line||!selected||!c||!c->source||!width||width>P64B_SCANLINE_MAX||!c->world_width||!c->world_height||c->world_width>65535)return P64B_CONTEXT_ERROR;
 int status=index_blob(&d,blob,size);if(status<0)return status;
 return apply_prepared(line,selected,width,&d,c);
}
