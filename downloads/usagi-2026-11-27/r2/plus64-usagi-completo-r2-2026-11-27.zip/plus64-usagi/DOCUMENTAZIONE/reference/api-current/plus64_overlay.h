/* plus/64 0.5: indexed video overlay compositing - independent of VICE. */
#ifndef PLUS64_OVERLAY_H
#define PLUS64_OVERLAY_H
#include <stdint.h>
#include <stddef.h>
/* plus/64 color indices 0..120 correspond to 121 DISTINCT TED colors.
   The VICE TED raster buffer uses 0..127 indices, with black repeated at
   0,16,32,...112. Convert without discarding the last 7 colors. */
uint8_t p64_ted_color(uint8_t index);
/* Stable native border state captured before raster_line_emulate resets its
 * open-border flags. blank includes the current row's vertical flip-flop.
 * Coordinates and colour are native TED-buffer values, not compact inks.
 * This transient host descriptor does not allocate guest RAM. */
typedef struct p64_native_border_s {
    int display_start, display_stop;
    int open_left, open_right, disabled, blank;
    uint8_t color;
} p64_native_border_t;
/* FD9F bit4 with scenery capability18: native closed borders win after all
 * composition. Only the logical320x200 area is touched; collisions are not.
 * A native blank row is wholly border unless its left border is open. */
void p64_side_border_clip_scanline(uint8_t *line,size_t width,int y,int gx,
                                  unsigned profile,uint8_t flags,
                                  const p64_native_border_t *border);
/* Compose one 320x200 logical sprite scanline over an existing indexed TED
   scanline. framebuffer/mask are 320x200; line is a logical TED raster line.
   gfx_x/y are VICE gfx origin within the raster geometry. */
void p64_overlay_scanline(uint8_t *ted_line, size_t ted_width, int line,
                          int gfx_x, int gfx_y, const uint8_t *overlay,
                          const uint8_t *alpha);
/* Native source-bit classification for the five ordinary TED graphics modes
 * 0=standard text,1=multicolour text,2=hires bitmap,3=MC bitmap,4=ECM text.
 * Input views are40 character/attribute bytes,2048 font bytes or8192 bitmap
 * bytes. Origins and clipping are in native raster-buffer coordinates.
 * Illegal/idle/blank modes have no foreground. This is transient host work,
 * not another guest memory pool. */
typedef struct {
    const uint8_t *vbuf, *cbuf, *font, *bitmap;
    unsigned mode, ycounter, memptr;
    int reverse_mode, cursor_visible, cursor_cell;
    int source_origin, overlay_origin, clip_start, clip_stop, active;
} p64_ted_row_t;
void p64_ted_foreground_row(uint8_t foreground[320],const p64_ted_row_t *row);
/* alpha is a deferred visible-slot union. Its lowest set bit identifies the
 * top visible sprite. Only those bits present in behind_mask obey foreground;
 * lower sprites never appear through an occluded higher-priority sprite. */
void p64_overlay_scanline_priority(uint8_t *ted_line,size_t ted_width,int line,
                                  int gfx_x,int gfx_y,const uint8_t *overlay,
                                  const uint8_t *alpha,const uint8_t foreground[320],
                                  uint8_t behind_mask);
/* Scenery21: generic anchored front material. Type10 nodes are16 bytes:
 * next16,left/right anchor glyphs,anchor character row,anchor span in cells,
 * rectangle-stream head16,count,shade depth,base compact ink,type10,
 * tint top/bottom exclusive,native hue key,flags0. Each streamed rectangle
 * is relative-X LE16,absolute-Y,width,height,reserved0 (six bytes), using the
 * ordinary next16,length8 stream segments. Span is the distance between
 * anchors; material width is(span+1)*8. The first left anchor wins; a right
 * anchor is a fallback when the left has scrolled out. Rectangles are ANDed
 * with actual native foreground. Tint is horizontal and keyed to native hue.
 * Always clears mask; returns1 for a valid active anchored owner, otherwise0.
 * Caller saves the marked pre-sprite colors and restores them after sprites.
 * This does not alter sprite occupancy, priority between actors or collisions.
 * All geometry and storage are guest-selected; no extra guest memory pool. */
int p64_front_layer_scanline(uint8_t mask[320],uint8_t *line,size_t width,
                            int y,int gx,const uint8_t *ram,const uint8_t *regs,
                            const p64_ted_row_t *row,const uint8_t *chars,
                            unsigned version);
/* Scenery22: type11 nodes select a guest-owned material program/archive.
 * Original source facts come from the actual TED row, before recolouring.
 * Programs execute after older materials and before actor/front composition.
 * See p64_background_native.h for the24-byte guest configuration contract. */
int p64_guest_material_scanline(uint8_t *line,size_t width,int y,int gx,
                              const uint8_t *main_ram,const uint8_t *aux,
                              const uint8_t *regs,const p64_ted_row_t *row,
                              const uint8_t background[4],unsigned version);
/* Explicit per-frame work variant; NULL retains the per-call path. */
struct p64b_frame_work_s;
int p64_guest_material_scanline_work(uint8_t *line,size_t width,int y,int gx,
                              const uint8_t *main_ram,const uint8_t *aux,
                              const uint8_t *regs,const p64_ted_row_t *row,
                              const uint8_t background[4],unsigned version,
                              struct p64b_frame_work_s *work);
/* FD9D/E linked-list head in existing main RAM; FD9F bit0 enables.
 * Nodes: next16, x/y/w/h in character cells, xmin/ymin/xmax/ymax in
 * local pixels, compact transparent colour, flags (0). Maximum32 nodes.
 * Changes only TED luminance; apply before sprite composition. */
void p64_light_scanline(uint8_t *line, size_t width, int y, int gx,
                         const uint8_t *ram, const uint8_t *regs);
/* Scenery22 type12 is a16-byte external lighting phase owner:
 * next16,phaseX16,gateMAINaddr16,value8,mask8,reserved[3]0,type12,
 * reserved[4]0. The first active, valid owner in the resolved material list
 * selects phase0..319. Conditional owner replacement and font protection
 * follow material_head: put phase nodes inside the active branch, never
 * before an owner that replaces them. Phase0 and older versions retain the
 * unshifted path. Only the logical320-pixel viewport is written; the wrap
 * uses one transient320-byte scanline and unchanged C21 material equations.
 */
/* Scenery19: tint flag-byte bit3 clips the tint to a pixel-centred ellipse.
 * Scenery20 adds keyed vertical palette-ramp nodes9. Earlier restored
 * profiles retain their original interpretation. No new guest RAM. */
void p64_light_scanline_versioned(uint8_t *line,size_t width,int y,int gx,
                         const uint8_t *ram,const uint8_t *regs,unsigned version);
/* Versioned streamed scenery node (flag2). Source image and material bytes
 * stay in guest-owned linked segments; only a transient scanline is decoded. */
void p64_scene_scanline(uint8_t *line, size_t width, int y, int gx,
                         const uint8_t *ram, const uint8_t *regs);

/* Flag4 node: guest-selected top/bottom bounds, applied after sprites. */
void p64_window_scanline(uint8_t *line,size_t width,int y,int gx,
                         const uint8_t *ram,const uint8_t *regs);

#endif
