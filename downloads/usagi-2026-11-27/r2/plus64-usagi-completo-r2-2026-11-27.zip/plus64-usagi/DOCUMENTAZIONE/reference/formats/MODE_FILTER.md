# Generic optional node11 native-mode filter

The24-byte node layout is unchanged. Offset19 is now flags with bit0 `MODE_FILTER`; offset20 is a native mode mask. Offsets21–23 remain reserved zero. Flags0 preserves the previous behavior and requires offset20 zero. Flags1 requires a nonzero mask containing only bits0–4. Other flag bits, a zero enabled mask, unknown mask bits or nonzero reserved bytes fail closed.

When enabled, a row is processed only if `mode_mask & (1 << row.mode)` is nonzero. A filtered row returns0, keeps every output pixel unchanged and clears the optional selection mask. The existing active/valid-mode guards run before the shift. Each of the five native modes remains available both through flags0 and through its explicit mask bit. This is a generic mode selector, with no game names, font addresses or HUD coordinates in the platform.

For example, flags1/mask2 selects multicolour text mode1. All register/source interpretation remains inside the existing native-row adapter. The parser source `p64_background.c` and public parser header are unchanged from `FINAL_PARSER_FREEZE.json`; common metadata method dispatch is not modified here.

The isolated tests compare flags0 and flags1/mask2 against the same full17-scene fixture and native fine-scroll cases, with zero RGB/mask differences. A compiled ASan/UBSan/LeakSanitizer harness tests mode0 exclusion with unchanged native UI pixels, identical mode1 output, explicit positive masks for all five modes, every reserved/invalid flag-mask boundary, compressed corruption and6,000 configuration mutations. These are compiled-C tests, not actual emulator UI captures or final game qualification.
