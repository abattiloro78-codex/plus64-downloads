
# ABI5additions

Shader13is18B `<BBBhhHHBBBBBBB>` hue,low,high,lightLefti16,lightTopi16,lightWu16,lightHu16,cxPercent,cyPercent,weightXPercent,weightYPercent,mixPercent,oldLumLow,oldLumHigh. Allpercents0..100,hue1..15,low<=high<=7,dimensions>0;whenmix>0oldHigh>oldLow,oldlums0..7. Compute world lighting L=fieldX+lightLeft,T=fieldY+lightTop;cx=(L+L+W)/2+((cxPercent−50)/100)*W,cy=T+(cyPercent/100)*H;u=(worldPairCentre1−cx)/max(1,W/2),v=(worldY−cy)/max(1,H/2);f=clip(1−(wx/100*u*u+wy/100*v*v),0,1). Ifmix>0:old=clip((currentPixelLum−oldLow)/(oldHigh−oldLow),0,1);f=(100−mix)/100*f+mix/100*old. Luminance=low+rint((high−low)*f).

TLV17volume table: id:u8,count:u8,sx:u16,sy:u16,then count18Bentries`<hhhhBBhhHH>`:distanceCx, distanceCy,forceLeft,forceTop,forceWidth,forceHeight,lightingLeft,lightingTop,lightingWidth,lightingHeight. Allcoordinates are field-local; dimensionspositive except eitherforceW/H0 disablesitsrect. Count>0andscales>0.

Shader15payload11B:hue,low,high,tableID,cxPercent,cyPercent,weightXPercent,weightYPercent,mixPercent,oldLumLow,oldLumHigh. Pick entryminimizing((physicalLocalX−distanceCx)/sx)^2+((physicalLocalY−distanceCy)/sy)^2;strictless-thanandfirstminimumwin. Then anyforceRectcontainingpixeloverridesinentryorder,lastmatchwins. Use chosenentrylightingrectangle withshader13formula. This is a generic guest-parameterized nearest-volume field, not a game-specificruntimecatalogue.

Shader14andscaledperiodicenvelopesare frozen inwater_ops.py; see WATER_FREEZE inparentbackground-core.

InitialimageinthisfixtureisexistingC21prelight; scene04usesphase280(allotherphases0),matchingthepriorapproved2520pxcopy. CtestsstartfromexpectedNPZ.initialandcompare native_after/covered_mask. Originalsourcecontextstaysimmutableandnativeattribute-normalized. No fit claim: thissnapshot'sresidentcompresseddataexceedsbudget.
