# Scenery22 external lighting phase

The isolated patch adds one guest-authored type12 linked node. It preserves
all existing lighting equations, source glyphs, material owner replacement,
foreground/background dispatch and snapshot layout.

| Offset | Field |
| --- | --- |
| 0 | next, u16 little endian |
| 2 | phase X, u16, valid 0..319 |
| 4 | MAIN gate address, u16 |
| 6 | gate value, u8 |
| 7 | gate mask, u8 |
| 8..10 | reserved zero |
| 11 | kind 12 |
| 12..15 | reserved zero |

The first structurally valid node satisfying `(MAIN[gate] & mask) == value`
wins, including phase 0. A false or malformed node is skipped. Versions below
22 ignore this new kind. The phase scan begins at `material_head` and follows
`material_next`, bounded to 32 nodes. Consequently the node must live inside
the active branch, for example:

`old game owner → true branch: BG11 → Phase12 → previous sky head`

A phase placed before an owner that replaces earlier layers is legitimately
replaced too. The false/menu branch retains the previous behavior.

For a nonzero active phase, the public function copies only its logical
320-pixel viewport to a transient row. It calls the unchanged unshifted code
with origins `-phase` and `320-phase`, then copies the row back only within the
physical buffer and logical viewport. It does not first apply an unshifted
pass. This adds 320 bytes of temporary scanline working state and no stored
asset, cache, glyph, palette or image data.

The previous C21 function body is byte-identical, with only its private name
changed. Phase 0, false gates, disabled owners and old versions call that same
unshifted path directly.

## Qualification

- 34,560 actual C comparisons cover all 320 phases, six hue maps and 18 rows
  against a one-pass, rotated old-C oracle.
- 2,808 further comparisons check phase 0, false gates and versions18..21.
- First-owner priority, malformed owners and conditional replacement pass.
- Actual scene04: 216,000 pixels match the frozen C21 source-pad280/crop oracle
  exactly. The prelight-only unshifted mismatch is10,124 pixels; the separately
  measured10,051 final-scene mismatch excluded pixels overwritten by P64B.
- Type12 is skipped by foreground, guest background, scene and window paths.
  Original glyph/font data and foreground source classification remain exact.
- ASAN/UBSAN passes30,621 viewport/border/fuzz cases, including5,000 reserved/
  gate variations, full-node boundaries, cycles, nulls and extreme active
  origins. No write occurs outside the logical320-pixel viewport.

`PHASE.patch` is the reviewable production diff. `SOURCE_REFERENCE.json` records
the vendor base; `HANDOFF.json` records the final candidate hashes. Test stubs,
fixtures, libraries and instrumentation are excluded from the product. Other
C files, C8 sources, guest source artwork and historical proofs were not edited.
