# Final capability-8 source wire: direct frame IDs

This isolated candidate preserves the qualified draw-local material reuse from
`../core8-fast`. The material VM and all approved colour metadata are unchanged.
The final unpublished source flag 8 now uses P64F version 4 without per-frame CPU
headers. Source bytes 0/1 contain a direct opaque frame ID, including valid ID 0;
source byte 2 is the fixed marker 2. Source byte 11 is ignored. Bytes 13/14 still
select the P64F root in the same MAIN/AUX bank as the source.

The helper checks the logical ID against `frameCount`, not RAM capacity. Legacy
private P64F versions 1/2 retain their address bounds and prefix checks. Version
3 is rejected. Every codec still verifies its complete compressed member and
checksum, expands at most 32×63 = 2,016 source bytes, copies one 63-byte frame,
and frees that temporary view. No source atlas or persistent cache is added.

The two final guest source archives are:

| Archive | Guest bytes |
| --- | ---: |
| `framebank-method1-nearest-v4/archive.bin` | 11,017 |
| `framebank-method2-nearest-v4/archive.bin` | 10,409 |

The LZMA archive saves 1,710 bytes against the previous nearest packet by
removing its 342 five-byte headers. All 342 decoded source streams retain their
original hashes. CPU pointer aliases and their direct IDs are supplied by the
parent archive `BUILD.json`; the C circuit has no game-specific source map.

The sprite shader archive remains 7,197 guest bytes. The native driver, total
81,920-byte allocation and final captures are owned by the parent integration.

## Qualification

`C8_FINAL_MASTER_QUALIFICATION.json` records the exact C and shared metadata
master used. Checks include:

- 3,216 final-wire C frame draws: 804 contexts, both orientations, both codecs.
- 3,216 overlapping draws, with exact colours, alpha bit masks and collisions.
- 3,216 version-1 compatibility draws; old RLE/grammar and 70-byte paths remain
  exact through 3,216 and 3,312 further cases.
- 4,104 direct frame decodes: every one of 342 streams, both codecs, MAIN/AUX
  views, and P64F versions 1/2/4.
- ID 0 accepted; logical ID 16,385 accepted with a 16,384-byte AUX view and
  confirmed through the actual renderer. This proves IDs are not RAM addresses.
- Wrong markers, out-of-range IDs and version 3 rejected; arbitrary source
  byte 11 values leave representative images exact.
- ASAN/UBSAN: 24 full pipeline fixtures, 600 malformed variants, 5,000 metadata
  mutations, 28 truncations and the eight-context working bound.

Only `plus64_sprite.c/.h` and the new `framebank_source.c` differ from the prior
fast candidate. `sprite_vm.c/.h`, metadata wire, shared eight-byte contexts and
all previous frozen source trees remain unchanged. Source expansion counts
remain 9 per ordinary composite and 6 per HUD, within each draw call only.

Promote the final production C files and the shared metadata master; all test
fixtures, instrumentation and `.so` files are excluded. These are controlled C
proofs, not a natural-gameplay, physical-hardware or platform-performance claim.
