# Generic shader14: source-conditioned power envelope

Payload5bytes: `palette_id:u8,envelope_id:u8,exponent_numerator:u8,exponent_denominator:u8,flags:u8`. Numerator and denominator must be positive. Flags bits0–4 are defined; bits5–7 must be zero. The referenced type13 envelope must match the effective field height.

At localY load signed L/R from the guest envelope. Let `scale=2^(flags>>2)`, `l=L/scale`, `r=R/scale`. Bits2–4 provide fixed-point contour precision without changing the existing type13 schema. At physical worldX, let `pair=floor(worldX/2)*2+offset-fieldOriginX`, with offset0.5 when flag bit1 is set, otherwise1.0. Then:

```
cross = clamp((pair-(l+0.5))/max(1,r-l-1),0,1)
light = bit0 ? 1-abs(2*cross-1) : cross
index = min(palette_count-1,
            floor(palette_count*pow(light,numerator/denominator)+0.5))
```

The selected palette colour is written only when all original-source pair/glyph/native-attribute/native-colour and clip predicates match. No pixel outside the current viewport row is read. Widths, contour scales, exponent and palettes are all guest-authored data, with no named material or game IDs in C. Existing operators and type13 bytes are unchanged.

The reviewed recipes emit exponent3/5, symmetric/half-pair flags3, scale1 ordinarily and scale4 for two41-row bridge interpolations. The scale4 envelope is chosen only when it produces exactly the approved palette bins for every selected source pixel; it does not reconstruct or retain any bitmap. The selected body palette is26/36/46/56/66. The accepted097 indexed data has darker banks and a brighter centre; its historical contrary prose label is not reinterpreted.

Original white-wave geometry and reviewed tip accents are separate ordinary constant-colour source-conditioned fields. The source17 lake retains its previously approved vertical palette ramp using existing shader4. The two source09 ponds are a separate target update, transferring only exact original source water/wave geometry from the approved source15 ponds; green banks, source black holes and all non-water176 pixels are preserved.

The C addition is isolated in this folder; `WATER_C_PATCH.diff` applies only shader14 validation/sampling to ABI3. It does not contain the independently owned shader13 extension. No vendor code, guest executable or final memory allocation is changed here.
