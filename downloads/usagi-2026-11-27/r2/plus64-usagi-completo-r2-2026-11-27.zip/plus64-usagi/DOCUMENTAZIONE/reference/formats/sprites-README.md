# Exact approved sprite metadata prototype

The guest package is `sprite_vm.p64z` (7,197 bytes), wrapping the 14,180-byte
`SVM4` metadata stream. It reconstructs the accepted colours from the unchanged
original source RLE. It contains selectors, material profiles, arithmetic
expressions and routing; no occupancy bitmap or coloured sprite texture is
added. The only authorized geometry change is the four removed Ryo antenna
pixels. Original source geometry is sampled for every other context.

The reference corpus has 804 contexts, 430 distinct colour images and all 207
canonical source poses. It includes reviewed actor variants, dynamic shared
states, four HUD portraits and explicit unchanged fallbacks. A context appearing
in this corpus is not a claim that natural gameplay has reached that state.
Historical sources and approved boards remain unchanged.

## Files used for integration

- `sprite_vm.p64z`: guest-resident archive; SHA-256
  `9fa9fbf03f81a8d0f5aa85a74d98eb410f8ca417aede3b3bd75e5dc4569c108c`.
- `core/sprite_vm.c` / `.h`: generic metadata VM, bounded 96-double expression
  stack, original source-pair/ink callback, no game IDs or persistent asset cache.
- `core/plus64_sprite.c` / `.h`: isolated capability-7 candidate, based on the
  current capability-6 vendor source recorded in `core/C6_SOURCE_REFERENCE.json`.
- Shared dependency: `../background-core/p64_metadata.c` / `.h`, linked with
  `-lz`; generic temporary P64Z expansion. The metadata view is closed within
  the same draw call and never retained in guest state, snapshots or globals.
- `C7_PIPELINE_PROOF.json`, `C7_COLLISION_PROOF.json`, `C7_LEGACY_PROOF.json`,
  `C7_SAFETY_PROOF.json`: actual C pipeline qualification, not a native-game or
  emulator-frame-rate claim.

The complete integrated RAM allocation and CPU driver are owned by the parent
integration. The package consumes 7,197 of its currently measured 11,542 bytes,
leaving 4,345 bytes before other live binding/driver allocations. The 169-byte
old portrait asset is represented in the package, but its CPU initialization
must still be routed to capability 7 correctly.

## Shared source16 binding for capability 7

Source record modes 0/1 retain their old meanings. Modes 2/3 require capability
7 and use a shared eight-byte context pointed to by source bytes 8/9:

| Offset | Field |
| --- | --- |
| 0 | Guest AUX metadata archive root, little-endian u16 |
| 2 | Guest AUX source-column directory, little-endian u16 |
| 4 | Number of source columns, 1..3 |
| 5 | Full composite height, 1..63 |
| 6 | Opaque logical material key, u8 |
| 7 | Opaque guest selector, u8 |

Mode 2 selects the primary guest base map; mode 3 selects its first alternate.
Byte 11 remains original software data. The decoder finds the current record
in the source directory to infer its column and 21-row band; it does not assume
contiguous columns. The source mirror bit remains the same. Every record in a
composite must identify the same context and mode. The current implementation
shares one archive per draw call; all present contexts use that one archive.

For this guest's compiler, the CPU supplies key `family*128+pose`, actor/type
as selector, and dynamically captured ink. This arithmetic and the selector
meaning belong to the game driver, not the C circuit. The dynamically created
Ryo selects its own guest route. HUD modes keep ink values 51/49/47/50, which
select the approved blue/purple/red/green backgrounds; blue facial details are
protected by the guest recipe.

## SVM4 stream

All integer fields are little endian. The 28-byte header is `SVM4`, six u16
section lengths, then six u16 section counts. Sections appear in this order:

1. Mask dictionary: u16 offsets plus terminal offset, then selector records.
   A high-bit header is a whole-source-pair bit mask; other records contain
   pair-conditioned rectangle groups. Each rectangle is 24 bits:
   `x0 | y0<<6 | x1<<12 | y1<<18`, with X in MCM cells and Y in native rows.
2. Expression dictionary: u16 offsets and postfix programs. Small constants
   0..31 are inline; `3F,index` reads a shared binary64 constant; `40..46`
   read X, Y, MCM-X, pair, occupied row bounds and capped Manhattan distance
   to original source pair 1. `80..8E` are arithmetic, comparisons, min/max,
   abs, sqrt, floor, nearest-even rounding and conditional selection.
3. Binary64 constants, 8 bytes each.
4. Paint-program dictionary: u16 offsets and operations with a varuint mask ID.
   Operations are literal, profile, horizontal ramp, weighted three-grey ramp,
   retint of original base, retint of current result, vertical ramp, expression,
   three source-pair literals, copy of original base, and two native half-cell
   literals. All geometry comes from original source pairs.
5. Sparse routing: selector/ink-specific table directory and key/program pairs.
6. Legacy generic base recipes: alternate count and recipe IDs, 256-entry
   primary key map, then u16-offset recipe dictionary. This retains the existing
   generic rectangle material equations without any hard-coded source family
   size or HUD pose number in C.

The P64Z wrapper is `P64Z`, version=1, method=1, raw length u16, stored length
u16, reserved u16=0, followed by exactly one complete zlib member. The wrapper
is shared with background metadata. It adds 12 bytes to the compressed stream.

## Verification

`verify_c.py` compares every native pixel against the approved corpus.
`verify_pipeline.py` exercises full source16-to-frame C drawing for all 804
contexts, both orientations and both RLE and shared pair-grammar sources.
`verify_collision.py` checks overlapping bit masks and line collisions, plus
single-pixel probes where Ryo antennae were removed. `verify_legacy.py` compares
207 old poses, 48/72-pixel domains and both orientations at capabilities 4/6/7
against the authenticated historical C wrapper. `verify_safety.py` runs ASAN
and UBSAN on representative full pipelines, unsupported-version rejection,
malformed contexts, metadata mutations and truncations.

No vendor, emulator, release, game source or historical preview was edited by
this task. Temporary metadata expansion is decoder workspace, not a persistent
asset/image cache. The C test timings measure controlled fixtures on this host;
they do not establish natural gameplay speed or physical cartridge feasibility.
