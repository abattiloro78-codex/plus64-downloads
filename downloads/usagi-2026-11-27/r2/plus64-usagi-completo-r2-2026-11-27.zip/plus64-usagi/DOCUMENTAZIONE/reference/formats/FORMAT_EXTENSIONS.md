# Additive P64B version1 extensions, fixture ABI2

The original type1..7 and shader0..6 encodings remain unchanged. This document defines new types and shader opcodes. Source `ink` in native fixtures is the actual TED attribute byte (`cbuf&127`), not a C64 palette index. Matching nativeTED/pair/glyph always uses the immutable unlit source. Coordinates and phases are physical world pixels. No operator requests offscreen source pixels.

## Additional selectors / bindings

### Type12: wide source-conditioned multi-interval clip

Payload: `id:u8,height:u8,record_count:u8`, followed by records `row_repeat:u8,span_count:u8`, then `span_count` pairs `left:u16,width:u16`. The intervals are field-local and select their union in each repeated row. An empty span list rejects the row. Repeat counts are positive and sum to height; intervals are sorted, nonoverlapping, positive-width and within the bound field width. Type3 and12 share the clipID namespace, with no duplicate IDs.

The compiler uses a full-width interval whenever the source predicate already supplies the correct row geometry. It does not redundantly store the source font's contour.

### Type13: shared periodic-delta row envelope

Payload: `id:u8,height:u8,initial_left:i16,initial_right:i16,segment_count:u8`. Each segment is `steps:u8,mode:u8`, followed by a periodic delta pattern. `period=mode&127` is1..16; bit7 selects signed16-bit delta pairs, otherwise signed8-bit pairs. A pattern entry is `(delta_left,delta_right)`. Steps>=period; all steps sum to height−1. Row0 uses the initial coordinates. For each following step j in a segment, add pattern[j%period] to L/R. Coordinates are field-local; they may be negative but L<=R in each row. This is guest-owned contour data, not an offscreen source lookup.

### Type14: shared global-field binding

Payload8bytes: `scene:u8,x:u16,y:u8,width:u16,height:u8,field_id:u8`. Execute a reusable type7 field at this rectangle with localx/y0. Its outerwidth/height override the width/height in the field definition; the stored type7 height remains positive. Width0 means the rest of the panorama. Bound clip/envelope/row-profile lengths must be compatible with the effective height. This avoids repeated shader/LUT payloads across maps.

### Type15: source-glyph subcell selector

Payload: `id:u8,entry_count:u8`, then entries `glyph:u8,bitmap[8]`. Type2 and15 share one glyph-selectorID namespace, with no duplicate IDs. Type15 tests the current original glyph and bit `(bitmap[worldY&7]>>(worldX&7))&1`. Bits are **LSB-first** horizontally. An absent glyph is false; count0 is an empty valid selector; duplicate glyph entries are invalid. This selection is ANDed with nativeTED/pair/ink and clip selectors. It contains only a tiny material role mask; the actual source glyph remains resident guest data.

The internal mountain light openings in glyph28..2B have34true subcell phases, identical in the checked snow/blue copies. Four9-byte entries replace several kilobytes of redundant world-row clipping without filling genuine sky above the silhouette.

## New shaders

###7: reviewed radial surface124/128

Payload11bytes: `hue:u8,low:u8,high:u8,lighting_left:i16,lighting_top:i16,lighting_width:u16,lighting_height:u16`. The lighting rectangle is relative to the field origin; it may extend outside the field, which preserves anchors for cropped or extended copies.

For field-local x/y and world field origin X, let `paircentre=floor((X+x)/2)*2+1-X`. Compute:

```
u=(paircentre-(lighting_left+lighting_width/2))/(lighting_width/2+4)
v=(y-(lighting_top+lighting_height))/(lighting_height+4)
f=clamp(.65*u-.65*v+.70*sqrt(max(0,1-u*u-v*v)),0,1)
L=low+rint((high-low)*f)
colour=(L<<4)|hue
```

`rint` is nearest with ties to even, matching the approved NumPy reference. This preserves black/sourceholes because only explicitly selected source P1/P3 material is painted.

###8: endpoint palette rampY

Payload `palette_id:u8`. With effective field height h and palette size n, index=`min(n-1,floor(localY*(n-1)/max(1,h-1)))`. Both endpoints are included. This shader is supported by the reference but the current fixture uses the more compact glyph-row profile for repeated ice objects.

###9: mountain envelopeX ramp

Payload `palette_id:u8,envelope_id:u8`. Fetch L/R from type13 at localY. Index=`clamp(floor((localX-L)*palette_size/(R-L+1)),0,palette_size-1)`. Division must floor toward negative infinity; C signed integer truncation toward zero alone is insufficient for negative numerators. Palette output is selected only by the source predicate and original opaque mountain role.

###10: glyph-row palette lookup

Payload `palette_id:u8,entry_count:u8`, then `glyph:u8,index[8]` for each entry. On a selected pixel use `palette[index_for_original_glyph[worldY&7]]`. Missing glyph on a selected pixel is an error (fail closed); duplicate glyphs and out-of-range indices are invalid. The compiler restricts its source glyph selector to the provided entries. This reproduces the exact approved16/24px ice profiles without per-object instances.

###11: periodic column palette lookup

Payload `palette_id:u8,period:u8,index[period]`. Period is positive; use `palette[index[localX%period]]`. This supplies the exact precomputed105cylindrical wood profile and reviewed front wood on original source pair masks. It needs no offscreen source geometry and no floating-point profile reconstruction.

###12: parameterized radial field105

Payload15bytes, little-endian struct `<BBBbbbBhhHH`:

```
hue:u8, low:u8, high:u8, luminance_offset:i8,
coefficient_u:i8, coefficient_v:i8, coefficient_sqrt:u8,
centre_x_times2:i16, centre_y_times2:i16,
scale_x_times2:u16, scale_y_times2:u16
```

Centres are relative to field origin, scales are positive. With the same local paircentre definition as7:

```
u=(2*paircentre-centre_x_times2)/scale_x_times2
v=(2*localY-centre_y_times2)/scale_y_times2
light=clamp((coefficient_u/100)*u+(coefficient_v/100)*v
            +(coefficient_sqrt/100)*sqrt(max(0,1-u*u-v*v)),0,1)
L=clamp(rint(low+(high-low)*light)+luminance_offset,low,high)
colour=(L<<4)|hue
```

Coefficients55,−25,80, scales36/36 and centre(x0+12,y0+20) reproduce the approved105fan light. Separate source pair selectors provide offsets−1/−2/0 for P1/P2/P3; the explicit tiny original stem uses the constant wood38rule. No outline or sourceP0pixel is added.

## Compressed resident wrapper

When used, P64Z contains: magic`P64Z`,version1:u8,method1:u8,raw_length:u16,stored_length:u16,reserved:u16=0, then exactly one complete zlib member. Both lengths are positive and<=65535; total region is12+stored_length. Compression is a resident-byte representation only; the final linker must count this region and any guest scratch. The generic decoder may use bounded transient working memory derived from guest bytes, with no persistent expanded asset atlas.
