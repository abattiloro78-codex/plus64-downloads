#include "plus64_sprite.h"
#include <string.h>
#include "sprite_vm.h"
#include "p64_metadata.h"
int p64_source_frame(const uint8_t *memory,unsigned capacity,unsigned source,
                     unsigned root,unsigned software_length,uint8_t out[63]);

int plus64_set_extended_formats(plus64_t *p, int enable) {
    if (p->regs[0]) return -1;
    p->extended_formats=(uint8_t)(enable!=0);
    p->collision_only_formats=enable?2u:0u;
    p->material_full_palette=(uint8_t)(enable!=0);
    p->sparse_formats=(uint8_t)(enable!=0);
    p->light_directions=(uint8_t)(enable!=0);
    p->front_mask_profile=(uint8_t)(enable!=0);
    p->tile_lighting=(uint8_t)(enable!=0);
    p->diagonal_lighting=(uint8_t)(enable!=0);
    p->dense_formats=(uint8_t)(enable!=0);
    p->dense_height_formats=(uint8_t)(enable!=0);
    p->dense_material_formats=(uint8_t)(enable ? 8u : 0u);
    return 0;
}

/* Selectable material profile in the video circuit. No texture RAM, game IDs,
 * sprite IDs or game addresses. Hue comes from the descriptor; occupancy
 * always comes from the ordinary source mask. Integer math is deterministic.
 * Legacy highlight at the upper-left quarter; optional eight directions plus front. */
static unsigned light_direction(const plus64_t *p, unsigned slot) {
    unsigned value=(p->regs[9u+slot/2u]>>((slot&1u)*4u))&15u;
    return p->light_directions && value<=9u ? value : 0u;
}

/* Preserve each original MCM ink and change only its luminance. Equal
 * levels lie on diagonals, using the actual opaque source bounding box. */
static uint8_t diagonal_colour(uint8_t ink,int x,int y,int xmin,int ymin,int xmax,int ymax) {
    int dx=xmax-xmin,dy=ymax-ymin,level;
    if (!ink || ink>120u) return ink;
    if (!dx)dx=1;
    if (!dy)dy=1;
    level=((int)ink-1)/15+2-5*((x-xmin)*dy+(y-ymin)*dx)/(2*dx*dy);
    if(level<0)level=0;
    if(level>7)level=7;
    return (uint8_t)(1u+((unsigned)ink-1u)%15u+15u*(unsigned)level);
}

static uint8_t tone_colour(const plus64_t *p, unsigned slot, uint8_t base, int px, int py, int full_palette) {
    static const int8_t light_x[10]={6,12,23,23,23,12,0,0,0,12};
    static const int8_t light_y[10]={5,0,0,10,20,20,20,10,0,10};
    unsigned direction=light_direction(p,slot);
    int dx=px-light_x[direction], dy=py-light_y[direction];
    int level=7-(dx*dx+dy*dy)/40;
    if (base==0 || base>120) return base;
    if (level<0) level=0;
    /* The chosen colour is the highlight. Legacy snapshots retain the
       original hue-only ramp; new materials honour its luminance too. */
    if (full_palette) level=level*((base-1)/15)/7;
    return (uint8_t)(15*level+1+(base-1)%15);
}

/* Frontal light follows each occupied row span, rather than putting a
 * bright spot in the centre of an entire sparse record. Thin faces/arms
 * keep their selected highlight; broad spans have shaded edges. This is a
 * generic mask profile, with no knowledge of body parts or game addresses. */
static uint8_t front_mask_colour(uint8_t base, const uint8_t mask[63], int x, int y) {
    int left=x,right=x,level=7;
    if (base==0 || base>120) return base;
    while(left>0 && (mask[y*3+(left-1)/8]&(128u>>((left-1)&7)))) --left;
    while(right<23 && (mask[y*3+(right+1)/8]&(128u>>((right+1)&7)))) ++right;
    int width=right-left+1;
    if(width>2) {
        int distance=x-left<right-x ? x-left : right-x;
        int radius=(width-1)/2;
        level=6+distance/radius;
    }
    return (uint8_t)(15*(level*((base-1)/15)/7)+1+(base-1)%15);
}

/* Authored composite materials. All bindings, recipes and source masks belong
 * to the existing16KiB backing. This is geometry/colour computation, not a
 * bitmap cache: no game IDs, anatomy, inferred grouping or extra payload RAM. */
typedef struct {
    unsigned recipe,count,colours,directory,columns,parts,width,height,ox,oy;
    int mirror,rectangular,compact;
    unsigned stride;
    const uint8_t *main_ram;
    uint8_t decoded[9][63];
    p64_svm vm;
    const plus64_t *platform;
    unsigned vm_mode;
} p64_material;

typedef struct {
    unsigned x0,y0,x1,y1,pair,profile,component;
} p64_material_rect;


/* Compact source records refer only to the existing MAIN/AUX backings.
 * Decoded bytes below are transient renderer work, never guest-addressable
 * or retained between captures. Old APIs pass no MAIN view and fail closed
 * for a MAIN source, while AUX sources remain self-contained. */
static uint8_t source_reverse_pairs(uint8_t b) {
    return (uint8_t)(((b&3u)<<6)|((b&12u)<<2)|((b&48u)>>2)|((b&192u)>>6));
}

/* A grammar has256 shared rules, in three256-byte guest planes: left low,
 * right low, then high flags (bits0/1). Children must precede their rule.
 * Frame tokens are nine bits, grouped as one high bitmap and up to eight
 * low bytes. The guest frame prefix is old-software-length,token-count.
 * Only the ordinary63-byte working result and bounded transient traversal
 * stack exist here; the dictionary and all frame data stay in guest RAM. */
static int source_grammar_decode(const uint8_t *memory,unsigned limit,
                                unsigned source,unsigned dictionary,
                                unsigned software_length,uint8_t out[63]) {
    unsigned count,input=0u,produced=0u,at;
    if(source>limit-2u || dictionary>limit-768u)return 0;
    if(memory[source]!=software_length)return 0;
    count=memory[source+1u];
    if(!count || count>63u)return 0;
    unsigned bytes=count+(count+7u)/8u;
    if(bytes>limit-source-2u)return 0;
    for(unsigned rule=0;rule<256u;rule++) {
        unsigned flags=memory[dictionary+512u+rule];
        if(flags&252u)return 0;
        unsigned left=memory[dictionary+rule]|((flags&1u)<<8);
        unsigned right=memory[dictionary+256u+rule]|((flags&2u)<<7);
        if(left>=256u+rule || right>=256u+rule)return 0;
    }
    at=source+2u;
    while(input<count) {
        unsigned remaining=count-input,n=remaining<8u?remaining:8u;
        unsigned high=memory[at++];
        if(n<8u && (high>>n))return 0;
        for(unsigned i=0;i<n;i++) {
            unsigned value=memory[at++]|(((high>>i)&1u)<<8);
            unsigned stack[256],depth=0u;
            for(;;) {
                if(value<256u) {
                    if(produced>=63u)return 0;
                    out[produced++]=(uint8_t)value;
                    if(!depth)break;
                    value=stack[--depth];
                } else {
                    unsigned rule=value-256u,flags=memory[dictionary+512u+rule];
                    if(depth>=256u)return 0;
                    stack[depth++]=memory[dictionary+256u+rule]|((flags&2u)<<7);
                    value=memory[dictionary+rule]|((flags&1u)<<8);
                }
            }
        }
        input+=n;
    }
    return produced==63u;
}

static int source_decode(const plus64_t *p,unsigned at,
                         const uint8_t *main_ram,uint8_t out[63]) {
    unsigned source,length,limit,in=0u,n=0u;
    const uint8_t *memory;
    if(!p->ram || at>PLUS64_RAM_SIZE-16u || p->dense_material_formats<5u)return 0;
    const uint8_t *r=p->ram+at;
    if(r[15]!=0xa6u || r[12]!=16u ||
       (!(r[3]&12u) && (r[13] || r[14])) ||
       (r[3]&12u)==12u ||
       (r[3]&(p->dense_material_formats>=8u?240u:p->dense_material_formats>=6u?248u:252u)) || !r[2] || r[2]>128u || r[7]>252u ||
       r[4]>120u || r[5]>120u || r[6]>120u || r[9]>63u || r[10]>(p->dense_material_formats>=7u?3u:1u))return 0;
    source=(unsigned)r[0]|((unsigned)r[1]<<8);length=r[2];
    memory=(r[3]&2u)?p->ram:main_ram;
    limit=(r[3]&2u)?PLUS64_RAM_SIZE:65536u;
    /* Frame-bank version4 uses an opaque ID, not a RAM address. */
    if(!memory || (!(r[3]&8u)&&source>limit))return 0;
    if(r[3]&8u) {
        unsigned root=(unsigned)r[13]|((unsigned)r[14]<<8);
        if(p->dense_material_formats<8u||!p64_source_frame(memory,limit,source,root,length,out))return 0;
        n=63u;in=length;
    } else if(r[3]&4u) {
        unsigned dictionary=(unsigned)r[13]|((unsigned)r[14]<<8);
        if(!source_grammar_decode(memory,limit,source,dictionary,length,out))return 0;
        n=63u;in=length;
    } else if(length>limit-source)return 0;
    while(n<63u) {
        unsigned token,run;
        if(in>=length)return 0;
        token=memory[source+in++];run=token&127u;
        if(!run || run>63u-n)return 0;
        if(token&128u) {
            if(in>=length)return 0;
            uint8_t value=memory[source+in++];
            for(unsigned j=0;j<run;j++)out[n++]=value;
        } else {
            if(run>length-in)return 0;
            for(unsigned j=0;j<run;j++)out[n++]=memory[source+in++];
        }
    }
    if(in!=length)return 0;
    if(r[3]&1u)for(unsigned row=0;row<21u;row++) {
        unsigned q=row*3u;uint8_t a=out[q],b=out[q+1u],c=out[q+2u];
        out[q]=source_reverse_pairs(c);out[q+1u]=source_reverse_pairs(b);
        out[q+2u]=source_reverse_pairs(a);
    }
    return 1;
}

static unsigned material_u16(const plus64_t *p,unsigned at) {
    return (unsigned)p->ram[at]|((unsigned)p->ram[at+1u]<<8);
}

static int dense_part_valid(const plus64_t *p,unsigned at,int compact,const uint8_t *main_ram) {
    if(compact){uint8_t out[63];return source_decode(p,at,main_ram,out);}
    unsigned mode;
    if(at>PLUS64_RAM_SIZE-70u)return 0;
    mode=p->ram[at+0x41u];
    if(mode==1u)return p->ram[at+0x45u]==0xa5u;
    return p->dense_material_formats && (mode==2u || mode==0x82u)
        && (p->ram[at+0x45u]&0xc0u)==0x80u;
}

static void material_rect(const plus64_t *p,const p64_material *m,unsigned index,p64_material_rect *r) {
    unsigned at=m->recipe+1u+index*4u;
    uint32_t v=(uint32_t)p->ram[at]|((uint32_t)p->ram[at+1u]<<8)
        |((uint32_t)p->ram[at+2u]<<16)|((uint32_t)p->ram[at+3u]<<24);
    r->x0=(v&63u)*2u;r->y0=(v>>6)&63u;
    r->x1=((v>>12)&63u)*2u+1u;r->y1=(v>>18)&63u;
    r->pair=(v>>24)&3u;r->profile=(v>>26)&7u;r->component=(v>>29)&7u;
}

typedef struct {
    p64_metadata_view_t view;
    unsigned root;
    int opened;
} p64_draw_metadata;

/* Validated source/material execution state is shared only within one draw.
 * Eight is the hardware slot bound, not an asset catalogue. No entry survives
 * the call, and every source byte is still derived from the guest backings. */
typedef struct {
    p64_material material;
    unsigned binding,mode,mirror,local;
} p64_draw_material_entry;
typedef struct {
    unsigned count;
    p64_draw_material_entry entries[8];
} p64_draw_materials;

static unsigned vm_original_sample(void *user,int x,int y,uint8_t *ink);
static int vm_archive(const plus64_t *p,unsigned root,p64_draw_metadata *metadata) {
    if(metadata->opened)return metadata->root==root;
    unsigned bytes=0u;
    if(root>PLUS64_RAM_SIZE-12u)return 0;
    if(!memcmp(p->ram+root,"P64Z",4u))bytes=12u+material_u16(p,root+8u);
    else if(root<=PLUS64_RAM_SIZE-28u&&!memcmp(p->ram+root,"SVM4",4u)) {
        bytes=28u;for(unsigned i=0;i<6u;i++)bytes+=material_u16(p,root+4u+2u*i);
    } else return 0;
    if(bytes>PLUS64_RAM_SIZE-root||p64_metadata_open(p->ram+root,bytes,&metadata->view)!=0)return 0;
    metadata->root=root;metadata->opened=1;return 1;
}

static int material_init(const plus64_t *p,unsigned pattern,unsigned rows,p64_material *m,int compact,const uint8_t *main_ram,p64_draw_metadata *metadata) {
    m->compact=compact;m->stride=compact?16u:70u;m->main_ram=main_ram;m->vm_mode=0u;m->platform=p;
    unsigned binding=compact?material_u16(p,pattern+8u):((unsigned)p->ram[pattern]|((unsigned)(p->ram[pattern+0x45u]&63u)<<8));
    if(binding>PLUS64_RAM_SIZE-8u)return 0;
    if(compact&&p->ram[pattern+10u]>=2u) {
        unsigned mode=p->ram[pattern+10u];
        if(p->dense_material_formats<7u||mode>3u)return 0;
        unsigned root=material_u16(p,binding),key=p->ram[binding+6u],selector=p->ram[binding+7u];
        m->directory=material_u16(p,binding+2u);m->columns=p->ram[binding+4u];m->height=p->ram[binding+5u];
        if(m->columns<1u||m->columns>3u||!m->height||m->height>63u||m->directory>PLUS64_RAM_SIZE-2u*m->columns)return 0;
        m->width=m->columns*24u;m->parts=(m->height+20u)/21u;
        m->mirror=(p->ram[pattern+3u]&1u)!=0u;
        unsigned matches=0u;
        for(unsigned column=0;column<m->columns;column++) {
            unsigned head=material_u16(p,m->directory+column*2u);
            if(head>PLUS64_RAM_SIZE-m->parts*16u)return 0;
            for(unsigned part=0;part<m->parts;part++) {
                unsigned at=head+part*16u;
                if(p->ram[at+10u]!=mode||material_u16(p,at+8u)!=binding||
                   ((p->ram[at+3u]&1u)!=0u)!=m->mirror||
                   !source_decode(p,at,main_ram,m->decoded[column*m->parts+part]))return 0;
                if(at==pattern){m->ox=column*24u;m->oy=part*21u;matches++;}
            }
        }
        if(matches!=1u||m->oy+rows>m->height||!vm_archive(p,root,metadata))return 0;
        unsigned local=p->ram[pattern+5u];
        if(!p64_svm_init(&m->vm,metadata->view.bytes,metadata->view.size,vm_original_sample,m,
                         selector,key,local,mode-2u,m->width,m->height))return 0;
        m->vm_mode=mode;return 1;
    }
    m->recipe=material_u16(p,binding);m->directory=material_u16(p,binding+2u);
    m->columns=p->ram[binding+4u];m->ox=p->ram[binding+5u];
    m->oy=p->ram[binding+6u];m->height=p->ram[binding+7u];
    m->mirror=compact?((p->ram[pattern+3u]&1u)!=0u):(p->ram[pattern+0x41u]==0x82u);
    if(m->columns<1u || m->columns>3u || !m->height || m->height>63u)return 0;
    m->width=m->columns*24u;m->parts=(m->height+20u)/21u;
    if(m->ox%24u || m->oy%21u || m->ox+24u>m->width || m->oy+rows>m->height)return 0;
    if(m->directory>PLUS64_RAM_SIZE-m->columns*2u)return 0;
    for(unsigned column=0;column<m->columns;column++) {
        unsigned head=material_u16(p,m->directory+column*2u);
        if(head>PLUS64_RAM_SIZE-m->parts*m->stride)return 0;
        for(unsigned part=0;part<m->parts;part++) {
            unsigned at=head+part*m->stride;
            if(!dense_part_valid(p,at,compact,main_ram))return 0;
            if(compact&&!source_decode(p,at,main_ram,m->decoded[column*m->parts+part]))return 0;
        }
    }
    if(material_u16(p,m->directory+m->ox/24u*2u)+m->oy/21u*m->stride!=pattern)return 0;
    if(m->recipe>=PLUS64_RAM_SIZE)return 0;
    unsigned recipe_kind=p->ram[m->recipe]&0xc0u;
    m->rectangular=recipe_kind==0xc0u;
    if(recipe_kind!=0x80u && !(m->rectangular && p->dense_material_formats>=4u))return 0;
    m->count=p->ram[m->recipe]&63u;
    if(m->recipe>PLUS64_RAM_SIZE-1u-m->count*4u)return 0;
    unsigned colour_count=0;
    m->colours=m->recipe+1u+m->count*4u;
    for(unsigned i=0;i<m->count;i++) {
        p64_material_rect r;material_rect(p,m,i,&r);
        unsigned limit_x=p->dense_material_formats>=2u ? 72u : m->width;
        unsigned limit_y=p->dense_material_formats>=2u ? 63u : m->height;
        unsigned max_profile=p->dense_material_formats>=3u ? 7u : (p->dense_material_formats>=2u ? 6u : 5u);
        if(r.x0>r.x1 || r.y0>r.y1 || r.x1>=limit_x || r.y1>=limit_y || r.profile>max_profile)return 0;
        if(r.profile==7u && colour_count<=r.component)colour_count=r.component+1u;
    }
    if(colour_count>PLUS64_RAM_SIZE-m->colours)return 0;
    for(unsigned i=0;i<colour_count;i++) {
        unsigned colour=p->ram[m->colours+i];
        if(colour>120u && !(m->rectangular && p->dense_material_formats>=4u
                           && colour>=128u && colour<=248u))return 0;
    }
    return 1;
}

/* The head record determines the same base ink as the existing tall-band
 * path. Origins are re-inferred for every requested record, so unrelated or
 * aliased directory records cannot borrow a validated context accidentally. */
static int draw_material_init(const plus64_t *p,unsigned head,unsigned pattern,unsigned rows,
                              p64_material *m,const uint8_t *main_ram,
                              p64_draw_metadata *metadata,p64_draw_materials *working) {
    if(head>PLUS64_RAM_SIZE-16u||pattern>PLUS64_RAM_SIZE-16u||p->dense_material_formats<7u)return 0;
    unsigned binding=material_u16(p,head+8u),mode=p->ram[head+10u];
    unsigned mirror=(p->ram[head+3u]&1u)!=0u,local=p->ram[head+5u];
    if(mode<2u||mode>3u||binding>PLUS64_RAM_SIZE-8u||
       material_u16(p,pattern+8u)!=binding||p->ram[pattern+10u]!=mode||
       ((p->ram[pattern+3u]&1u)!=0u)!=mirror)return 0;
    unsigned found=working->count;
    for(unsigned i=0;i<working->count;i++) {
        const p64_draw_material_entry *e=&working->entries[i];
        if(e->binding==binding&&e->mode==mode&&e->mirror==mirror&&e->local==local){found=i;break;}
    }
    if(found<working->count) {
        *m=working->entries[found].material;
    } else {
        unsigned head_rows=p->ram[head+7u];if(!head_rows||head_rows>21u)head_rows=21u;
        if(!material_init(p,head,head_rows,m,1,main_ram,metadata))return 0;
        if(working->count<8u) {
            p64_draw_material_entry *e=&working->entries[working->count++];
            e->binding=binding;e->mode=mode;e->mirror=mirror;e->local=local;
            e->material=*m;e->material.vm.user=&e->material;
        }
    }
    unsigned matches=0u;
    for(unsigned column=0;column<m->columns;column++) {
        unsigned first=material_u16(p,m->directory+2u*column);
        for(unsigned part=0;part<m->parts;part++)if(first+16u*part==pattern) {
            m->ox=column*24u;m->oy=part*21u;matches++;
        }
    }
    if(matches!=1u||m->oy+rows>m->height)return 0;
    m->vm.user=m;return 1;
}

/* Sample the original source pair and ink, never a previously shaded pixel. */
static unsigned material_sample(const plus64_t *p,const p64_material *m,unsigned x,unsigned y,uint8_t *ink) {
    unsigned at=material_u16(p,m->directory+x/24u*2u)+y/21u*m->stride;
    unsigned i=y%21u*3u+(x%24u)/8u;
    uint8_t raw=m->compact?m->decoded[x/24u*m->parts+y/21u][i]:p->ram[at+0x3fu-i];
    unsigned pair=(raw>>(6u-2u*((x&7u)/2u)))&3u;
    *ink=pair ? p->ram[at+(m->compact?3u+pair:0x45u-pair)] : 255u;
    return pair;
}

/* VM queries are in the original unmirrored composite domain. The source
 * chain may itself be mirrored; undo only that projection for sampling. */
static unsigned vm_original_sample(void *user,int x,int y,uint8_t *ink) {
    const p64_material *m=(const p64_material *)user;
    if(x<0||y<0||(unsigned)x>=m->width||(unsigned)y>=m->height){*ink=255u;return 0u;}
    unsigned actual=m->mirror?m->width-1u-(unsigned)x:(unsigned)x;
    return material_sample(m->platform,m,actual,(unsigned)y,ink);
}

/* Last matching rectangle wins; region zero is ordinary source colour. */
static int material_select(const plus64_t *p,const p64_material *m,unsigned x,unsigned y,unsigned pair,p64_material_rect *selected) {
    int found=-1;
    for(unsigned i=0;i<m->count;i++) {
        p64_material_rect r;material_rect(p,m,i,&r);
        if(x>=r.x0 && x<=r.x1 && y>=r.y0 && y<=r.y1 && (!r.pair || r.pair==pair)) {
            *selected=r;found=(int)i;
        }
    }
    return found;
}

static uint8_t material_colour(const plus64_t *p,const p64_material *m,unsigned px,unsigned py,unsigned pair,uint8_t ink) {
    unsigned gx=m->ox+px,gy=m->oy+py;
    unsigned x=m->mirror ? m->width-1u-gx : gx;
    if(m->vm_mode)return p64_svm_colour(&m->vm,x,gy);
    p64_material_rect target;
    int selected=material_select(p,m,x,gy,pair,&target);
    if(selected<0 || ink>120u)return ink;
    if(!target.profile) {
        /* Version4 opts profile0 components1..7 into a rectangular relief.
         * Earlier snapshots and component0 keep the original source ink. */
        if(!m->rectangular || p->dense_material_formats<4u || !target.component || !ink)return ink;
        unsigned rx=(target.x1-target.x0)/2u,ry=(target.y1-target.y0)/2u;
        unsigned ex=x-target.x0<target.x1-x ? x-target.x0 : target.x1-x;
        unsigned ey=gy-target.y0<target.y1-gy ? gy-target.y0 : target.y1-gy;
        if(!rx)rx=1u;
        if(!ry)ry=1u;
        unsigned edge=ex*ry<ey*rx ? ex*ry : ey*rx;
        unsigned minimum=target.component-1u;
        unsigned level=minimum+(7u-minimum)*edge/(rx*ry);
        if(level>7u)level=7u;
        return (uint8_t)(1u+((unsigned)ink-1u)%15u+15u*level);
    }
    if((target.profile<=3u || target.profile>=6u) && !ink)return 0; /* outlines need an explicit dark-front region */
    unsigned base=target.profile==7u ? p->ram[m->colours+target.component] : ink;
    if(target.profile==7u && m->rectangular && p->dense_material_formats>=4u
       && (base&128u))return (uint8_t)(base&127u);
    if(target.profile==7u && !base)return 0;
    unsigned hue=base ? 1u+(base-1u)%15u : 1u,level;
    if(target.profile==1u || target.profile>=6u) {
        static const unsigned threshold[6]={2u,4u,5u,8u,9u,10u};
        unsigned distance=10u;
        /* Beyond radius3 every possible squared distance already saturates6. */
        for(int dy=-3;dy<=3;dy++)for(int dx=-3;dx<=3;dx++) {
            int xx=(int)gx+dx,yy=(int)gy+dy;
            unsigned d=(unsigned)(dx*dx+dy*dy);uint8_t other;
            if(d>=distance || xx<0 || yy<0 || xx>=(int)m->width || yy>=(int)m->height)continue;
            if(material_sample(p,m,(unsigned)xx,(unsigned)yy,&other) && !other)distance=d;
        }
        level=0;while(level<6u && distance>=threshold[level])level++;
        if(target.profile>=6u)level=1u+(level+1u)/2u;
        if(target.profile==7u) {
            int shifted=(int)((base-1u)/15u)+(int)level-3;
            if(shifted<0)shifted=0;
            if(shifted>7)shifted=7;
            level=(unsigned)shifted;
        }
    } else {
        unsigned lo=m->width,hi=0;
        for(unsigned xx=0;xx<m->width;xx++) {
            unsigned actual=m->mirror ? m->width-1u-xx : xx;
            uint8_t other;p64_material_rect candidate;
            unsigned other_pair=material_sample(p,m,actual,gy,&other);
            if(!other_pair || other>120u)continue;
            int index=material_select(p,m,xx,gy,other_pair,&candidate);
            if(index<0)continue;
            if(target.component) {
                if(candidate.component!=target.component || candidate.profile!=target.profile || candidate.pair!=target.pair)continue;
            } else if(index!=selected)continue;
            if(xx<lo)lo=xx;
            if(xx>hi)hi=xx;
        }
        if(lo>hi || x<lo || x>hi)return ink;
        unsigned width=hi-lo+1u;
        if(target.profile==2u || target.profile==3u) {
            level=7u;
            if(width>(target.profile==3u ? 4u : 2u)) {
                unsigned depth=target.profile==3u || width<=4u ? 1u : 2u;
                unsigned edge=x-lo<hi-x ? x-lo : hi-x;
                level=7u-depth+(2u*depth*edge+width-2u)/(width-1u);
                if(level>7u)level=7u;
            }
        } else {
            int delta=(int)(2u*x)-(int)(lo+hi);
            unsigned denominator=(width+1u)*(width+1u);
            unsigned front=denominator-(unsigned)(delta*delta);
            unsigned gain=target.profile==4u ? 16u : 72u;
            unsigned divisor=target.profile==4u ? 5u : 25u;
            level=gain*front/(divisor*denominator);
            if(level>3u)level=3u;
            hue=1u;
        }
    }
    return (uint8_t)(hue+15u*level);
}

/* Sparse RAW64: 63 bitmap bytes compressed by zero-byte omission, with
 * optional inclusive palette rectangles. All data is in the existing inverse
 * RAW64 cache metadata; no texture bank, game IDs or guest RAM is added.
 * Header A7, occupancy offset (3+4*n), base colour/material; n rectangles
 * packed20-bit x0/y0/x1/y1, colour/material; eight occupancy bytes in reverse bitmap-byte
 * order, then the nonzero values in that order. Byte63 is orientation1/80.
 * Decode into a transient host mask, never a second guest payload. */
static int sparse_mask(const plus64_t *p, unsigned at, uint8_t mask[63], unsigned *rects) {
    unsigned start=p->ram[at+0x23eu], value, n;
    if (p->ram[at+0x23fu]!=0xa7u || start<3u || (start-3u)%4u) return -1;
    n=(start-3u)/4u;
    if (n>10u || start+8u>63u) return -1;
    for (unsigned i=0;i<n;i++) {
        unsigned r=at+0x23cu-4u*i;
        unsigned bounds=(unsigned)p->ram[r]|((unsigned)p->ram[r-1u]<<8)|((unsigned)p->ram[r-2u]<<16);
        unsigned x0=bounds&31u, y0=(bounds>>5)&31u;
        unsigned x1=(bounds>>10)&31u, y1=(bounds>>15)&31u;
        if (bounds>>20 || x0>x1 || y0>y1 || x1>23u || y1>20u
            || (p->ram[r-3u]&127u)>120u) return -1;
    }
    if ((p->ram[at+0x23du]&127u)>120u) return -1;
    value=start+8u;
    for (unsigned i=0;i<63u;i++) {
        unsigned flags=p->ram[at+0x23fu-start-i/8u];
        mask[62u-i]=0;
        if (flags & (128u>>(i&7u))) {
            if (value>=63u) return -1;
            mask[62u-i]=p->ram[at+0x23fu-value++];
        }
    }
    *rects=n;
    return 0;
}

void plus64_bind_ram(plus64_t *p, uint8_t *ram) { p->ram=ram; }
void plus64_reset(plus64_t *p) { memset(p->regs,0,sizeof(p->regs)); p->collision=0; }

void plus64_write(plus64_t *p, uint16_t a, uint8_t v) {
    if (a < PLUS64_BASE || a > PLUS64_END) return;
    unsigned r = a - PLUS64_BASE;
    if (r == 1) return;  /* collision latch is read-only */
    p->regs[r] = v;
    if (r == 6) { /* $FD96: sprite RAM data, with auto-increment */
        unsigned at = (unsigned)p->regs[7] | ((unsigned)p->regs[8] << 8);
        if (p->ram) p->ram[at & (PLUS64_RAM_SIZE - 1)] = v;
        ++at;
        p->regs[7] = (uint8_t)at;
        p->regs[8] = (uint8_t)(at >> 8);
    }
}

uint8_t plus64_read(plus64_t *p, uint16_t a) {
    if (a < PLUS64_BASE || a > PLUS64_END) return 0xff;
    unsigned r = a - PLUS64_BASE;
    if (r == 1) { uint8_t v = p->collision; p->collision = 0; return v; }
    if (r == 6) {
        unsigned at = (unsigned)p->regs[7] | ((unsigned)p->regs[8] << 8);
        uint8_t v = p->ram ? p->ram[at & (PLUS64_RAM_SIZE - 1)] : 0xff;
        ++at;
        p->regs[7] = (uint8_t)at;
        p->regs[8] = (uint8_t)(at >> 8);
        return v;
    }
    return p->regs[r];
}

static void draw_masked_common(plus64_t *p, uint8_t *frame, uint8_t *alpha, size_t stride, int packed_cache, int deferred, uint8_t *line_collisions, int left_mcm,const uint8_t *main_ram) {
    /* Registered sprites overlap by per-pixel occupancy. Earlier sprite wins.
       $FD90: enable; $FD92: multi mask reserved; $FD93: expand X;
       $FD94: expand Y; $FD95: behind-background reserved.
       8 sprites x 6 registers starting $FDA0, pattern 63 bytes each.
       Screen coordinates are 320x200 logical pixels, not PAL beam clocks. */
    const unsigned left_margin=left_mcm ? 24u : 0u;
    const unsigned collision_width=(line_collisions ? 512u : PLUS64_WIDTH)+left_margin;
    uint8_t occupied[collision_width * PLUS64_HEIGHT];
    uint16_t visible[collision_width * PLUS64_HEIGHT];
    if (line_collisions) memset(line_collisions,0,PLUS64_HEIGHT);
    memset(occupied, 0, sizeof(occupied));
    memset(visible, 0, sizeof(visible));
    /* Collision latch remains set until CPU reads $FD91. */
    if (alpha) memset(alpha, 0, stride*PLUS64_HEIGHT);
    if (!p->ram) return;
    p64_draw_metadata metadata;memset(&metadata,0,sizeof(metadata));
    p64_draw_materials working;working.count=0u;
    for (unsigned s=0; s<8; ++s) {
        if (!(p->regs[0] & (1u << s))) continue;
        const unsigned b=0x10u + s*6u;
        int x=(int)p->regs[b] + ((p->regs[b+2] & 1u) ? 256 : 0);
        int y=p->regs[b+1];
        uint8_t col=p->regs[b+3] & 0x7fu;
        unsigned pattern=((unsigned)p->regs[b+4] | ((unsigned)p->regs[b+5]<<8)) & (PLUS64_RAM_SIZE-1);
        /* New opt-in only. Do not round an arbitrary pointer to a record.
           Existing HIRES pointer/color semantics remain below, unchanged. */
        unsigned raw_pattern=(unsigned)p->regs[b+4] | ((unsigned)p->regs[b+5]<<8);
        int raw8_mixed = p->extended_formats && packed_cache
            && (p->regs[2] & (1u<<s))
            && (raw_pattern & 0xc000u)==PLUS64_RAW8_TAG;
        int stream_mcm=p->extended_formats&&p->dense_formats&&p->dense_material_formats>=5u&&packed_cache
            &&(p->regs[2]&(1u<<s))&&(raw_pattern&0xc000u)==PLUS64_SOURCE_MCM_TAG;
        unsigned part_stride=stream_mcm?16u:70u;
        int dense_mcm = stream_mcm || (p->extended_formats && p->dense_formats && packed_cache
            && (p->regs[2] & (1u<<s))
            && (raw_pattern & 0xc000u)==PLUS64_DENSE_MCM_TAG);
        unsigned packed_bias=dense_mcm ? 0u : 0x200u;
        uint8_t tone_base=col;
        int tonal = p->extended_formats && packed_cache && !raw8_mixed
            && (p->regs[b+3] & PLUS64_TONE_MASK);
        int packed = packed_cache && !raw8_mixed && (p->regs[2] & (1u<<s));
        int diagonal = packed && p->extended_formats && p->diagonal_lighting
            && p->light_directions && ((p->regs[9u+s/2u]>>((s&1u)*4u))&15u)==10u;
        int collision_only=0,occluding=0;
        int xmin=23,ymin=20,xmax=0,ymax=0;
        int hires_packed = left_mcm && packed_cache && !(p->regs[2] & (1u<<s));
        int sparse=hires_packed && p->sparse_formats && p->regs[b+3]==0xf9u;
        uint8_t sparse_bits[63]; unsigned sparse_rects=0;
        /* Tagged RAW8 must fit; never wrap a partial image across the bank. */
        if (raw8_mixed && pattern>PLUS64_RAM_SIZE-504u) continue;
        /* Tagged dense records have no alignment requirement, but every
           source and metadata byte must belong to the existing16KiB view. */
        if (dense_mcm && pattern>PLUS64_RAM_SIZE-part_stride) continue;
        unsigned source_height=21u,dense_parts=1u;
        p64_material materials[12];
        uint8_t material_parts[12]={0};
        uint8_t decoded_parts[12][63];
        int dense_height=dense_mcm && p->dense_height_formats;
        if (dense_height) {
            unsigned height=p->ram[pattern+(stream_mcm?7u:0x40u)];
            if (height>252u) continue;
            source_height=height ? height : 21u;
            dense_parts=(source_height+20u)/21u;
            if (pattern>PLUS64_RAM_SIZE-dense_parts*part_stride) continue;
        }
        int dense_tall=dense_height && source_height>21u;
        /* The opted-in publisher maps VIC Y to (rawY-50) modulo256.
           Its positive outputs never exceed205. Tall dense images therefore
           use206..255 for -50..-1. Every existing21-row path keeps215..255
           for -41..-1, including expanded images. */
        if (left_mcm && packed_cache && y>=(dense_tall?206:215)) y-=256;
        if (hires_packed) {
            unsigned raw_pattern=(unsigned)p->regs[b+4] | ((unsigned)p->regs[b+5]<<8);
            if (raw_pattern != pattern || (pattern & 1023u) != 0
                || p->ram[pattern+0x245u] != 0xa5
                || p->ram[pattern+0x241u] != 0
                || p->ram[pattern+0x240u] > 23) continue;
        }
        if (sparse) {
            tonal=0;
            /* The game's ordinary bitmap/death buffers can retain this
               descriptor selector while using a plain mask. Their fallback
               ink is the existing cached shared1 colour. */
            if (p->ram[pattern+0x23fu]!=0xa7u) {
                sparse=0;
                col=p->ram[pattern+0x242u];
                if (col>120u) continue;
            } else if (sparse_mask(p,pattern,sparse_bits,&sparse_rects)<0) continue;
        }
        if (packed) {
            unsigned raw_pattern=(unsigned)p->regs[b+4] | ((unsigned)p->regs[b+5]<<8);
            if (dense_mcm) {
                if(!dense_height && p->ram[pattern+(stream_mcm?7u:0x40u)]!=0)continue;
                int valid=1;
                for (unsigned part=0;part<dense_parts;part++) {
                    unsigned at=pattern+part*part_stride;
                    if(stream_mcm&&p->ram[pattern+10u]>=2u) {
                        unsigned rows=source_height-part*21u;if(rows>21u)rows=21u;
                        if(!draw_material_init(p,pattern,at,rows,&materials[part],main_ram,&metadata,&working)) {valid=0;break;}
                        if(part&&(materials[part].ox!=materials[0].ox||materials[part].oy!=materials[0].oy+part*21u)) {valid=0;break;}
                        unsigned index=materials[part].ox/24u*materials[part].parts+materials[part].oy/21u;
                        if(index>=9u){valid=0;break;}
                        memcpy(decoded_parts[part],materials[part].decoded[index],63u);
                        material_parts[part]=1u;continue;
                    }
                    /* Decoding a compact record already validates its full
                       envelope and source; do not expand the same block twice. */
                    if(!stream_mcm&&!dense_part_valid(p,at,0,main_ram)) {valid=0;break;}
                    if(stream_mcm&&!source_decode(p,at,main_ram,decoded_parts[part])){valid=0;break;}
                    if(stream_mcm?p->ram[at+10u]!=0u:p->ram[at+0x41u]!=1u) {
                        unsigned rows=source_height-part*21u;
                        if(rows>21u)rows=21u;
                        material_parts[part]=1;
                        if(stream_mcm&&part&&material_parts[0]&&materials[0].vm_mode) {
                            /* The first band validated the whole composite.
                               Reuse only its transient execution state for the
                               remaining bands in this same source column. */
                            unsigned origin=materials[0].oy+part*21u;
                            if(p->ram[at+10u]!=materials[0].vm_mode||
                               material_u16(p,at+8u)!=material_u16(p,pattern+8u)||
                               ((p->ram[at+3u]&1u)!=0u)!=materials[0].mirror||
                               origin+rows>materials[0].height) {valid=0;break;}
                            materials[part]=materials[0];materials[part].oy=origin;
                            materials[part].vm.user=&materials[part];
                        } else if(!material_init(p,at,rows,&materials[part],stream_mcm,main_ram,&metadata)) {valid=0;break;}
                    }
                }
                if (!valid) continue;
            } else {
                if(raw_pattern!=pattern || (pattern&1023u)!=0
                    || p->ram[pattern+packed_bias+0x45u]!=0xa5u
                    || p->ram[pattern+packed_bias+0x41u]!=1u
                    || p->ram[pattern+packed_bias+0x40u]!=0)continue;
            }
            /* Explicit opt-in projection of original raw VIC X0..23.
               Valid unexpanded source descriptors otherwise use X0..487. */
            if (left_mcm && x>=488) x-=512;
        }
        /* Software-owned byte63: new 80..F8 tags select colour0..120.
           Legacy snapshots retain 81..8F hue tags. FF orientation remains
           ordinary data in both formats; all64 bytes stay in the key. */
        if(material_parts[0])tonal=0;
        if (packed && p->extended_formats && !dense_tall && !material_parts[0]) {
            uint8_t tag=stream_mcm?0u:p->ram[pattern+packed_bias];
            occluding=p->collision_only_formats>=2u && tag==0xfau;
            collision_only=occluding || (p->collision_only_formats && tag==0xf9u);
            if (p->material_full_palette) {
                if (tag>=0x80u && tag<=0xf8u) {
                    tonal=1;
                    tone_base=tag & 0x7fu;
                }
            } else if ((tag & 0xf0u)==0x80u && (tag & 15u)) {
                tonal=1;
                tone_base=tag & 15u;
            }
        }
        if (diagonal && !dense_tall && !material_parts[0]) {
            int found=0;
            tonal=0; /* profile10 preserves all three original inks */
            for (int my=0;my<21;my++) for(int mx=0;mx<24;mx+=2) {
                unsigned i=(unsigned)my*3u+(unsigned)mx/8u;
                uint8_t raw=stream_mcm?decoded_parts[0][i]:p->ram[pattern+packed_bias+0x3fu-i];
                unsigned pair=(raw>>(6u-2u*(((unsigned)mx&7u)/2u)))&3u;
                if(!pair)continue;
                if(mx<xmin)xmin=mx;
                if(mx+1>xmax)xmax=mx+1;
                if(my<ymin)ymin=my;
                if(my>ymax)ymax=my;
                found=1;
            }
            if(!found)continue;
        }
        if (!dense_tall && tonal && tone_base>120u) continue;
        if (raw8_mixed && left_mcm && x>=488) x-=512;
        int sx=(p->regs[3] & (1u<<s)) ? 2 : 1;
        /* Original raw VIC X0..23 projects to -24..-1. Expanded HIRES
           beams have visible pixels even at rawX0. Positive native
           descriptors from this publisher never exceed487. Keep the
           existing packed-MCM validity and all default paths unchanged. */
        if (left_mcm && packed_cache && !(p->regs[2] & (1u<<s))
            && sx==2 && x>=488) x-=512;
        int sy=(p->regs[4] & (1u<<s)) ? 2 : 1;
        int part_valid=1;
        for (int py=0; py<(int)source_height; ++py) {
            int source_py=dense_tall ? py%21 : py;
            unsigned part_pattern=pattern+(dense_tall ? (unsigned)(py/21)*part_stride : 0u);
            unsigned part_index=dense_tall ? (unsigned)(py/21) : 0u;
            int authored=material_parts[part_index]!=0;
            if (dense_tall && source_py==0) {
                uint8_t tag=stream_mcm?0u:p->ram[part_pattern];
                tone_base=p->regs[b+3]&127u;
                tonal=(p->regs[b+3]&PLUS64_TONE_MASK)!=0;
                occluding=p->collision_only_formats>=2u && tag==0xfau;
                collision_only=occluding || (p->collision_only_formats && tag==0xf9u);
                if(authored) {tonal=0;occluding=0;collision_only=0;}
                else if (p->material_full_palette) {
                    if (tag>=0x80u && tag<=0xf8u) {tonal=1;tone_base=tag&127u;}
                } else if ((tag&0xf0u)==0x80u && (tag&15u)) {tonal=1;tone_base=tag&15u;}
                part_valid=!(tonal && tone_base>120u);
                if (diagonal && !authored) {
                    int found=0;
                    tonal=0;xmin=23;ymin=20;xmax=0;ymax=0;
                    for (int my=0;my<21;my++) for(int mx=0;mx<24;mx+=2) {
                        unsigned i=(unsigned)my*3u+(unsigned)mx/8u;
                        uint8_t raw=stream_mcm?decoded_parts[part_index][i]:p->ram[part_pattern+0x3fu-i];
                        unsigned pair=(raw>>(6u-2u*(((unsigned)mx&7u)/2u)))&3u;
                        if (!pair) continue;
                        if (mx<xmin) xmin=mx;
                        if (mx+1>xmax) xmax=mx+1;
                        if (my<ymin) ymin=my;
                        if (my>ymax) ymax=my;
                        found=1;
                    }
                    part_valid=found;
                }
            }
            if (!part_valid) continue;
            for (int px=0; px<24; ++px) {
            unsigned source_pair=0;
            if (p->regs[2] & (1u<<s)) {
                if (packed) {
                    unsigned i=(unsigned)source_py*3u + (unsigned)px/8u;
                    uint8_t raw=stream_mcm?decoded_parts[part_index][i]:p->ram[part_pattern+packed_bias+0x3fu-i];
                    unsigned pair=(raw >> (6u-2u*(((unsigned)px&7u)/2u))) & 3u;
                    source_pair=pair;
                    /* pair0 is transparent; preserve full8-bit key colors.
                       Tag63 at+200 is not an image byte. */
                    /* A selected material replaces the three source inks. Its
                       opacity depends only on pair0, never on a source ink
                       that software may tag as an extended descriptor. */
                    col=pair ? (tonal ? 0 : p->ram[part_pattern+(stream_mcm?3u+pair:packed_bias+0x45u-pair)]) : 255;
                } else {
                    unsigned byte=(pattern + py*24u + (unsigned)px) & (PLUS64_RAM_SIZE-1);
                    col=p->ram[byte];
                }
                if (col>120) continue;
            } else if (hires_packed) {
                /* Existing inverse RAW64 metadata: no second bitmap upload.
                   Reproduce the old CPU's logical left shift exactly; the
                   shifted-out right tail is transparent, not wrapped. */
                unsigned source_x=(unsigned)px+p->ram[pattern+0x240u];
                if (source_x>=24) continue;
                unsigned material_x=source_x;
                if (sparse && (p->ram[pattern+0x200u]&128u)) material_x=23u-source_x;
                unsigned i=(unsigned)py*3u+material_x/8u;
                uint8_t bits=sparse ? sparse_bits[i] : p->ram[pattern+0x23fu-i];
                if (!(bits & (0x80u>>(material_x&7u)))) continue;
                if (sparse) {
                    uint8_t material=p->ram[pattern+0x23du];
                    for (unsigned r=0;r<sparse_rects;r++) {
                        unsigned q=pattern+0x23cu-4u*r;
                        unsigned bounds=(unsigned)p->ram[q]|((unsigned)p->ram[q-1u]<<8)|((unsigned)p->ram[q-2u]<<16);
                        if (material_x>=(bounds&31u) && (unsigned)py>=((bounds>>5)&31u)
                            && material_x<=((bounds>>10)&31u) && (unsigned)py<=((bounds>>15)&31u)) material=p->ram[q-3u];
                    }
                    if ((material&128u) && p->front_mask_profile && light_direction(p,s)==9u)
                        col=front_mask_colour(material&127u,sparse_bits,(int)material_x,py);
                    else col=(material&128u) ? tone_colour(p,s,material&127u,light_direction(p,s) ? px : (int)material_x,py,1) : material;
                }
            } else {
                unsigned byte=(pattern + py*3u + (unsigned)px/8u) & (PLUS64_RAM_SIZE-1);
                if (!(p->ram[byte] & (0x80u >> (px&7)))) continue;
            }
            if(authored)col=material_colour(p,&materials[part_index],(unsigned)px,(unsigned)source_py,source_pair,col);
            else {
                if (diagonal) col=diagonal_colour(col,px,source_py,xmin,ymin,xmax,ymax);
                if (tonal) col=tone_colour(p,s,tone_base,px,source_py,p->material_full_palette);
            }
            if(authored&&materials[part_index].vm_mode&&col==255u)continue;
            for (int ey=0; ey<sy; ++ey) for (int ex=0; ex<sx; ++ex) {
                int xx=x+px*sx+ex, yy=y+py*sy+ey;
                if (xx<-(int)left_margin || xx>=(int)(collision_width-left_margin) || yy<0 || yy>=PLUS64_HEIGHT) continue;
                unsigned off=(unsigned)yy * collision_width + (unsigned)(xx+(int)left_margin);
                if (occupied[off]) {
                    if (line_collisions) line_collisions[yy] |= (uint8_t)(occupied[off] | (1u << s));
                    if (!deferred) p->collision |= (uint8_t)(occupied[off] | (1u << s));
                }
                if (!collision_only && !visible[off] && xx>=0 && xx<PLUS64_WIDTH) {
                    /* First enabled sprite has display priority. */
                    frame[(size_t)yy * stride + (size_t)xx] = col;
                    if (alpha) alpha[(size_t)yy * stride + (size_t)xx] = 1;
                }
                /* Still track every sprite for three-way overlaps. */
                occupied[off] |= (uint8_t)(1u << s);
                /* A hidden occluder retains display priority without emitting
                   alpha: later sprites reveal the original scene behind it. */
                if (occluding && !visible[off]) visible[off]=256u;
                if (!collision_only && !(visible[off]&256u)) visible[off] |= (uint8_t)(1u << s);
                if (alpha && deferred && xx>=0 && xx<PLUS64_WIDTH) alpha[(size_t)yy * stride + (size_t)xx] = (uint8_t)visible[off];
            }
        }
        }
    }
    p64_metadata_close(&metadata.view);
}

void plus64_draw_masked(plus64_t *p, uint8_t *frame, uint8_t *alpha, size_t stride) {
    draw_masked_common(p,frame,alpha,stride,0,0,NULL,0,NULL);
}

void plus64_draw_masked_packed_cache(plus64_t *p, uint8_t *frame, uint8_t *alpha, size_t stride) {
    draw_masked_common(p,frame,alpha,stride,1,0,NULL,0,NULL);
}

void plus64_draw_masked_deferred(plus64_t *p, uint8_t *frame, uint8_t *alpha, size_t stride, int packed_cache) {
    draw_masked_common(p,frame,alpha,stride,packed_cache != 0,1,NULL,0,NULL);
}

void plus64_draw_masked_left_mcm(plus64_t *p, uint8_t *frame, uint8_t *alpha, size_t stride, int packed_cache, int deferred, uint8_t *line_collisions) {
    draw_masked_common(p,frame,alpha,stride,packed_cache != 0,deferred,line_collisions,1,NULL);
}

void plus64_draw_masked_deferred_border(plus64_t *p, uint8_t *frame, uint8_t *alpha, size_t stride, int packed_cache, uint8_t *line_collisions) {
    draw_masked_common(p,frame,alpha,stride,packed_cache != 0,1,line_collisions,0,NULL);
}

void plus64_draw_masked_main(plus64_t *p,uint8_t *frame,uint8_t *alpha,size_t stride,int packed_cache,int deferred,uint8_t *line_collisions,int left_mcm,const uint8_t *main_ram) {
    draw_masked_common(p,frame,alpha,stride,packed_cache!=0,deferred,line_collisions,left_mcm!=0,main_ram);
}

void plus64_latch_masked_line(plus64_t *p, const uint8_t *masks, size_t stride, unsigned int y) {
    if (!masks || stride < PLUS64_WIDTH || y >= PLUS64_HEIGHT) return;
    const uint8_t *line=masks+(size_t)y*stride;
    for (unsigned x=0; x<PLUS64_WIDTH; ++x) {
        uint8_t m=line[x];
        if (m & (uint8_t)(m-1u)) p->collision |= m;
    }
}

int plus64_prepare_packed_cache_switch(plus64_t *p) {
    if (p->regs[0] != 0) return -1;
    if (p->ram) for (unsigned r=0; r<16; ++r) p->ram[r*1024u+0x245u]=0;
    return 0;
}

void plus64_draw(plus64_t *p, uint8_t *frame, size_t stride) {
    plus64_draw_masked(p,frame,NULL,stride);
}
