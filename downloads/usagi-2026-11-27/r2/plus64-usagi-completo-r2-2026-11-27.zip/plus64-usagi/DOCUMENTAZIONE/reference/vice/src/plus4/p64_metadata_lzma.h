/* Optional bounded, temporary expansion of generic guest metadata. */
#ifndef P64_METADATA_LZMA_H
#define P64_METADATA_LZMA_H
#include <stddef.h>
#include <stdint.h>
#define P64_LZMA_FORMAT_ERROR (-4)
#define P64_LZMA_MEMORY_ERROR (-5)
typedef struct {
    const uint8_t *bytes;
    size_t size;
    uint8_t *owned;
} p64_metadata_lzma_view;
/* P64Z version1 method2: ordinary12-byte header, then5 LZMA properties,
 * EOS-terminated LZMA1 stream, then little-endian CRC32 of expanded metadata.
 * Raw/stored lengths are16-bit; reserved header word is zero. This optional
 * helper accepts only method2. Existing raw/method1 behavior stays external.
 * The caller must close the view on every path within its rendering call.
 * Never retain it in global state, a guest buffer, or a snapshot. */
int p64_metadata_lzma_open(const uint8_t *guest,size_t guest_bytes,
                           p64_metadata_lzma_view *view);
void p64_metadata_lzma_close(p64_metadata_lzma_view *view);
#endif
