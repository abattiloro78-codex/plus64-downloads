/*
 * ted-timer.c - Timer implementation for the TED emulation.
 *
 * Written by
 *  Andreas Boose <viceteam@t-online.de>
 *
 * This file is part of VICE, the Versatile Commodore Emulator.
 * See README for copyright notice.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
 *  02111-1307  USA.
 *
 */

#include "vice.h"

#include <stdio.h>

#include "alarm.h"
#include "log.h"
#include "maincpu.h"
#include "ted-irq.h"
#include "ted-timer.h"
#include "tedtypes.h"
#include "ted.h"
#include "types.h"
#include "ted-snapshot-wire.h"


/*#define DEBUG_TIMER*/


static alarm_t *ted_t1_alarm = NULL;
static alarm_t *ted_t2_alarm = NULL;
static alarm_t *ted_t3_alarm = NULL;

/* static CLOCK t1_start; */
static CLOCK t2_start;
static CLOCK t3_start;

static CLOCK t1_last_restart;
static CLOCK t2_last_restart;
static CLOCK t3_last_restart;

static CLOCK t1_value;
static CLOCK t2_value;
static CLOCK t3_value;

/*-----------------------------------------------------------------------*/

static void ted_t1_alarm_handler(CLOCK offset, void *data)
{
    alarm_set(ted_t1_alarm, maincpu_clk
              + (ted.t1_start == 0 ? 65536 : ted.t1_start) * 2 - offset);
    t1_value = (ted.t1_start == 0 ? 65536 : ted.t1_start) * 2 - offset;
#ifdef DEBUG_TIMER
    log_debug(LOG_DEFAULT, "TI1 ALARM %x", maincpu_clk);
#endif
    ted_irq_timer1_set();
    t1_last_restart = maincpu_clk - offset;
}

static void ted_t2_alarm_handler(CLOCK offset, void *data)
{
    alarm_set(ted_t2_alarm, maincpu_clk + 65536 * 2 - offset);
    t2_start = 0;
    t2_value = 65536 * 2 - offset;
#ifdef DEBUG_TIMER
    log_debug(LOG_DEFAULT, "TI2 ALARM %x", maincpu_clk);
#endif
    ted_irq_timer2_set();
    t2_last_restart = maincpu_clk - offset;
}

static void ted_t3_alarm_handler(CLOCK offset, void *data)
{
    alarm_set(ted_t3_alarm, maincpu_clk + 65536 * 2 - offset);
    t3_start = 0;
    t3_value = 65536 * 2 - offset;
#ifdef DEBUG_TIMER
    log_debug(LOG_DEFAULT, "TI3 ALARM %x", maincpu_clk);
#endif
    ted_irq_timer3_set();
    t3_last_restart = maincpu_clk - offset;
}

/*-----------------------------------------------------------------------*/

static void ted_timer_t1_store_low(uint8_t value)
{
    alarm_unset(ted_t1_alarm);
    if (ted.timer_running[0]) {
        t1_value -= maincpu_clk - t1_last_restart;
        t1_last_restart = maincpu_clk;
    }
    t1_value = (ted.t1_start = (ted.t1_start & 0xff00) | value) << 1;
    ted.timer_running[0] = 0;
}

static void ted_timer_t1_store_high(uint8_t value)
{
    alarm_unset(ted_t1_alarm);
    t1_value = (ted.t1_start = (ted.t1_start & 0x00ff) | (value << 8)) << 1;
    alarm_set(ted_t1_alarm, maincpu_clk
              + (ted.t1_start == 0 ? 65536 : ted.t1_start) * 2);
    t1_last_restart = maincpu_clk;
    ted.timer_running[0] = 1;
}

static void ted_timer_t2_store_low(uint8_t value)
{
    alarm_unset(ted_t2_alarm);
    t2_value = (t2_start = (t2_start & 0xff00) | value) << 1;
    ted.timer_running[1] = 0;
}

static void ted_timer_t2_store_high(uint8_t value)
{
    alarm_unset(ted_t2_alarm);
    t2_value = (t2_start = (t2_start & 0x00ff) | (value << 8)) << 1;
    alarm_set(ted_t2_alarm, maincpu_clk
              + (t2_start == 0 ? 65536 : t2_start) * 2);
    t2_last_restart = maincpu_clk;
    ted.timer_running[1] = 1;
}

static void ted_timer_t3_store_low(uint8_t value)
{
    alarm_unset(ted_t3_alarm);
    t3_value = (t3_start = (t3_start & 0xff00) | value) << 1;
    ted.timer_running[2] = 0;
}

static void ted_timer_t3_store_high(uint8_t value)
{
    alarm_unset(ted_t3_alarm);
    t3_value = (t3_start = (t3_start & 0x00ff) | (value << 8)) << 1;
    alarm_set(ted_t3_alarm, maincpu_clk
              + (t3_start == 0 ? 65536 : t3_start) * 2);
    t3_last_restart = maincpu_clk;
    ted.timer_running[2] = 1;
}

static uint8_t ted_timer_t1_read_low(void)
{
#ifdef DEBUG_TIMER
    log_debug(LOG_DEFAULT, "TI1 READL %02x", t1_value & 0xff);
#endif
    if (ted.timer_running[0]) {
        t1_value -= maincpu_clk - t1_last_restart;
        t1_last_restart = maincpu_clk;
    }
    return (uint8_t)(t1_value >> 1);
}

static uint8_t ted_timer_t1_read_high(void)
{
#ifdef DEBUG_TIMER
    log_debug(LOG_DEFAULT, "TI1 READH %02x", t1_value >> 8);
#endif
    if (ted.timer_running[0]) {
        t1_value -= maincpu_clk - t1_last_restart;
        t1_last_restart = maincpu_clk;
    }
    return (uint8_t)(t1_value >> 9);
}

static uint8_t ted_timer_t2_read_low(void)
{
#ifdef DEBUG_TIMER
    log_debug(LOG_DEFAULT, "TI2 READL %02x", t2_value & 0xff);
#endif
    if (ted.timer_running[1]) {
        t2_value -= maincpu_clk - t2_last_restart;
        t2_last_restart = maincpu_clk;
    }
    return (uint8_t)(t2_value >> 1);
}

static uint8_t ted_timer_t2_read_high(void)
{
#ifdef DEBUG_TIMER
    log_debug(LOG_DEFAULT, "TI2 READH %02x", t2_value >> 8);
#endif
    if (ted.timer_running[1]) {
        t2_value -= maincpu_clk - t2_last_restart;
        t2_last_restart = maincpu_clk;
    }
    return (uint8_t)(t2_value >> 9);
}

static uint8_t ted_timer_t3_read_low(void)
{
#ifdef DEBUG_TIMER
    log_debug(LOG_DEFAULT, "TI3 READL %02x", t3_value & 0xff);
#endif
    if (ted.timer_running[2]) {
        t3_value -= maincpu_clk - t3_last_restart;
        t3_last_restart = maincpu_clk;
    }
    return (uint8_t)(t3_value >> 1);
}

static uint8_t ted_timer_t3_read_high(void)
{
#ifdef DEBUG_TIMER
    log_debug(LOG_DEFAULT, "TI3 READH %02x", t3_value >> 8);
#endif
    if (ted.timer_running[2]) {
        t3_value -= maincpu_clk - t3_last_restart;
        t3_last_restart = maincpu_clk;
    }
    return (uint8_t)(t3_value >> 9);
}

/*-----------------------------------------------------------------------*/

void ted_timer_store(uint16_t addr, uint8_t value)
{
#ifdef DEBUG_TIMER
    log_debug(LOG_DEFAULT, "TI STORE %02x %02x CLK %x", addr, value, maincpu_clk);
#endif
    switch (addr) {
        case 0:
            ted_timer_t1_store_low(value);
            break;
        case 1:
            ted_timer_t1_store_high(value);
            break;
        case 2:
            ted_timer_t2_store_low(value);
            break;
        case 3:
            ted_timer_t2_store_high(value);
            break;
        case 4:
            ted_timer_t3_store_low(value);
            break;
        case 5:
            ted_timer_t3_store_high(value);
            break;
    }
}

uint8_t ted_timer_read(uint16_t addr)
{
    switch (addr) {
        case 0:
            return ted_timer_t1_read_low();
        case 1:
            return ted_timer_t1_read_high();
        case 2:
            return ted_timer_t2_read_low();
        case 3:
            return ted_timer_t2_read_high();
        case 4:
            return ted_timer_t3_read_low();
        case 5:
            return ted_timer_t3_read_high();
    }
    return 0;
}

void ted_timer_init(void)
{
    ted.t1_start = 0;
    ted_t1_alarm = alarm_new(maincpu_alarm_context, "TED T1", ted_t1_alarm_handler, NULL);
    ted_t2_alarm = alarm_new(maincpu_alarm_context, "TED T2", ted_t2_alarm_handler, NULL);
    ted_t3_alarm = alarm_new(maincpu_alarm_context, "TED T3", ted_t3_alarm_handler, NULL);
}

void ted_timer_reset(void)
{
    alarm_unset(ted_t1_alarm);
    ted.t1_start = 0;
    alarm_unset(ted_t2_alarm);
    alarm_unset(ted_t3_alarm);
}

/* Snapshot-only access to the otherwise private timer state. Ordinary
 * execution, reads, reloads, IRQs and timing above are unchanged. */
typedef struct ted_timer_snapshot_state_s {
    CLOCK clock;
    CLOCK start[3];
    CLOCK value[3];
    CLOCK restart[3];
    uint8_t running[3];
    uint8_t pending[3];
    CLOCK deadline[3];
} ted_timer_snapshot_state_t;

static int ted_timer_snapshot_decode(snapshot_t *s, int required,
                                     ted_timer_snapshot_state_t *state)
{
    uint8_t payload[TED_TIMER_SNAPSHOT_PAYLOAD];
    unsigned at = 0;
    int result = ted_snap_read(s, TED_TIMER_SNAPSHOT_MODULE, "TMR8", payload,
                              sizeof(payload), required);
    if (result != 0) {
        return result;
    }
    state->clock = (CLOCK)ted_snap_get(payload, &at, 8);
    for (unsigned i = 0; i < 3; ++i) state->start[i] = (CLOCK)ted_snap_get(payload, &at, 8);
    for (unsigned i = 0; i < 3; ++i) state->value[i] = (CLOCK)ted_snap_get(payload, &at, 8);
    for (unsigned i = 0; i < 3; ++i) state->restart[i] = (CLOCK)ted_snap_get(payload, &at, 8);
    for (unsigned i = 0; i < 3; ++i) state->running[i] = payload[at++];
    for (unsigned i = 0; i < 3; ++i) state->pending[i] = payload[at++];
    for (unsigned i = 0; i < 3; ++i) state->deadline[i] = (CLOCK)ted_snap_get(payload, &at, 8);
    for (unsigned i = 0; i < 3; ++i) {
        if (state->start[i] > 65535u || state->running[i] > 1
            || state->pending[i] > 1 || (!state->pending[i] && state->deadline[i] != 0)
            || (state->pending[i] && state->deadline[i] == CLOCK_MAX)) {
            snapshot_set_error(SNAPSHOT_MODULE_INCOMPATIBLE);
            return -1;
        }
    }
    return at == sizeof(payload) ? 0 : -1;
}

int ted_timer_snapshot_write_module(snapshot_t *s)
{
    uint8_t payload[TED_TIMER_SNAPSHOT_PAYLOAD];
    unsigned at = 0;
    alarm_t *alarms[3] = {ted_t1_alarm, ted_t2_alarm, ted_t3_alarm};
    const CLOCK starts[3] = {ted.t1_start, t2_start, t3_start};
    const CLOCK values[3] = {t1_value, t2_value, t3_value};
    const CLOCK restarts[3] = {t1_last_restart, t2_last_restart, t3_last_restart};
    for (unsigned i = 0; i < 3; ++i) {
        if (!alarms[i] || ted.timer_running[i] > 1) {
            snapshot_set_error(SNAPSHOT_CANNOT_WRITE_SNAPSHOT);
            return -1;
        }
    }
    ted_snap_put(payload, &at, maincpu_clk, 8);
    for (unsigned i = 0; i < 3; ++i) ted_snap_put(payload, &at, starts[i], 8);
    for (unsigned i = 0; i < 3; ++i) ted_snap_put(payload, &at, values[i], 8);
    for (unsigned i = 0; i < 3; ++i) ted_snap_put(payload, &at, restarts[i], 8);
    for (unsigned i = 0; i < 3; ++i) payload[at++] = (uint8_t)ted.timer_running[i];
    for (unsigned i = 0; i < 3; ++i) payload[at++] = alarms[i]->pending_idx >= 0;
    for (unsigned i = 0; i < 3; ++i) {
        CLOCK deadline = 0;
        if (alarms[i]->pending_idx >= 0) {
            unsigned index = (unsigned)alarms[i]->pending_idx;
            if (index >= alarms[i]->context->num_pending_alarms
                || alarms[i]->context->pending_alarms[index].alarm != alarms[i]) {
                snapshot_set_error(SNAPSHOT_CANNOT_WRITE_SNAPSHOT);
                return -1;
            }
            deadline = alarms[i]->context->pending_alarms[index].clk;
        }
        ted_snap_put(payload, &at, deadline, 8);
    }
    return ted_snap_write(s, TED_TIMER_SNAPSHOT_MODULE, "TMR8", payload, at);
}

int ted_timer_snapshot_preflight(snapshot_t *s, int required)
{
    ted_timer_snapshot_state_t state;
    uint8_t major, minor;
    CLOCK cpu_clock = 0;
    snapshot_module_t *cpu;
    int result = ted_timer_snapshot_decode(s, required, &state);
    if (result != 0) {
        return result < 0 ? -1 : 0;
    }
    /* This extension is tied to the exact CPU instant, not the machine that
     * happens to be live while preflight runs. Check the saved MAINCPU prefix
     * now so an inconsistent timer module is refused before CPU/RAM changes.
     */
    cpu = snapshot_module_open(s, "MAINCPU", &major, &minor);
    if (!cpu) return -1;
    result = major != 1 || minor != 3 || SMR_CLOCK(cpu, &cpu_clock) < 0
        || cpu_clock != state.clock;
    if (snapshot_module_close(cpu) < 0) result = 1;
    if (result) {
        snapshot_set_error(SNAPSHOT_MODULE_INCOMPATIBLE);
        return -1;
    }
    return 0;
}

int ted_timer_snapshot_read_module(snapshot_t *s, int required)
{
    ted_timer_snapshot_state_t state;
    alarm_t *alarms[3] = {ted_t1_alarm, ted_t2_alarm, ted_t3_alarm};
    int result = ted_timer_snapshot_decode(s, required, &state);
    if (result != 0) {
        return result < 0 ? -1 : 0;
    }
    if (state.clock != maincpu_clk) {
        snapshot_set_error(SNAPSHOT_MODULE_INCOMPATIBLE);
        return -1;
    }
    for (unsigned i = 0; i < 3; ++i) {
        if (!alarms[i]) return -1;
        alarm_unset(alarms[i]);
    }
    ted.t1_start = state.start[0];
    t2_start = state.start[1];
    t3_start = state.start[2];
    t1_value = state.value[0];
    t2_value = state.value[1];
    t3_value = state.value[2];
    t1_last_restart = state.restart[0];
    t2_last_restart = state.restart[1];
    t3_last_restart = state.restart[2];
    for (unsigned i = 0; i < 3; ++i) {
        ted.timer_running[i] = state.running[i];
        if (state.pending[i]) alarm_set(alarms[i], state.deadline[i]);
    }
    return 0;
}
