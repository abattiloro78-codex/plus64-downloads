/*
 * ted-sound.h
 *
 * Written by
 *  Andreas Boose <viceteam@t-online.de>
 *  Marco van den Heuvel <blackystardust68@yahoo.com>
 *
 * This file is part of VICE, the Versatile Commodore Emulator.
 * See README for copyright notice.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
 *  02111-1307  USA.
 *
 */

#ifndef VICE_TEDSOUND_H
#define VICE_TEDSOUND_H

#include "types.h"

#include "sound.h"

void ted_sound_store(uint16_t addr, uint8_t value);
uint8_t ted_sound_read(uint16_t addr);

void ted_sound_reset(sound_t *psid, CLOCK cpu_clk);

void ted_sound_chip_init(void);

/* Snapshot-only preservation of native TED tone/noise/sample phase. */
struct snapshot_s;
int ted_sound_snapshot_write_module(struct snapshot_s *s);
int ted_sound_snapshot_preflight(struct snapshot_s *s, int required);
int ted_sound_snapshot_read_module(struct snapshot_s *s, int required);

#endif
