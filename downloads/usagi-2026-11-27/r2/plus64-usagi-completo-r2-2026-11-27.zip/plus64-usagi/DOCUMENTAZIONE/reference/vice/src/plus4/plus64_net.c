#define _POSIX_C_SOURCE 200112L
#include "plus64_net.h"
#include <stdio.h>
#include <string.h>
#ifdef _WIN32
#define WIN32_LEAN_AND_MEAN
#include <winsock2.h>
#include <ws2tcpip.h>
/* VICE configure links ws2_32 on Windows. */
typedef SOCKET sock_t;
typedef int p64_socklen_t;
#define INVALID_SOCK INVALID_SOCKET
#define SOCK_ERROR SOCKET_ERROR
#define NET_WOULD_BLOCK(e) ((e)==WSAEWOULDBLOCK || (e)==WSAEINPROGRESS)
#define NET_IN_PROGRESS(e) ((e)==WSAEWOULDBLOCK || (e)==WSAEINPROGRESS || (e)==WSAEALREADY)
static int last_err(void){return WSAGetLastError();}
static void close_sock(sock_t s){closesocket(s);}
static int nonblock(sock_t s){u_long x=1;return ioctlsocket(s,FIONBIO,&x);}
#else
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/select.h>
#include <netdb.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
typedef int sock_t;
typedef socklen_t p64_socklen_t;
#define INVALID_SOCK (-1)
#define SOCK_ERROR (-1)
#define NET_WOULD_BLOCK(e) ((e)==EWOULDBLOCK || (e)==EAGAIN)
#define NET_IN_PROGRESS(e) ((e)==EINPROGRESS || (e)==EWOULDBLOCK)
static int last_err(void){return errno;}
static void close_sock(sock_t s){close(s);}
static int nonblock(sock_t s){int fl=fcntl(s,F_GETFL,0);return fl<0?-1:fcntl(s,F_SETFL,fl|O_NONBLOCK);}
#endif
static void net_close(void *arg){
    p64_tcp *n=(p64_tcp*)arg;
    if((sock_t)n->fd!=INVALID_SOCK){close_sock((sock_t)n->fd);n->fd=(intptr_t)INVALID_SOCK;}
    n->connecting=0;
}
void p64_tcp_init(p64_tcp *n){
    n->fd=(intptr_t)INVALID_SOCK;n->connecting=0;n->started=0;
#ifdef _WIN32
    {WSADATA w;if(WSAStartup(MAKEWORD(2,2),&w)==0)n->started=1;}
#else
    n->started=1;
#endif
}
void p64_tcp_cleanup(p64_tcp *n){
    net_close(n);
#ifdef _WIN32
    if(n->started)WSACleanup();
#endif
    n->started=0;
}
static int net_open(void *arg,const char *host,unsigned port){
    p64_tcp *n=(p64_tcp*)arg;struct addrinfo hints,*addrs=NULL,*p;char service[8];int ok=-1;
    if(!n->started)return -1;
    net_close(n);
    memset(&hints,0,sizeof(hints));hints.ai_family=AF_UNSPEC;hints.ai_socktype=SOCK_STREAM;
    snprintf(service,sizeof(service),"%u",port);
    /* getaddrinfo() is synchronous in this prototype; future builds should
       move DNS to a worker to avoid emulator UI pauses on bad hostnames. */
    if(getaddrinfo(host,service,&hints,&addrs)!=0)return -1;
    for(p=addrs;p;p=p->ai_next){
        sock_t s=socket(p->ai_family,p->ai_socktype,p->ai_protocol);
        if(s==INVALID_SOCK)continue;
        if(nonblock(s)!=0){close_sock(s);continue;}
        if(connect(s,p->ai_addr,(p64_socklen_t)p->ai_addrlen)==0){
            n->fd=(intptr_t)s;n->connecting=0;ok=1;break;
        }
        if(NET_IN_PROGRESS(last_err())){
            n->fd=(intptr_t)s;n->connecting=1;ok=0;break;
        }
        close_sock(s);
    }
    freeaddrinfo(addrs);return ok;
}
static int net_state(void *arg){
    p64_tcp *n=(p64_tcp*)arg;fd_set wf;struct timeval tv={0,0};int err=0;p64_socklen_t len=(p64_socklen_t)sizeof(err);int r;
    if((sock_t)n->fd==INVALID_SOCK)return -1;
    if(!n->connecting)return 1;
    FD_ZERO(&wf);FD_SET((sock_t)n->fd,&wf);
#ifdef _WIN32
    r=select(0,NULL,&wf,NULL,&tv);
#else
    r=select((int)n->fd+1,NULL,&wf,NULL,&tv);
#endif
    if(r==0)return 0;
    if(r<0 || getsockopt((sock_t)n->fd,SOL_SOCKET,SO_ERROR,(void*)&err,&len)!=0 || err!=0){net_close(n);return -1;}
    n->connecting=0;return 1;
}
static int net_send(void *arg,const uint8_t *data,size_t size){
    p64_tcp *n=(p64_tcp*)arg;int r;
    if((sock_t)n->fd==INVALID_SOCK)return -1;
#ifdef MSG_NOSIGNAL
    r=(int)send((sock_t)n->fd,(const char*)data,(int)size,MSG_NOSIGNAL);
#else
    r=(int)send((sock_t)n->fd,(const char*)data,(int)size,0);
#endif
    if(r==SOCK_ERROR && NET_WOULD_BLOCK(last_err()))return 0;
    return r<=0?-1:r;
}
static int net_recv(void *arg,uint8_t *dst,size_t cap){
    p64_tcp *n=(p64_tcp*)arg;int r;
    if((sock_t)n->fd==INVALID_SOCK)return -1;
    r=(int)recv((sock_t)n->fd,(char*)dst,(int)cap,0);
    if(r==SOCK_ERROR && NET_WOULD_BLOCK(last_err()))return 0;
    return r<=0?-1:r;
}
p64_modem_netops p64_tcp_ops(void){
    p64_modem_netops o={net_open,net_state,net_send,net_recv,net_close};return o;
}
