/* Included once, at the end of ted.c, to access its private timing latches.
 * No native host pointers or struct padding are written to the snapshot.
 */
#ifndef VICE_TED_PIPELINE_SNAPSHOT_H
#define VICE_TED_PIPELINE_SNAPSHOT_H
#include "interrupt.h"
#include "plus4memrom.h"
#include "ted-pipeline.h"
#include "ted-snapshot-wire.h"

/* Stable explicit IDs; adding a field requires a format version change.
 * Queue destinations are a subset of this same closed field list.
 */
#define TED_PIPE_FIELDS(X) \
    X(irq_status, irq_status, 0) \
    X(raster_irq_line, raster_irq_line, 0) \
    X(allow_bad_lines, allow_bad_lines, 0) \
    X(ext_bg0, ext_background_color[0], 1) \
    X(ext_bg1, ext_background_color[1], 1) \
    X(ext_bg2, ext_background_color[2], 1) \
    X(reverse_mode, reverse_mode, 0) \
    X(idle_state, idle_state, 0) \
    X(force_display_state, force_display_state, 0) \
    X(tv_current_line, tv_current_line, 0) \
    X(ted_raster_counter, ted_raster_counter, 0) \
    X(memory_fetch_done, memory_fetch_done, 0) \
    X(memptr, memptr, 0) \
    X(memptr_col, memptr_col, 0) \
    X(mem_counter, mem_counter, 0) \
    X(chr_pos_reload, chr_pos_reload, 0) \
    X(chr_pos_count, chr_pos_count, 0) \
    X(chr_pos_inc_enable, chr_pos_inc_enable, 0) \
    X(mem_counter_inc, mem_counter_inc, 0) \
    X(bad_line, bad_line, 0) \
    X(cursor_visible, cursor_visible, 0) \
    X(cursor_phase, cursor_phase, 0) \
    X(crsrpos, crsrpos, 0) \
    X(ycounter_reset_checked, ycounter_reset_checked, 0) \
    X(force_black, force_black_overscan_background_color, 0) \
    X(idle_data, idle_data, 1) \
    X(idle_data_location, idle_data_location, 0) \
    X(screen_height, screen_height, 0) \
    X(first_displayed_line, first_displayed_line, 0) \
    X(last_displayed_line, last_displayed_line, 0) \
    X(row25start, row_25_start_line, 0) \
    X(row25stop, row_25_stop_line, 0) \
    X(row24start, row_24_start_line, 0) \
    X(row24stop, row_24_stop_line, 0) \
    X(leftborderwidth, screen_leftborderwidth, 0) \
    X(rightborderwidth, screen_rightborderwidth, 0) \
    X(cycles_per_line, cycles_per_line, 0) \
    X(draw_cycle, draw_cycle, 0) \
    X(first_dma_line, first_dma_line, 0) \
    X(last_dma_line, last_dma_line, 0) \
    X(vsync_line, vsync_line, 0) \
    X(offset, offset, 0) \
    X(fastmode, fastmode, 0) \
    X(character_fetch_on, character_fetch_on, 0) \
    X(xsmooth, raster.xsmooth, 1) \
    X(ysmooth, raster.ysmooth, 0) \
    X(sprite_xsmooth, raster.sprite_xsmooth, 0) \
    X(xsmooth_shift_left, raster.xsmooth_shift_left, 0) \
    X(xsmooth_shift_right, raster.xsmooth_shift_right, 0) \
    X(sprite_xsmooth_shift_right, raster.sprite_xsmooth_shift_right, 0) \
    X(current_line, raster.current_line, 0) \
    X(border_color, raster.border_color, 1) \
    X(background_color, raster.background_color, 1) \
    X(idle_background_color, raster.idle_background_color, 1) \
    X(xsmooth_color, raster.xsmooth_color, 1) \
    X(blank_enabled, raster.blank_enabled, 0) \
    X(blank_this_line, raster.blank_this_line, 0) \
    X(open_right_border, raster.open_right_border, 0) \
    X(open_left_border, raster.open_left_border, 0) \
    X(can_disable_border, raster.can_disable_border, 0) \
    X(border_disable, raster.border_disable, 0) \
    X(blank_off, raster.blank_off, 0) \
    X(blank, raster.blank, 0) \
    X(display_ystart, raster.display_ystart, 0) \
    X(display_ystop, raster.display_ystop, 0) \
    X(display_xstart, raster.display_xstart, 1) \
    X(display_xstop, raster.display_xstop, 1) \
    X(draw_idle_state, raster.draw_idle_state, 0) \
    X(ycounter, raster.ycounter, 0) \
    X(video_mode, raster.video_mode, 1) \
    X(last_video_mode, raster.last_video_mode, 0)

enum ted_pipe_field_id {
#define TED_PIPE_ENUM(id, member, queue) TED_PIPE_##id,
    TED_PIPE_FIELDS(TED_PIPE_ENUM)
#undef TED_PIPE_ENUM
    TED_PIPE_FIELD_COUNT
};
typedef struct ted_pipe_field_s { void *pointer; uint8_t queue; } ted_pipe_field_t;
static const ted_pipe_field_t ted_pipe_fields[] = {
#define TED_PIPE_ENTRY(id, member, queue) { &ted.member, queue },
    TED_PIPE_FIELDS(TED_PIPE_ENTRY)
#undef TED_PIPE_ENTRY
};

#define TED_PIPE_MODULE "TEDPIPE80"
/* A fixed capacity is the existing renderer's bound, not new emulated RAM.
 * Only used entries are copied; unused wire slots are canonical zeroes.
 */
#define TED_PIPE_PAYLOAD (82379u + 4u * TED_PIPE_FIELD_COUNT)
#define TED_PIPE_MODULE_SIZE (TED_PIPE_PAYLOAD + 34u)

typedef struct ted_pipe_region_s { uint8_t *base; unsigned size; } ted_pipe_region_t;
static unsigned ted_pipe_regions(ted_pipe_region_t regions[10])
{
    regions[0] = (ted_pipe_region_t){NULL, 0};
    regions[1] = (ted_pipe_region_t){mem_ram, 65536};
    regions[2] = (ted_pipe_region_t){plus4memrom_basic_rom, 16384};
    regions[3] = (ted_pipe_region_t){plus4memrom_kernal_rom, 16384};
    regions[4] = (ted_pipe_region_t){plus4memrom_kernal_trap_rom, 16384};
    regions[5] = (ted_pipe_region_t){extromlo1, 16384};
    regions[6] = (ted_pipe_region_t){extromhi1, 16384};
    regions[7] = (ted_pipe_region_t){extromlo3, 16384};
    regions[8] = (ted_pipe_region_t){extromhi3, 16384};
    regions[9] = (ted_pipe_region_t){mem_get_open_space(), 65536};
    return 10;
}

/* role: screen, bitmap, chargen, color. Physical backing IDs remain valid
 * across RAM/ROM selection changes, unlike logical TED segment indices.
 */
static int ted_pipe_pointer_valid(uint32_t reference, unsigned role, int nullable)
{
    unsigned region = reference >> 24, offset = reference & 0x00ffffffu;
    unsigned size = region == 1 || region == 9 ? 65536u : 16384u;
    if (reference == 0) return nullable;
    if (region == 0 || region >= 10 || offset >= size) return 0;
    if (region == 9) return (role == 1 || role == 2) && offset == 0;
    switch (role) {
        case 0: return (offset & 0x7ffu) == 0x400 && offset + 1024u <= size;
        case 1: return (offset & 0x1fffu) == 0 && offset + 8192u <= size;
        case 2: return (offset & 0x3ffu) == 0 && offset + 1024u <= size;
        case 3: return (offset & 0x7ffu) == 0 && offset + 1024u <= size;
    }
    return 0;
}

static int ted_pipe_pointer_encode(const uint8_t *pointer, unsigned role,
                                    int nullable, uint32_t *reference)
{
    ted_pipe_region_t regions[10];
    uintptr_t address = (uintptr_t)pointer;
    if (!pointer) { *reference = 0; return nullable ? 0 : -1; }
    ted_pipe_regions(regions);
    for (unsigned i = 1; i < 10; ++i) {
        uintptr_t base = (uintptr_t)regions[i].base;
        if (address >= base && address - base < regions[i].size) {
            *reference = ((uint32_t)i << 24) | (uint32_t)(address - base);
            return ted_pipe_pointer_valid(*reference, role, nullable) ? 0 : -1;
        }
    }
    return -1;
}

static uint8_t *ted_pipe_pointer_decode(uint32_t reference)
{
    ted_pipe_region_t regions[10];
    if (!reference) return NULL;
    ted_pipe_regions(regions);
    return regions[reference >> 24].base + (reference & 0x00ffffffu);
}

static raster_changes_t *ted_pipe_queue(unsigned i)
{
    raster_changes_all_t *all = ted.raster.changes;
    if (!all) return NULL;
    switch (i) {
        case 0: return all->background;
        case 1: return all->foreground;
        case 2: return all->border;
        case 3: return all->sprites;
        case 4: return all->next_line;
    }
    return NULL;
}

static int ted_pipe_value_valid(unsigned id, uint32_t bits)
{
    int32_t value = (int32_t)bits;
    switch (id) {
        case TED_PIPE_ext_bg0: case TED_PIPE_ext_bg1: case TED_PIPE_ext_bg2:
        case TED_PIPE_border_color: case TED_PIPE_background_color:
        case TED_PIPE_idle_background_color: case TED_PIPE_xsmooth_color:
            return value >= 0 && value <= 127;
        case TED_PIPE_idle_data: return value >= 0 && value <= 255;
        case TED_PIPE_video_mode: return value >= 0 && value < TED_NUM_VMODES;
        case TED_PIPE_last_video_mode: return value >= -1 && value < TED_NUM_VMODES;
        case TED_PIPE_xsmooth: case TED_PIPE_ysmooth: case TED_PIPE_ycounter:
            return value >= 0 && value <= 7;
        case TED_PIPE_mem_counter_inc: return value >= 0 && value <= 40;
        case TED_PIPE_mem_counter: case TED_PIPE_memptr: case TED_PIPE_memptr_col:
        case TED_PIPE_chr_pos_reload: case TED_PIPE_chr_pos_count:
            return value >= 0 && value <= 1023;
        case TED_PIPE_memory_fetch_done: return value >= 0 && value <= 2;
        case TED_PIPE_cursor_phase: return value >= 0 && value <= 31;
        case TED_PIPE_crsrpos: return value >= 0 && value <= 1023;
        case TED_PIPE_screen_height: return value > 0 && value <= 1024;
        case TED_PIPE_cycles_per_line: return value >= 100 && value <= 160;
        case TED_PIPE_draw_cycle: return value >= 0 && value <= 160;
        case TED_PIPE_leftborderwidth: case TED_PIPE_rightborderwidth:
            return value >= 0 && value <= 1024;
        case TED_PIPE_current_line: case TED_PIPE_tv_current_line:
            return value >= 0 && value <= 2047;
        case TED_PIPE_ted_raster_counter: case TED_PIPE_raster_irq_line:
            return value >= 0 && value <= 511;
        case TED_PIPE_display_xstart: case TED_PIPE_display_xstop:
        case TED_PIPE_display_ystart: case TED_PIPE_display_ystop:
            return value >= -1 && value <= 2047;
        default: return value >= -2048 && value <= 2048;
    }
}

/* Decode into fixed-width host staging only. This is also the preflight
 * validation path: it never replaces live TED fields or alarm queues.
 */
typedef struct ted_pipe_state_s {
    CLOCK clocks[9];
    int32_t old_mode;
    uint32_t fields[TED_PIPE_FIELD_COUNT], pointers[8];
    uint8_t pending[3];
    CLOCK deadlines[3];
    uint8_t cbuf_tmp[40], gfx_msk[256], kbdval, last_read, last_cpu_val;
    uint8_t reserved;
    uint32_t have_changes, counts[5];
    uint32_t actions[5][RASTER_CHANGES_MAX][4];
} ted_pipe_state_t;

static int ted_pipe_decode(snapshot_t *s, int required, ted_pipe_state_t *state)
{
    uint8_t payload[TED_PIPE_PAYLOAD];
    unsigned at = 0;
    int result = ted_snap_read(s, TED_PIPE_MODULE, "TDP8", payload,
                              sizeof(payload), required);
    if (result != 0) return result;
    for (unsigned i = 0; i < 9; ++i) state->clocks[i] = ted_snap_get(payload, &at, 8);
    state->old_mode = (int32_t)ted_snap_get(payload, &at, 4);
    for (unsigned i = 0; i < TED_PIPE_FIELD_COUNT; ++i) {
        state->fields[i] = (uint32_t)ted_snap_get(payload, &at, 4);
        if (!ted_pipe_value_valid(i, state->fields[i])) goto invalid;
    }
    for (unsigned i = 0; i < 8; ++i) {
        state->pointers[i] = (uint32_t)ted_snap_get(payload, &at, 4);
        if (!ted_pipe_pointer_valid(state->pointers[i], i % 4u, i >= 4)) goto invalid;
    }
    for (unsigned i = 0; i < 3; ++i) state->pending[i] = payload[at++];
    for (unsigned i = 0; i < 3; ++i) {
        state->deadlines[i] = ted_snap_get(payload, &at, 8);
        if (state->pending[i] > 1 || (!state->pending[i] && state->deadlines[i])
            || (state->pending[i] && state->deadlines[i] == CLOCK_MAX)) goto invalid;
    }
    memcpy(state->cbuf_tmp, payload + at, 40); at += 40;
    memcpy(state->gfx_msk, payload + at, 256); at += 256;
    state->kbdval = payload[at++];
    state->last_read = payload[at++];
    state->last_cpu_val = payload[at++];
    state->reserved = payload[at++];
    state->have_changes = (uint32_t)ted_snap_get(payload, &at, 4);
    for (unsigned i = 0; i < 5; ++i) {
        state->counts[i] = (uint32_t)ted_snap_get(payload, &at, 4);
        if (state->counts[i] > RASTER_CHANGES_MAX || (i == 3 && state->counts[i])) goto invalid;
    }
    for (unsigned q = 0; q < 5; ++q) {
        for (unsigned j = 0; j < RASTER_CHANGES_MAX; ++j) {
            uint32_t *action = state->actions[q][j];
            for (unsigned k = 0; k < 4; ++k) action[k] = (uint32_t)ted_snap_get(payload, &at, 4);
            if (j >= state->counts[q]) {
                if (action[0] || action[1] || action[2] || action[3]) goto invalid;
                continue;
            }
            if ((q == 4 && action[0] != 0)
                || (q == 1 && (action[0] == 0 || action[0] >= 40))
                || ((q == 0 || q == 2) && (action[0] == 0
                    || action[0] >= state->fields[TED_PIPE_leftborderwidth]
                        + 320u + state->fields[TED_PIPE_rightborderwidth]))) goto invalid;
            if (action[1] == RASTER_CHANGES_TYPE_INT) {
                if (action[2] >= TED_PIPE_FIELD_COUNT || !ted_pipe_fields[action[2]].queue
                    || !ted_pipe_value_valid(action[2], action[3])) goto invalid;
            } else if (action[1] == RASTER_CHANGES_TYPE_PTR) {
                if (action[2] >= 4 || !ted_pipe_pointer_valid(action[3], action[2], 0)) goto invalid;
            } else goto invalid;
        }
    }
    if (at != sizeof(payload) || state->reserved || state->have_changes > 1
        || state->old_mode < -1 || state->old_mode > 7 || state->clocks[2] > 113) goto invalid;
    return 0;
invalid:
    snapshot_set_error(SNAPSHOT_MODULE_INCOMPATIBLE);
    return -1;
}

int ted_pipeline_snapshot_write_module(snapshot_t *s)
{
    uint8_t payload[TED_PIPE_PAYLOAD];
    uint8_t *pointers[8] = {ted.screen_ptr, ted.bitmap_ptr, ted.chargen_ptr,
        ted.color_ptr, old_screen_ptr, old_bitmap_ptr, old_chargen_ptr, old_color_ptr};
    alarm_t *alarms[3] = {ted.raster_fetch_alarm, ted.raster_draw_alarm, ted.raster_irq_alarm};
    CLOCK clocks[9] = {maincpu_clk, old_maincpu_clk, old_cycle, first_write_cycle,
        last_write_cycle, ted.fetch_clk, ted.draw_clk, ted.raster_irq_clk, ted.last_emulate_line_clk};
    unsigned at = 0;
    memset(payload, 0, sizeof(payload));
    for (unsigned i = 0; i < 9; ++i) ted_snap_put(payload, &at, clocks[i], 8);
    ted_snap_put(payload, &at, (uint32_t)old_video_mode, 4);
    for (unsigned i = 0; i < TED_PIPE_FIELD_COUNT; ++i) {
        uint32_t value;
        memcpy(&value, ted_pipe_fields[i].pointer, 4);
        if (!ted_pipe_value_valid(i, value)) goto invalid;
        ted_snap_put(payload, &at, value, 4);
    }
    for (unsigned i = 0; i < 8; ++i) {
        uint32_t reference;
        if (ted_pipe_pointer_encode(pointers[i], i % 4u, i >= 4, &reference) < 0) goto invalid;
        ted_snap_put(payload, &at, reference, 4);
    }
    for (unsigned i = 0; i < 3; ++i) {
        if (!alarms[i]) goto invalid;
        payload[at++] = alarms[i]->pending_idx >= 0;
    }
    for (unsigned i = 0; i < 3; ++i) {
        CLOCK deadline = 0;
        if (alarms[i]->pending_idx >= 0) {
            unsigned index = (unsigned)alarms[i]->pending_idx;
            if (index >= alarms[i]->context->num_pending_alarms
                || alarms[i]->context->pending_alarms[index].alarm != alarms[i]) goto invalid;
            deadline = alarms[i]->context->pending_alarms[index].clk;
        }
        ted_snap_put(payload, &at, deadline, 8);
    }
    memcpy(payload + at, ted.cbuf_tmp, 40); at += 40;
    memcpy(payload + at, ted.raster.gfx_msk, 256); at += 256;
    payload[at++] = ted.kbdval;
    payload[at++] = ted.last_read;
    payload[at++] = ted.last_cpu_val;
    payload[at++] = 0;
    if (!ted.raster.changes) goto invalid;
    ted_snap_put(payload, &at, ted.raster.changes->have_on_this_line, 4);
    for (unsigned i = 0; i < 5; ++i) {
        raster_changes_t *q = ted_pipe_queue(i);
        if (!q || q->count > RASTER_CHANGES_MAX || (i == 3 && q->count)) goto invalid;
        ted_snap_put(payload, &at, q->count, 4);
    }
    for (unsigned i = 0; i < 5; ++i) {
        raster_changes_t *q = ted_pipe_queue(i);
        for (unsigned j = 0; j < RASTER_CHANGES_MAX; ++j) {
            if (j >= q->count) { at += 16; continue; }
            raster_changes_action_t *action = &q->actions[j];
            uint32_t target = 0, value = 0;
            if (action->type == RASTER_CHANGES_TYPE_INT) {
                for (; target < TED_PIPE_FIELD_COUNT; ++target)
                    if (ted_pipe_fields[target].pointer == (void *)action->value.integer.oldp) break;
                if (target == TED_PIPE_FIELD_COUNT || !ted_pipe_fields[target].queue) goto invalid;
                value = (uint32_t)action->value.integer.newone;
                if (!ted_pipe_value_valid(target, value)) goto invalid;
            } else if (action->type == RASTER_CHANGES_TYPE_PTR) {
                void **destinations[4] = {(void **)&ted.screen_ptr, (void **)&ted.bitmap_ptr,
                    (void **)&ted.chargen_ptr, (void **)&ted.color_ptr};
                for (; target < 4; ++target)
                    if (destinations[target] == action->value.ptr.oldp) break;
                if (target == 4 || ted_pipe_pointer_encode(action->value.ptr.newone, target, 0, &value) < 0) goto invalid;
            } else goto invalid;
            ted_snap_put(payload, &at, (uint32_t)action->where, 4);
            ted_snap_put(payload, &at, (uint32_t)action->type, 4);
            ted_snap_put(payload, &at, target, 4);
            ted_snap_put(payload, &at, value, 4);
        }
    }
    if (at != sizeof(payload)) goto invalid;
    return ted_snap_write(s, TED_PIPE_MODULE, "TDP8", payload, at);
invalid:
    snapshot_set_error(SNAPSHOT_CANNOT_WRITE_SNAPSHOT);
    return -1;
}

int ted_pipeline_snapshot_preflight(snapshot_t *s, int required)
{
    ted_pipe_state_t state;
    /* These are selected by ted_timing_set(), never by guest register stores.
     * Raster display start/stop latches are deliberately NOT included here:
     * they are dynamic saved state, including the valid -1 sentinel.
     */
    static const unsigned fixed_geometry[] = {
        TED_PIPE_screen_height, TED_PIPE_first_displayed_line, TED_PIPE_last_displayed_line,
        TED_PIPE_row25start, TED_PIPE_row25stop, TED_PIPE_row24start, TED_PIPE_row24stop,
        TED_PIPE_leftborderwidth, TED_PIPE_rightborderwidth, TED_PIPE_cycles_per_line,
        TED_PIPE_draw_cycle, TED_PIPE_first_dma_line, TED_PIPE_last_dma_line,
        TED_PIPE_vsync_line, TED_PIPE_offset
    };
    uint8_t major, minor;
    CLOCK cpu_clock;
    int result = ted_pipe_decode(s, required, &state);
    if (result != 0) return result < 0 ? -1 : 0;
    for (unsigned i = 0; i < sizeof(fixed_geometry) / sizeof(fixed_geometry[0]); ++i) {
        unsigned field = fixed_geometry[i];
        uint32_t live;
        memcpy(&live, ted_pipe_fields[field].pointer, 4);
        if (state.fields[field] != live) {
            log_error(ted.log, "TED snapshot fixed video geometry is incompatible with the current video standard or border mode.");
            snapshot_set_error(SNAPSHOT_MODULE_INCOMPATIBLE);
            return -1;
        }
    }
    snapshot_module_t *cpu = snapshot_module_open(s, "MAINCPU", &major, &minor);
    if (!cpu) return -1;
    result = major != 1 || minor != 3 || SMR_CLOCK(cpu, &cpu_clock) < 0
        || cpu_clock != state.clocks[0];
    if (snapshot_module_close(cpu) < 0) result = 1;
    if (result) snapshot_set_error(SNAPSHOT_MODULE_INCOMPATIBLE);
    return result ? -1 : 0;
}

int ted_pipeline_snapshot_read_module(snapshot_t *s, int required)
{
    ted_pipe_state_t state;
    alarm_t *alarms[3] = {ted.raster_fetch_alarm, ted.raster_draw_alarm, ted.raster_irq_alarm};
    uint8_t **pointers[8] = {&ted.screen_ptr, &ted.bitmap_ptr, &ted.chargen_ptr,
        &ted.color_ptr, &old_screen_ptr, &old_bitmap_ptr, &old_chargen_ptr, &old_color_ptr};
    int result = ted_pipe_decode(s, required, &state);
    if (result != 0) return result < 0 ? -1 : 0;
    if (state.clocks[0] != maincpu_clk) goto invalid;
    for (unsigned i = 0; i < 3; ++i) if (!alarms[i]) goto invalid;
    for (unsigned i = 0; i < 5; ++i) if (!ted_pipe_queue(i)) goto invalid;
    for (unsigned i = 0; i < 3; ++i) alarm_unset(alarms[i]);
    old_maincpu_clk = state.clocks[1]; old_cycle = state.clocks[2];
    first_write_cycle = state.clocks[3]; last_write_cycle = state.clocks[4];
    ted.fetch_clk = state.clocks[5]; ted.draw_clk = state.clocks[6];
    ted.raster_irq_clk = state.clocks[7]; ted.last_emulate_line_clk = state.clocks[8];
    old_video_mode = state.old_mode;
    for (unsigned i = 0; i < TED_PIPE_FIELD_COUNT; ++i)
        memcpy(ted_pipe_fields[i].pointer, &state.fields[i], 4);
    for (unsigned i = 0; i < 8; ++i) *pointers[i] = ted_pipe_pointer_decode(state.pointers[i]);
    memcpy(ted.cbuf_tmp, state.cbuf_tmp, 40);
    memcpy(ted.raster.gfx_msk, state.gfx_msk, 256);
    ted.kbdval = state.kbdval; ted.last_read = state.last_read; ted.last_cpu_val = state.last_cpu_val;
    ted.raster.changes->have_on_this_line = (int)state.have_changes;
    for (unsigned i = 0; i < 5; ++i) {
        raster_changes_t *q = ted_pipe_queue(i);
        q->count = state.counts[i];
        for (unsigned j = 0; j < q->count; ++j) {
            raster_changes_action_t *action = &q->actions[j];
            const uint32_t *saved = state.actions[i][j];
            action->where = (int32_t)saved[0];
            action->type = (raster_changes_type_t)saved[1];
            if (action->type == RASTER_CHANGES_TYPE_INT) {
                action->value.integer.oldp = (int *)ted_pipe_fields[saved[2]].pointer;
                action->value.integer.newone = (int32_t)saved[3];
            } else {
                action->value.ptr.oldp = (void **)pointers[saved[2]];
                action->value.ptr.newone = ted_pipe_pointer_decode(saved[3]);
            }
        }
    }
    for (unsigned i = 0; i < 3; ++i)
        if (state.pending[i]) alarm_set(alarms[i], state.deadlines[i]);
    interrupt_restore_irq(maincpu_int_status, ted.int_num, (ted.irq_status & 0x80) != 0);
    return 0;
invalid:
    snapshot_set_error(SNAPSHOT_MODULE_INCOMPATIBLE);
    return -1;
}
#endif
