#include "p64_metadata_lzma.h"
#include "upstream/LzmaDec.h"
#include <stdlib.h>
#include <string.h>
#include <zlib.h>

static unsigned word(const uint8_t *p) {
    return (unsigned)p[0]|((unsigned)p[1]<<8);
}
static uint32_t dword(const uint8_t *p) {
    return (uint32_t)p[0]|((uint32_t)p[1]<<8)|
           ((uint32_t)p[2]<<16)|((uint32_t)p[3]<<24);
}
static uint32_t metadata_crc32(const uint8_t *p,size_t bytes) {
    return (uint32_t)crc32(0L,p,(uInt)bytes);
}
/* Only probability tables are allocated by the one-call SDK interface.
 * Its dictionary IS the bounded output buffer, not another64KiB allocation. */
static void *prob_alloc(ISzAllocPtr ignored,size_t bytes) {
    (void)ignored;
    return bytes && bytes<=65536u ? malloc(bytes) : NULL;
}
static void prob_free(ISzAllocPtr ignored,void *p) {
    (void)ignored;free(p);
}

int p64_metadata_lzma_open(const uint8_t *guest,size_t bytes,
                           p64_metadata_lzma_view *v) {
    if(!v)return P64_LZMA_FORMAT_ERROR;
    v->bytes=NULL;v->size=0;v->owned=NULL;
    if(!guest||bytes<12u||bytes>65535u||memcmp(guest,"P64Z\1\2",6)||
       guest[10]||guest[11])return P64_LZMA_FORMAT_ERROR;
    unsigned raw=word(guest+6),stored=word(guest+8);
    if(!raw||stored<14u||stored!=bytes-12u)return P64_LZMA_FORMAT_ERROR;
    const uint8_t *payload=guest+12;
    CLzmaProps props;
    unsigned dictionary=dword(payload+1);
    if(dictionary<4096u||dictionary>65536u||
       LzmaProps_Decode(&props,payload,5)!=SZ_OK||
       (unsigned)props.lc+props.lp>4u)return P64_LZMA_FORMAT_ERROR;
    uint8_t *out=(uint8_t*)malloc(raw);
    if(!out)return P64_LZMA_MEMORY_ERROR;
    const ISzAlloc alloc={prob_alloc,prob_free};
    SizeT output=raw,input=stored-9u;
    ELzmaStatus status=LZMA_STATUS_NOT_SPECIFIED;
    SRes result=LzmaDecode(out,&output,payload+5,&input,payload,5,
                          LZMA_FINISH_END,&status,&alloc);
    if(result!=SZ_OK||status!=LZMA_STATUS_FINISHED_WITH_MARK||
       output!=raw||input!=stored-9u||
       metadata_crc32(out,raw)!=dword(payload+stored-4u)) {
        free(out);
        return result==SZ_ERROR_MEM?P64_LZMA_MEMORY_ERROR:P64_LZMA_FORMAT_ERROR;
    }
    v->bytes=out;v->size=raw;v->owned=out;
    return 0;
}

void p64_metadata_lzma_close(p64_metadata_lzma_view *v) {
    if(!v)return;
    free(v->owned);v->bytes=NULL;v->size=0;v->owned=NULL;
}
