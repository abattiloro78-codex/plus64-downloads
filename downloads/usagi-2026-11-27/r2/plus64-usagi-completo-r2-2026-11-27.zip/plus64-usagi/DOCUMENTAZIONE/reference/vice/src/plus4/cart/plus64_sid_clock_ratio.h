#ifndef PLUS64_SID_CLOCK_RATIO_H
#define PLUS64_SID_CLOCK_RATIO_H
#include <stdint.h>
#include <assert.h>

/* Host emulation metadata, never CPU-visible RAM or an I/O register. */
typedef struct {
    uint32_t numerator, denominator;
    uint64_t remainder;
} plus64_sid_clock_ratio_t;

static inline uint64_t plus64_sid_clock_plan(const plus64_sid_clock_ratio_t *s, uint64_t cpu)
{
    assert(s->numerator && s->denominator && s->remainder < s->denominator);
    assert(cpu <= (UINT64_MAX - s->remainder) / s->numerator);
    return (s->remainder + cpu * s->numerator) / s->denominator;
}

/* Commit only native clocks actually consumed by the sound engine. This
 * preserves fractional phase even if its output buffer fills partway. */
static inline uint64_t plus64_sid_clock_commit(plus64_sid_clock_ratio_t *s, uint64_t cpu, uint64_t sid)
{
    uint64_t total = s->remainder + cpu * s->numerator;
    uint64_t planned = total / s->denominator;
    uint64_t consumed = cpu;
    assert(sid <= planned);
    if (sid < planned) {
        consumed = ((sid + 1) * s->denominator - 1 - s->remainder) / s->numerator;
    }
    s->remainder += consumed * s->numerator;
    s->remainder -= sid * s->denominator;
    assert(consumed <= cpu && s->remainder < s->denominator);
    return consumed;
}
#endif
