/* Generic bounded compressed source frames. No retained pixels or assets. */
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include "p64_metadata.h"
static unsigned f_u16(const uint8_t *p){return p[0]|((unsigned)p[1]<<8);}
int p64_source_frame(const uint8_t *memory,unsigned capacity,unsigned source,
                     unsigned root,unsigned software_length,uint8_t out[63]){
    unsigned groups,frames,blocks,index,which,within,entry,address,stored,nframes;
    p64_metadata_view_t view;
    if(!memory||!out||(capacity!=16384u&&capacity!=65536u)||root>capacity-12u)return 0;
    const uint8_t *h=memory+root,*s=NULL;
    if(memcmp(h,"P64F",4)||(h[4]!=1u&&h[4]!=2u&&h[4]!=4u)||
       !h[5]||h[5]>32u||h[6]!=63u||h[7])return 0;
    unsigned version=h[4],compact=version==2u;
    if(version==4u){
        /* The source is a16-bit opaque frame index; no duplicated prefix. */
        if(software_length!=2u)return 0;
        index=source;
    }else{
        unsigned header=compact?4u:5u;
        if(source>capacity-header)return 0;
        s=memory+source;
        if(compact?software_length!=4u:(!software_length||software_length>128u||s[0]!=software_length))return 0;
        index=f_u16(s+(compact?2u:3u));
    }
    groups=h[5];frames=f_u16(h+8);blocks=f_u16(h+10);
    if(!frames||blocks!=(frames+groups-1u)/groups||blocks>(capacity-root-12u)/4u||index>=frames)return 0;
    which=index/groups;within=index%groups;entry=root+12u+which*4u;
    address=f_u16(memory+entry);stored=f_u16(memory+entry+2u);
    if(address>capacity||stored<12u||stored>capacity-address||memcmp(memory+address,"P64Z",4))return 0;
    nframes=frames-which*groups;if(nframes>groups)nframes=groups;
    if(nframes*63u>2016u||f_u16(memory+address+6u)!=nframes*63u)return 0;
    memset(&view,0,sizeof(view));
    if(p64_metadata_open(memory+address,stored,&view)!=0)return 0;
    int valid=view.size==nframes*63u;
    if(valid){
        const uint8_t *raw=view.bytes+within*63u;
        if(version!=4u)valid=raw[0]==s[compact?0u:1u]&&raw[2]==s[compact?1u:2u];
        if(valid)memcpy(out,raw,63u);
    }
    p64_metadata_close(&view);return valid;
}
