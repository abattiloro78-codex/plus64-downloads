/* Fixed-width portable snapshot fields. No guest-addressable data backing. */
#ifndef VICE_TED_SNAPSHOT_WIRE_H
#define VICE_TED_SNAPSHOT_WIRE_H

#include <stdint.h>
#include <string.h>
#include "snapshot.h"

#define TED_TIMER_SNAPSHOT_MODULE "TEDTIMERS80"
#define TED_TIMER_SNAPSHOT_PAYLOAD 110u
#define TED_TIMER_SNAPSHOT_MODULE_SIZE 144u
#define TED_SOUND_SNAPSHOT_MODULE "TEDAUDIO80"
#define TED_SOUND_SNAPSHOT_PAYLOAD 60u
#define TED_SOUND_SNAPSHOT_MODULE_SIZE 94u

static inline void ted_snap_put(uint8_t *p, unsigned *at, uint64_t value, unsigned bytes)
{
    while (bytes--) {
        p[(*at)++] = (uint8_t)value;
        value >>= 8;
    }
}

static inline uint64_t ted_snap_get(const uint8_t *p, unsigned *at, unsigned bytes)
{
    uint64_t value = 0;
    for (unsigned shift = 0; shift < bytes * 8u; shift += 8u) {
        value |= (uint64_t)p[(*at)++] << shift;
    }
    return value;
}

static inline uint32_t ted_snap_crc32(const uint8_t *p, unsigned size)
{
    uint32_t crc = 0xffffffffu;
    for (unsigned i = 0; i < size; ++i) {
        crc ^= p[i];
        for (unsigned bit = 0; bit < 8; ++bit) {
            crc = (crc >> 1) ^ ((crc & 1u) ? 0xedb88320u : 0u);
        }
    }
    return crc ^ 0xffffffffu;
}

static inline int ted_snap_write(snapshot_t *s, const char *name,
                                const char magic[4], const uint8_t *data, unsigned size)
{
    snapshot_module_t *module = snapshot_module_create(s, name, 1, 0);
    int failed;
    if (!module) {
        return -1;
    }
    failed = SMW_BA(module, (const uint8_t *)magic, 4) < 0
        || SMW_DW(module, size) < 0
        || SMW_BA(module, data, size) < 0
        || SMW_DW(module, ted_snap_crc32(data, size)) < 0;
    if (snapshot_module_close(module) < 0) {
        failed = 1;
    }
    return failed ? -1 : 0;
}

/* Missing optional modules retain stock behavior for a legacy plain-machine
 * snapshot. New PLUS64 snapshots require both extensions at preflight. */
static inline int ted_snap_read(snapshot_t *s, const char *name, const char magic[4],
                               uint8_t *data, unsigned size, int required)
{
    uint8_t major = 0, minor = 0, actual_magic[4];
    uint32_t actual_size = 0, crc = 0;
    snapshot_module_t *module = snapshot_module_open(s, name, &major, &minor);
    int failed;
    if (!module) {
        /* Stock VICE reports an absent optional module as a header-read
         * error on reaching EOF. The outer preflight has already checked
         * every module boundary, so these denote absence, not truncation.
         */
        int error = snapshot_get_error();
        if (!required && (error == SNAPSHOT_MODULE_NOT_FOUND_ERROR
                          || error == SNAPSHOT_FIRST_MODULE_NOT_FOUND_ERROR
                          || error == SNAPSHOT_MODULE_HEADER_READ_ERROR)) {
            snapshot_set_error(SNAPSHOT_NO_ERROR);
            return 1;
        }
        return -1;
    }
    failed = major != 1 || minor != 0
        || SMR_BA(module, actual_magic, 4) < 0
        || memcmp(actual_magic, magic, 4) != 0
        || SMR_DW(module, &actual_size) < 0
        || actual_size != size
        || SMR_BA(module, data, size) < 0
        || SMR_DW(module, &crc) < 0
        || crc != ted_snap_crc32(data, size);
    if (snapshot_module_close(module) < 0) {
        failed = 1;
    }
    if (failed) {
        snapshot_set_error(SNAPSHOT_MODULE_INCOMPATIBLE);
        return -1;
    }
    return 0;
}

#endif
