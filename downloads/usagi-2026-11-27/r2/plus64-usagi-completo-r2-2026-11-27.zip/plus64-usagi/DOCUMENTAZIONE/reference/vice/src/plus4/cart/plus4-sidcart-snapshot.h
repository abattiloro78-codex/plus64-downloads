/* Plus/4 SID cartridge snapshot integration, GPL-2.0-or-later. */
#ifndef VICE_PLUS4_SIDCART_SNAPSHOT_H
#define VICE_PLUS4_SIDCART_SNAPSHOT_H
struct snapshot_s;
int sidcart_snapshot_write_allowed(void);
int sidcart_snapshot_write_module(struct snapshot_s *s);
/* require_module is true for the new complete PLUS64 snapshot format. */
int sidcart_snapshot_prepare_read(struct snapshot_s *s, int require_module);
int sidcart_snapshot_apply_read(struct snapshot_s *s);
void sidcart_snapshot_abort_read(void);
#endif
