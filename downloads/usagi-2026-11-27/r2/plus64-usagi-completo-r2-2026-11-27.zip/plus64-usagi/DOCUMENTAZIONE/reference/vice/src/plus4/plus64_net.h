#ifndef PLUS64_NET_H
#define PLUS64_NET_H
#include "plus64_modem.h"
#include <stdint.h>
typedef struct {
    intptr_t fd;
    int connecting;
    int started;
} p64_tcp;
void p64_tcp_init(p64_tcp *net);
void p64_tcp_cleanup(p64_tcp *net);
p64_modem_netops p64_tcp_ops(void);
#endif
