/* GPL-compatible integration adapter for VICE xplus4.
   Depends on VICE's cartio/resources APIs, not on any raw motherboard access.
   Modem is polled in machine_vsync_hook().  Sprite rendering is added at TED raster scanline completion. */
#include "vice.h"
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "lib.h"
#include "log.h"
#include "snapshot.h"
#include "zfile.h"
#include "screenshot.h"
#include "ted.h"
#include "tedtypes.h"
#include "cartio.h"
#include "cmdline.h"
#include "cartridge.h"
#include "resources.h"
#include "mem.h"
#include "plus64vice.h"
#include "plus64_sprite.h"
#include "plus64_memory.h"
#include "plus64_modem.h"
#include "plus64_net.h"
#include "plus64_overlay.h"
#include "plus64_snapshot_format.h"
#include "raster.h"
#include "viewport.h" /* VICE defines struct geometry_s here */

static p64_modem modem;
static p64_tcp link;
static plus64_t sprite;
static p64_memory banked_ram;
static io_source_list_t *memory_device_handle;
static io_source_list_t *modem_device_handle;
static io_source_list_t *sprite_device_handle;
static int plus64_enabled;
static int plus64_main_ram;
static int plus64_scene_formats; /* host format version, no guest storage */
static int plus64_mixed_sprites; /* explicit opt-in format/material extension */
static int plus64_packed_cache; /* NEW opt-in video format, default0 */
static int plus64_left_mcm; /* signed packed left projection, default0 */
static int plus64_raster_collisions; /* frozen-frame scanline latch, default0 */
static int previous_ram_size;
static int main_ram_owned_expansion;
static int plus64_memory_changing;
static int plus64_snapshot_configuring;
int plus64vice_snapshot_restoring(void) { return plus64_snapshot_configuring; }
int plus64vice_ram_size_allowed(int size) {
    return !plus64_enabled || plus64_memory_changing || size==(plus64_main_ram ? 64 : 16);
}
int plus64vice_memory_hack_allowed(int value) { return !plus64_enabled || value==0; }
size_t plus64vice_memory_budget(void) { return p64_memory_total_ram(); }
uint8_t *plus64vice_host_ram(void) { return plus64_enabled ? p64_memory_host_ram(&banked_ram) : NULL; }
uint8_t *plus64vice_cart_bank(unsigned bank) { return plus64_enabled ? p64_memory_bank(&banked_ram,bank) : NULL; }
int plus64vice_main_ram_enabled(void) { return plus64_main_ram; }
int plus64vice_native_ram_enabled(void) { return plus64_enabled && !plus64_main_ram; }
/* If plus/64 automatically enabled VICE SIDcart, it may later release it. */
static int plus64_sid_owned;
/* Latched sprite pixels updated at vblank, applied after TED raster scanline.
   Fixed 320x200 active area; TED color index 0..127, not RGB. */
static uint8_t overlay[PLUS64_WIDTH * PLUS64_HEIGHT];
static uint8_t alpha[PLUS64_WIDTH * PLUS64_HEIGHT];
/* Host-only raster summary, not additional addressable device RAM. */
static uint8_t collision_lines[PLUS64_HEIGHT];
static int overlay_ready;

/* FD95 is defined only for enabled tagged dense-MCM slots. Historical
 * descriptors retain the reserved-register behaviour, including old snapshots. */
static uint8_t p64_dense_behind_mask(void) {
    unsigned slots=0;
    if (!plus64_packed_cache || !sprite.extended_formats || !sprite.dense_formats) return 0;
    for (unsigned s=0;s<8u;s++) {
        unsigned b=0x10u+s*6u;
        unsigned pointer=(unsigned)sprite.regs[b+4u]|((unsigned)sprite.regs[b+5u]<<8);
        if ((sprite.regs[0]&sprite.regs[2]&(1u<<s)) &&
            ((pointer&0xc000u)==PLUS64_DENSE_MCM_TAG ||
             (sprite.dense_material_formats>=5u && (pointer&0xc000u)==PLUS64_SOURCE_MCM_TAG))) slots|=1u<<s;
    }
    return (uint8_t)(slots&sprite.regs[5]);
}

static void modem_store(uint16_t a,uint8_t b){p64_modem_store(&modem,a,b);}
static uint8_t modem_read(uint16_t a){return p64_modem_read(&modem,a);}
static uint8_t modem_peek(uint16_t a){return p64_modem_peek(&modem,a);}
static void sprite_store(uint16_t a,uint8_t b){
    plus64_write(&sprite,a,b);
    /* Existing publication boundary: descriptors first, enable last. This
       also makes disable effective for subsequent scanlines of this frame.
       Previously drawn lines and the read-clear latch are not rewritten. */
    if (plus64_raster_collisions && a==PLUS64_BASE) {
        if (plus64_left_mcm)
            plus64_draw_masked_main(&sprite,overlay,alpha,PLUS64_WIDTH,plus64_packed_cache,1,collision_lines,1,plus64_main_ram?mem_ram:NULL);
        else plus64_draw_masked_main(&sprite,overlay,alpha,PLUS64_WIDTH,plus64_packed_cache,1,collision_lines,0,plus64_main_ram?mem_ram:NULL);
        overlay_ready=1;
    }
}
static uint8_t sprite_read(uint16_t a){return plus64_read(&sprite,a);}
static uint8_t sprite_peek(uint16_t a){
    unsigned r=a-PLUS64_BASE;
    if(r==1)return sprite.collision;
    if(r==6){unsigned i=(unsigned)sprite.regs[7] | ((unsigned)sprite.regs[8]<<8);
       return sprite.ram ? sprite.ram[i&(PLUS64_RAM_SIZE-1)] : 0xff;}
    if(r<sizeof(sprite.regs))return sprite.regs[r];
    return 0xff;
}
static void memory_store(uint16_t a,uint8_t v){p64_memory_write(&banked_ram,a,v);}
static uint8_t memory_read(uint16_t a){return p64_memory_read(&banked_ram,a);}
static uint8_t memory_peek(uint16_t a){return p64_memory_peek(&banked_ram,a);}
static io_source_t plus64_memory_io = {
    "plus/64 SRAM", IO_DETACH_RESOURCE, "Plus64Enabled",
    0xfde8,0xfded,0xffff,1,
    memory_store,NULL,memory_read,memory_peek,NULL,
    CARTRIDGE_NONE, IO_PRIO_NORMAL,0,IO_MIRROR_NONE
};
static io_source_t plus64_modem_io = {
    "plus/64 modem", IO_DETACH_RESOURCE, "Plus64Enabled",
    0xfdf0,0xfdf7,0xffff,1,
    modem_store,NULL,modem_read,modem_peek,NULL,
    CARTRIDGE_NONE, IO_PRIO_NORMAL,0,IO_MIRROR_NONE
};
static io_source_t plus64_sprite_io = {
    "plus/64 sprites", IO_DETACH_RESOURCE, "Plus64Enabled",
    0xfd90,0xfdcf,0xffff,1,
    sprite_store,NULL,sprite_read,sprite_peek,NULL,
    CARTRIDGE_NONE, IO_PRIO_NORMAL,0,IO_MIRROR_NONE
};
static int plus64_set_enabled(int enable,void *unused){
    (void)unused;
    enable=(enable!=0);
    if (!enable && plus64_main_ram) return -1;
    if(enable==plus64_enabled)return 0;
    if(enable){
        int memory_hack=0;
        /* Refuse existing optional RAM before changing any resource, RAM
           payload, I/O registration or SID ownership. Never silently
           disable an expansion whose data belong to the caller. */
        if (resources_get_int("MemoryHack",&memory_hack)<0 || memory_hack!=0) return -1;
        /* Both hosts use only their common 16K native decoder. The other
           three mem_ram blocks are cartridge backing, not extra host RAM. */
        if (resources_get_int("RamSize",&previous_ram_size)<0) return -1;
        plus64_memory_changing=1;
        if (resources_set_int("RamSize",16)<0) {
            plus64_memory_changing=0;
            return -1;
        }
        plus64_memory_changing=0;
        p64_memory_powerup(&banked_ram,mem_ram);
        plus64_bind_ram(&sprite,p64_memory_sprite_ram(&banked_ram));
        plus64_reset(&sprite);
        overlay_ready = 0;
        p64_tcp_init(&link);
        p64_modem_init(&modem,p64_tcp_ops(),&link,p64_memory_modem_ram(&banked_ram));
        sprite_device_handle=io_source_register(&plus64_sprite_io);
        modem_device_handle=io_source_register(&plus64_modem_io);
        memory_device_handle=io_source_register(&plus64_memory_io);
        /* Virtual plus/64 includes a SID: reuse the authentic VICE SIDcart at
           $FD40, and do not override an existing user-configured SIDcart. */
        {
            int sidcart_was_enabled = 0;
            plus64_sid_owned = 0;
            if (resources_get_int("SidCart", &sidcart_was_enabled) == 0 &&
                !sidcart_was_enabled && resources_set_int("SidCart", 1) == 0) {
                plus64_sid_owned = 1;
            }
        }
    }else{
        if(memory_device_handle){io_source_unregister(memory_device_handle);memory_device_handle=NULL;}
        if(modem_device_handle){io_source_unregister(modem_device_handle);modem_device_handle=NULL;}
        if(sprite_device_handle){io_source_unregister(sprite_device_handle);sprite_device_handle=NULL;}
        p64_modem_reset(&modem);p64_tcp_cleanup(&link);
        plus64_bind_ram(&sprite,NULL);
        plus64_memory_changing=1;
        (void)resources_set_int("RamSize",previous_ram_size);
        plus64_memory_changing=0;
        if (plus64_sid_owned) {
            (void)resources_set_int("SidCart", 0);
            plus64_sid_owned = 0;
        }
    }
    overlay_ready = 0;
    plus64_enabled=enable;
    return 0;
}
/* Strict shared backing: one mem_ram[64K] plus p64_aux_ram[16K].
 * Switching reorders the five existing blocks without copying to a hidden
 * pool, preserving cartridge and host contents. The CPU decoder is native
 * 16K or cartridge 64K; it never exposes the native host's extra Plus/4 RAM.
 * Profile changes require disabled sprites and an idle modem; otherwise
 * reject before any memory, resource or network side effect.
 */
static int plus64_set_main_ram(int enable, void *unused) {
    int expanded=0;
    (void)unused;
    enable=enable!=0;
    if (enable==plus64_main_ram) return 0;
    if (sprite.regs[0] || modem.connected || modem.dialing || modem.r_count ||
        modem.t_count || modem.clen) return -1;
    if (enable) {
        expanded=!plus64_enabled;
        if (plus64_set_enabled(1,NULL)<0) return -1;
    }
    plus64_memory_changing=1;
    if (resources_set_int("RamSize",enable ? 64 : 16)<0) {
        plus64_memory_changing=0;
        if (expanded) (void)plus64_set_enabled(0,NULL);
        return -1;
    }
    plus64_memory_changing=0;
    p64_memory_bind_main_ram(&banked_ram,enable ? mem_ram : NULL);
    plus64_bind_ram(&sprite,p64_memory_sprite_ram(&banked_ram));
    p64_modem_init(&modem,p64_tcp_ops(),&link,p64_memory_modem_ram(&banked_ram));
    plus64_main_ram=enable;
    overlay_ready=0;
    if (enable) {
        main_ram_owned_expansion=expanded;
    } else {
        if (main_ram_owned_expansion) (void)plus64_set_enabled(0,NULL);
        main_ram_owned_expansion=0;
    }
    return 0;
}
/* This config does not add a CPU register or device RAM. Switching format
 * while output is enabled is rejected. Both directions invalidate16 markers;
 * metadata-only MCM records cannot be consumed by the legacy8bpp backend. */
static int plus64_set_packed_cache(int enable, void *unused) {
    (void)unused;
    enable=(enable!=0);
    if (enable==plus64_packed_cache) return 0;
    if (!enable && (plus64_left_mcm || plus64_mixed_sprites)) return -1;
    if (plus64_prepare_packed_cache_switch(&sprite)<0) return -1;
    plus64_packed_cache=enable;
    overlay_ready=0;
    return 0;
}
static int plus64_set_mixed_sprites(int enable, void *unused) {
    (void)unused;
    enable=(enable!=0);
    if (enable==plus64_mixed_sprites) return 0;
    if (enable && !plus64_packed_cache) return -1;
    if (plus64_set_extended_formats(&sprite,enable)<0) return -1;
    plus64_mixed_sprites=enable;
    plus64_scene_formats=enable?22:0;
    overlay_ready=0;
    return 0;
}
static int plus64_set_raster_collisions(int enable, void *unused) {
    (void)unused;
    enable=(enable!=0);
    if (enable==plus64_raster_collisions) return 0;
    if (sprite.regs[0]!=0) return -1;
    plus64_raster_collisions=enable;
    overlay_ready=0; /* discard old alpha representation; retain pending latch */
    return 0;
}
static int plus64_set_left_mcm(int enable, void *unused) {
    (void)unused;
    enable=(enable!=0);
    if (enable==plus64_left_mcm) return 0;
    if (sprite.regs[0]!=0 || (enable && !plus64_packed_cache)) return -1;
    plus64_left_mcm=enable;
    overlay_ready=0;
    return 0;
}
static const resource_int_t plus64_resources[] = {
    {"Plus64MixedSprites",0,RES_EVENT_SAME,NULL,
        &plus64_mixed_sprites,plus64_set_mixed_sprites,NULL},
    {"Plus64Enabled",0,RES_EVENT_SAME,NULL,
        &plus64_enabled,plus64_set_enabled,NULL},
    {"Plus64MainRAM",0,RES_EVENT_SAME,NULL,
        &plus64_main_ram,plus64_set_main_ram,NULL},
    {"Plus64PackedCache",0,RES_EVENT_SAME,NULL,
        &plus64_packed_cache,plus64_set_packed_cache,NULL},
    {"Plus64RasterCollisions",0,RES_EVENT_SAME,NULL,
        &plus64_raster_collisions,plus64_set_raster_collisions,NULL},
    {"Plus64LeftMCM",0,RES_EVENT_SAME,NULL,
        &plus64_left_mcm,plus64_set_left_mcm,NULL},
    RESOURCE_INT_LIST_END
};
int plus64vice_resources_init(void){return resources_register_int(plus64_resources);}
void plus64vice_shutdown(void){
    plus64_main_ram=0;
    p64_memory_bind_main_ram(&banked_ram,NULL);
    plus64_bind_ram(&sprite,p64_memory_sprite_ram(&banked_ram));
    (void)plus64_set_enabled(0,NULL);
}
void plus64vice_reset(void){
    if(plus64_enabled){
        p64_modem_reset(&modem);
        plus64_reset(&sprite);
        p64_memory_reset_registers(&banked_ram);
        overlay_ready = 0;
    }
}
void plus64vice_frame(void){
    /* Optional diagnostic PNG from the actual VICE TED framebuffer.
       This is not a render approximation: VICE screenshot_save reads its canvas.
       Delayed to let BASIC/ROM execute and the video update. */
    static unsigned long capture_frames;
    const char *capture = getenv("PLUS64_CAPTURE_PNG");
    const char *frame_str = getenv("PLUS64_CAPTURE_FRAME");
    unsigned long capture_at = frame_str && *frame_str ? strtoul(frame_str, NULL, 10) : 50;
    ++capture_frames;
    if (capture && *capture && capture_frames == capture_at) {
        screenshot_save("PNG", capture, ted_get_canvas());
    }
    /* Multi-frame capture from real TED rendering for reproducible motion tests.
       Disabled unless PLUS64_CAPTURE_SEQUENCE is explicitly set. */
    const char *sequence = getenv("PLUS64_CAPTURE_SEQUENCE");
    if (sequence && *sequence) {
        const char *start_str = getenv("PLUS64_CAPTURE_START");
        const char *step_str = getenv("PLUS64_CAPTURE_STEP");
        unsigned long start = start_str && *start_str ? strtoul(start_str, NULL, 10) : 160;
        unsigned long step  = step_str && *step_str ? strtoul(step_str, NULL, 10) : 5;
        if (step && capture_frames >= start &&
            capture_frames < start + 20 * step &&
            (capture_frames - start) % step == 0) {
            char pathname[1024];
            if (snprintf(pathname, sizeof(pathname), "%s_%03lu", sequence,
                         (capture_frames-start)/step) < (int)sizeof(pathname)) {
                screenshot_save("PNG", pathname, ted_get_canvas());
            }
        }
    }
    if (!plus64_enabled) return;
    p64_modem_poll(&modem);
    if (plus64_raster_collisions) {
        if (plus64_left_mcm)
            plus64_draw_masked_main(&sprite,overlay,alpha,PLUS64_WIDTH,plus64_packed_cache,1,collision_lines,1,plus64_main_ram?mem_ram:NULL);
        else plus64_draw_masked_main(&sprite,overlay,alpha,PLUS64_WIDTH,plus64_packed_cache,1,collision_lines,0,plus64_main_ram?mem_ram:NULL);
    } else if (plus64_left_mcm)
        plus64_draw_masked_main(&sprite,overlay,alpha,PLUS64_WIDTH,plus64_packed_cache,0,NULL,1,plus64_main_ram?mem_ram:NULL);
    else if (plus64_packed_cache)
        plus64_draw_masked_main(&sprite,overlay,alpha,PLUS64_WIDTH,1,0,NULL,0,plus64_main_ram?mem_ram:NULL);
    else plus64_draw_masked(&sprite,overlay,alpha,PLUS64_WIDTH);
    /* Immediate capture above retains its historical collision latch. Only
       the new dense priority path needs a second side-effect-free capture
       to retain exact visible-slot identities when raster collisions are off. */
    if (!plus64_raster_collisions && p64_dense_behind_mask()) {
        if (plus64_left_mcm)
            plus64_draw_masked_main(&sprite,overlay,alpha,PLUS64_WIDTH,plus64_packed_cache,1,NULL,1,plus64_main_ram?mem_ram:NULL);
        else plus64_draw_masked_main(&sprite,overlay,alpha,PLUS64_WIDTH,plus64_packed_cache,1,NULL,0,plus64_main_ram?mem_ram:NULL);
    }
    overlay_ready = 1;
}
int plus64vice_background_lighting(void) {
    return plus64_enabled && plus64_main_ram &&
        ((sprite.tile_lighting && (sprite.regs[15]&15u)) ||
         (plus64_scene_formats>=18 && (sprite.regs[15]&16u)));
}
/* Called IMMEDIATELY after VICE raster_line_emulate(TED), before presenting. */
void plus64vice_overlay_line(struct raster_s *raster, unsigned int line,
                            const struct p64_native_border_s *border){
    if (!plus64_enabled || !overlay_ready || !raster || !raster->geometry) return;
    /* Collision time follows completed scanlines, independently of display
       buffer availability/frame skipping. Pixels still use the same capture. */
    if (plus64_raster_collisions) {
        int y=(int)line-raster->geometry->gfx_position.y;
        if (y>=0 && y<PLUS64_HEIGHT) sprite.collision |= collision_lines[y];
    }
    if (!raster->draw_buffer_ptr) return;
    if (plus64_main_ram && sprite.tile_lighting)
        p64_light_scanline_versioned(raster->draw_buffer_ptr,
            (size_t)raster->geometry->screen_size.width,
            (int)line-raster->geometry->gfx_position.y,
            raster->geometry->gfx_position.x,mem_ram,sprite.regs,(unsigned)plus64_scene_formats);
    if (plus64_main_ram && plus64_scene_formats)
        p64_scene_scanline(raster->draw_buffer_ptr,
            (size_t)raster->geometry->screen_size.width,
            (int)line-raster->geometry->gfx_position.y,
            raster->geometry->gfx_position.x,mem_ram,sprite.regs);
    {
        uint8_t behind=p64_dense_behind_mask();
        uint8_t foreground[320],front_mask[320],front_pixels[320];
        int front_active=0;
        int gx=raster->geometry->gfx_position.x;
        size_t width=(size_t)raster->geometry->screen_size.width;
        if (behind || (plus64_main_ram && plus64_scene_formats>=21)) {
            p64_ted_row_t row;
            row.vbuf=ted.vbuf;row.cbuf=ted.cbuf;
            row.font=ted.chargen_ptr;row.bitmap=ted.bitmap_ptr;
            row.mode=(unsigned)raster->video_mode;row.ycounter=raster->ycounter;
            row.memptr=ted.memptr;row.reverse_mode=ted.reverse_mode;
            row.cursor_visible=ted.cursor_visible;
            row.cursor_cell=ted.crsrpos-(int)ted.memptr;
            row.source_origin=ted.screen_leftborderwidth+raster->xsmooth;
            row.overlay_origin=raster->geometry->gfx_position.x;
            row.clip_start=raster->open_left_border ? row.source_origin : raster->display_xstart;
            row.clip_stop=raster->open_right_border ? row.source_origin+320 : raster->display_xstop;
            row.active=!raster->blank_enabled && !raster->draw_idle_state;
            if (behind) p64_ted_foreground_row(foreground,&row);
            /* Scenery21 owns an explicitly anchored foreground layer. Its
               source-bit mask is independent of sprite formats and FD95;
               source colours are retained before any actor composition. */
            if (plus64_main_ram && plus64_scene_formats>=21 && gx>=0 &&
                width>=320 && (size_t)gx<=width-320) {
                front_active=p64_front_layer_scanline(front_mask,
                    raster->draw_buffer_ptr,width,
                    (int)line-raster->geometry->gfx_position.y,gx,
                    mem_ram,sprite.regs,&row,ted.screen_ptr,
                    (unsigned)plus64_scene_formats);
                if (plus64_scene_formats>=22) {
                    const uint8_t background[4]={ted.regs[0x15],ted.regs[0x16],
                                                  ted.regs[0x17],ted.regs[0x18]};
                    p64_guest_material_scanline(raster->draw_buffer_ptr,width,
                        (int)line-raster->geometry->gfx_position.y,gx,mem_ram,
                        sprite.ram,sprite.regs,&row,background,
                        (unsigned)plus64_scene_formats);
                }
                if (front_active)
                    for (unsigned x=0;x<320;++x)
                        if (front_mask[x]) front_pixels[x]=raster->draw_buffer_ptr[gx+x];
            }
        }
        if (behind) {
            p64_overlay_scanline_priority(raster->draw_buffer_ptr,
                (size_t)raster->geometry->screen_size.width,(int)line,
                raster->geometry->gfx_position.x,raster->geometry->gfx_position.y,
                overlay,alpha,foreground,behind);
        } else p64_overlay_scanline(raster->draw_buffer_ptr,
            (size_t)raster->geometry->screen_size.width,(int)line,
            raster->geometry->gfx_position.x,raster->geometry->gfx_position.y,
            overlay,alpha);
        if (front_active)
            for (unsigned x=0;x<320;++x)
                if (front_mask[x]) raster->draw_buffer_ptr[gx+x]=front_pixels[x];
    }
    if (plus64_main_ram && plus64_scene_formats>=11)
        p64_window_scanline(raster->draw_buffer_ptr,
            (size_t)raster->geometry->screen_size.width,
            (int)line-raster->geometry->gfx_position.y,
            raster->geometry->gfx_position.x,mem_ram,sprite.regs);
    /* Guest-controlled presentation blanking keeps construction frames hidden.
       Collision accumulation above remains independent of visible pixels. */
    if (plus64_scene_formats>=9 && (sprite.regs[15]&6u)) {
        int y=(int)line-raster->geometry->gfx_position.y;
        int x=raster->geometry->gfx_position.x;
        if(y>=0 && y<PLUS64_HEIGHT && x>=0 &&
           (size_t)x+PLUS64_WIDTH<=raster->geometry->screen_size.width)
            memset(raster->draw_buffer_ptr+x,0,PLUS64_WIDTH);
    }
    /* Opt-in native borders are final presentation, after scenery, sprites,
       windows and guest blanking. The collision path above is unchanged. */
    p64_side_border_clip_scanline(raster->draw_buffer_ptr,
        (size_t)raster->geometry->screen_size.width,
        (int)line-raster->geometry->gfx_position.y,
        raster->geometry->gfx_position.x,(unsigned)plus64_scene_formats,
        sprite.regs[15],border);
}
void plus64vice_draw_indexed_frame(uint8_t *pixels,size_t stride){
    if(plus64_enabled) {
        if (plus64_left_mcm) plus64_draw_masked_main(&sprite,pixels,NULL,stride,plus64_packed_cache,plus64_raster_collisions,NULL,1,plus64_main_ram?mem_ram:NULL);
        else if (plus64_raster_collisions) plus64_draw_masked_main(&sprite,pixels,NULL,stride,plus64_packed_cache,1,NULL,0,plus64_main_ram?mem_ram:NULL);
        else if (plus64_packed_cache) plus64_draw_masked_main(&sprite,pixels,NULL,stride,1,0,NULL,0,plus64_main_ram?mem_ram:NULL);
        else plus64_draw(&sprite,pixels,stride);
    }
}

/* Public VICE options: -plus64 / +plus64. */
static const cmdline_option_t plus64_options[] = {
    { "-plus64", SET_RESOURCE, CMDLINE_ATTRIB_NONE,
      NULL, NULL, "Plus64Enabled", (resource_value_t)1,
      NULL, "Enable plus/64 expansion" },
    { "+plus64", SET_RESOURCE, CMDLINE_ATTRIB_NONE,
      NULL, NULL, "Plus64Enabled", (resource_value_t)0,
      NULL, "Disable plus/64 expansion" },
    { "-plus64mainram", SET_RESOURCE, CMDLINE_ATTRIB_NONE,
      NULL, NULL, "Plus64MainRAM", (resource_value_t)1,
      NULL, "Shared 64K cartridge CPU/TED plus 16K host buffer (80K total)" },
    { "+plus64mainram", SET_RESOURCE, CMDLINE_ATTRIB_NONE,
      NULL, NULL, "Plus64MainRAM", (resource_value_t)0,
      NULL, "Disable experimental shared main RAM" },
    { "-plus64packedcache", SET_RESOURCE, CMDLINE_ATTRIB_NONE,
      NULL, NULL, "Plus64PackedCache", (resource_value_t)1,
      NULL, "NEW experimental exact-cache packed MCM video format" },
    { "+plus64packedcache", SET_RESOURCE, CMDLINE_ATTRIB_NONE,
      NULL, NULL, "Plus64PackedCache", (resource_value_t)0,
      NULL, "Use legacy expanded8bpp plus/64 MCM format" },
    { "-plus64rastercollisions", SET_RESOURCE, CMDLINE_ATTRIB_NONE,
      NULL, NULL, "Plus64RasterCollisions", (resource_value_t)1,
      NULL, "Experimental scanline collision latch including hidden horizontal overlaps" },
    { "+plus64rastercollisions", SET_RESOURCE, CMDLINE_ATTRIB_NONE,
      NULL, NULL, "Plus64RasterCollisions", (resource_value_t)0,
      NULL, "Legacy whole-frame collision latch" },
    { "-plus64leftmcm", SET_RESOURCE, CMDLINE_ATTRIB_NONE,
      NULL, NULL, "Plus64LeftMCM", (resource_value_t)1,
      NULL, "Experimental packed MCM X488..511 means negative left projection" },
    { "+plus64leftmcm", SET_RESOURCE, CMDLINE_ATTRIB_NONE,
      NULL, NULL, "Plus64LeftMCM", (resource_value_t)0,
      NULL, "Keep legacy unsigned descriptor projection" },
    { "-plus64mixedsprites", SET_RESOURCE, CMDLINE_ATTRIB_NONE,
      NULL, NULL, "Plus64MixedSprites", (resource_value_t)1,
      NULL, "Opt-in mixed RAW8 and compact tonal sprite formats" },
    { "+plus64mixedsprites", SET_RESOURCE, CMDLINE_ATTRIB_NONE,
      NULL, NULL, "Plus64MixedSprites", (resource_value_t)0,
      NULL, "Disable extended sprite formats" },
    CMDLINE_LIST_END
};
int plus64vice_cmdline_options_init(void) {
    return cmdline_register_options(plus64_options);
}

/* Snapshot wire data and staging are transient HOST I/O state. They are
 * never mapped to the emulated CPU/TED/cartridge; the guest still owns only
 * mem_ram[65536] + p64_aux_ram[16384]. Keep the latched compositor state:
 * rebuilding it from live descriptors would change mid-frame multiplexing.
 */
typedef struct {
    uint8_t payload[P64_SNAPSHOT_PAYLOAD_SIZE];
    uint8_t cpu_ram[P64_MEM_TOTAL];
} p64_snapshot_staging;
static p64_snapshot_staging *snapshot_pending;

static uint32_t p64_get32(const uint8_t *p) {
    return (uint32_t)p[0]|((uint32_t)p[1]<<8)|((uint32_t)p[2]<<16)|((uint32_t)p[3]<<24);
}
static void p64_put32(uint8_t *p,uint32_t v) {
    p[0]=(uint8_t)v;p[1]=(uint8_t)(v>>8);p[2]=(uint8_t)(v>>16);p[3]=(uint8_t)(v>>24);
}
static uint32_t p64_crc32(const uint8_t *p,size_t n) {
    uint32_t crc=0xffffffffu;
    while(n--){crc^=*p++;for(unsigned b=0;b<8;++b)crc=(crc>>1)^(0xedb88320u&((uint32_t)0-(crc&1u)));}
    return ~crc;
}
static int p64_snapshot_error(const char *message) {
    log_error(LOG_DEFAULT,"plus/64 snapshot: %s",message);
    snapshot_set_error(SNAPSHOT_MODULE_INCOMPATIBLE);
    return -1;
}
static int p64_snapshot_modem_busy(void) {
    return plus64_enabled && (modem.connected||modem.dialing||link.connecting||link.fd!=(intptr_t)-1);
}
int plus64vice_snapshot_write_allowed(void) {
    if(p64_snapshot_modem_busy())return p64_snapshot_error("disconnect the live modem before saving; remote TCP state cannot be rewound");
    return 0;
}
void plus64vice_snapshot_discard_read(void) {
    if(snapshot_pending){lib_free(snapshot_pending);snapshot_pending=NULL;}
}
int plus64vice_snapshot_has_pending_read(void) { return snapshot_pending!=NULL; }

/* Bound every module before VICE's historical name search. Its old search
 * assumes positive module sizes; a zero-sized predecessor must not hang the
 * emulator. zfile gives this the same compressed-file support as VICE.
 */
static int p64_snapshot_file_bounds(const char *name) {
    FILE *file=zfile_fopen(name,"rb");
    uint8_t head[37],version[13],module[22];
    long length,position;
    static const char *const unique_names[]={
        "PLUS64","PLUS4MEM","SIDCARTP64","SID","SIDEXTENDED","TEDTIMERS80","TEDAUDIO80",
        "MAINCPU","TED","TEDPIPE80"
    };
    /* Exact fixed wire lengths for the new 1.0 modules. The base VICE
       modules and SID metadata validate their own versioned payloads. */
    static const uint32_t exact_sizes[]={
        P64_SNAPSHOT_PAYLOAD_SIZE+22u,0,0,0,0,144u,94u,0,0,82697u
    };
    unsigned counts[sizeof(unique_names)/sizeof(unique_names[0])]={0};
    int good=0;
    if(!file)return p64_snapshot_error("cannot inspect snapshot bounds");
    if(fseek(file,0,SEEK_END)<0||(length=ftell(file))<37||fseek(file,0,SEEK_SET)<0)goto done;
    if(fread(head,1,sizeof(head),file)!=sizeof(head)||memcmp(head,"VICE Snapshot File\032",19))goto done;
    position=37;
    if(fread(version,1,sizeof(version),file)==sizeof(version)&&!memcmp(version,"VICE Version\032",13))position=58;
    if(position>length)goto done;
    while(position<length){
        uint32_t size;
        if(length-position<22||fseek(file,position,SEEK_SET)<0||fread(module,1,sizeof(module),file)!=sizeof(module))goto done;
        size=p64_get32(module+18);
        if(size<22u||(unsigned long)size>(unsigned long)(length-position))goto done;
        for(unsigned i=0;i<sizeof(unique_names)/sizeof(unique_names[0]);++i){
            size_t n=strlen(unique_names[i]);
            if(!memcmp(module,unique_names[i],n)&&module[n]==0){
                if(++counts[i]>1||(exact_sizes[i]&&size!=exact_sizes[i]))goto done;
            }
        }
        position+=(long)size;
    }
    /* The new cartridge module requires its base CPU/MEM/TED state too.
       Reject removal/duplication here before the historical reader mutates
       the current machine or follows an ambiguous module name. */
    good=position==length&&(!counts[0]||(counts[1]==1&&counts[7]==1&&counts[8]==1));
done:
    zfile_fclose(file);
    return good ? 0 : p64_snapshot_error("invalid, duplicate or truncated snapshot module bounds");
}

static int p64_snapshot_payload_valid(const uint8_t *p) {
    static const unsigned bools[]={12,13,14,15,16,17,19,21,62,63};
    uint32_t rxh=p64_get32(p+32),rxt=p64_get32(p+36),rxc=p64_get32(p+40);
    uint32_t txh=p64_get32(p+44),txt=p64_get32(p+48),txc=p64_get32(p+52);
    uint32_t ram=p64_get32(p+24),previous=p64_get32(p+28);
    if(memcmp(p,"P64S",4)||p64_get32(p+4)!=P64_SNAPSHOT_PAYLOAD_SIZE)return -1;
    if(p64_get32(p+8)!=p64_crc32(p+12,P64_SNAPSHOT_PAYLOAD_SIZE-12))return -1;
    for(unsigned i=0;i<sizeof(bools)/sizeof(bools[0]);++i)if(p[bools[i]]>1)return -1;
    if(p[13]&&!p[12])return -1;
    if(p[15]&&!p[14])return -1;
    if(p[17]&&!p[12])return -1;
    if(p[19]&&!p[12])return -1;
    if(p[21]&&!p[13])return -1;
    if(p[20]>3||((unsigned)p[22]|((unsigned)p[23]<<8))>=P64_MEM_BANK_SIZE)return -1;
    if(ram!=16&&ram!=32&&ram!=64)return -1;
    if(p[12]&&ram!=(p[13]?64u:16u))return -1;
    if(previous!=0&&previous!=16&&previous!=32&&previous!=64)return -1;
    if(p[12]&&!previous)return -1;
    if(rxh>=P64_RX_CAP||rxt>=P64_RX_CAP||rxc>P64_RX_CAP)return -1;
    if(txh>=P64_TX_CAP||txt>=P64_TX_CAP||txc>P64_TX_CAP)return -1;
    if((rxt+P64_RX_CAP-rxh)%P64_RX_CAP!=rxc%P64_RX_CAP)return -1;
    if((txt+P64_TX_CAP-txh)%P64_TX_CAP!=txc%P64_TX_CAP)return -1;
    if(p64_get32(p+56)>=P64_CMD_CAP||p[60]>4)return -1;
    if(p[61]&&p[61]!=251&&p[61]!=252&&p[61]!=253&&p[61]!=254)return -1;
    if(p[64]||p[65]||p[66]||p[67])return -1;
    if(p[72]>1 || (p[72] && !p[14]))return -1;
    if(p[73]>1 || (p[73] && !p[72]))return -1;
    if(p[74]>1 || (p[74] && !p[73]))return -1;
    if(p[75]>1 || (p[75] && !p[73]))return -1;
    if(p[76]>1 || (p[76] && (!p[74] || !p[75])))return -1;
    if(p[77]>1 || (p[77] && !p[72]))return -1;
    if(p[78]>1 || (p[78] && (!p[72] || !p[75])))return -1;
    if((p[79]!=0 && p[79]!=1 && p[79]!=3 && p[79]!=4 && p[79]!=5 && p[79]!=6 && p[79]!=7 && p[79]!=8 && p[79]!=9&&p[79]!=10&&p[79]!=11&&p[79]!=12&&p[79]!=13&&p[79]!=14&&p[79]!=15&&p[79]!=16&&p[79]!=17&&p[79]!=18&&p[79]!=19&&p[79]!=20&&p[79]!=21&&p[79]!=22) || (p[79] && (!p[72] || !p[77])))return -1;
    if(p[80]>1 || (p[80] && (!p[72] || !p[14])))return -1;
    if(p[81]>1 || (p[81] && (!p[80] || !p[72] || !p[14])))return -1;
    if(p[82]>8 || (p[82] && (!p[80] || !p[72] || !p[14])))return -1;
    for(unsigned i=83;i<P64_SNAPSHOT_HEADER_SIZE;++i)if(p[i])return -1;
    /* Cached TED colour indices come only from a masked HIRES colour or
       a validated expanded pixel. Never accept an out-of-palette index. */
    for(unsigned i=P64_SNAPSHOT_OVERLAY_OFFSET;i<P64_SNAPSHOT_ALPHA_OFFSET;++i)if(p[i]>127)return -1;
    return 0;
}

int plus64vice_snapshot_write_module(snapshot_t *s) {
    snapshot_module_t *module=NULL;
    uint8_t *p;
    int ram_size=0,hack=0,result=-1;
    if(plus64vice_snapshot_write_allowed()<0)return -1;
    /* Plain-machine2.0 snapshots keep their historical optional-memory
       support and do not promise any active plus/64 cartridge state. */
    if(!plus64_enabled)return 0;
    if(resources_get_int("RamSize",&ram_size)<0||resources_get_int("MemoryHack",&hack)<0)return -1;
    if(hack)return p64_snapshot_error("optional memory expansion conflicts with RAM80");
    p=lib_calloc(1,P64_SNAPSHOT_PAYLOAD_SIZE);
    memcpy(p,"P64S",4);p64_put32(p+4,P64_SNAPSHOT_PAYLOAD_SIZE);
    p[12]=(uint8_t)plus64_enabled;p[13]=(uint8_t)plus64_main_ram;
    p[14]=(uint8_t)plus64_packed_cache;p[15]=(uint8_t)plus64_left_mcm;
    p[16]=(uint8_t)plus64_raster_collisions;p[17]=(uint8_t)overlay_ready;
    p[72]=(uint8_t)plus64_mixed_sprites;
    p[73]=sprite.material_full_palette;
    p[74]=sprite.sparse_formats;
    p[75]=sprite.light_directions;
    p[76]=sprite.front_mask_profile;
    p[77]=sprite.tile_lighting;
    p[78]=sprite.diagonal_lighting;
    p[79]=(uint8_t)plus64_scene_formats;
    p[80]=sprite.dense_formats;
    p[81]=sprite.dense_height_formats;
    p[82]=sprite.dense_material_formats;
    p[18]=sprite.collision;p[19]=(uint8_t)plus64_sid_owned;
    p[20]=banked_ram.bank;p[21]=(uint8_t)main_ram_owned_expansion;
    p[22]=(uint8_t)banked_ram.offset;p[23]=(uint8_t)(banked_ram.offset>>8);
    p64_put32(p+24,(uint32_t)ram_size);p64_put32(p+28,(uint32_t)previous_ram_size);
    p64_put32(p+32,(uint32_t)modem.r_head);p64_put32(p+36,(uint32_t)modem.r_tail);p64_put32(p+40,(uint32_t)modem.r_count);
    p64_put32(p+44,(uint32_t)modem.t_head);p64_put32(p+48,(uint32_t)modem.t_tail);p64_put32(p+52,(uint32_t)modem.t_count);
    p64_put32(p+56,(uint32_t)modem.clen);p[60]=modem.telnet_state;p[61]=modem.telnet_verb;
    p[62]=(uint8_t)modem.echo;p[63]=(uint8_t)modem.overrun;
    p64_put32(p+68,p64_crc32(mem_ram,P64_MEM_TOTAL));
    memcpy(p+P64_SNAPSHOT_REGS_OFFSET,sprite.regs,sizeof(sprite.regs));
    memcpy(p+P64_SNAPSHOT_AUX_OFFSET,p64_aux_ram,P64_HOST_RAM_SIZE);
    memcpy(p+P64_SNAPSHOT_OVERLAY_OFFSET,overlay,sizeof(overlay));
    memcpy(p+P64_SNAPSHOT_ALPHA_OFFSET,alpha,sizeof(alpha));
    memcpy(p+P64_SNAPSHOT_COLLISION_OFFSET,collision_lines,sizeof(collision_lines));
    p64_put32(p+8,p64_crc32(p+12,P64_SNAPSHOT_PAYLOAD_SIZE-12));
    if(p64_snapshot_payload_valid(p)<0){p64_snapshot_error("current device state cannot be represented");goto done;}
    module=snapshot_module_create(s,P64_SNAPSHOT_MODULE,P64_SNAPSHOT_MAJOR,P64_SNAPSHOT_MINOR);
    if(!module||SMW_BA(module,p,P64_SNAPSHOT_PAYLOAD_SIZE)<0)goto done;
    if(snapshot_module_close(module)<0){module=NULL;goto done;}module=NULL;
    result=0;
done:
    if(module)snapshot_module_close(module);
    lib_free(p);
    return result;
}

int plus64vice_snapshot_prepare_read(snapshot_t *s,const char *filename) {
    snapshot_module_t *module=NULL;
    uint8_t major=0,minor=0,byte;
    int hack=0,result=-1;
    plus64vice_snapshot_discard_read();
    if(p64_snapshot_modem_busy())return p64_snapshot_error("disconnect the live modem before loading; its remote peer cannot be rewound");
    if(p64_snapshot_file_bounds(filename)<0)return -1;
    module=snapshot_module_open(s,P64_SNAPSHOT_MODULE,&major,&minor);
    if(!module){
        if(plus64_enabled)return p64_snapshot_error("legacy snapshot has no complete plus/64 state");
        snapshot_set_error(SNAPSHOT_NO_ERROR);return 0;
    }
    if(major!=P64_SNAPSHOT_MAJOR||minor!=P64_SNAPSHOT_MINOR)goto invalid;
    snapshot_pending=lib_malloc(sizeof(*snapshot_pending));
    if(SMR_BA(module,snapshot_pending->payload,P64_SNAPSHOT_PAYLOAD_SIZE)<0)goto invalid;
    /* Fixed version1.0 has no optional trailing fields. Probe its boundary
       without consuming another module, then clear the expected EOF status. */
    if(SMR_B(module,&byte)==0||snapshot_get_error()!=SNAPSHOT_READ_OUT_OF_BOUNDS_ERROR)goto invalid;
    snapshot_set_error(SNAPSHOT_NO_ERROR);
    if(snapshot_module_close(module)<0){module=NULL;goto invalid;}module=NULL;
    if(p64_snapshot_payload_valid(snapshot_pending->payload)<0)goto invalid;
    if(resources_get_int("MemoryHack",&hack)<0||hack)goto invalid;
    module=snapshot_module_open(s,"PLUS4MEM",&major,&minor);
    if(!module||major!=1||minor!=0)goto invalid;
    for(unsigned i=0;i<4;++i)if(SMR_B(module,&byte)<0)goto invalid;
    if(SMR_BA(module,snapshot_pending->cpu_ram,P64_MEM_TOTAL)<0)goto invalid;
    if(snapshot_module_close(module)<0){module=NULL;goto invalid;}module=NULL;
    if(p64_crc32(snapshot_pending->cpu_ram,P64_MEM_TOTAL)!=p64_get32(snapshot_pending->payload+68))goto invalid;
    result=0;
    return result;
invalid:
    if(module)snapshot_module_close(module);
    plus64vice_snapshot_discard_read();
    return p64_snapshot_error("incomplete, corrupt or unsupported plus/64 module");
}

int plus64vice_snapshot_configure_read(void) {
    const uint8_t *p;
    int result=0;
    if(!snapshot_pending)return 0;
    p=snapshot_pending->payload;
    plus64_snapshot_configuring=1;
    /* Only a validated offline snapshot reaches this point. Configuration
       happens while the main CPU is stopped, before its saved state loads. */
    if(plus64_enabled&&!p[12]){
        plus64_main_ram=0;
        result=plus64_set_enabled(0,NULL);
    }else if(!plus64_enabled&&p[12])result=plus64_set_enabled(1,NULL);
    if(result==0){
        plus64_mixed_sprites=p[72];sprite.extended_formats=p[72];sprite.material_full_palette=p[73];sprite.sparse_formats=p[74];sprite.light_directions=p[75];sprite.front_mask_profile=p[76];sprite.tile_lighting=p[77];sprite.diagonal_lighting=p[78];plus64_scene_formats=p[79];sprite.collision_only_formats=p[79]>=16?2u:(p[79]>=15?1u:0u);sprite.dense_formats=p[80];sprite.dense_height_formats=p[81];sprite.dense_material_formats=p[82];
        plus64_main_ram=p[13];plus64_packed_cache=p[14];plus64_left_mcm=p[15];plus64_raster_collisions=p[16];
        previous_ram_size=(int)p64_get32(p+28);main_ram_owned_expansion=p[21];plus64_sid_owned=p[19];
        result=resources_set_int("RamSize",(int)p64_get32(p+24));
        if(result==0){
            p64_memory_restore_views(&banked_ram,mem_ram,plus64_main_ram);
            plus64_bind_ram(&sprite,plus64_enabled?p64_memory_sprite_ram(&banked_ram):NULL);
            p64_modem_init(&modem,p64_tcp_ops(),&link,p64_memory_modem_ram(&banked_ram));
            overlay_ready=0;
        }
    }
    plus64_snapshot_configuring=0;
    return result;
}
void plus64vice_snapshot_apply_read(void) {
    const uint8_t *p;
    if(!snapshot_pending)return;
    p=snapshot_pending->payload;
    memcpy(mem_ram,snapshot_pending->cpu_ram,P64_MEM_TOTAL);
    memcpy(p64_aux_ram,p+P64_SNAPSHOT_AUX_OFFSET,P64_HOST_RAM_SIZE);
    memcpy(sprite.regs,p+P64_SNAPSHOT_REGS_OFFSET,sizeof(sprite.regs));sprite.collision=p[18];
    banked_ram.bank=p[20];banked_ram.offset=(uint16_t)((unsigned)p[22]|((unsigned)p[23]<<8));
    modem.r_head=p64_get32(p+32);modem.r_tail=p64_get32(p+36);modem.r_count=p64_get32(p+40);
    modem.t_head=p64_get32(p+44);modem.t_tail=p64_get32(p+48);modem.t_count=p64_get32(p+52);
    modem.clen=p64_get32(p+56);modem.telnet_state=p[60];modem.telnet_verb=p[61];
    modem.echo=p[62];modem.overrun=p[63];modem.connected=0;modem.dialing=0;
    memcpy(overlay,p+P64_SNAPSHOT_OVERLAY_OFFSET,sizeof(overlay));
    memcpy(alpha,p+P64_SNAPSHOT_ALPHA_OFFSET,sizeof(alpha));
    memcpy(collision_lines,p+P64_SNAPSHOT_COLLISION_OFFSET,sizeof(collision_lines));overlay_ready=p[17];
}
