/*
 * ted-timer.h - Timer implementation for the TED emulation.
 *
 * Written by
 *  Andreas Boose <viceteam@t-online.de>
 *
 * This file is part of VICE, the Versatile Commodore Emulator.
 * See README for copyright notice.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
 *  02111-1307  USA.
 *
 */

#ifndef VICE_TED_TIMER_H
#define VICE_TED_TIMER_H

#include "types.h"

void ted_timer_init(void);
void ted_timer_reset(void);

void ted_timer_store(uint16_t addr, uint8_t value);
uint8_t ted_timer_read(uint16_t addr);

/* Portable exact timer state, including half-clock phase and alarm deadlines.
 * Preflight validates without changing live counters or pending alarms.
 */
struct snapshot_s;
int ted_timer_snapshot_write_module(struct snapshot_s *s);
int ted_timer_snapshot_preflight(struct snapshot_s *s, int required);
int ted_timer_snapshot_read_module(struct snapshot_s *s, int required);

#endif
