/* SPDX-License-Identifier: GPL-2.0-or-later */
/* Generic temporary view of guest-owned material/bytecode metadata. */
#ifndef P64_METADATA_H
#define P64_METADATA_H
#include <stdint.h>
#include <stddef.h>
#define P64_METADATA_HEADER_BYTES 12u
#define P64_METADATA_MAX_BYTES 65535u
#define P64_METADATA_FORMAT_ERROR (-4)
#define P64_METADATA_MEMORY_ERROR (-5)
typedef struct p64_metadata_view_s {
 const uint8_t *bytes;
 size_t size;
 uint8_t *owned;
} p64_metadata_view_t;
/* Raw data is borrowed. P64Z version1/method1 or2 owns only a temporary expansion:
 * magic4,version8,method8,rawlen16,storedlen16,reserved16zero,member. Method1 is a zlib member. Method2 is five
 * LZMA properties, an EOS-terminated LZMA1 stream and raw CRC32little-endian.
 * Both codecs check exact input/output lengths and integrity before publishing.
 * No retained/global state. Consumer must close on every path, within its
 * render/capture call; never store expanded pointers in guest or snapshots. */
int p64_metadata_open(const uint8_t *guest,size_t guest_bytes,p64_metadata_view_t *view);
void p64_metadata_close(p64_metadata_view_t *view);
#endif
