/*
 * sidcartjoy.c - SIDCART joystick port emulation.
 *
 * Written by
 *  Marco van den Heuvel <blackystardust68@yahoo.com>
 *
 * This file is part of VICE, the Versatile Commodore Emulator.
 * See README for copyright notice.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
 *  02111-1307  USA.
 *
 */

#include "vice.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "cartio.h"
#include "cartridge.h"
#include "cmdline.h"
#include "digiblaster.h"
#include "export.h"
#include "joyport.h"
#include "keyboard.h"
#include "plus4.h"
#include "resources.h"
#include "sid.h"
#include "resid.h"
#include "sid-cmdline-options.h"
#include "sid-resources.h"
#include "sidcart.h"
#include "sid-snapshot.h"
#include "snapshot.h"
#include "log.h"
#include "plus4-sidcart-snapshot.h"
#include "sound.h"
#include "types.h"
#include "uiapi.h"

int sidcartjoy_enabled = 0;

int sidcart_address = 0xfd40;
int sidcart_clock = 1;

/* ------------------------------------------------------------------------- */

#include "plus64_sid_clock_ratio.h"

static plus64_sid_clock_ratio_t sidcart_ratio;

static int sidcart_sound_machine_init(sound_t *psid, int speed, int cycles_per_sec)
{
    sidcart_ratio.denominator = cycles_per_sec;
    /* Constants from the existing C64 PAL/NTSC timing definitions. */
    sidcart_ratio.numerator = cycles_per_sec == PLUS4_PAL_CYCLES_PER_SEC ? 985248 : 1022730;
    sidcart_ratio.remainder = 0;
    return sid_sound_machine_init(psid, speed,
        sidcart_clock ? cycles_per_sec : sidcart_ratio.numerator);
}

#ifdef SOUND_SYSTEM_FLOAT
static int sidcart_sound_machine_calculate_samples(sound_t **psid, float *pbuf, int nr, int channels, CLOCK *delta_t)
#define SIDCART_CALCULATE(d) sid_sound_machine_calculate_samples(psid, pbuf, nr, channels, d)
#else
static int sidcart_sound_machine_calculate_samples(sound_t **psid, int16_t *pbuf, int nr, int soc, int scc, CLOCK *delta_t)
#define SIDCART_CALCULATE(d) sid_sound_machine_calculate_samples(psid, pbuf, nr, soc, scc, d)
#endif
{
    CLOCK native_delta, sid_delta;
    uint64_t planned, consumed;
    int result;
    if (sidcart_clock || !sid_sound_machine_cycle_based()) {
        return SIDCART_CALCULATE(delta_t);
    }
    native_delta = *delta_t;
    planned = plus64_sid_clock_plan(&sidcart_ratio, native_delta);
    sid_delta = planned;
    result = SIDCART_CALCULATE(&sid_delta);
    consumed = plus64_sid_clock_commit(&sidcart_ratio, native_delta, planned - sid_delta);
    *delta_t = native_delta - consumed;
    return result;
}
#undef SIDCART_CALCULATE

static void sidcart_sound_machine_reset(sound_t *psid, CLOCK cpu_clk)
{
    sidcart_ratio.remainder = 0;
    sid_sound_machine_reset(psid, cpu_clk);
}

#ifdef SOUND_SYSTEM_FLOAT
/* stereo mixing placement of the PLUS4 SID cartridge sound */
static sound_chip_mixing_spec_t sidcart_sound_mixing_spec[SOUND_CHIP_CHANNELS_MAX] = {
    {
        100, /* left channel volume % in case of stereo output, default output to both */
        100  /* right channel volume % in case of stereo output, default output to both */
    }
};
#endif

/* PLUS4 SID cartridge sound chip */
static sound_chip_t sidcart_sound_chip = {
    sid_sound_machine_open,              /* sound chip open function */
    sidcart_sound_machine_init,          /* sound chip init function */
    sid_sound_machine_close,             /* sound chip close function */
    sidcart_sound_machine_calculate_samples, /* exact device clock domain */
    sid_sound_machine_store,             /* sound chip store function */
    sid_sound_machine_read,              /* sound chip read function */
    sidcart_sound_machine_reset,          /* reset fractional clock phase */
    sid_sound_machine_cycle_based,       /* sound chip 'is_cycle_based()' function, RESID engine is cycle based, all other engines are NOT */
    sid_sound_machine_channels,          /* sound chip 'get_amount_of_channels()' function, sound chip has 1 channel */
#ifdef SOUND_SYSTEM_FLOAT
    sidcart_sound_mixing_spec,           /* stereo mixing placement specs */
#endif
    0                                    /* sound chip enabled flag, toggled upon device (de-)activation */
};

static uint16_t sidcart_sound_chip_offset = 0;

void sidcart_sound_chip_init(void)
{
    sidcart_sound_chip_offset = sound_chip_register(&sidcart_sound_chip);
}

/* ------------------------------------------------------------------------- */

/* Some prototypes are needed */
static void sidcartjoy_store(uint16_t addr, uint8_t value);
static uint8_t sidcartjoy_read(uint16_t addr);

static io_source_t sidcart_fd40_device = {
    "SID Cartridge",      /* name of the device */
    IO_DETACH_RESOURCE,   /* use resource to detach the device when involved in a read-collision */
    "SidCart",            /* resource to set to '0' */
    0xfd40, 0xfd5d, 0x1f, /* range for the device, regs:$fd40-$fd5d */
    1,                    /* read is always valid */
    sid_store,            /* store function */
    NULL,                 /* NO poke function */
    sid_read,             /* read function */
    sid_peek,             /* peek function */
    sid_dump,             /* device state information dump function */
    CARTRIDGE_PLUS4_SIDCART,      /* cartridge id */
    IO_PRIO_NORMAL,       /* normal priority, device read needs to be checked for collisions */
    0,                    /* insertion order, gets filled in by the registration function */
    IO_MIRROR_NONE        /* NO mirroring */
};

static io_source_t sidcart_fe80_device = {
    "SID Cartridge",      /* name of the device */
    IO_DETACH_RESOURCE,   /* use resource to detach the device when involved in a read-collision */
    "SidCart",            /* resource to set to '0' */
    0xfe80, 0xfe9d, 0x1f, /* range for the device, regs:$fe80-$fe9d */
    1,                    /* read is always valid */
    sid_store,            /* store function */
    NULL,                 /* NO poke function */
    sid_read,             /* read function */
    sid_peek,             /* peek function */
    sid_dump,             /* device state information dump function */
    CARTRIDGE_PLUS4_SIDCART,      /* cartridge id */
    IO_PRIO_NORMAL,       /* normal priority, device read needs to be checked for collisions */
    0,                    /* insertion order, gets filled in by the registration function */
    IO_MIRROR_NONE        /* NO mirroring */
};

static const export_resource_t export_res1 = {
    CARTRIDGE_PLUS4_NAME_SIDCART, 0, 0, &sidcart_fd40_device, NULL, CARTRIDGE_PLUS4_SIDCART
};

static const export_resource_t export_res2 = {
    CARTRIDGE_PLUS4_NAME_SIDCART, 0, 0, NULL, &sidcart_fe80_device, CARTRIDGE_PLUS4_SIDCART
};

static io_source_t sidcart_joy_device = {
    "SID Cartridge Joystick", /* name of the device */
    IO_DETACH_RESOURCE,       /* use resource to detach the device when involved in a read-collision */
    "SIDCartJoy",             /* resource to set to '0' */
    0xfd80, 0xfd8f, 0xff,     /* range for the device, address is ignored, reg:$fd80, mirrors:$fd81-$fd8f */
    1,                        /* read is always valid */
    sidcartjoy_store,         /* store function */
    NULL,                     /* NO poke function */
    sidcartjoy_read,          /* read function */
    NULL,                     /* TODO: peek function */
    NULL,                     /* TODO: device state information dump function */
    CARTRIDGE_PLUS4_SIDCART,      /* cartridge id */
    IO_PRIO_NORMAL,           /* normal priority, device read needs to be checked for collisions */
    0,                        /* insertion order, gets filled in by the registration function */
    IO_MIRROR_NONE            /* NO mirroring */
};

static const export_resource_t export_res_joy = {
    CARTRIDGE_PLUS4_NAME_SIDCART, 0, 0, &sidcart_joy_device, NULL, CARTRIDGE_PLUS4_SIDCART
};

static io_source_list_t *sidcartjoy_list_item = NULL;
static io_source_list_t *sidcart_list_item = NULL;

int sidcart_enabled(void)
{
    return sidcart_sound_chip.chip_enabled;
}

static int set_sidcart_enabled(int value, void *param)
{
    int val = value ? 1 : 0;

    if (val == sidcart_sound_chip.chip_enabled) {
        return 0;
    }

    export_remove(&export_res1);
    export_remove(&export_res2);
    if (val) {
        if (sidcart_address == 0xfd40) {
            sidcart_list_item = io_source_register(&sidcart_fd40_device);
            if (export_add(&export_res1) < 0) {
                return -1;
            }
        } else {
            sidcart_list_item = io_source_register(&sidcart_fe80_device);
            if (export_add(&export_res2) < 0) {
                return -1;
            }
        }
    } else {
        io_source_unregister(sidcart_list_item);
        sidcart_list_item = NULL;
    }
    sidcart_sound_chip.chip_enabled = val;
#ifdef HAVE_RESID
    sid_set_enable(val);
#endif
    sound_state_changed = 1;
    return 0;
}

static int set_sid_address(int val, void *param)
{
    switch (val) {
        case 0xfd40:
        case 0xfe80:
            break;
        default:
            return -1;
    }

    if (sidcart_address == val) {
        return 0;
    }

    export_remove(&export_res1);
    export_remove(&export_res2);
    if (sidcart_sound_chip.chip_enabled) {
        io_source_unregister(sidcart_list_item);
        if (val == 0xfd40) {
            sidcart_list_item = io_source_register(&sidcart_fd40_device);
            if (export_add(&export_res1) < 0) {
                return -1;
            }
        } else {
            sidcart_list_item = io_source_register(&sidcart_fe80_device);
            if (export_add(&export_res2) < 0) {
                return -1;
            }
        }
    }

    digiblaster_set_address((uint16_t)val);
    sidcart_address = val;

    return 0;
}

static int set_sid_clock(int val, void *param)
{
    switch (val) {
        case SIDCART_CLOCK_C64:
        case SIDCART_CLOCK_NATIVE:
            break;
        default:
            return -1;
    }

    if (val != sidcart_clock) {
        sidcart_clock = val;
        sid_state_changed = 1;
    }
    return 0;
}

static int set_sidcartjoy_enabled(int value, void *param)
{
    int val = value ? 1 : 0;

    if (val == sidcartjoy_enabled) {
        return 0;
    }

    export_remove(&export_res_joy);

    if (val) {
        sidcartjoy_list_item = io_source_register(&sidcart_joy_device);
        if (export_add(&export_res_joy) < 0) {
            return -1;
        }
        joystick_adapter_set_add_ports(1);
    } else {
        io_source_unregister(sidcartjoy_list_item);
        sidcartjoy_list_item = NULL;
        joystick_adapter_set_add_ports(0);
    }

    sidcartjoy_enabled = val;

    return 0;
}

/* ------------------------------------------------------------------------- */

static const resource_int_t sidcart_resources_int[] = {
    { "SidCart", 0, RES_EVENT_SAME, NULL,
      &sidcart_sound_chip.chip_enabled, set_sidcart_enabled, NULL },
    { "SIDCartJoy", 0, RES_EVENT_SAME, NULL,
      &sidcartjoy_enabled, set_sidcartjoy_enabled, NULL },
    { "SidAddress", 0xfd40, RES_EVENT_SAME, NULL,
      &sidcart_address, set_sid_address, NULL },
    { "SidClock", SIDCART_CLOCK_NATIVE, RES_EVENT_SAME, NULL,
      &sidcart_clock, set_sid_clock, NULL },
    RESOURCE_INT_LIST_END
};

int sidcart_resources_init(void)
{
#ifdef HAVE_RESID
    sid_set_enable(0);
#endif
    if (sid_resources_init() < 0) {
        return -1;
    }
    return resources_register_int(sidcart_resources_int);
}

/* ------------------------------------------------------------------------- */

static const cmdline_option_t sidcart_cmdline_options[] =
{
    { "-sidcart", SET_RESOURCE, CMDLINE_ATTRIB_NONE,
      NULL, NULL, "SidCart", (resource_value_t)1,
      NULL, "Enable the SID cartridge" },
    { "+sidcart", SET_RESOURCE, CMDLINE_ATTRIB_NONE,
      NULL, NULL, "SidCart", (resource_value_t)0,
      NULL, "Disable the SID cartridge" },
    { "-sidcartjoy", SET_RESOURCE, CMDLINE_ATTRIB_NONE,
      NULL, NULL, "SIDCartJoy", (resource_value_t)1,
      NULL, "Enable SID cartridge joystick" },
    { "+sidcartjoy", SET_RESOURCE, CMDLINE_ATTRIB_NONE,
      NULL, NULL, "SIDCartJoy", (resource_value_t)0,
      NULL, "Disable SID cartridge joystick" },
    { "-sidcartaddress", SET_RESOURCE, CMDLINE_ATTRIB_NEED_ARGS,
      NULL, NULL, "SidAddress", NULL,
      "<address>", "SID cartridge address (0xFD40/0xFE80)" },
    { "-sidcartclock", SET_RESOURCE, CMDLINE_ATTRIB_NEED_ARGS,
      NULL, NULL, "SidClock", NULL,
      "<clock>", "SID cartridge clock (0: C64 clock, 1: PLUS4 clock)" },
    CMDLINE_LIST_END
};

int sidcart_cmdline_options_init(void)
{
    if (sid_cmdline_options_init(SIDTYPE_SIDCART) < 0) {
        return -1;
    }
    return cmdline_register_options(sidcart_cmdline_options);
}

/** \brief  Free memory allocated for the sidcart command line options
 */
void sidcart_cmdline_options_shutdown(void)
{
    /* clean up the runtime-constructed sid cmdline help */
    sid_cmdline_options_shutdown();
}

/* ------------------------------------------------------------------------- */

static void sidcartjoy_store(uint16_t addr, uint8_t value)
{
    store_joyport_dig(JOYPORT_PLUS4_SIDCART, value, 0xff);
}

static uint8_t sidcartjoy_read(uint16_t addr)
{
    return read_joyport_dig(JOYPORT_PLUS4_SIDCART);
}

/* ------------------------------------------------------------------------- */
/* SIDCARTP64 1.0 complements the unchanged VICE SID 1.5 / SIDEXTENDED 1.4
 * modules. These are host snapshot buffers, not additional guest RAM.
 *
 * As in standard VICE, reSID snapshots preserve oscillator/noise/envelope and
 * bus/pipeline state. Analogue filter integrators and FIR history are not serialized by that
 * backend. The scalar sample schedule is added here so TED receives the
 * same number of samples after restoring the unchanged digital SID state. Sound=0 has no running synthesis engine:
 * preserve its register cache and configuration without opening an audio device.
 */
#define SIDCART_SNAP_NAME "SIDCARTP64"
#define SIDCART_SNAP_SIZE 313
#define SIDCART_SIMPLE_SIZE 36
#define SIDCART_EXTENDED_SIZE 133
#define SIDCART_CFG_COUNT 15

enum {
    SC_SOUND, SC_ENGINE, SC_MODEL, SC_FILTERS, SC_RAW, SC_SAMPLING,
    SC_PASSBAND, SC_GAIN, SC_BIAS, SC_8580_PASSBAND, SC_8580_GAIN,
    SC_8580_BIAS, SC_STEREO, SC_SAMPLE_RATE, SC_SPEED
};
static const char *const sidcart_snapshot_resource[SIDCART_CFG_COUNT] = {
    "Sound", "SidEngine", "SidModel", "SidFilters", "SidResidEnableRawOutput",
    "SidResidSampling", "SidResidPassband", "SidResidGain", "SidResidFilterBias",
    "SidResid8580Passband", "SidResid8580Gain", "SidResid8580FilterBias", "SidStereo",
    "SoundSampleRate", "Speed"
};
typedef struct {
    int present, enabled, joy, clock, address;
    int cfg[SIDCART_CFG_COUNT];
    plus64_sid_clock_ratio_t ratio;
    uint8_t cache[32];
    uint32_t simple_crc, extended_crc;
    int32_t sample_phase;
    uint32_t sample_period;
    uint32_t hidden[45];
} sidcart_snapshot_state_t;
static sidcart_snapshot_state_t sidcart_snapshot_pending;

static uint32_t sidcart_snapshot_crc(const uint8_t *data, unsigned int size)
{
    uint32_t crc = 0xffffffffU;
    unsigned int i, bit;
    for (i = 0; i < size; ++i) {
        crc ^= data[i];
        for (bit = 0; bit < 8; ++bit) {
            crc = (crc >> 1) ^ ((crc & 1U) ? 0xedb88320U : 0U);
        }
    }
    return crc ^ 0xffffffffU;
}
static void sidcart_snapshot_put(uint8_t **p, uint64_t value, unsigned int size)
{
    while (size--) {
        *(*p)++ = (uint8_t)value;
        value >>= 8;
    }
}
static uint64_t sidcart_snapshot_get(const uint8_t **p, unsigned int size)
{
    uint64_t result = 0;
    unsigned int i;
    for (i = 0; i < size; ++i) {
        result |= (uint64_t)*(*p)++ << (8 * i);
    }
    return result;
}
static int sidcart_snapshot_invalid(const char *reason)
{
    log_error(LOG_DEFAULT, "SID cartridge snapshot rejected: %s", reason);
    snapshot_set_error(SNAPSHOT_MODULE_INCOMPATIBLE);
    return -1;
}
/* Match sid_init/resid_init arithmetic without opening or changing a sound
 * backend during preflight. Percentage Speed is stored with the phase; the
 * frame-rate based negative Speed configuration is explicitly unsupported. */
static uint32_t sidcart_snapshot_sample_period(const sidcart_snapshot_state_t *st)
{
    int speed;
    double period;
    uint32_t clock = st->clock ? st->ratio.denominator : st->ratio.numerator;
    if (st->cfg[SC_SPEED] <= 0 || st->cfg[SC_SAMPLE_RATE] <= 0 || !clock) return 0;
    speed = (int)((double)st->cfg[SC_SAMPLE_RATE] * 100.0 / st->cfg[SC_SPEED]);
    if (speed <= 0) return 0;
    period = (double)clock / speed * 65536.0 + 0.5;
    if (period < 1.0 || period > 2147483647.0) return 0;
    return (uint32_t)period;
}
static int sidcart_snapshot_hidden_valid(const uint32_t p[45])
{
    for (unsigned i=0; i<3; ++i) {
        const uint32_t *v=p+15*i;
        if (v[0]>255 || v[1]>255 || v[2]>2 || v[3]>3 || v[4]>1 || v[5]>3
            || v[6]>1 || (v[7]!=0 && v[7]!=0x800000)
            || (v[8]!=0 && v[8]!=0xfff) || v[9]>0xfff || v[10]>0xfff
            || (v[11]!=0 && v[11]!=0xfff) || v[12]>0xfff || v[13]>0xfff
            || v[14]>0xfff) return 0;
    }
    return 1;
}
static int sidcart_snapshot_valid(const sidcart_snapshot_state_t *st)
{
    const int *c = st->cfg;
    int ratio_zero = !st->ratio.numerator && !st->ratio.denominator && !st->ratio.remainder;
    int ratio_valid =
        ((st->ratio.denominator == PLUS4_PAL_CYCLES_PER_SEC && st->ratio.numerator == 985248)
         || (st->ratio.denominator == PLUS4_NTSC_CYCLES_PER_SEC && st->ratio.numerator == 1022730))
        && st->ratio.remainder < st->ratio.denominator;
    if ((st->enabled != 0 && st->enabled != 1) || (st->joy != 0 && st->joy != 1)
        || (st->clock != 0 && st->clock != 1)
        || (st->address != 0xfd40 && st->address != 0xfe80)
        || (c[SC_SOUND] != 0 && c[SC_SOUND] != 1) || c[SC_STEREO] != 0
        || c[SC_MODEL] < SID_MODEL_6581 || c[SC_MODEL] > SID_MODEL_DTVSID
        || (c[SC_FILTERS] != 0 && c[SC_FILTERS] != 1)
        || (c[SC_RAW] != 0 && c[SC_RAW] != 1)
        || c[SC_SAMPLING] < 0 || c[SC_SAMPLING] > 3
        || c[SC_PASSBAND] < 0 || c[SC_PASSBAND] > 90
        || c[SC_8580_PASSBAND] < 0 || c[SC_8580_PASSBAND] > 90
        || c[SC_GAIN] < 90 || c[SC_GAIN] > 100
        || c[SC_8580_GAIN] < 90 || c[SC_8580_GAIN] > 100
        || c[SC_BIAS] < -5000 || c[SC_BIAS] > 5000
        || c[SC_8580_BIAS] < -5000 || c[SC_8580_BIAS] > 5000
        || c[SC_SAMPLE_RATE] <= 0
        || (c[SC_SOUND] && (c[SC_SAMPLE_RATE] < 8000 || c[SC_SAMPLE_RATE] > 96000))) {
        return sidcart_snapshot_invalid("invalid cartridge or sound configuration");
    }
    if (st->enabled) {
#ifndef HAVE_RESID
        return sidcart_snapshot_invalid("reSID is unavailable in this build");
#else
        if (c[SC_ENGINE] != SID_ENGINE_RESID) {
            return sidcart_snapshot_invalid("a restorable software reSID engine is required");
        }
#endif
        if (c[SC_SOUND] && c[SC_MODEL] == SID_MODEL_DTVSID) {
            return sidcart_snapshot_invalid("DTVSID sampling phase is not supported by this physical-SID profile");
        }
        if ((!ratio_valid && !ratio_zero) || (c[SC_SOUND] && !ratio_valid)) {
            return sidcart_snapshot_invalid("invalid fractional SID clock phase");
        }
    }
    if (st->enabled && c[SC_SOUND]) {
        uint32_t expected = sidcart_snapshot_sample_period(st);
        int32_t upper = c[SC_SAMPLING] == 0 ? 32767 : 65535;
        if (!sidcart_snapshot_hidden_valid(st->hidden)
            || !expected || st->sample_period != expected
            || st->sample_phase < -(int64_t)expected || st->sample_phase > upper) {
            return sidcart_snapshot_invalid("invalid SID sample scheduling phase, clock or percentage Speed");
        }
    } else {
        if (st->sample_phase || st->sample_period) {
            return sidcart_snapshot_invalid("unexpected sample phase for an inactive SID");
        }
        for (unsigned i=0;i<45;++i) if(st->hidden[i]) {
            return sidcart_snapshot_invalid("unexpected digital latches for an inactive SID");
        }
    }
    return 0;
}
static int sidcart_snapshot_capture(sidcart_snapshot_state_t *st, int check_ratio)
{
    unsigned int i;
    memset(st, 0, sizeof(*st));
    st->enabled = sidcart_enabled();
    st->joy = sidcartjoy_enabled;
    st->clock = sidcart_clock;
    st->address = sidcart_address;
    st->ratio = sidcart_ratio;
    memcpy(st->cache, sid_get_siddata(0), sizeof(st->cache));
    for (i = 0; i < SIDCART_CFG_COUNT; ++i) {
        if (resources_get_int(sidcart_snapshot_resource[i], &st->cfg[i]) < 0) {
            return sidcart_snapshot_invalid("a required sound resource is missing");
        }
    }
    /* write_allowed runs before sound_snapshot_prepare initializes/flushes the
     * backend. Check a canonical phase there; write_module checks the real one. */
    if (!check_ratio && st->enabled && st->cfg[SC_SOUND]) {
        st->ratio.numerator = 985248;
        st->ratio.denominator = PLUS4_PAL_CYCLES_PER_SEC;
        st->ratio.remainder = 0;
    }
    if (!check_ratio && st->cfg[SC_SOUND]
        && (st->cfg[SC_SAMPLE_RATE] < 8000 || st->cfg[SC_SAMPLE_RATE] > 96000)) {
        st->cfg[SC_SAMPLE_RATE] = SOUND_SAMPLE_RATE;
    }
    if (st->enabled && st->cfg[SC_SOUND]) {
        if (st->cfg[SC_ENGINE] != SID_ENGINE_RESID || st->cfg[SC_MODEL] == SID_MODEL_DTVSID) {
            return sidcart_snapshot_invalid("only the physical-SID reSID backend can save digital latches");
        }
        if (!check_ratio) {
            st->sample_period = sidcart_snapshot_sample_period(st);
        } else {
#ifdef HAVE_RESID
            if (resid_snapshot_runtime_read(sound_get_psid(0), &st->sample_phase,
                                           &st->sample_period, st->hidden) < 0) {
                return sidcart_snapshot_invalid("SID sample scheduling phase is unavailable");
            }
#else
            return sidcart_snapshot_invalid("reSID sample scheduling phase is unavailable");
#endif
        }
    }
    return sidcart_snapshot_valid(st);
}
static void sidcart_snapshot_pack_resid(uint8_t out[SIDCART_EXTENDED_SIZE])
{
    sid_snapshot_state_t st;
    uint8_t *p = out;
    unsigned int i;
    memset(&st, 0, sizeof(st));
    sid_state_read(0, &st);
    memcpy(p, st.sid_register, 32); p += 32;
    sidcart_snapshot_put(&p, st.bus_value, 1);
    sidcart_snapshot_put(&p, st.bus_value_ttl, 4);
#define SC_PACK_ARRAY(field, size) \
    for (i = 0; i < 3; ++i) { sidcart_snapshot_put(&p, st.field[i], size); }
    SC_PACK_ARRAY(accumulator, 4)
    SC_PACK_ARRAY(shift_register, 4)
    SC_PACK_ARRAY(rate_counter, 2)
    SC_PACK_ARRAY(exponential_counter, 2)
    SC_PACK_ARRAY(envelope_counter, 1)
    SC_PACK_ARRAY(envelope_state, 1)
    SC_PACK_ARRAY(hold_zero, 1)
    SC_PACK_ARRAY(rate_counter_period, 2)
    SC_PACK_ARRAY(exponential_counter_period, 2)
    SC_PACK_ARRAY(envelope_pipeline, 1)
    SC_PACK_ARRAY(shift_pipeline, 1)
    SC_PACK_ARRAY(shift_register_reset, 4)
    SC_PACK_ARRAY(floating_output_ttl, 4)
    SC_PACK_ARRAY(pulse_output, 2)
#undef SC_PACK_ARRAY
    sidcart_snapshot_put(&p, st.write_pipeline, 1);
    sidcart_snapshot_put(&p, st.write_address, 1);
    sidcart_snapshot_put(&p, st.voice_mask, 1);
}
int sidcart_snapshot_write_allowed(void)
{
    sidcart_snapshot_state_t st;
    return sidcart_snapshot_capture(&st, 0);
}
int sidcart_snapshot_write_module(snapshot_t *s)
{
    sidcart_snapshot_state_t st;
    snapshot_module_t *m;
    uint8_t raw[SIDCART_SNAP_SIZE], simple[SIDCART_SIMPLE_SIZE], extended[SIDCART_EXTENDED_SIZE];
    uint8_t *p = raw;
    unsigned int i;
    if (sidcart_snapshot_capture(&st, 1) < 0) {
        return -1;
    }
    if (st.enabled && st.cfg[SC_SOUND]) {
        if (sound_get_psid(0) == NULL) {
            return sidcart_snapshot_invalid("running SID backend is unavailable");
        }
        simple[0] = 0;
        simple[1] = (uint8_t)st.cfg[SC_SOUND];
        simple[2] = (uint8_t)st.cfg[SC_ENGINE];
        simple[3] = (uint8_t)st.cfg[SC_MODEL];
        memcpy(simple + 4, st.cache, 32);
        sidcart_snapshot_pack_resid(extended);
        st.simple_crc = sidcart_snapshot_crc(simple, sizeof(simple));
        st.extended_crc = sidcart_snapshot_crc(extended, sizeof(extended));
        if (sid_snapshot_write_module(s) < 0) {
            return -1;
        }
    }
    sidcart_snapshot_put(&p, st.enabled, 1);
    sidcart_snapshot_put(&p, st.joy, 1);
    sidcart_snapshot_put(&p, st.clock, 1);
    sidcart_snapshot_put(&p, st.address, 2);
    for (i = 0; i < SC_SAMPLE_RATE; ++i) {
        sidcart_snapshot_put(&p, (uint32_t)st.cfg[i], 4);
    }
    sidcart_snapshot_put(&p, st.ratio.numerator, 4);
    sidcart_snapshot_put(&p, st.ratio.denominator, 4);
    sidcart_snapshot_put(&p, st.ratio.remainder, 8);
    memcpy(p, st.cache, 32); p += 32;
    sidcart_snapshot_put(&p, st.simple_crc, 4);
    sidcart_snapshot_put(&p, st.extended_crc, 4);
    sidcart_snapshot_put(&p, (uint32_t)st.cfg[SC_SAMPLE_RATE], 4);
    sidcart_snapshot_put(&p, (uint32_t)st.sample_phase, 4);
    sidcart_snapshot_put(&p, st.sample_period, 4);
    sidcart_snapshot_put(&p, (uint32_t)st.cfg[SC_SPEED], 4);
    for (i=0;i<45;++i) sidcart_snapshot_put(&p, st.hidden[i], 4);
    sidcart_snapshot_put(&p, sidcart_snapshot_crc(raw, SIDCART_SNAP_SIZE - 4), 4);
    m = snapshot_module_create(s, SIDCART_SNAP_NAME, 1, 0);
    if (m == NULL) {
        return -1;
    }
    if (SMW_BA(m, raw, sizeof(raw)) < 0) {
        snapshot_module_close(m);
        return -1;
    }
    return snapshot_module_close(m);
}
/* Open, read and verify the *whole* module into host scratch space. No resource,
 * CPU, device, memory or sound state changes are permitted during this phase. */
static int sidcart_snapshot_read_exact(snapshot_t *s, const char *name,
    uint8_t major_expected, uint8_t minor_expected, uint8_t *raw, unsigned int size)
{
    uint8_t major, minor, extra;
    snapshot_module_t *m = snapshot_module_open(s, name, &major, &minor);
    int result = -1;
    if (m == NULL) {
        return -1;
    }
    if (major != major_expected || minor != minor_expected) {
        snapshot_set_error(SNAPSHOT_MODULE_INCOMPATIBLE);
    } else if (SMR_BA(m, raw, size) == 0) {
        /* A failed read exactly at the module boundary is expected here. It
         * rejects an oversized module as well as truncated versions above. */
        if (SMR_B(m, &extra) < 0 && snapshot_get_error() == SNAPSHOT_READ_OUT_OF_BOUNDS_ERROR) {
            snapshot_set_error(SNAPSHOT_NO_ERROR);
            result = 0;
        } else {
            snapshot_set_error(SNAPSHOT_MODULE_INCOMPATIBLE);
        }
    }
    if (snapshot_module_close(m) < 0) {
        return -1;
    }
    return result;
}
void sidcart_snapshot_abort_read(void)
{
    memset(&sidcart_snapshot_pending, 0, sizeof(sidcart_snapshot_pending));
}
int sidcart_snapshot_prepare_read(snapshot_t *s, int require_module)
{
    sidcart_snapshot_state_t st;
    uint8_t raw[SIDCART_SNAP_SIZE], simple[SIDCART_SIMPLE_SIZE], extended[SIDCART_EXTENDED_SIZE];
    const uint8_t *p = raw;
    const uint8_t *checksum = raw + SIDCART_SNAP_SIZE - 4;
    unsigned int i;
    sidcart_snapshot_abort_read();
    if (sidcart_snapshot_read_exact(s, SIDCART_SNAP_NAME, 1, 0, raw, sizeof(raw)) < 0) {
        /* VICE's module scanner reports an absent final module as a header
         * read error at EOF; the caller has already bounded/validated headers. */
        if (!require_module && !sidcart_enabled()
            && (snapshot_get_error() == SNAPSHOT_MODULE_NOT_FOUND_ERROR
                || snapshot_get_error() == SNAPSHOT_MODULE_HEADER_READ_ERROR
                || snapshot_get_error() == SNAPSHOT_FIRST_MODULE_NOT_FOUND_ERROR)) {
            snapshot_set_error(SNAPSHOT_NO_ERROR);
            return 0;
        }
        return -1;
    }
    if (sidcart_snapshot_crc(raw, SIDCART_SNAP_SIZE - 4)
        != (uint32_t)sidcart_snapshot_get(&checksum, 4)) {
        return sidcart_snapshot_invalid("metadata checksum mismatch");
    }
    memset(&st, 0, sizeof(st));
    st.present = 1;
    st.enabled = (int)sidcart_snapshot_get(&p, 1);
    st.joy = (int)sidcart_snapshot_get(&p, 1);
    st.clock = (int)sidcart_snapshot_get(&p, 1);
    st.address = (int)sidcart_snapshot_get(&p, 2);
    for (i = 0; i < SC_SAMPLE_RATE; ++i) {
        st.cfg[i] = (int32_t)sidcart_snapshot_get(&p, 4);
    }
    st.ratio.numerator = (uint32_t)sidcart_snapshot_get(&p, 4);
    st.ratio.denominator = (uint32_t)sidcart_snapshot_get(&p, 4);
    st.ratio.remainder = sidcart_snapshot_get(&p, 8);
    memcpy(st.cache, p, 32); p += 32;
    st.simple_crc = (uint32_t)sidcart_snapshot_get(&p, 4);
    st.extended_crc = (uint32_t)sidcart_snapshot_get(&p, 4);
    st.cfg[SC_SAMPLE_RATE] = (int32_t)sidcart_snapshot_get(&p, 4);
    st.sample_phase = (int32_t)sidcart_snapshot_get(&p, 4);
    st.sample_period = (uint32_t)sidcart_snapshot_get(&p, 4);
    st.cfg[SC_SPEED] = (int32_t)sidcart_snapshot_get(&p, 4);
    for(i=0;i<45;++i) st.hidden[i] = (uint32_t)sidcart_snapshot_get(&p, 4);
    if (sidcart_snapshot_valid(&st) < 0) {
        return -1;
    }
    if (st.enabled && st.cfg[SC_SOUND]) {
        if (sidcart_snapshot_read_exact(s, "SID", 1, 5, simple, sizeof(simple)) < 0
            || sidcart_snapshot_read_exact(s, "SIDEXTENDED", 1, 4, extended, sizeof(extended)) < 0) {
            return -1;
        }
        if (sidcart_snapshot_crc(simple, sizeof(simple)) != st.simple_crc
            || sidcart_snapshot_crc(extended, sizeof(extended)) != st.extended_crc
            || simple[0] != 0 || simple[1] != st.cfg[SC_SOUND]
            || simple[2] != st.cfg[SC_ENGINE] || simple[3] != st.cfg[SC_MODEL]
            || memcmp(simple + 4, st.cache, 32) != 0) {
            return sidcart_snapshot_invalid("SID engine payload checksum/configuration mismatch");
        }
        /* reSID digital state invariants, before passing data to its decoder. */
        for (i = 0; i < 3; ++i) {
            const uint8_t *acc = extended + 37 + 4 * i;
            /* The noise shift register can legitimately be 0xffffffff during
             * the reSID TEST-reset pipeline, not just a 23-bit value. */
            if (acc[3] != 0
                || extended[76 + i] > 2 || extended[79 + i] > 1) {
                return sidcart_snapshot_invalid("invalid reSID oscillator/envelope state");
            }
        }
        if (extended[131] > 31) {
            return sidcart_snapshot_invalid("invalid reSID write address");
        }
    } else if (st.simple_crc != 0 || st.extended_crc != 0) {
        return sidcart_snapshot_invalid("unexpected payload for an inactive SID engine");
    }
    sidcart_snapshot_pending = st;
    return 0;
}
int sidcart_snapshot_apply_read(snapshot_t *s)
{
    sidcart_snapshot_state_t *st = &sidcart_snapshot_pending;
    unsigned int i;
    int engine, sample_rate;
    if (!st->present) {
        return 0;
    }
    /* Stop the old engine before changing its cartridge routing/configuration. */
    sound_close();
    if (resources_set_int("SidCart", 0) < 0
        || resources_set_int("SidAddress", st->address) < 0
        || resources_set_int("SidClock", st->clock) < 0
        || resources_set_int("SIDCartJoy", st->joy) < 0) {
        goto fail;
    }
    for (i = 0; i < SIDCART_CFG_COUNT; ++i) {
        if (!st->enabled && i != SC_SOUND && i != SC_SAMPLE_RATE) {
            continue;
        }
        if (resources_set_int(sidcart_snapshot_resource[i], st->cfg[i]) < 0) {
            goto fail;
        }
    }
    if (resources_set_int("SidCart", st->enabled) < 0) {
        goto fail;
    }
    if (st->enabled && st->cfg[SC_SOUND]) {
        if (sid_snapshot_read_module(s) < 0
            || resources_get_int("SidEngine", &engine) < 0
            || engine != st->cfg[SC_ENGINE] || sound_get_psid(0) == NULL) {
            goto fail;
        }
    } else {
        memcpy(sid_get_siddata(0), st->cache, sizeof(st->cache));
        if (st->cfg[SC_SOUND] && sound_open() < 0) {
            goto fail;
        }
    }
    if (st->cfg[SC_SOUND]
        && (resources_get_int("SoundSampleRate", &sample_rate) < 0
            || sample_rate != st->cfg[SC_SAMPLE_RATE])) {
        goto fail;
    }
    /* Standard SID read reopens sound and creates new envelope/wave latches.
     * Restore all saved digital latches after it, with the sample schedule.
     * It also zeroes the resampler schedule.
     * Restore the scalar sample offset too: it determines the sample count
     * passed to TED, independently of analogue/FIR history. */
#ifdef HAVE_RESID
    if (st->enabled && st->cfg[SC_SOUND]
        && resid_snapshot_runtime_write(sound_get_psid(0), st->sample_phase,
                                      st->sample_period, st->hidden) < 0) goto fail;
#endif
    sidcart_ratio = st->ratio;
    sidcart_snapshot_abort_read();
    return 0;
fail:
    sidcart_snapshot_abort_read();
    return sidcart_snapshot_invalid("could not restore the validated SID cartridge state");
}
