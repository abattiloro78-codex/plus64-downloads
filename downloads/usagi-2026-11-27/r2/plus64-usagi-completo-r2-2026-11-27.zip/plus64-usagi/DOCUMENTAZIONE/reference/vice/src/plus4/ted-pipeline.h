#ifndef VICE_TED_PIPELINE_H
#define VICE_TED_PIPELINE_H

struct snapshot_s;
int ted_pipeline_snapshot_write_module(struct snapshot_s *s);
int ted_pipeline_snapshot_preflight(struct snapshot_s *s, int required);
int ted_pipeline_snapshot_read_module(struct snapshot_s *s, int required);

#endif
