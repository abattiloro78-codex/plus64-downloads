#include "plus64_modem.h"
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

static void rx_byte(p64_modem *m,uint8_t c) {
    if(m->r_count>=P64_RX_CAP){m->overrun=1;return;}
    m->rx[m->r_tail]=c;m->r_tail=(m->r_tail+1)%P64_RX_CAP;m->r_count++;
}
static void rx_text(p64_modem *m,const char *s){while(*s)rx_byte(m,(uint8_t)*s++);}
static void tx_byte(p64_modem *m,uint8_t c){
    if(m->t_count>=P64_TX_CAP){m->overrun=1;return;}
    m->tx[m->t_tail]=c;m->t_tail=(m->t_tail+1)%P64_TX_CAP;m->t_count++;
}
static void disconnect_link(p64_modem *m){
    if((m->connected||m->dialing)&&m->ops.close)m->ops.close(m->ctx);
    m->connected=0;m->dialing=0;m->t_count=m->t_head=m->t_tail=0;
    m->telnet_state=0;
}
void p64_modem_init(p64_modem *m,p64_modem_netops ops,void *ctx,uint8_t *storage){
    memset(m,0,sizeof(*m));m->ops=ops;m->ctx=ctx;
    if(storage){
        m->rx=storage+P64_MODEM_RX_OFFSET;
        m->tx=storage+P64_MODEM_TX_OFFSET;
        m->cmd=(char *)(storage+P64_MODEM_CMD_OFFSET);
    }
}
void p64_modem_reset(p64_modem *m){
    p64_modem_netops ops=m->ops;void *ctx=m->ctx;
    uint8_t *rx=m->rx,*tx=m->tx;char *cmd=m->cmd;
    disconnect_link(m);memset(m,0,sizeof(*m));m->ops=ops;m->ctx=ctx;
    m->rx=rx;m->tx=tx;m->cmd=cmd;
    /* Reset indices and device registers, never the shared bank. */
}
static void respond(p64_modem *m,const char *s){rx_text(m,"\r\n");rx_text(m,s);rx_text(m,"\r\n");}
static int ci_prefix(const char *s,const char *prefix){
    while(*prefix){if(toupper((unsigned char)*s++)!=*prefix++)return 0;}
    return 1;
}
static void command(p64_modem *m){
    const char *p=m->cmd;
    if(!ci_prefix(p,"AT")){respond(m,"ERROR");return;}
    p+=2;
    if(!*p){respond(m,"OK");return;}
    if(ci_prefix(p,"E0")&&!p[2]){m->echo=0;respond(m,"OK");return;}
    if(ci_prefix(p,"E1")&&!p[2]){m->echo=1;respond(m,"OK");return;}
    if(ci_prefix(p,"Z")&&!p[1]){p64_modem_reset(m);respond(m,"OK");return;}
    if(ci_prefix(p,"H")&&!p[1]){disconnect_link(m);respond(m,"OK");return;}
    if(ci_prefix(p,"DT")||ci_prefix(p,"D")){
        char *addr=m->cmd+(p-m->cmd)+(toupper((unsigned char)p[1])=='T'?2:1);
        char *end;long port=23;
        char *colon=strrchr(addr,':');size_t size;
        if(m->connected||m->dialing||!*addr){respond(m,"ERROR");return;}
        size=colon?(size_t)(colon-addr):strlen(addr);
        if(size==0||size>=220u){respond(m,"ERROR");return;}
        if(colon){
            if(!colon[1]){respond(m,"ERROR");return;}
            port=strtol(colon+1,&end,10);
            if(*end||port<1||port>65535){respond(m,"ERROR");return;}
        }
        if(!m->ops.open){respond(m,"NO CARRIER");return;}
        {
            int res;
            /* open() consumes its hostname synchronously. Use the command
               bank itself for the temporary terminator, then restore it. */
            if(colon)*colon=0;
            res=m->ops.open(m->ctx,addr,(unsigned)port);
            if(colon)*colon=':';
            if(res==1){m->connected=1;respond(m,"CONNECT 9600");}
            else if(res==0)m->dialing=1;
            else respond(m,"NO CARRIER");
        }
        return;
    }
    respond(m,"ERROR");
}
static void stream_from_device(p64_modem *m,uint8_t c){
    if(m->connected){tx_byte(m,c);return;}
    if(m->echo)rx_byte(m,c);
    if(c=='\n')return;
    if(c=='\r'){
        m->cmd[m->clen]=0;command(m);m->clen=0;return;
    }
    if(c==8 || c==127){if(m->clen)m->clen--;return;}
    if(c<32 || c>126)return;
    if(m->clen>=P64_CMD_CAP-1){m->clen=0;respond(m,"ERROR");return;}
    m->cmd[m->clen++]=(char)c;
}
static void telnet_in(p64_modem *m,uint8_t b){
    /* Minimal Telnet negotiation: refuse unsupported options. */
    switch(m->telnet_state){
        case 0:if(b==255)m->telnet_state=1;else rx_byte(m,b);break;
        case 1:
            if(b==255){rx_byte(m,255);m->telnet_state=0;}
            else if(b==251||b==252||b==253||b==254){m->telnet_verb=b;m->telnet_state=2;}
            else if(b==250)m->telnet_state=3;
            else m->telnet_state=0;
            break;
        case 2:
            if(m->telnet_verb==251||m->telnet_verb==253){
                tx_byte(m,255);tx_byte(m,m->telnet_verb==251?254:252);tx_byte(m,b);
            }
            m->telnet_state=0;break;
        case 3: if(b==255)m->telnet_state=4;break;
        case 4: m->telnet_state=(b==240)?0:3;break;
    }
}
void p64_modem_poll(p64_modem *m){
    int r;
    if(!m->rx||!m->tx||!m->cmd)return;
    if(m->dialing&&m->ops.state){
        r=m->ops.state(m->ctx);
        if(r>0){m->dialing=0;m->connected=1;respond(m,"CONNECT 9600");}
        else if(r<0){disconnect_link(m);respond(m,"NO CARRIER");}
    }
    if(!m->connected)return;
    if(m->t_count&&m->ops.send_bytes){
        size_t contiguous=P64_TX_CAP-m->t_head;
        if(contiguous>m->t_count)contiguous=m->t_count;
        r=m->ops.send_bytes(m->ctx,m->tx+m->t_head,contiguous);
        if(r<0||(size_t)r>contiguous){disconnect_link(m);respond(m,"NO CARRIER");return;}
        if(r>0){m->t_head=(m->t_head+(size_t)r)%P64_TX_CAP;m->t_count-=(size_t)r;}
    }
    if(m->ops.recv_bytes&&m->r_count<P64_RX_CAP){
        size_t at=m->r_tail,space=P64_RX_CAP-m->r_count;
        size_t contiguous=P64_RX_CAP-at;
        if(contiguous>space)contiguous=space;
        if(contiguous>512u)contiguous=512u;
        /* Receive into the free ring span. Telnet decoding only removes
           bytes, so its output never overtakes unread input in this span.
           Full rings apply transport backpressure instead of losing bytes. */
        r=m->ops.recv_bytes(m->ctx,m->rx+at,contiguous);
        if(r<0||(size_t)r>contiguous){disconnect_link(m);respond(m,"NO CARRIER");return;}
        for(int i=0;i<r;i++)telnet_in(m,m->rx[at+(size_t)i]);
    }
}
static uint8_t status(const p64_modem *m){
    return (m->r_count?1:0)|((m->tx&&m->t_count<P64_TX_CAP)?2:0)|
           (m->connected?4:0)|(m->dialing?8:0)|
           (m->overrun?16:0)|(!m->connected&&!m->dialing?32:0);
}
uint8_t p64_modem_peek(const p64_modem *m,uint16_t a){
    switch(a){
    case 0xfdf0:return m->r_count?m->rx[m->r_head]:0;
    case 0xfdf1:return status(m);
    case 0xfdf2:return 0;
    case 0xfdf3:return 4; /* 9600 display value, baud is virtual */
    case 0xfdf4:return (uint8_t)(m->r_count>255?255:m->r_count);
    case 0xfdf5:return (uint8_t)(m->t_count>255?255:m->t_count);
    case 0xfdf6:return 0x64;
    case 0xfdf7:return 0x03; /* Shared-bank storage contract. */
    default:return 0xff;
    }
}
uint8_t p64_modem_read(p64_modem *m,uint16_t a){
    if(a==0xfdf0){
        uint8_t b;
        if(!m->r_count)return 0;
        b=m->rx[m->r_head];m->r_head=(m->r_head+1)%P64_RX_CAP;m->r_count--;return b;
    }
    return p64_modem_peek(m,a);
}
void p64_modem_store(p64_modem *m,uint16_t a,uint8_t v){
    if(!m->rx||!m->tx||!m->cmd)return;
    if(a==0xfdf0){stream_from_device(m,v);return;}
    if(a==0xfdf2){
        if(v&1)p64_modem_reset(m);
        else if(v&2){disconnect_link(m);respond(m,"OK");}
        if(v&4)m->overrun=0;
    }
}
