/* plus/64 strict 64 KiB cartridge + 16 KiB host backing.
 * Register map is unchanged. Protocol $FDED=$05 identifies shared storage.
 * Native: CPU/TED host mem_ram[0..3fff]; cartridge banks use the remaining
 * three mem_ram blocks and p64_aux_ram. MainRAM: cartridge is mem_ram[64K]
 * and the distinct host buffer is p64_aux_ram[16K]. No private SRAM array.
 */
#ifndef PLUS64_MEMORY_H
#define PLUS64_MEMORY_H
#include <stddef.h>
#include <stdint.h>
#define P64_MEM_BASE 0xFDE8u
#define P64_MEM_END  0xFDEDu
#define P64_MEM_TOTAL 65536u
#define P64_MEM_BANK_SIZE 16384u
#define P64_HOST_RAM_SIZE 16384u
#define P64_TOTAL_RAM_SIZE (P64_MEM_TOTAL + P64_HOST_RAM_SIZE)
#define P64_NATIVE_SPRITE_BANK 2u
#define P64_NATIVE_MODEM_BANK 3u
#define P64_NATIVE_MODEM_OFFSET 0x3e00u
#define P64_MAIN_MODEM_OFFSET 0x0000u
extern uint8_t p64_aux_ram[P64_HOST_RAM_SIZE];
typedef struct {
    uint8_t *banks[4];
    uint8_t *cpu_ram;
    uint8_t *host_ram;
    uint16_t offset; /* $0000-$3fff */
    uint8_t bank;
    uint8_t main_ram;
} p64_memory;
/* Power-on clears the cartridge view only, never the active native host. */
void p64_memory_powerup(p64_memory *m, uint8_t *cpu_ram);
/* NULL selects native mode. Non-NULL must equal the supplied cpu_ram.
 * Rotate the existing five 16K blocks in place to preserve host and all
 * cartridge contents when changing profile; no staging/data array exists.
 */
void p64_memory_bind_main_ram(p64_memory *m, uint8_t *ram);
/* Bind already-restored physical bytes without rotating or clearing them. */
void p64_memory_restore_views(p64_memory *m, uint8_t *cpu_ram, int main_ram);
void p64_memory_reset_registers(p64_memory *m);
uint8_t *p64_memory_bank(p64_memory *m, unsigned bank);
uint8_t *p64_memory_host_ram(p64_memory *m);
uint8_t *p64_memory_sprite_ram(p64_memory *m);
uint8_t *p64_memory_modem_ram(p64_memory *m);
size_t p64_memory_total_ram(void);
uint8_t p64_memory_host_read(const p64_memory *m, uint16_t address);
void p64_memory_host_store(p64_memory *m, uint16_t address, uint8_t value);
uint8_t p64_memory_read(p64_memory *m, uint16_t address);
uint8_t p64_memory_peek(const p64_memory *m, uint16_t address);
void p64_memory_write(p64_memory *m, uint16_t address, uint8_t value);
#endif
