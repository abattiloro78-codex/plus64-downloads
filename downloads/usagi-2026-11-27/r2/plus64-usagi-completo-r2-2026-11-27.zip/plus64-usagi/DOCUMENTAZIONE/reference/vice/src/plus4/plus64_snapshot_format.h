/* PLUS64 snapshot module 1.0, fixed little-endian wire format.
 * This describes file/transient HOST serialization, not extra guest RAM.
 */
#ifndef PLUS64_SNAPSHOT_FORMAT_H
#define PLUS64_SNAPSHOT_FORMAT_H
#define P64_SNAPSHOT_MODULE "PLUS64"
#define P64_SNAPSHOT_MAJOR 1
#define P64_SNAPSHOT_MINOR 0
#define P64_SNAPSHOT_HEADER_SIZE 128u
#define P64_SNAPSHOT_REGS_OFFSET 128u
#define P64_SNAPSHOT_AUX_OFFSET 192u
#define P64_SNAPSHOT_OVERLAY_OFFSET 16576u
#define P64_SNAPSHOT_ALPHA_OFFSET 80576u
#define P64_SNAPSHOT_COLLISION_OFFSET 144576u
#define P64_SNAPSHOT_PAYLOAD_SIZE 144776u
/* Header:
 * 0 magic P64S,4 u32 payload length,8 CRC32 bytes12..end,
 * 12 enabled,13 main,14 packed,15 left,16 raster,17 overlay_ready,
 * 18 collision,19 SID ownership,20 SRAM bank,21 main expansion ownership,
 * 22 u16 SRAM offset,24 u32 RamSize,28 u32 prior RamSize,
 * 32/36/40 RX head/tail/count,44/48/52 TX head/tail/count,56 command len,
 * 60 Telnet state,61 verb,62 echo,63 overrun,64 connected,65 dialing,
 * 66..67 reserved0,68 u32 CRC32 standard PLUS4MEM64,72 mixed sprites bool,73 full material palette bool,74 sparse format bool,75 light-directions bool,76 mask-aware front bool,77 tile-lighting bool,78 per-ink diagonal sprite lighting bool,79 scenery version (0,1,3..22;18 adds opt-in native border clip;19 adds opt-in elliptical tint footprints;20 adds keyed vertical palette ramps;21 adds explicit glyph-anchored foreground nodes;22 adds guest material programs on immutable native TED source facts),80 dense MCM capability bool,81 dense chained-height bool,82 authored dense materials version (0=off,1=strict,2=source-domain clipping/soft shading,3=inline compact-colour table,4=profile0 rectangular centre light,5=generic16-byte source-RLE references,6=guest-owned pair-grammar source codec,7=guest material VM with transient metadata decoding,8=bounded compressed source frames/direct frame IDs and shared metadata method2),83..127 reserved0.
 * Legacy readers reject nonzero72, so extended snapshots fail closed there.
 */
#endif
