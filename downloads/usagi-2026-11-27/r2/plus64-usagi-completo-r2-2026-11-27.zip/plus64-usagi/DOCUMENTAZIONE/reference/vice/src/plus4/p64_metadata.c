/* SPDX-License-Identifier: GPL-2.0-or-later */
#include "p64_metadata.h"
#include "p64_metadata_lzma.h"
#include <stdlib.h>
#include <string.h>
#include <zlib.h>
static unsigned le16(const uint8_t *p){return(unsigned)p[0]|((unsigned)p[1]<<8);}
int p64_metadata_open(const uint8_t *guest,size_t bytes,p64_metadata_view_t *v){
 if(!v)return P64_METADATA_FORMAT_ERROR;
 v->bytes=NULL;v->size=0;v->owned=NULL;
 if(!guest||!bytes||bytes>P64_METADATA_MAX_BYTES)return P64_METADATA_FORMAT_ERROR;
 if(bytes<4||memcmp(guest,"P64Z",4)){
  v->bytes=guest;v->size=bytes;return 0;
 }
 if(bytes<P64_METADATA_HEADER_BYTES||guest[4]!=1||guest[10]||guest[11])return P64_METADATA_FORMAT_ERROR;
 if(guest[5]==2u){
  p64_metadata_lzma_view local;
  int result=p64_metadata_lzma_open(guest,bytes,&local);
  if(result<0)return result;
  /* The two public view types are intentionally distinct. Transfer owned
   * fields explicitly; do not alias or cast their struct pointers. */
  v->bytes=local.bytes;v->size=local.size;v->owned=local.owned;
  return 0;
 }
 if(guest[5]!=1u)return P64_METADATA_FORMAT_ERROR;
 unsigned raw=le16(guest+6),stored=le16(guest+8);
 if(!raw||!stored||stored!=bytes-P64_METADATA_HEADER_BYTES)return P64_METADATA_FORMAT_ERROR;
 uint8_t *out=(uint8_t*)malloc(raw);if(!out)return P64_METADATA_MEMORY_ERROR;
 z_stream stream;memset(&stream,0,sizeof(stream));
 stream.next_in=(Bytef*)(guest+P64_METADATA_HEADER_BYTES);stream.avail_in=stored;
 stream.next_out=out;stream.avail_out=raw;
 int status=inflateInit(&stream);
 if(status!=Z_OK){free(out);return status==Z_MEM_ERROR?P64_METADATA_MEMORY_ERROR:P64_METADATA_FORMAT_ERROR;}
 status=inflate(&stream,Z_FINISH);
 int complete=status==Z_STREAM_END&&stream.total_out==raw&&stream.avail_in==0;
 inflateEnd(&stream);
 if(!complete){free(out);return status==Z_MEM_ERROR?P64_METADATA_MEMORY_ERROR:P64_METADATA_FORMAT_ERROR;}
 v->bytes=out;v->size=raw;v->owned=out;return 0;
}
void p64_metadata_close(p64_metadata_view_t *v){
 if(!v)return;
 free(v->owned);v->bytes=NULL;v->size=0;v->owned=NULL;
}
