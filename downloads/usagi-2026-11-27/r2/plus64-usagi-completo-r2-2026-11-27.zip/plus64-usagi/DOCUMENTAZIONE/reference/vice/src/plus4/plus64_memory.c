#include "plus64_memory.h"
#include <string.h>

/* The only added data backing: native cartridge bank 3 / MainRAM host 16K.
 * The other 64K are the existing VICE mem_ram[] array, not another array.
 */
uint8_t p64_aux_ram[P64_HOST_RAM_SIZE];

static void bind_views(p64_memory *m) {
    if (!m->cpu_ram) return;
    if (m->main_ram) {
        for (unsigned i=0; i<4; ++i) m->banks[i]=m->cpu_ram+i*P64_MEM_BANK_SIZE;
        m->host_ram=p64_aux_ram;
    } else {
        for (unsigned i=0; i<3; ++i) m->banks[i]=m->cpu_ram+(i+1u)*P64_MEM_BANK_SIZE;
        m->banks[3]=p64_aux_ram;
        m->host_ram=m->cpu_ram;
    }
}
void p64_memory_restore_views(p64_memory *m,uint8_t *cpu_ram,int main_ram) {
    m->cpu_ram=cpu_ram;m->main_ram=(uint8_t)(main_ram!=0);bind_views(m);
}
void p64_memory_powerup(p64_memory *m, uint8_t *cpu_ram) {
    memset(m,0,sizeof(*m));
    m->cpu_ram=cpu_ram;
    bind_views(m);
    if (cpu_ram) for (unsigned i=0; i<4; ++i) memset(m->banks[i],0,P64_MEM_BANK_SIZE);
}
void p64_memory_reset_registers(p64_memory *m) { m->offset=0; m->bank=0; }
void p64_memory_bind_main_ram(p64_memory *m, uint8_t *ram) {
    unsigned enable=ram!=NULL;
    if (!m->cpu_ram || (ram && ram!=m->cpu_ram) || enable==m->main_ram) return;
    /* [host,c0,c1,c2,c3] <-> [c0,c1,c2,c3,host]. One byte of
     * temporary register/stack state; no hidden 16K buffer or allocation.
     */
    for (unsigned i=0; i<P64_MEM_BANK_SIZE; ++i) {
        uint8_t last;
        if (enable) {
            last=m->cpu_ram[i];
            m->cpu_ram[i]=m->cpu_ram[P64_MEM_BANK_SIZE+i];
            m->cpu_ram[P64_MEM_BANK_SIZE+i]=m->cpu_ram[2u*P64_MEM_BANK_SIZE+i];
            m->cpu_ram[2u*P64_MEM_BANK_SIZE+i]=m->cpu_ram[3u*P64_MEM_BANK_SIZE+i];
            m->cpu_ram[3u*P64_MEM_BANK_SIZE+i]=p64_aux_ram[i];
            p64_aux_ram[i]=last;
        } else {
            last=p64_aux_ram[i];
            p64_aux_ram[i]=m->cpu_ram[3u*P64_MEM_BANK_SIZE+i];
            m->cpu_ram[3u*P64_MEM_BANK_SIZE+i]=m->cpu_ram[2u*P64_MEM_BANK_SIZE+i];
            m->cpu_ram[2u*P64_MEM_BANK_SIZE+i]=m->cpu_ram[P64_MEM_BANK_SIZE+i];
            m->cpu_ram[P64_MEM_BANK_SIZE+i]=m->cpu_ram[i];
            m->cpu_ram[i]=last;
        }
    }
    m->main_ram=(uint8_t)enable;
    bind_views(m);
}
uint8_t *p64_memory_bank(p64_memory *m,unsigned bank) { return m->banks[bank&3u]; }
uint8_t *p64_memory_host_ram(p64_memory *m) { return m->host_ram; }
uint8_t *p64_memory_sprite_ram(p64_memory *m) {
    return m->main_ram ? m->host_ram : m->banks[P64_NATIVE_SPRITE_BANK];
}
uint8_t *p64_memory_modem_ram(p64_memory *m) {
    uint8_t *base=m->main_ram ? m->host_ram : m->banks[P64_NATIVE_MODEM_BANK];
    return base ? base+(m->main_ram ? P64_MAIN_MODEM_OFFSET : P64_NATIVE_MODEM_OFFSET) : NULL;
}
size_t p64_memory_total_ram(void) { return P64_TOTAL_RAM_SIZE; }
uint8_t p64_memory_host_read(const p64_memory *m,uint16_t a) {
    return m->host_ram ? m->host_ram[a&(P64_HOST_RAM_SIZE-1u)] : 0xff;
}
void p64_memory_host_store(p64_memory *m,uint16_t a,uint8_t v) {
    if(m->host_ram)m->host_ram[a&(P64_HOST_RAM_SIZE-1u)]=v;
}
static void bump(p64_memory *m) { m->offset=(uint16_t)((m->offset+1u)&0x3fffu); }
uint8_t p64_memory_peek(const p64_memory *m,uint16_t a) {
    switch(a) {
        case 0xFDE8:return (uint8_t)m->offset;
        case 0xFDE9:return (uint8_t)(m->offset>>8);
        case 0xFDEA:return m->banks[m->bank] ? m->banks[m->bank][m->offset&0x3fffu] : 0xff;
        case 0xFDEB:return m->bank;
        case 0xFDEC:return 0x64;
        case 0xFDED:return 0x05; /* shared 64+16 backing, no private sprite RAM */
        default:return 0xff;
    }
}
uint8_t p64_memory_read(p64_memory *m,uint16_t a) {
    uint8_t v=p64_memory_peek(m,a);if(a==0xFDEA)bump(m);return v;
}
void p64_memory_write(p64_memory *m,uint16_t a,uint8_t v) {
    switch(a) {
        case 0xFDE8:m->offset=(uint16_t)((m->offset&0x3f00u)|v);break;
        case 0xFDE9:m->offset=(uint16_t)((m->offset&0xffu)|((v&0x3fu)<<8));break;
        case 0xFDEA:if(m->banks[m->bank])m->banks[m->bank][m->offset&0x3fffu]=v;bump(m);break;
        case 0xFDEB:m->bank=v&3u;break;
        default:break;
    }
}
