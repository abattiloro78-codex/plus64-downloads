#ifndef PLUS64_MODEM_H
#define PLUS64_MODEM_H
#include <stddef.h>
#include <stdint.h>
#define PLUS64_MODEM_START 0xFDF0
#define PLUS64_MODEM_END 0xFDF7
#define P64_RX_CAP 128u
#define P64_TX_CAP 128u
#define P64_CMD_CAP 256u
#define P64_MODEM_STORAGE_SIZE 512u
#define P64_MODEM_RX_OFFSET 0x0000u
#define P64_MODEM_TX_OFFSET 0x0080u
#define P64_MODEM_CMD_OFFSET 0x0100u
/* All payload bytes are views of one caller-owned 512-byte region. This
   region is part of the machine's existing 64+16 KiB, not private modem
   RAM. Software must reserve it while the modem is in use. The remaining
   fields are device register/counter state, not an additional data pool. */
/* Connector contract: open(): 1 connected, 0 pending, -1 failed.
   state(): 1 connected, 0 pending, -1 disconnected/error.
   send(): 0 would block, >0 bytes sent, -1 disconnected.
   recv(): 0 would block, >0 bytes received, -1 disconnected. */
typedef struct {
    int (*open)(void *,const char *,unsigned);
    int (*state)(void *);
    int (*send_bytes)(void *,const uint8_t *,size_t);
    int (*recv_bytes)(void *,uint8_t *,size_t);
    void (*close)(void *);
} p64_modem_netops;
typedef struct {
    p64_modem_netops ops;
    void *ctx;
    uint8_t *rx,*tx;
    size_t r_head,r_tail,r_count,t_head,t_tail,t_count;
    char *cmd;
    size_t clen;
    uint8_t telnet_state,telnet_verb;
    int connected,dialing,echo,overrun;
} p64_modem;
void p64_modem_init(p64_modem *,p64_modem_netops,void *,uint8_t *);
void p64_modem_reset(p64_modem *);
void p64_modem_poll(p64_modem *);
void p64_modem_store(p64_modem *,uint16_t,uint8_t);
uint8_t p64_modem_read(p64_modem *,uint16_t);
uint8_t p64_modem_peek(const p64_modem *,uint16_t);
#endif
