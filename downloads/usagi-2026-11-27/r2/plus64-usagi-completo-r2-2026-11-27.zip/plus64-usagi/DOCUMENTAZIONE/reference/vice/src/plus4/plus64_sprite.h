#ifndef PLUS64_H
#define PLUS64_H
#include <stdint.h>
#include <stddef.h>
#define PLUS64_WIDTH 320
#define PLUS64_HEIGHT 200
#define PLUS64_RAM_SIZE 16384
#define PLUS64_BASE 0xFD90
#define PLUS64_END 0xFDCF

typedef struct {
    uint8_t regs[0x40];
    uint8_t *ram; /* view of caller-owned 16K; never separate sprite RAM */
    uint8_t collision;
    uint8_t collision_only_formats; /* HOST: 0=legacy,1=F9,2=F9/occluding FA */
    uint8_t material_full_palette; /* versioned HOST material configuration */
    uint8_t diagonal_lighting; /* versioned per-ink MCM diagonal profile */
    uint8_t tile_lighting; /* versioned opt-in background lighting */
    uint8_t front_mask_profile; /* HOST snapshot shading version */
    uint8_t light_directions; /* HOST snapshot format version */
    uint8_t sparse_formats; /* HOST format version, not guest RAM */
    uint8_t extended_formats; /* HOST configuration, not guest payload RAM */
    uint8_t dense_formats; /* versioned opt-in 70-byte inverse MCM records */
    uint8_t dense_height_formats; /* versioned chained dense MCM height */
    uint8_t dense_material_formats; /* 0=off,1=strict,2=clipped,3=inline colour,4=rectangular relief,5=source16,6=pair grammar,7=guest material VM,8=bounded frame-bank sources */
} plus64_t;
#define PLUS64_RAW8_TAG 0x4000u
#define PLUS64_DENSE_MCM_TAG 0x8000u
#define PLUS64_SOURCE_MCM_TAG 0xc000u
#define PLUS64_TONE_MASK 0x80u
/* FD99..FD9C: low nibble even slot, high nibble odd slot. Zero keeps
 * the original profile; 1..8=N,NE,E,SE,S,SW,W,NW; 9=front; 10=per-ink MCM diagonal; 11..15 reserved. */
#define PLUS64_LIGHT_BASE 0xFD99u
int plus64_set_extended_formats(plus64_t *p, int enable);
void plus64_bind_ram(plus64_t *p, uint8_t *ram);
/* Reset registers/latches only; preserve backing and its payload. */
void plus64_reset(plus64_t *p);
void plus64_write(plus64_t *p, uint16_t address, uint8_t value);
uint8_t plus64_read(plus64_t *p, uint16_t address);
/* Draws pixel-index overlay into an existing 320x200 frame (index 0-127),
 * no TED access implied. A bit set in occupancy denotes sprite coverage. */
/* FD92 bits enable 8-bit-per-pixel TED palette sprite images, 504 bytes each.
 * Color indices 0..120; 255=transparent. alpha disambiguates black 0.
 */
void plus64_draw_masked(plus64_t *p, uint8_t *frame, uint8_t *alpha, size_t stride);
void plus64_draw(plus64_t *p, uint8_t *frame, size_t stride);
/* NEW experimental format: FD92 MCM slots read exact global-cache metadata.
 * Requires aligned1024 records, raw64 inverse+200/key5 inverse+240/valid245.
 * Extended dense MCM uses pointer tag8000 and the same record minus bias200,
 * at any lower14-bit offset where its full70 bytes fit without wrapping.
 * With dense_height_formats, head+40 is height0=21 or1..252; ceil(height/21)
 * consecutive70-byte parts must fit and each part retains its own inks/tag.
 * With dense_material_formats, mode+41=2/82 selects an authored composite
 * material binding: pointer low at+00, high6bits at+45 (top bits must be10).
 * Mode82 mirrors recipe coordinates; source bitmap and three inks stay intact.
 * The8-byte binding and compact rectangle recipes use the same16KiB view.
 * Material version4 with recipe header C0|count opts profile0/component1..7
 * into rectangular centre light
 * from minimum luminance component-1 to7, retaining the original ink hue.
 * Component0 and all legacy80|count profile0 recipes retain the original ink.
 * Readers with material versions0..3 reject C0|count recipes.
 * Only C0 recipes in version4 also allow profile7 table bytes128..248:
 * these select literal compact colour byte&127, without relative shading.
 * Original opaque black and source occupancy are preserved as usual.
 * This is not the0.94 format or an existing physical cartridge capability. */
void plus64_draw_masked_packed_cache(plus64_t *p, uint8_t *frame, uint8_t *alpha, size_t stride);
/* Configuration change only: refuse enabled output; invalidate all16 markers. */
int plus64_prepare_packed_cache_switch(plus64_t *p);
/* Experimental frozen-frame scanline latch. Alpha contains sprite bit masks;
 * its nonzero coverage and visible pixels match the corresponding old draw.
 * Preparing a frame does NOT create collisions. Fold each completed line. */
void plus64_draw_masked_deferred(plus64_t *p, uint8_t *frame, uint8_t *alpha, size_t stride, int packed_cache);
/* The optional 200-byte host summary includes hidden horizontal pixels
 * in the existing nine-bit descriptor domain. It never draws the border. */
void plus64_draw_masked_deferred_border(plus64_t *p, uint8_t *frame, uint8_t *alpha, size_t stride, int packed_cache, uint8_t *line_collisions);
/* Material version5 also accepts packed MCM pointer tagC000: a16-byte
 * AUX record containing source16,length8,flags8 (bit0 horizontal mirror,
 * bit1 AUX source; MAIN otherwise),pair1/2/3 compact inks,height8,
 * material binding16,mode8 (0plain/1authored),software-only byte11,
 * stride16,reserved0/0,magicA6. Source RLE must decode exactly63 bytes:
 * bit7 token repeats next byte, otherwise literal run, low7 bits=count.
 * Version6 permits flagbit2: shared pair-grammar sources. Bytes13/14 then
 * select a768-byte dictionary in the same source bank:256 left lows,
 * 256 right lows,256 high flags (bit0left,bit1right). A9-bit child must
 * precede its rule. Source prefix=softwareLength,tokenCount1..63, then
 * groups of one highbitmap and up to8 lowbytes; decode exactly63 bytes.
 * Without bit2, bytes13/14 remain reserved0 and the RLE rules above apply.
 * Version7 adds mode2/3: descriptor binding8/9 points to an8-byte AUX
 * material context: archiveRoot16,directory16,columns8,height8,key8,selector8.
 * The current record must have exactly one directory column/band origin.
 * Mode3 selects the guest-declared alternate base/opaque portrait domain.
 * ArchiveRoot selects raw SVM4 or a P64Z compressed metadata packet. The
 * metadata is expanded only within the rendering call and always released.
 * VM transparency255 skips coverage/collisions; black0 stays opaque.
 * Version8 permits source flagbit3, mutually exclusive with grammarbit2.
 * Bytes13/14 select a same-bank P64F root: magic4,version8,groupSize8<=32,
 * frameStride8=63,reserved0,frameCount16,blockCount16,then(address16,length16)
 * for each block. Each P64Z block expands to at most2016 working bytes;
 * only the selected63-byte frame is consumed, with no retained source bank.
 * P64F version4 uses descriptor0/1 as an opaque frameID,0 valid,and byte2=2.
 * Legacy roots1/2 keep source-pointer prefixes. All original source formats
 * and material modes remain available. Per-draw reuse of validated contexts
 * ends before returning; nothing is added to guest RAM or snapshot state.
 * Byte11 is not a legacy colour/collision tag and is never interpreted.
 * MAIN is a borrowed65536-byte view; no asset copy is retained. The old
 * entry points remain unchanged and reject MAIN records without a view. */
void plus64_draw_masked_main(plus64_t *p,uint8_t *frame,uint8_t *alpha,size_t stride,int packed_cache,int deferred,uint8_t *line_collisions,int left_mcm,const uint8_t *main_ram);
void plus64_latch_masked_line(plus64_t *p, const uint8_t *masks, size_t stride, unsigned int y);
/* Separate opt-in signed projection for packed MCM X488..511 only. */
void plus64_draw_masked_left_mcm(plus64_t *p, uint8_t *frame, uint8_t *alpha, size_t stride, int packed_cache, int deferred, uint8_t *line_collisions);
#endif
