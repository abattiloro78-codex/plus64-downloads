# plus/64 development addendum: native border clipping

The current software implementation adds an opt-in presentation rule through **FD9F bit 4**, SDK constant **`P64_SIDE_BORDER_CLIP = 16`**. Scenery capability **18**, recorded at PLUS64 snapshot header byte 79, versions this rule. RAM protocol `$05`, snapshot module 1.0, its 144,776-byte payload, dense capabilities 80/81 and the total **65,536 + 16,384 = 81,920 guest bytes** remain unchanged.

Use the matching current runtime and SDK. Enable packed cache and mixed formats before enabling sprite output; use the shared MainRAM profile for the current porting contract. In xa syntax, preserve existing FD9F controls when enabling clipping:

```asm
    lda P64_LAYER_FLAGS
    ora #P64_SIDE_BORDER_CLIP
    sta P64_LAYER_FLAGS
```

The bit uses the existing register block and no descriptor, stream, extra sprite slot or guest buffer. RAM protocol 05 alone does not identify capability 18. Old runtimes retain FD9F register bytes but do not implement the new rule; register readback is therefore not a capability probe.

## Pixel rule and native state

The final presentation pass respects TED's native display start/stop coordinates, open-left/open-right flags, border-disable flag, blank state and border colour. It replaces pixels outside a closed native display edge with the native TED border code, within the logical 320×200 area only. For the ordinary 38-column geometry this covers precisely the seven left pixels and nine right pixels; these numbers follow the native bounds rather than a hardcoded game rectangle. Forty-column mode has its own bounds. Open sides remain open; disabling the native border suppresses this pass. A native blank row is wholly border unless the left border is open. Black is opaque and all TED border colours are supported.

Composition order is native TED, lighting/scenery, sprites, guest presentation windows, guest black masking, then this optional native-border pass. A window or sprite cannot paint over a closed native border while the bit is active. Sprite overlap/collision accumulation is unchanged and still precedes presentation clipping, including overlaps hidden by a border. This is pixel presentation, not a new background-collision latch.

The VICE raster routine resets open-border and per-line blank flags before returning. The TED integration therefore captures native bounds, side flags, border disable, per-line blank and colour in a transient **host stack descriptor before** calling `raster_line_emulate`; the completed row's vertical flip-flop is then added before composition. This descriptor is not guest RAM or additional snapshot data. The existing native base is redrawn while the feature is active, so raster-cache reuse cannot retain old composed pixels.

This implementation is qualified for stable scanline state. Cycle-exact changes of border colour, width or open-border state within one line remain unqualified. It performs no game, address, glyph or room recognition.

## Snapshot compatibility

Current readers accept scenery versions 0, 1 and 3–20; withdrawn prototype 2 remains invalid. Version 18 requires mixed formats and tile lighting; the existing dependency rules also require packed cache. Older readers reject 18 before applying the snapshot. Restoring a supported profile below 18 preserves its previous behaviour: FD9F bit 4 remains inactive even when its stored register byte contains that bit. A current profile with bit 4 clear also retains the existing compositor behaviour. Dense and chained-height capabilities remain independently versioned at bytes 80/81; byte82 versions composite materials0..3 and bytes83–127 remain reserved zero.

The source tests cover 20,353 clipping cases, 38,912 old/new cache-guard combinations and 268 validations using the actual old and current snapshot-validation functions. Both optimized and AddressSanitizer/UndefinedBehaviorSanitizer builds pass. They include all 128 native TED code indices, exact side bounds, open/disabled/blank rows, buffer bounds, old-profile/no-flag inertness and strict rejection of unsupported versions. Matching-binary native pixel and snapshot reports provide the execution scope separately; these tests do not certify a campaign, native Windows or physical hardware.

Published runtime/manual 2.0 archives remain historical. This addendum documents the maintained emulator and programming interface, without certifying an electrical cartridge implementation.
