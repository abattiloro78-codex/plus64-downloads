# plus/64 — primo piano ancorato a caratteri, scenario21

La capacità scenario21 aggiunge il **nodo10 da16 byte**. Il software sceglie
due caratteri distinti nella matrice video nativa e un insieme limitato di
rettangoli. Il nodo segue i caratteri durante lo scorrimento, colora i pixel
nativi selezionati e conserva davanti a tutti i formati sprite soltanto il
primo piano richiesto. Non contiene indirizzi o nomi di oggetti di un gioco.

## Nodo e flusso dei rettangoli

| Offset | Byte | Significato |
| --- | ---: | --- |
| 0 | 2 | Nodo successivo, LE16; zero termina la lista |
| 2 | 1 | Codice del carattere di ancoraggio sinistro |
| 3 | 1 | Codice del carattere destro, diverso dal sinistro |
| 4 | 1 | Riga della matrice per gli ancoraggi, 0..24 |
| 5 | 1 | Distanza fra le colonne dei due caratteri, 1..39 |
| 6 | 2 | Puntatore LE16 al flusso dei rettangoli |
| 8 | 1 | Numero di rettangoli, 1..16 |
| 9 | 1 | Profondità della sfumatura orizzontale, 0..7 e non superiore alla luminanza base |
| 10 | 1 | Colore compatto base, 1..120 |
| 11 | 1 | Tipo nodo10 |
| 12 | 1 | Y superiore incluso della scena |
| 13 | 1 | Y inferiore escluso; superiore < inferiore <=200 |
| 14 | 1 | Tinta TED nativa da selezionare, 1..15 |
| 15 | 1 | Flag; zero |

Il flusso riusa i segmenti concatenati nella RAM principale: puntatore al
successivoLE16, lunghezzaU8 e i byte di contenuto. Ogni rettangolo occupa
sei byte: `xLE16, yU8, larghezzaU8, altezzaU8, riservato0`. X è relativo
all'ancoraggio sinistro ricostruito; Y è assoluto nella scena. Larghezza e
altezza sono diverse da zero. Il limite orizzontale dell'oggetto misura
`(distanza fra gli ancoraggi + 1)*8` pixel; tutti i rettangoli devono restare
in tale limite e nei200 pixel verticali. Tutti i record e i byte riservati
sono verificati prima di colorare o selezionare il primo piano.

Il renderer usa il primo carattere sinistro nella riga scelta. Se è visibile
soltanto il destro, sottrae la distanza dichiarata per recuperare l'origine.
La posizione in pixel include lo scorrimento fine effettivo del TED. Si
legge la matrice nativa reale, separatamente dai quaranta caratteri già
caricati per la linea corrente. Il software gestisce l'unicità dei caratteri,
la memoria dei rettangoli e l'installazione di caratteri e font.
Sono ammesse soltanto linee native valide e attive nel modo testo multicolore.
Gli altri modi grafici e le linee inattive o oscurate non attivano il nodo.

La tinta copre l'intera larghezza dell'oggetto ancorato e l'intervallo
superiore/inferiore del nodo. L'unione dei rettangoli sceglie soltanto la
priorità del primo piano e non restringe tale intervallo di tinta. I pixel
con la tinta nativa selezionata passano dalla luminanza base a sinistra alla
profondità più scura dichiarata a destra; altri colori e nero nativo restano
invariati.

## Composizione e compatibilità

Il nodo opera dopo illuminazione e scenario ordinari e prima degli sprite.
Seleziona i bit di primo piano nativi intersecati con i rettangoli del
programma: nel multicolore, le coppie0/1 restano sfondo e le coppie2/3 primo
piano. I colori selezionati sono conservati per la linea e ripristinati dopo
gli sprite, prima di finestre, oscuramento e bordi nativi. Vale per attori
ordinari, RAW8 e densi, senza modificare `$FD95`, alpha, dati delle collisioni
o il momento in cui vengono accumulati.

Colori e maschere salvati sono dati temporanei di una linea sull'host.
Non si aggiungono registri, slot sprite, bitmap o backing RAM del guest.
Descrittori, segmenti, caratteri e installatore devono rientrare nei
**65.536 +16.384 =81.920 byte** già disponibili. Un descrittore da solo non
dimostra che il gioco abbia installato i dati in una zona sicura.

Abilitare gli sprite misti pubblicizza ora la capacità21. Il nuovo nodo è
esplicito: senza di esso resta la presentazione esistente. Il caricamento di
uno snapshot con capacità20 o precedente conserva il profilo salvato e non
interpreta il nodo10. Modulo PLUS64 1.0, payload da144.776 byte, offset e CRC
restano invariati; il byte79 può ora contenere21. I vecchi lettori rifiutano
21 prima del ripristino. Questa funzione software non qualifica una
cartuccia fisica.
