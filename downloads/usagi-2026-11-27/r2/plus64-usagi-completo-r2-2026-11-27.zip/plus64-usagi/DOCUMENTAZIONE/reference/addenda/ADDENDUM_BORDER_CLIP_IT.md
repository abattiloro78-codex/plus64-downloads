# Addendum di sviluppo plus/64: ritaglio dei bordi nativi

L'implementazione software corrente aggiunge una regola di presentazione opzionale mediante **FD9F bit 4**, costante SDK **`P64_SIDE_BORDER_CLIP = 16`**. La capacità scenari **18**, registrata al byte 79 dell'intestazione snapshot PLUS64, versiona questa regola. Protocollo RAM `$05`, modulo snapshot 1.0, payload da 144.776 byte, capacità dense 80/81 e totale di **65.536 + 16.384 = 81.920 byte emulati** rimangono invariati.

Usare runtime e SDK correnti corrispondenti. Abilitare cache compatta e formati misti prima dell'uscita sprite; per il contratto corrente di porting usare il profilo MainRAM condiviso. In sintassi xa, conservare gli altri controlli FD9F quando si abilita il ritaglio:

```asm
    lda P64_LAYER_FLAGS
    ora #P64_SIDE_BORDER_CLIP
    sta P64_LAYER_FLAGS
```

Il bit usa il blocco di registri esistente e non richiede descrittori, stream, altri slot sprite o buffer del programma. Il solo protocollo RAM 05 non identifica la capacità 18. I vecchi runtime conservano i byte del registro FD9F ma non implementano la nuova regola: rileggere il registro non è quindi una sonda della capacità.

## Regola sui pixel e stato nativo

Il passaggio finale di presentazione rispetta coordinate native TED di inizio/fine display, flag di apertura sinistro/destro, disabilitazione del bordo, stato blank e colore del bordo. Sostituisce con il codice TED nativo i pixel esterni a un margine chiuso, limitatamente all'area logica 320×200. Nella normale geometria a 38 colonne copre esattamente sette pixel a sinistra e nove a destra: i numeri derivano dai limiti nativi e non da un rettangolo fisso di un gioco. Il modo a 40 colonne usa i suoi limiti. I lati aperti restano aperti; il bordo nativo disabilitato sopprime questo passaggio. Una riga nativa blank è interamente bordo salvo bordo sinistro aperto. Il nero è opaco e sono supportati tutti i colori TED del bordo.

L'ordine è TED nativo, illuminazione/scena, sprite, finestre di presentazione del programma, mascheramento nero del programma e infine questo passaggio opzionale dei bordi nativi. Con il bit attivo, una finestra o uno sprite non può coprire un bordo nativo chiuso. Accumulo delle collisioni e sovrapposizioni fra sprite non cambiano e precedono il ritaglio, anche per sovrapposizioni nascoste dal bordo. Si tratta della presentazione dei pixel, non di un nuovo latch di collisione con lo sfondo.

La routine raster VICE azzera i flag dei bordi aperti e il blank della singola riga prima del ritorno. L'integrazione TED cattura quindi limiti, flag laterali, disabilitazione, blank della riga e colore in un **descrittore temporaneo sullo stack dell'host prima** di chiamare `raster_line_emulate`; prima della composizione aggiunge poi il flip-flop verticale della riga completata. Il descrittore non è RAM del programma né ulteriore dato snapshot. Con la funzione attiva si ridisegna la base nativa esistente, impedendo alla cache raster di conservare vecchi pixel già composti.

L'implementazione è qualificata per stato stabile nella riga. Cambiamenti a precisione di ciclo di colore, larghezza o apertura del bordo dentro una riga restano non qualificati. Non viene riconosciuto alcun gioco, indirizzo, glifo o numero di stanza.

## Compatibilità degli snapshot

I lettori correnti accettano le versioni scenari 0, 1 e 3–20; il prototipo 2 ritirato resta non valido. La versione 18 richiede formati misti e illuminazione dei livelli; le dipendenze esistenti richiedono anche cache compatta. I lettori precedenti rifiutano 18 prima di applicare lo snapshot. Il ripristino di un profilo supportato inferiore a 18 conserva il comportamento precedente: il bit 4 FD9F rimane inattivo anche se presente nel byte del registro salvato. Anche il profilo corrente con bit 4 spento conserva il comportamento esistente del compositore. MCM denso e altezza concatenata restano versionati separatamente ai byte 80/81; il byte82 versiona i materiali composti0..3 e i byte83–127 rimangono riservati e nulli.

Le prove sui sorgenti coprono 20.353 casi di ritaglio, 38.912 combinazioni dei controlli vecchi/nuovi della cache e 268 convalide eseguite con le vere funzioni precedenti e correnti degli snapshot. Passano sia la build ottimizzata sia AddressSanitizer/UndefinedBehaviorSanitizer. Comprendono tutti i 128 codici TED nativi, limiti laterali esatti, righe aperte/disabilitate/blank, limiti dei buffer, assenza di effetti per vecchi profili o bit spento e rifiuto rigoroso delle versioni non supportate. I rapporti nativi su pixel e snapshot dell'eseguibile corrispondente definiscono separatamente il proprio ambito; queste prove non certificano una campagna, Windows nativo o hardware fisico.

Gli archivi runtime/manuale 2.0 pubblicati rimangono storici. Questo addendum documenta l'emulatore mantenuto e l'interfaccia di programmazione, senza certificare un'implementazione elettrica della cartuccia.
