# Addendum di sviluppo plus/64: MCM denso e FD95

Questo addendum alle fonti descrive l'implementazione di sviluppo provata il
16 novembre 2026. I pacchetti manuale/runtime 2.0 pubblicati restano storici.
La funzione densa è stata introdotta separatamente dalla revisione17 degli
scenari, al byte80 dell'intestazione snapshot PLUS64. Il runtime corrente
supporta inoltre il [ritaglio nativo dei bordi della revisione18](ADDENDUM_BORDER_CLIP_IT.md). Il protocollo RAM
resta `$05`, il modulo resta 1.0 con payload da 144.776 byte e la RAM ospite
resta **64+16 KiB**.

Abilitare `-plus64packedcache -plus64mixedsprites` prima dell'uscita sprite.
Con il bit FD92 dello slot impostato, i bit 15..14 del puntatore=`10`, tag
`$8000`, selezionano un record MCM denso nella vista sprite esistente.
I 14 bit bassi ne indicano l'offset. Tutti i 70 byte devono rientrare senza wrap;
`$3FBA` è l'ultimo indirizzo iniziale valido. Non serve allineamento.
Gli slot visualizzati restano otto. La catena deve rientrare tutta: 63 righe richiedono 210 byte e un inizio non successivo a `$3F2E`.

| Offset | Contenuto |
|---|---|
| `$00` | Tag del byte 63 sorgente, non visualizzato |
| `$01..$3F` | Byte bitmap sorgenti 62..0, invertiti nell'ordine |
| `$40/$41` | Altezza della testa (0=21,1..252) con funzionalità 81; altrimenti shift 0. Modalità 1 |
| `$42/$43/$44` | Inchiostri delle coppie `11/10/01` |
| `$45` | Marcatore valido `$A5` |

La coppia 0 è trasparente; l'inchiostro 0 è nero opaco. Si conservano materiali,
luce diagonale, clipping, espansioni e collisioni fra sprite. Si elimina il
bias `$200` del record precedente, senza aggiungere un archivio texture.

Il bit FD95 di uno slot denso abilitato lo pone dietro al foreground nativo.
Testo standard/ECM e bitmap hires usano i bit sorgenti impostati; celle di
testo multicolore e bitmap multicolore usano le coppie `10/11`, mentre `00/01`
restano background. Le celle hires nel testo multicolore usano i singoli bit.
Il testo standard rispetta inverso, lampeggio e cursore. Anche il foreground
nero occlude. Lo sprite visibile con priorità maggiore continua a prevalere;
se nascosto, rivela il TED, non uno sprite inferiore. Non si aggiunge un latch
di collisioni con lo sfondo. FD95 resta riservato per i formati precedenti/non
densi.

La classificazione è qualificata per stato stabile nella riga raster; i
cambiamenti a precisione di ciclo di modo, font, scroll o bordo dentro una riga
restano non qualificati. Blank, idle e modi illegali non forniscono foreground
grafico. Il byte 80=1 richiede formati misti e cache compatta. Il ripristino di
80=0 conserva il significato precedente di puntatori e registro anche con
formati misti abilitati; i lettori precedenti rifiutano 80=1. Il solo protocollo
SRAM 05 non identifica il supporto denso: usare il runtime corrispondente.

## Altezza concatenata e snapshot 81

Con la funzionalità 81 abilitata, il byte `$40` della testa vale 0 per 21 righe
oppure 1..252 per l'altezza logica; 253..255 non sono validi. La colonna è
composta da `ceil(altezza/21)` parti consecutive da 70 byte, tutte con modalità 1
e marcatore `$A5`. L'intera catena deve rientrare senza wrap, comprese le parti
fuori schermo. Il campo `$40` nelle parti successive viene ignorato. La riga y
sceglie parte `y div21` e riga `y mod21`. Ogni parte conserva inchiostri, tag,
materiale e profilo diagonale propri, come record da 21 righe sovrapposti in
verticale. L'espansione segue la scelta della riga sorgente. La colonna usa
ancora uno degli otto slot visualizzati.

Con leftmcm, una colonna densa più alta di 21 proietta Ygrezza 206..255 in −50..−1;
i percorsi da 21 righe/precedenti conservano la proiezione Y 215..255. La
funzionalità 81=1 richiede 80, formati misti e cache compatta. Uno snapshot
precedente con 81=0 conserva il vecchio vincolo byte `$40`=0; i lettori anteriori
rifiutano 81=1. I byte 82..127 restano riservati e nulli. Non si aggiungono payload,
banchi RAM o slot sprite.

La seguente transazione xa presume il TED configurato e la porta sprite
assegnata al chiamante. Usa l'include SDK corrente, modifica A/X e pubblica per
ultimo. Il record è una colonna opaca 24×63 nel blu compatto 81. Il nome SDK
`P64_SPR_RAW8` di FD92 seleziona anche MCM con la configurazione packed-cache.

```asm
#include "plus64.inc"
* = $1100
dense_example:
    php
    sei
    lda #0
    sta P64_SPR_ENABLE
    sta P64_SPR_ADDR_LO
    sta P64_SPR_ADDR_HI
    ldx #0
dense_upload:
    lda dense_record,x
    sta P64_SPR_DATA
    inx
    cpx #3*P64_DENSE_MCM_BYTES
    bne dense_upload
    lda #40
    sta P64_SPR_DESC
    lda #80
    sta P64_SPR_DESC+1
    lda #0
    sta P64_SPR_DESC+2
    sta P64_SPR_DESC+3
    sta P64_SPR_DESC+4
    lda #>P64_DENSE_MCM_TAG
    sta P64_SPR_DESC+5
    lda #1
    sta P64_SPR_RAW8
    sta P64_SPR_BEHIND
    sta P64_SPR_ENABLE
    plp
    rts
dense_record:
    .byt 0
    .dsb 63,$aa
    .byt 63,1,81,81,81,$a5
    .byt 0
    .dsb 63,$aa
    .byt 0,1,81,81,81,$a5
    .byt 0
    .dsb 63,$aa
    .byt 0,1,81,81,81,$a5
```

Dalla radice del repository, salvare il codice come `dense.asm` e assemblare con `xa -Idocs/developers/sdk-current/include -o dense.bin dense.asm`. L’output senza intestazione misura 275 byte, compresi 210 byte sorgente/metadati; l’ingresso chiamabile è `$1100`.

La suite altezza verifica inoltre 5815 fotogrammi a tre parti contro record precedenti sovrapposti e 1310 casi con tutte le altezze 1..252, limiti, espansioni e proiezione, comprese le dipendenze snapshot 81 e il rifiuto dei lettori precedenti.

L'eseguibile Linux nativo verificato ha SHA256
`edcabd4dc13421e15440ad9ccec31afe904b5dbdd14d39151bcb1eb9ce79faed`.
Le prove ottimizzate e ASan/UBSan coprono 4779 equivalenze di fotogrammi
densi/precedenti, 256 configurazioni del decoder precedente, compatibilità
snapshot, 75032 casi di foreground/priorità e 2048 casi del filtro effettivo
degli slot densi. Le prove reali da 63 righe su C16 e Plus/4 preservano 756 pixel neri di
foreground, lasciano FD95 inerte sui formati precedenti e riproducono lo stesso
BMP completo dopo il ripristino di un nuovo snapshot con funzionalità 80/81.
Anche il percorso da 63 righe con collisioni immediate passa su C16. La regressione corrente
SDK C16 con avvio D64 a freddo passa. Sono prove software dedicate, non
qualifiche di partita completa, Windows nativo, progetto elettrico o hardware
fisico.

Vedere [il capitolo video corrente](../../chapters/it/03_video_sprite.md),
[il formato dati](../../FORMATI_GRAFICI.md) e
[la specifica snapshot](../../SNAPSHOT_FORMAT.md).
