# plus/64 — indexed tints with an elliptical footprint

Scenery revision **19** adds an optional elliptical footprint to indexed
tint types **5** and **7**. Software selects it with **bit 3 (`$08`) of the
style byte at node offset 10**. This is a descriptor bit in guest RAM,
distinct from FD9F bit 3, which continues to control the post-sprite
presentation window.

Type 5 remains **12 bytes** and type 7 **20 bytes**. Registers, addresses,
colour tables, conditions, 8-pixel-cell geometry and the 32-node limit do
not change. The x/y/width/height rectangle bounds the ellipse, whose edge
is evaluated at single-pixel resolution. With the bit clear, the footprint
remains rectangular.

The SDK constant is `P64_TINT_ELLIPSE=$08`;
`P64_SCENERY_ELLIPSE_VERSION=19` and `P64_SNAPSHOT_SCENERY_CAP_OFFSET=79`
identify the serialized revision.

For an integer local pixel `(u,v)` in a rectangle `w` pixels wide and `h`
pixels high, the sample centre is tested using:

```text
dx = 2*u + 1 - w
dy = 2*v + 1 - h
inside if dx*dx*h*h + dy*dy*w*w <= w*w*h*h
```

The comparison uses 64-bit integer products and includes points on the
boundary. This test clips only the footprint: lighting retains its existing
coordinates and formula.

## Pixel selection and colours

The node leaves pixels outside the ellipse unchanged. Inside, ordinary
indexed-tint rules apply: native black is protected, tables select compact
colours 0..120 and 255 preserves a pixel. Style bit 7 restricts source hues
to 0..7; bit 6 selects tables by source luminance below 5 or at least 5.
The low three bits retain shade depth and bit 5 frontal illumination.
Bit 3 does not change the palette, depth or lighting formula.

Type-7 conditions are checked before tinting. The ellipse does not add
sprite opacity or alter collisions or source RAM. Tinting remains in the
layer pass, before streamed scenery and sprites. Several ellipses may
overlap through the existing list; software-selected order and tables
determine which pixels are recoloured. The renderer contains no cloud,
game or image-part recognition.

An xa example selecting only bright native blue and replacing it with white:

```asm
ellipse_node:
    .word 0                 ; end of list
    .byte 14,3,8,4          ; x,y,w,h in cells:64x32-pixel rectangle
    .word 0                 ; dark bank: preserve all pixels
    .word bright_blue_lut   ; bright bank, source L>=5
    .byte $c8,5             ; hue<8 limit + luminance bank + ellipse
bright_blue_lut:
    .byte 255,255,255,255,255,255,106,255
```

Eight table bytes suffice because bit 7 excludes indices 8..15. Entry 6
selects blue; 106 is compact white at luminance 7. Software must place the
node and table in its reserved RAM and publish their pointer through
FD9D/FD9E with FD9F bit 0 enabled. Register readback does not establish
ellipse support in an older executable: use the matching revision-19 runtime.

## Snapshots and memory

HOST PLUS64 header field **79** identifies the scenery revision. With value
19, style bit 3 can select the ellipse. Restoring a supported profile
**through 18** ignores the same bit and retains historical rectangular
behaviour. An older reader supporting at most 18 rejects a version-19
snapshot before applying it.

RAM protocol `$05`, PLUS64 module 1.0, its 144,776-byte payload and the
**65,536 + 16,384 = 81,920-byte** backing remain unchanged. Dense capabilities
80/81 and authored materials at byte 82 are independently versioned. No
buffers, per-luminance images, sprite slots or guest-addressable RAM are
added. Host compositing work is distinct from the guest memory budget and
does not qualify a physical cartridge or its timing.

C tests, emulator cold boots and Wine tests identify their binary and scope
separately. This addendum does not transfer older executable qualification
to newly built binaries.
