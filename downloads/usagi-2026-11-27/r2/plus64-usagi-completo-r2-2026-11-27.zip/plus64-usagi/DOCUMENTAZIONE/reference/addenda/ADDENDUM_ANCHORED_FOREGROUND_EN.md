# plus/64 — glyph-anchored foreground, scenery21

Scenery capability21 adds explicit **16-byte node10**. Software selects two
distinct character markers in the current native matrix and a bounded set of
rectangles. The node follows those markers during scrolling, colours matching
native pixels, and retains only the selected native foreground pixels over
every sprite format. It contains no game addresses or object names.

## Node and rectangle stream

| Offset | Bytes | Meaning |
| --- | ---: | --- |
| 0 | 2 | Next node, LE16; zero ends the list |
| 2 | 1 | Left anchor character code |
| 3 | 1 | Right anchor character code, distinct from the left |
| 4 | 1 | Anchor matrix row, 0..24 |
| 5 | 1 | Distance between anchor columns, 1..39 |
| 6 | 2 | Rectangle stream pointer, LE16 |
| 8 | 1 | Rectangle count, 1..16 |
| 9 | 1 | Horizontal shading depth, 0..7 and no greater than base luminance |
| 10 | 1 | Base compact colour, 1..120 |
| 11 | 1 | Node type10 |
| 12 | 1 | Included top canvas Y |
| 13 | 1 | Excluded bottom canvas Y; top < bottom <=200 |
| 14 | 1 | Source native TED hue key, 1..15 |
| 15 | 1 | Flags; zero |

The rectangle stream uses existing linked main-RAM chunks: next-pointerLE16,
payload-lengthU8, then that many payload bytes. Each six-byte rectangle is
`xLE16, yU8, widthU8, heightU8, reserved0`. X is relative to the recovered
left anchor; Y is an absolute canvas coordinate. Width and height are nonzero.
The horizontal owner bounds are `(anchor distance + 1)*8` pixels; every
rectangle must fit those bounds and the 200-pixel canvas. All records and
reserved bytes are validated before any tint or foreground selection.

The renderer uses the first left marker in the selected row. If only a right
marker is visible, its column minus the declared distance recovers the left
origin. The current TED source origin, including fine scroll, determines the
pixel position. It reads the actual native matrix, independently of the
current scanline's forty fetched character cells. Software owns marker
uniqueness, rectangle storage, and marker/font installation.
Only a valid, active native multicolour-text row is eligible. Other graphics
modes and idle/blank rows leave the new layer inactive.

Tinting uses the complete anchored horizontal owner bounds and the node's
top/bottom interval. The rectangle union selects foreground priority only;
it does not restrict this separate tint interval. Matching native hue pixels
are shaded from the base luminance on the left toward the declared darker
depth on the right; other hues and native black remain unchanged.

## Composition and compatibility

The node runs after ordinary background lighting/scenery and before sprites.
It selects foreground from original native source bits, intersected with the
guest rectangles; multicolour pairs0/1 remain background and pairs2/3 remain
foreground. The selected source colours are retained for this scanline and
restored after sprite composition, before windows, blanking and native border
clipping. This selection applies to ordinary, RAW8 and dense actors without
changing `$FD95`, sprite alpha, collision inputs, or collision timing.

The saved colours and masks are transient host scanline data. No register,
sprite slot, guest bitmap pool, or additional guest backing is allocated.
Descriptors, chunks, glyphs and any installer must fit the software's existing
**65,536 + 16,384 =81,920 bytes**. A descriptor alone is not proof that a game
has installed the data safely.

Enabling mixed sprites now advertises capability21. The new node is explicit
opt-in: absent nodes preserve the existing presentation. Restoring a snapshot
with capability20 or earlier retains its saved profile and ignores node10.
PLUS64 module1.0, its144,776-byte payload, offsets and CRC rules remain
unchanged; byte79 may now contain21. Older readers reject21 before applying
the snapshot. This software feature does not qualify physical cartridge hardware.
