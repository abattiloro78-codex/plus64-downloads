# plus/64 — tinte indicizzate con sagoma ellittica

La revisione scenari **19** aggiunge una sagoma ellittica opzionale alle
tinte indicizzate di tipo **5** e **7**. Il programma la seleziona con
**bit 3 (`$08`) del byte stile all'offset 10 del nodo**. Questo bit appartiene
al descrittore in RAM: è distinto da FD9F bit 3, che continua a controllare
la finestra di presentazione successiva agli sprite.

Il tipo 5 rimane di **12 byte**, il tipo 7 di **20 byte**. Non cambiano
registri, indirizzi, tavole di colore, condizioni, geometrie in celle da
8 pixel o limite di 32 nodi. Il rettangolo x/y/larghezza/altezza contiene
l'ellisse; i suoi bordi vengono valutati alla risoluzione del singolo pixel.
Il bit spento mantiene la sagoma rettangolare.

La costante SDK è `P64_TINT_ELLIPSE=$08`; `P64_SCENERY_ELLIPSE_VERSION=19`
e `P64_SNAPSHOT_SCENERY_CAP_OFFSET=79` identificano la revisione serializzata.

Per un pixel locale intero `(u,v)` nel rettangolo largo `w` e alto `h`
pixel, il centro del campione viene verificato con:

```text
dx = 2*u + 1 - w
dy = 2*v + 1 - h
interno se dx*dx*h*h + dy*dy*w*w <= w*w*h*h
```

Il confronto usa prodotti interi a 64 bit; i punti sul bordo sono inclusi.
Questa verifica ritaglia soltanto la sagoma: l'illuminazione continua a
usare le proprie coordinate e la formula preesistente.

## Selezione dei pixel e colori

Fuori dall'ellisse il nodo non modifica il pixel. Dentro, valgono le regole
consuete della tinta indicizzata: il nero nativo è protetto, le tavole
selezionano i colori compatti 0..120 e 255 conserva il pixel. Il bit 7 dello
stile limita le tinte sorgenti a 0..7; il bit 6 sceglie le tavole in base
alla luminanza sorgente, sotto 5 oppure almeno 5. I tre bit bassi conservano
la profondità dell'ombra e il bit 5 la luce frontale. Il bit 3 non cambia
palette, profondità o formula della luce.

Le condizioni del tipo 7 vengono verificate prima della tinta. L'ellisse
non aggiunge opacità agli sprite e non modifica collisioni o RAM sorgente.
La tinta resta nel passaggio dei livelli, prima di scena e sprite. Più
ellissi possono sovrapporsi usando la lista già disponibile; ordine e
tavole scelti dal programma stabiliscono quali pixel vengono ricolorati.
Il renderer non riconosce nuvole, giochi o parti di un'immagine.

Esempio xa di un'ellisse bianca che seleziona solo il blu nativo luminoso:

```asm
ellipse_node:
    .word 0                 ; fine lista
    .byte 14,3,8,4          ; x,y,w,h in celle: rettangolo64x32 pixel
    .word 0                 ; banca scura: non modifica nulla
    .word bright_blue_lut   ; banca luminosa, sorgente L>=5
    .byte $c8,5             ; limit hue<8 + banca luminanza + ellisse
bright_blue_lut:
    .byte 255,255,255,255,255,255,106,255
```

La tabella da otto byte è sufficiente perché bit 7 esclude gli indici 8..15.
La voce 6 seleziona la tinta blu; 106 è bianco compatto a luminanza 7.
Il programma deve collocare nodo e tabella nella propria RAM riservata e
pubblicarne il puntatore attraverso FD9D/FD9E, con FD9F bit 0 attivo.
La rilettura dei registri non dimostra che un vecchio eseguibile supporti
la forma ellittica: usare il runtime corrispondente alla revisione 19.

## Snapshot e memoria

Il campo **79** dell'intestazione HOST PLUS64 identifica la revisione scenari.
Con valore 19, bit 3 dello stile può selezionare l'ellisse. Ripristinando
un profilo supportato **fino a 18**, lo stesso bit viene ignorato e resta
il comportamento rettangolare storico. Un vecchio lettore che supporta
al massimo 18 rifiuta uno snapshot 19 prima di applicarlo.

Protocollo RAM `$05`, modulo PLUS64 1.0, payload da 144.776 byte e backing
da **65.536 + 16.384 = 81.920 byte** rimangono invariati. Le capacità dense
80/81 e i materiali composti al byte 82 sono versionati separatamente.
Non vengono creati buffer, immagini per ogni luminanza, slot sprite o
nuova RAM indirizzabile dal programma. Il calcolo del compositore è
distinto dal budget della macchina emulata e non qualifica una cartuccia
fisica o la sua temporizzazione.

Le prove del codice C, gli avvii nell'emulatore e le prove Wine identificano
separatamente eseguibile e ambito. Questo addendum non trasferisce ai nuovi
binari la qualifica degli eseguibili precedenti.
