#!/usr/bin/env python3
"""Generic P64Fv4/zlib authoring example, not a game or standalone PRG."""
from pathlib import Path
import argparse,struct,zlib,json,hashlib
p=argparse.ArgumentParser();p.add_argument('--input',type=Path,help='raw source: N original MCM frames of63 bytes');p.add_argument('--out',type=Path,required=True);p.add_argument('--base',type=lambda s:int(s,0),default=0x9000);p.add_argument('--capacity',type=int,choices=[16384,65536],default=65536);a=p.parse_args()
raw=a.input.read_bytes()if a.input else bytes((0x55,0xaa,0xff)[f]if y%2 else 0 for f in range(3)for y in range(63))
assert raw and len(raw)%63==0,'input must contain whole63-byte frames';count=len(raw)//63;assert count<=65535;groups=(count+31)//32;packets=[]
for k in range(groups):
 block=raw[k*2016:(k+1)*2016];stored=zlib.compress(block,9);packet=b'P64Z'+bytes([1,1])+struct.pack('<HHH',len(block),len(stored),0)+stored;assert zlib.decompress(packet[12:])==block;packets.append(packet)
root=bytearray(b'P64F'+bytes([4,32,63,0])+struct.pack('<HH',count,groups));offset=12+4*groups
for packet in packets:
 assert a.base+offset+len(packet)<=a.capacity,'encoded bank does not fit selected guest backing';root+=struct.pack('<HH',a.base+offset,len(packet));offset+=len(packet)
archive=bytes(root)+b''.join(packets);assert a.base>=0 and a.base+len(archive)<=a.capacity;a.out.mkdir(parents=True,exist_ok=False);(a.out/'framebank.bin').write_bytes(archive);(a.out/'BUILD.json').write_text(json.dumps(dict(format='P64Fv4',frames=count,root=a.base,guest_backing_capacity=a.capacity,resident_bytes=len(archive),end_exclusive=a.base+len(archive),source_records_count_separately=True,maximum_temporary_decoded_group_bytes=2016,archive_sha256=hashlib.sha256(archive).hexdigest(),standalone_PRG=False),indent=2)+'\n');print(f'{count} frames; {len(archive)} resident bytes; no additional guest backing')
