# Extended sprite formats and compact-mask materials

This optional video-circuit extension adds no emulated payload RAM, CPU
registers or sprite slots. Storage remains the existing 64 KiB cartridge
plus 16 KiB host backing. The implementation is in the maintained VICE
source and the RAM80 snapshot source overlay. Physical circuitry is not
qualified by these emulator tests.

Enable `Plus64PackedCache` first, then `Plus64MixedSprites` (CLI:
`-plus64packedcache -plus64mixedsprites`). The extension defaults off.
Changing it while any sprite is enabled is rejected without side effects.
It survives device reset as configuration; registers reset normally.

## Mixed RAW8

With FD92's slot bit set, bit14 of the descriptor pattern pointer selects
RAW8; bit15 must be zero. The lower 14 bits address the same existing
16 KiB backing. For example, `$4800` selects RAW8 at backing offset `$0800`.
The full 504-byte image must fit without wrapping the bank. Indices 0..120
are opaque, including black0; larger values are transparent, as in the
existing RAW8 decoder. Coordinates, expansion, priority and collisions use
the ordinary compositor. Untagged slots retain packed-cache semantics.
When the extension is disabled, tagged packed pointers remain invalid.

## Dense inverse multicolour records

With both `Plus64PackedCache` and `Plus64MixedSprites` enabled, and FD92's
slot bit set, descriptor pointer bits15..14=`10` select a dense multicolour
record. The tag is `$8000`; the lower14 bits select any byte offset in the
same existing16KiB sprite view. The complete70-byte record must fit without
wrapping: `$3FBA` is the last valid start, and `$3FBB` is invalid. There is no
alignment requirement and no implicit rounding to a1024-byte cache block.

| Offset | Meaning |
|---|---|
| `$00` | Software-owned source-byte63 tag, not displayed |
| `$01..$3F` | Source bitmap bytes62..0 in reverse byte order |
| `$40` | With capability81=0: shift0. With81=1: head height0=21 or1..252 rows; see below |
| `$41` | Mode, must be1 |
| `$42` | Ink for source pair3, corresponding to the second shared ink |
| `$43` | Ink for source pair2, the local ink |
| `$44` | Ink for source pair1, the first shared ink |
| `$45` | Valid marker, must be`$A5` |

This is the established inverse MCM record with its `$200` address bias
removed. Pair0 remains transparent; ink0 is opaque black. The existing
colour0..120, transparency, descriptor/tag materials, selected lighting,
per-ink diagonal lighting, collision-only tags and occluding tags apply
unchanged. Clipping, expansion, display priority and collision rules are the
same compositor paths. Invalid bounds or metadata draw nothing.

Pointer tags`00` retain the aligned legacy packed record, tag`01` retains
mixed RAW8, and tag`11` is invalid for packed slots. FD92-clear slots and
non-packed decoding retain their existing pointer semantics. This extension
adds no register, sprite slot, backing bank or game-specific recognition.
Its records are software-owned data in the same64+16KiB budget.

### Dense-only background priority: FD95

FD95's bit for an enabled dense-MCM slot requests placement behind native
TED foreground pixels. This meaning requires the dense capability, mixed
formats, packed cache, the slot's FD92 bit and its pointer tag`$8000`.
FD95 remains reserved for every older/non-dense format, even when the new
mixed-format configuration is active. Older snapshots with capability80=0
retain their reserved-register behaviour.

The native compositor classifies source bits rather than comparing colours.
Standard text and hires bitmap use set bits; multicolour text cells with
the multicolour attribute and multicolour bitmap use pairs`10/11` as
foreground, while`00/01` remain background. Hires cells within multicolour
text use individual bits. ECM text uses its64-glyph source. Standard text
honours reverse characters, blinking and the cursor as drawn by TED. Black
foreground remains foreground, and an opaque black sprite remains opaque.
Blank, idle and illegal modes contribute no graphics foreground.

For overlapping sprites, the lowest numbered visible slot retains priority.
If that top sprite requests behind placement and the native pixel is
foreground, the native TED pixel remains visible; a lower sprite cannot
appear through it. This presentation rule leaves sprite occupancy and
sprite/sprite collision latching unchanged. Deferred masks already retain
slot identities. When raster collision mode is off, this new path performs
a second host-side capture for those identities after the historical
immediate collision capture; it allocates no guest bytes or sprite slots.

Foreground uses the current TED character/attribute row, font/bitmap,
row counter, horizontal fine scroll and visible graphics bounds. It is
qualified for stable scanline graphics state. Cycle-exact effects that
change mode, font, fine scroll or border state within a scanline remain
unqualified: this extension does not add a TED drawing-pipeline hook.
Capability80 versions the dense record and this dense-only priority rule
together; this pre-release capability has not been published separately.

The focused helper regression is:

```sh
python3 emulator/experimental/sprite-formats/tests/dense-priority/run.py --out qa/dense-priority-new
```

It checks75032 source-bit/priority cases,256 legacy overlay equivalences and
2048 cases of the actual native dense-slot filter with optimized and
ASan/UBSan builds. The filter verifies that old/non-dense formats and
capability0 snapshots retain their reserved FD95 behaviour. Integrated
native captures and snapshot replay are separate from this standalone
qualification.

Snapshot header byte80 versions dense decoding independently of the other
format fields. New mixed-format configuration enables it. Loading an older
snapshot with byte80=0 explicitly leaves dense decoding disabled, even if
mixed sprites are enabled, so a previously invalid tagged pointer cannot
silently acquire a new meaning. Byte80 must be0 or1;1 requires mixed formats
and packed cache. Older readers reject1 through their reserved-byte checks.
The later height capability uses byte81; bytes82..127 remain reserved zero
and the fixed payload does not grow.

### Chained dense height: snapshot capability81

New mixed-format configuration also enables dense height support, separately
versioned at snapshot header81. For a dense record, the head's byte`$40` now
selects logical height:0 retains21 rows,1..252 select that many rows, and
253..255 are invalid. A height`h` consumes `ceil(h/21)` consecutive70-byte
parts. Every part must have mode1 and marker`$A5`; the entire chain must fit
in the16KiB view without wrapping. Invalid metadata in even an offscreen part
rejects the whole image. Only the head's byte`$40` determines the height;
the same field in following parts is not consumed.

For logical source row`y`, use part `floor(y/21)` and row`y mod21`. Each part
retains its own inverse bitmap, three inks and source tag. Material profiles
and diagonal bounds are computed within that21-row part, matching stacked
legacy records rather than automatically shading the whole column. Expansion
applies after logical row selection. This still occupies one displayed slot.

With `Plus64LeftMCM`, a dense image taller than21 rows projects raw Y206..255
to−50..−1, consistent with its publisher's `(rawY−50) mod256` convention.
The positive range is0..205. All21-row and older paths retain the previous
Y215..255 projection. X projection and ordinary clipping remain unchanged.

Header81 must be0 or1;1 requires capability80, mixed formats and packed cache.
Restoring81=0 keeps the previous rule that dense byte`$40` must be0, so an old
snapshot cannot implicitly enable a taller record. Readers predating height
support reject81=1 as a nonzero reserved field. Payload size and guest RAM
remain unchanged.

```sh
python3 emulator/experimental/sprite-formats/tests/dense-height/run.py --out qa/dense-height-new
```

The actual C decoder is checked in optimized and ASan/UBSan builds:5815
height63 versus three stacked legacy21-row frame comparisons,1310 checks
covering every height1..252, expansion, complete-chain bounds/markers, top
projection and collision bits, and the actual snapshot81 validator and wire
assignments. Existing dense21 and256-configuration legacy tests remain
separate regressions. These tests do not establish native game timing.

Run the actual C decoder and snapshot-validator tests with:

```sh
python3 emulator/experimental/sprite-formats/tests/dense-mcm/run.py --out qa/dense-mcm-new
```

The suite compares4779 complete legacy/dense frames, including all121 inks
and material highlights, sixteen selector values, diagonal shading, black,
alpha, collisions, clipping, expansion and bank bounds. It also checks256
legacy configurations, actual snapshot capability assignments, the previous
reader's rejection and the new reader's acceptance of old capability0 states.
Both optimized and ASan/UBSan builds use the actual maintained implementation.
These are standalone software tests, not native gameplay or physical tests.

## Eight-luminance mask material

For a valid packed multicolour record, the software-owned, non-displayed
RAW64 byte63 at record offset `$200` selects a full material colour:
`tag = $80 | colour`, with compact colour indices0..120. Therefore `$80..$F8`
are material tags; `$F9..$FF` and tags below `$80` are ordinary source tags.
Black0 remains opaque black. All64 source bytes remain part of the cache key.

The selected colour is the highlight, including its luminance. Shadows use
only lower luminances of the same hue. Index0 is black; indices1..15 are
hues1..15 at luminance0, indices16..30 at luminance1, and so on through
indices106..120 at luminance7. Examples: bright cyan108 uses tag`$EC`, bright
red107 uses`$EB`, bright blue111 uses`$EF`, blue3 uses81/tag`$D1`, and black
uses`$80`. In a user scale1=light to8=dark, TED luminance is`8-step`.

Alternatively, descriptor colour bit7 selects the material for a valid
compact mask; its lower seven bits select the same colour0..120. This also
supports HIRES masks. Tagged mixed RAW8 bypasses materials.

The profile has highlight origin (6,5) in the 24x21 sprite grid. For each
opaque pixel (x,y), luminance is:

```
max(0, 7 - ((x-6)*(x-6) + (y-5)*(y-5)) / 40)
```

Division is integer truncation. For selected colour`c > 0`, its maximum luminance is `(c-1)/15`, and
its hue is `1+(c-1)%15`. Scale the profile luminance by `maximum/7`, using
integer truncation, then output `15*luma+hue`. Colour0 outputs black.
The brightest selected colours retain all eight bands; darker selections
use fewer levels without exceeding the selected highlight colour.
The circuit computes this fixed material; it does not store an extra pixel
image or recognize game IDs, sprite IDs, game addresses or bitmap contents.
Every existing opacity, clipping, expansion and collision rule remains.
Different silhouettes need different visual evaluation of this fixed profile.

## Snapshots

PLUS64's existing fixed payload stores the configuration boolean in header
byte72, formerly reserved. Byte73 marks full-palette material semantics. CRC32 covers both. New readers accept old snapshots
with byte72 zero. First-generation material snapshots with byte72 one and
byte73 zero retain their old hue-only tags`$81..$8F` and full eight-level ramp;
their image is preserved. New full-palette snapshots use byte73 one. Old
readers reject these snapshots because they require
all reserved bytes to be zero. Corrupt booleans, palette-without-extension and extension-without-packed
configurations are rejected. Descriptors, source tags, latched colours,
alpha and collisions already have serialized storage, so no payload grows.

## Validation

```
python3 emulator/experimental/sprite-formats/tests/run.py --out qa/formats-new
```

This compiles the actual C decoder with ASan/UBSan and compares 256 supported
legacy configurations against the preserved pre-extension decoder. Additional
checks cover all121 RAW8 colours, opaque black, transparency, bank boundaries,
materials, clipping and collision invariance. The sphere integration's
`verify_game.py` adds actual cold VICE game A/B and fresh snapshot checks on
C16 and Plus/4. Neither suite is a physical-hardware test.

## Sparse mask and palette regions

A new version of the same opt-in extension accepts descriptor colour`F9`
for a valid HIRES packed record. Cache source byte0=`A7`, byte1=`S`,
byte2=base ink/material. `S=3+4*N`, where`N` is the number of inclusive
palette rectangles. Each four-byte rectangle stores bounds as the little-
endian20-bit value `x0|(y0<<5)|(x1<<10)|(y1<<15)`, followed by its ink.
Coordinates must satisfy `0<=x0<=x1<24`, `0<=y0<=y1<21`.

At source byte`S`, eight occupancy bytes identify nonzero bitmap bytes in
reverse bitmap order62..0, high bit first. The corresponding nonzero values
follow these eight bytes in the same order. Every read must fit bytes0..62;
malformed records draw nothing. Byte63's bit7 mirrors the logical source
horizontally. HIRES source shifting/clipping follows the existing rule.
Colours0..120 are solid; bit7 requests the existing luminance material using
the low seven bits. Later rectangles take precedence on opaque pixels only.
Neither the regions nor compression may introduce opacity. Rectangles,
colours, orientation and the base ink belong to software, with no game,
address, slot or silhouette recognition in the decoder.

An`F9`-selected ordinary bitmap without magic`A7` uses its cached shared1
colour as its solid ink. This permits software to reconstruct a bitmap for
ordinary bitwise effects while keeping its descriptor format selector.

The existing16KiB backing and inverse RAW64 metadata hold everything. The
63-byte temporary decoding mask in the host compositor is computation,
not extra CPU-addressable or snapshot payload memory. Hardware feasibility
and timing of this optional decoder remain unqualified.

PLUS64 header byte74 now versions sparse-format support. New extension
configuration enables it; old snapshots with74=0 retain their old behaviour.
Readers reject74>1 and sparse-without-full-palette. Bytes75..127 stay reserved.
Older executables reject the new reserved-byte value rather than loading a
snapshot with incompatible interpretation. Payload size remains unchanged.

## Eight selectable light directions plus front

With the extended formats enabled, existing registers`FD99..FD9C` select a
light direction per sprite, packed two slots per byte. The low nibble belongs
to the even slot; the high nibble to the following odd slot. Example:
`FD99=$30` gives slot1 east lighting and keeps slot0's historical highlight.

| Value | Direction | Highlight in the24x21 sprite grid |
|---|---|---|
|0|Historical profile|(6,5)|
|1|N|(12,0)|
|2|NE|(23,0)|
|3|E|(23,10)|
|4|SE|(23,20)|
|5|S|(12,20)|
|6|SW|(0,20)|
|7|W|(0,10)|
|8|NW|(0,0)|
|9|Front, from the viewer|(12,10)|

Values10..15 are reserved and retain the historical profile. Directions are
screen-relative: mirroring the source does not reverse a selected light.
The established radial luminance formula, selected highlight colour and
opacity remain unchanged. This is a colour profile, not a surface-normal or
3D lighting model. No new guest RAM, image upload or sprite slot is added;
these four registers already belonged to the existing64-byte register file.
Configuration reset sets selectors to0, preserving all previous pictures.
Snapshot header75 versions direction support; older snapshots ignore these
registers for materials. New snapshots require a reader supporting75=1.
Header bytes76..127 remain reserved.

The directions regression is in`tests/light-directions/test.c`: all121
colours, eight slots, sixteen selector values and every24x21pixel, with
ASan/UBSan, plus sparse mirroring and legacy behaviour. The reviewed game
art and launchers are not changed by implementing this platform feature.

### Mask-aware frontal material revision

For sparse masks, new snapshots with header76=1 use a frontal highlight
within each occupied row span. Thin spans retain the selected highlight;
wider spans shade their edges. This avoids darkening a face merely because
it lies away from a whole-record centre. Legacy snapshots keep the earlier
radial front9 profile. Header bytes77..127 remain reserved. No RGB palette
is invented: output remains the same121 TED colours.

### Mask material opacity

For a tagged compact-mask material, pair0 alone is transparent. Any nonzero
pair is opaque even if the old source-ink field contains an extended tag or
transparent marker: that ink is replaced by the selected material. Untagged
multicolour records retain their original ink/alpha behaviour. The sphere
regression in `tests/sphere-alpha` covers the formerly missing18 pixels.

## Diagonal character lighting (opt-in, snapshot header byte77)

With the mixed-format extension enabled, FD9D/FD9E point into existing main
RAM; FD9F bit0 enables a linked list of lighting rectangles. No additional
CPU-addressable storage or texture RAM is allocated. Rendering reads the
list directly, with at most32 nodes per scanline. Sprites are composited
AFTER this pass and retain their original pixels, alpha and collisions.

Base node (12 bytes): next pointer LE16; x,y,width,height in8px character
cells; local xmin,ymin,xmax,ymax; compact background key; flags. Coordinates
must fit320x200. Flags0 shades all nonblack pixels except the background
key. Flags1 uses a20-byte node, adding font-base LE16, live-character-base
LE16, live-attribute-base LE16 and expected-tile-character-base LE16. It
shades only matching glyph foreground pixels, with bit3 of the source
attribute selecting two-bit multicolour (pair0 transparent); otherwise
one-bit hires. This preserves opaque foregrounds matching the background
colour and excludes replaced characters such as search windows. Unknown
flags, invalid bounds or out-of-range reads never affect display pixels.

Hue is preserved. With dx=max(1,xmax-xmin),dy=max(1,ymax-ymin), local x,y
clamped to those bounds, the TED luminance is clamped0..7 after adding
2-floor(5*(x*dy+y*dx)/(2*dx*dy)). Thus equal-light bands are diagonal.
Black stays black. The optional VICE raster cache redraws the TED base
before lighting, preventing accumulation on static frames.

Snapshot PLUS64 header77 records the format version as a boolean dependent
on mixed formats; bytes78..127 remain zero. Descriptors and operands reside
in the existing64KiB main image and are already serialized. Old snapshots
restore with lighting disabled. Old readers reject the new nonzero flag.

## Per-ink diagonal MCM sprite lighting (snapshot header78)

Light-direction nibble10 is an opt-in diagonal profile for validated compact
MCM records. It retains all three original inks and pair0 transparency.
Black stays black; nonblack compact inks retain hue while luminance gets
2-floor(5*((x-xmin)*dy+(y-ymin)*dx)/(2*dx*dy)), clamped0..7. Bounds are
calculated from the original opaque source pairs per frame; dx/dy have a
minimum of1. Expansion replicates shaded source pixels. The light stays
in screen coordinates as the source robot head animation turns.

The effect runs before sprite priority/collision composition. It does not
modify source RAM, occupancy, collisions or texture upload grammar. RAW8,
HIRES and sparse sprites retain their existing behaviour. No guest storage
is added. The new flag fills existing host structure alignment padding.

Header78 is a boolean requiring mixed formats and light-directions support;
79..127 remain zero. Old snapshots restore78=0 and retain the historical
profile10 fallback. Old readers reject the new nonzero reserved flag.

## Streamed scenery (header79, scene nodes with flag2)

The extension adds no register or addressable RAM. A scene node in the
existing FD9D/E linked list is24 bytes: nextLE16; x,y,w,h in8px cells;
background streamLE16; material tile streamLE16; stone hue1..15; flag2;
source font-bank baseLE16; character baseLE16; attribute baseLE16;
selector tableLE16; source font-control pointerLE16; fallback hue1..15;
reserved0. The control is a VIC-compatible D018 shadow (character index
bits3..1), with its multicolour enable at control-2 bit4. The source bank
and planes are supplied by software; no game addresses are in the circuit.

Selector table: count<=16, then records font-index,first-glyph,last-glyph,
material-kind. Kind0 draws the background behind transparent font pixels;
kind1 draws the luminance tile, staggered on alternate tile rows; kind2
adds an upper-left bevel to opaque nonblack character pixels and puts the
background behind transparent ones; kind3 uses the background over the
whole selected character. Software supplies original glyph selections.

Both image streams are explicit guest-owned linked segments: nextLE16,
payload length8,payload bytes. Each image starts widthLE16,heightLE16,
limited320x200; then bands repeat8,token-count8,tokens. A token has a3-bit
luminance and a5-bit run length minus1. Runs exactly cover the image width;
bands exactly cover its height. Scenery stretches to the node rectangle;
the material tile repeats. Only transient host scanlines are decoded;
there is no persistent image pool or second guest copy. Segments are
bounded to64 per traversal and node lists to32; malformed reads fail safely.

Foreground character masking, room colours and the scene rectangle remain
software inputs. Sprites are composited afterwards. Nodes with flag2 are
ignored when scene support is off. Header79 is a boolean requiring mixed
formats and character lighting;80..127 remain zero. Old snapshots restore
79=0. Older readers reject the new nonzero reserved header flag.


### Scenery version3 vertical interiors and grooves

Header79 version3 adds material4, a vertical ramp with eight luminances
7 through0 across the software node rectangle, and material5, the same
ramp with a two-pixel dark groove and one-pixel lit lip at each selected
character's left edge. Hue follows the source foreground, with the node
fallback for black. Node byte23 bit0 skips unmatched characters, retaining
the earlier rendering. Other bits are reserved. Nodes and selectors remain
in the same guest RAM; there is no new pool or register. Version2 belonged
to a withdrawn prototype and is rejected to avoid ambiguous materials.


### Scenery version4 black panels and horizontal colour ramps

Material6 sets only selected characters to black. Materials7/8 ramp right/
left across the software rectangle, but only pixels whose hue matches node
byte10 or22. Other hues retain the previous rendering. Used with override-
only nodes, this changes a selected material without touching other scene
pixels. No new guest memory pool or register. Header79 accepts0,1,3,4;
older readers reject4. Existing material meanings remain unchanged.


### Scenery version5 character-width colour ramps

Materials9/10 use all eight luminances across one character width, directed
right/left. Hue filtering remains byte10/22, as for materials7/8. This lets
software shade narrow posts without scaling the ramp across a larger scene
rectangle. Header79 adds5, preserving0/1/3/4 and rejecting the withdrawn2.
No extra register, guest byte, or memory pool is required by the renderer.


### Scenery version6 raised UI rectangles

Linked node flag3 uses12 bytes: nextLE16, bounding x/y/w/h in cells,
layout-stream pointerLE16, grid count<=32, bevel width1..8 pixels,
two hue numbers packed in nibbles. Layout uses the existing bounded linked
segment reader; each record is x/y/w/h in cells, packed column/row counts, and packed X/Y steps. Counts are1..8, steps0..15, at most64 instances total. The two node hues select the native surfaces to shade.
Only matching nonblack native pixels are shaded. Top/left bevels are lit,
bottom/right bevels dark, with eight luminances across the face and rim.
Glyphs/icons, geometry, RAM and collision state are not rewritten. Older
readers reject header79=6. No extra RAM pool or register is introduced.


### Scenery version7 native icon protection

UI grid height bit7 protects pixels of the first node hue within that grid.
The height is bits6..0. Protected pixels are restored from the incoming
native TED scanline, before any UI frame layers, retaining their original
luminance and glyph detail. Other pixels keep the existing raised profile.
Only a transient host scanline is used; no guest byte or pool is added.
Header79 adds7; earlier supported versions retain their original behaviour.


### Scenery version8 symmetric corridor materials

Material5 follows the transparent edge of its supplied font row: trailing
clear bits mirror the groove and its lit lip. Material11 shades two wings
away from a central gap; node byte23 bits1..6 specify gap width in cells,
bit0 retains override-only semantics, bit7 remains reserved. The node
rectangle, material hues and font selections are software parameters.
Older materials keep their behaviour; header79 adds8 for fail-closed reads.
No extra guest storage or register is introduced.


### Scenery version9 world-anchored masonry and flat trim

Scene byte23 bit7 selects a row-counter pointer in bytes12..13. Its
containing 16KiB bank supplies the aligned font-bank base. When enabled, material1
samples both the tile row and its stagger in world Y (screen Y + 8 * counter).
The source counter, selected by software, therefore moves the wall texture
and freezes it when the counter stops. Other material layers remain fixed.
Material12 uses the same hue filter and central-gap parameters as11, but
renders one uniform midtone (luminance3, hue byte10). Header79 adds9.
One row-counter byte uses existing game padding. No additional RAM pool,
tile copy, register or CPU drawing loop is added.

For scenery version9, lighting register FD9F bits1 or2 request presentation
blanking of the 320x200 viewport after all background and sprite layers.
Collision accumulation remains active. Software holds this bit throughout
room construction and the original wipe, then marks completion with bit2. The next IRQ gate selects the completed
scene and replaces bit2 with the normal enable bit0.
The gate preserves blanking until the explicit completion hook. No image
copy, guest buffer, delay loop or change to the original room logic is used.


### Scenery version10 source-attached panels and local bevels

Material13 shades opaque source pixels with eight luminances within the
character row; clear pixels stay black. Byte22 optionally selects the hue
(zero selects the source ink hue); byte23 bits1..6 optionally exclude a
central gap in cells. Material14 preserves opaque native
pixels with a black transparent background. Materials15/16 locate the
contiguous vertical run of selected panel materials in source characters
and attributes. Byte10 is the attribute mask and byte22 the excluded value
(rendered black); byte23 bits1..6 supply the full panel height in cells.
This keeps illumination attached to moving, clipped panels. Material16
also retains the mirrored black groove and illuminated lip. These material
IDs and selectors are generic; no game glyph or CPU address is embedded
in the renderer. Header79 adds10, preserving version9 semantics.
No extra guest RAM pool, image copy or game drawing loop is introduced.

Materials17/18/20/21 are source-attached counterparts of the rectangular
and character-width horizontal ramps. Material19 supplies the two-wing
ramp. They derive coverage and the two shaded hues directly from supplied
multicolour font pixels (code1 uses byte22, code2 uses byte10), rather than
from a potentially older native framebuffer colour. This makes the same
material work with every shaft palette and avoids mixed update colours.

Material22 uses the same source mask, hue and central-gap fields as13,
with eight luminances increasing away from the gap toward the outer
edges of the supplied rectangle. This gives mirrored depth lighting for
floors leading from a central shaft to room entrances.

Material23 requires a dedicated single-selector node. It fills clear source
mask pixels from the shared bitmap at logical row byte22*8 + source row
within the character, stretched using the node height. Opaque pixels use
luminance7; byte10 supplies the surface hue. This preserves an approved
bitmap floor profile while attaching it to scrolling character geometry.
It reuses the existing scanline buffer and introduces no guest storage.

### Scenery version11 progressive presentation window

FD9F bit3 enables post-sprite window nodes (flag4). A12-byte node supplies
next16, x/y/w/h in character cells, top-source16, bottom-source16, native
TED colour and flag4. The two source bytes provide pixel Y bounds for a
central mask. Bounds outside the node rectangle are clipped; inverted or
empty bounds mask nothing. Collisions continue independently of visibility.
The game drives this generic mask from its original reveal bounds, so the
completed scene appears progressively instead of being enabled all at once.
The window descriptor and helpers reuse existing padding and retired
furniture-only helper bytes; no additional guest RAM pool is introduced.
For entry completion the game clears bit3 directly to the ordinary enable
bit, avoiding an additional full-black frame. Exit retains its separate
ready-blank flag until the following gate selects the corridor scene.

### Scenery version12 regular baseboard surface

Material24 retains the material23 floor profile except in the first three
source scanlines. In those scanlines it uses eight regular luminance steps
away from the central gap (byte23 bits1..6), with hue byte10. The central
cab area and the white walking surface keep the approved profile. The game
also links the presentation window to both scene lists and drives the same
original bounds during closing and reopening on entry and exit.

### Scenery format13: indexed colour materials and conditional owners

The existing81920 guest bytes remain the complete device memory. No new
CPU registers. Snapshot header79=13; readers through12 reject13. Older
versions0..12 remain accepted by this reader.

Flag5 is a12-byte indexed tint: nextLE16,x/y/w/h in character cells,
first-tableLE16,second-tableLE16,style,5. Tables contain compact colours0..120;
255 preserves a native pixel. Bit7 limits inputs to native hues0..7.
Normally two8-entry tables index native hue; bit6 instead selects two16-entry
tables by native luminance<5/>=5. Low three style bits select diagonal shade
depth0..7; bit5 selects frontal radial shading. A table colour with bit7 set
retains native luminance relative to white7 and caps shading at two steps,
useful for legible silver details and displays. Black native pixels remain
black. Tint runs before streamed scene materials and sprite composition.

Flag7 extends flag5 to20 bytes: bytes12/13 condition pointer,14 mask,
15/16 accepted masked values,17/18 second pointer,19 exact second value.
It draws only when both conditions hold. No addresses or colours are built
into the renderer.

Scenery revision19 additionally assigns style bit3 (`$08`) to an opt-in
elliptical footprint for flag5/7. The node size and tables do not change.
Earlier restored scenery profiles through18 ignore this bit and retain
their rectangular footprint. See the current ellipse section below.

Flag6 is a12-byte conditional link: fallbackLE16,targetLE16,conditionPtrLE16,
value,mask,ownerFlags,reserved0,reserved0,6. A matching condition chooses
target. ownerFlags bit0 replaces the preceding scene/light/window chain
with that target; this prevents stale game layers from touching an ending
owner. All walks are bounded to32 descriptors and checked RAM addresses.

### Scenery format14 protected native UI

Flag8 is a24-byte protected scene descriptor, sharing flag2's image streams,
source planes and selector. Its aligned font-low byte12 instead packs the
required source bank in bits0..2 and the final native-text glyph in bits3..7;
byte13 retains the aligned font base high byte. Byte22 packs native-text ink
in its high nibble and the existing fallback hue in its low nibble. Byte23
is an additional native UI glyph (for the solid horizontal border, included
only next to native text rows). Native UI protection
is active only when the source font first byte is nonzero.

A matching native text cell bypasses both furniture lighting and background
replacement; its original foreground and solid native background survive.
The source control pointer also names the standard logical view: control-3
is sprite enable. Wrong-bank or sprite-disabled owners suppress scene and
furniture effects, restoring original terminal/defeat backgrounds. An active
conditional ending owner takes precedence. The original transition window
mask remains independent of this UI protection. No CPU register, game
instruction or guest allocation is added. Snapshot byte79=14; older readers
reject14, while this reader retains versions0..13.

### Format15 collision only packed masks and transition protection

Packed MCM source tag63=F9 selects a collision-only mask. The inverse-cache
key retains the tag. All63 mask bytes, expansion, coordinates and collision
occupancy remain unchanged; the mask emits no pixels or visible priority.
Visible priority uses a separate transient host occupancy array. This adds
no guest RAM, device register, guest bitmap or guest instruction. Immediate
collision latching and the separate deferred scanline collision summaries
retain the full mask. Deferred callers using collision-only records must
use the separate scanline summary API: visual alpha contains visible sprites.

The host enables this interpretation in profile15 and restores the ordinary
reserved-tag interpretation for older snapshots. Snapshot byte79=15;
readers without profile15 reject it. Formats0..14 remain supported.

During a guest-selected flag4 window (FD9F bit3), flag8 native-UI suppression
and text-cell bypasses are suspended. Enhanced scenery stays visible behind
the original opening/closing mask even when source sprites are disabled.
Outside that window, the protected SEARCHING/terminal/defeat behavior remains.

The game marks its existing expanded collision stencil with F9. A linked
flag6 conditional and flag5 black palette cover only the bottom80 pixels
until the native HUD's first glyph is ready. These40 descriptor/palette bytes
reuse unused room-font slots; no6502 instruction or allocation is added.
The existing ending owner bypasses normal scene effects.

### Format16 hidden occluding masks

Packed MCM tagFA retains the original mask's sprite display priority while
emitting no image pixels. A lower-priority sprite covered by this mask is
hidden, revealing the scene already rendered underneath. Collision occupancy
is unchanged. TagF9 keeps the non-occluding behavior from profile15; FA stays
an ordinary reserved tag in profiles0..15. The host restores this distinction
from snapshot byte79. Invisible priority is a transient host bit alongside
visible occupancy; no guest RAM or source bitmap is added.

### Format17 framed masonry material

Scene material25 reuses material1's existing stone stream and staggering.
Byte23 bits1..6 select a centered gap in character cells. For valid gaps of
at least16 pixels, its interior is black, with two8-pixel vertical trim ramps
at the edges; byte22 supplies the trim hue, byte10 the masonry hue. Other
pixels use the existing tile. Scrolling retains flag2's counter semantics.

The lower-background scene descriptor and selector occupy29 bytes in an
explicit room-font lease, linked after the ending owner and computer tint.
Its bank1-only, matching-only material yields to the original bank3 HUD.
The shared stone stream, shaft and shaded rails continue through the lower
80 pixels until the apparatus covers them, as in the C64 arrangement.
The background adds no6502 instructions, allocations or image streams.
Snapshot byte79=17; older readers reject17 and this reader keeps0..16.

Reserve all original dynamic platform glyphs49..51, not just glyphs found
in static room initializers. In particular,4C..51 are the moving platforms'
half-step images and must retain their original font bytes. The game builder
checks every font lease against the original0DB4..0DBC platform glyph table.

Initial-pose publication uses36 bytes in3 instruction-aligned pieces in
other reserved font spans (5750,5738,5768), with2 inter-piece JMPs. Its
original LEFT flag is unchanged; the existing orientation adapter copies it
to the3 pose tags before initial C9B0 publication. A/X/Y/P/SP and ZP18/19
are preserved. The original warm font lease restores all3 pieces after the
ending's temporary ENDWAVE lease. There is no per-gameplay-frame CPU call.

## Authored composite dense materials (snapshot header82)

This opt-in format keeps the 70-byte record, original two-bit bitmap, three
source inks, displayed sprite slots and existing 64+16 KiB backing. All bindings,
column directories and recipes are software-authored bytes in that backing.
There is no game, character, body-part or address recognition in the renderer.

Mode `$41=1` retains its exact old tag/ink/marker semantics. With capability82>=1,
mode `$41=2` or `$82` instead selects an authored material record:

| Record offset | Meaning in mode2/82 |
|---|---|
| `$00` | Binding pointer low byte |
| `$01..$3F` | Original inverse bitmap, unchanged |
| `$40` | Existing dense head height, unchanged |
| `$41` | 2, or `$82` to mirror recipe coordinates |
| `$42..$44` | Original source inks for pairs3/2/1, unchanged |
| `$45` | `$80 | (binding_pointer >> 8)`; top two bits must be`10` |

The pointer is a full14-bit offset. The binding must fit8 bytes without wrapping:

| Binding offset | Meaning |
|---|---|
|0..1|Recipe pointer LE16, within the same16 KiB view|
|2..3|Column-directory pointer LE16|
|4|Number of columns,1..3|
|5|This record's source X origin in physical pixels, a multiple of24|
|6|This record's source Y origin, a multiple of21|
|7|Composite source height,1..63|

The directory contains one LE16 dense column-head address for each column, in
actual left-to-right source order. Each column has `ceil(height/21)` consecutive
70-byte parts. Column heads may be unaligned or noncontiguous. Every referenced
part must have valid mode/marker metadata. The selected directory cell plus
`originY/21 * 70` must equal the current record address; this prevents a binding
from silently sampling an unrelated cell. Directories contain addresses, not
further directories, and cannot recurse. The binding's origin and displayed rows
must lie within the composite dimensions.

Legacy recipe byte0 is `$80 | count`, with count0..63 and top bits`10`.
Material version4 also accepts `$C0 | count` to opt into rectangular centre
light; versions0..3 reject that header. Both encodings are followed by
count four-byte, little-endian rectangles:

| Bits | Meaning |
|---|---|
|0..5|Inclusive x0 in two-pixel MCM units|
|6..11|Inclusive y0 in source pixels|
|12..17|Inclusive x1 in two-pixel MCM units|
|18..23|Inclusive y1 in source pixels|
|24..25|Source-pair selector:0=any nonzero pair,1..3=that pair|
|26..28|Material profile0..5 in version1,0..6 in version2,0..7 in versions3/4|
|29..31|Component0..7|

Material version1 requires rectangles to fit the actual composite source dimensions.
Versions2..4 accept the fixed recipe schema0..71 in X and0..62 in Y, then intersects
selection and row-span sampling with the binding's actual source domain. Thus one
72-pixel recipe can shade a48-pixel source without allocating or reading a third
column. Coordinates outside the72x63 schema, reversed bounds and reserved profiles
still reject the displayed chain. The last matching rectangle wins. Unmatched pixels retain their original source ink. Profile0 does too unless the version4 rectangular header explicitly selects its new computation. Pair0 stays
transparent; no rectangle may add occupancy. Values above120 keep their ordinary
non-visible ink behaviour. Profiles1..3,6 and7 retain opaque black as black, so dark
outlines require an explicit profile4/5 region before they can be recoloured.

For frontal spans, component0 means that individual rectangle. Components1..7
join winning rectangles with the same pair selector and profile into one row
span, even across column/21-row boundaries. Its extrema are the first and last
matching opaque source pixels in that composite row. Holes and retained dark
details do not create new span centres. Different component values keep adjacent
shapes independent. This is authored grouping, not inferred anatomy.

| Profile | Colour computation |
|---|---|
|0|Original ink; opt-in rectangular centre light with version4 `$C0` recipe header|
|1|Keep hue; luminance0..6 follows distance from original opaque black pixels|
|2|Keep hue; soft frontal luminance5..7|
|3|Keep hue; pale frontal luminance6..7|
|4|Neutral dark frontal curve with gain16/5, luminance0..3|
|5|Neutral dark frontal curve with gain72/25, luminance0..2|
|6|Version2 soft edge-distance profile, hue retained, luminance1..4|
|7|Version3 inline compact-colour selection, with soft edge-distance luminance relative to the selected base|

Profile1 uses the nearest squared source-space distance to an opaque original
black pixel. Thresholds2,4,5,8,9,10 select the successive luminances; distance at
least10 saturates at6. Only a radius3 source neighbourhood is necessary. Sampling
uses all authored composite columns, original masks and original inks, never a
previously shaded image. Profile6 uses exactly the same distance level0..6, then
sets `level=1+(level+1)/2` with integer division. It therefore reduces contrast
without changing the strong profile1. Opaque black remains black. Version1
continues to reject profile6; no previously valid version1 recipe changes.

Version3 adds profile7 without changing any previously valid profile0..6
recipe. If at least one rectangle uses profile7, a compact-colour table follows
immediately after the `count * 4` rectangle bytes. Its length is one plus the
largest component value used by a profile7 rectangle, therefore1..8 bytes.
Every entry through that index must be in0..120, including any unused lower
indices, except the explicitly flagged version4 literal entries described below. The complete table must fit the same16 KiB backing without wrapping.
There is no table when profile7 is absent; trailing bytes after an old recipe
remain unrelated data. Versions1/2 reject profile7 before reading any table.

For profile7 only, component0..7 selects this table entry; it does not join
row-span groups. The source-pair filter and last-matching-rectangle precedence
are unchanged. Original opaque black is preserved before the base colour is
selected, so profile7 cannot recolour source-black outlines. A table value0
turns a selected nonblack opaque source pixel black without changing occupancy.
For a nonzero base, its hue is `1+(base-1)%15` and its luminance is
`baseL=(base-1)//15`. Let `soft=1+(strong+1)//2`, where strong is the profile1
source-black distance level0..6. The result has the selected hue and luminance
`clamp(baseL+soft-3,0,7)`. Thus a base at luminance3 uses the soft1..4 ramp;
other bases shift that same bounded ramp. All121 compact base colours are
supported. The renderer has no hardcoded hue or game/material identity.

For profiles2/3, let width be the row span, and edge the distance to its nearer
extremum. Profile2 uses depth1 at widths3/4 and depth2 for larger spans; widths1/2
stay at luminance7. Profile3 keeps widths1..4 at7 and otherwise uses depth1.
Other pixels use `7-depth+ceil(2*depth*edge/(width-1))`, clamped at7.

For profiles4/5, let lo/hi be the span extrema and let
`t=abs(2*x-lo-hi)/(width+1)`. Luminance is `floor(gain*(1-t*t))`; the output uses
neutral hue1. A recipe can select the lower-gain profile on authored rows without
putting source-specific row numbers in the renderer. All calculations use
bounded integer arithmetic.

Mode`$82` reflects recipe lookup X across the complete composite width. It does
not flip source bitmap bytes: software already owns their orientation. Distances
are computed in actual source space; the symmetric frontal curves use reflected
recipe/group coordinates. Expansion, clipping, display priority and collision
processing remain after this colour calculation.

Mode2/82 bypasses the old whole-record tag, radial and diagonal material
selectors. Mode1 is unchanged even when capability82 is enabled. Bad binding,
directory, recipe, rectangle, part metadata or complete-chain bounds reject the
entire displayed chain, including malformed offscreen parts. No pointer wraps.

`Plus64MixedSprites` enables the latest material version4 with the other opt-in
formats while output is disabled. Snapshot header82 is a version0..4 requiring
dense capability80, mixed formats and packed cache when nonzero. Version0 disables
the format; version1 restores the original strict source-size validation; version2
restores schema validation plus source-domain clipping and soft profile6; version3
adds profile7 and its optional inline compact-colour table; version4 additionally accepts the `$C0` recipe header for rectangular centre light. Bytes83..127 remain
reserved zero. The fixed
payload remains144776 bytes. Old snapshots with82=0 explicitly leave mode2/82
invalid. Readers predating this capability reject the nonzero reserved byte. Readers
supporting only version1 reject82=2/3, and version2 readers reject82=3. New readers retain the exact version1
validation when loading an old version1 snapshot; they do not silently upgrade
its rendering. Version2 snapshots likewise retain exact version2 validation and
rendering. Version3 snapshots retain exact version3 validation and rendering; version3 readers reject version4. A fresh configuration enables version4. Register data and authored
backing bytes already belong to the existing serialized payload.


## Rectangular centre light in version 4

Version 4 accepts the additional recipe header `$C0 | count`. Its low six bits
still encode 0..63 rectangles; the rectangles and optional profile-7 table are
unchanged. Readers with material versions 0..3 reject this header. The legacy
`$80 | count` header keeps every previous meaning even in version 4.

Only with the `$C0` header, profile 0 and component 1..7 select a rectangular
centre-to-edge luminance ramp. Component 0 retains the original ink. Component
1 selects luminance 0..7, component 2 selects 1..7, through component 7 selecting
6..7. Hue comes from the original source ink; opaque black stays black and inks
above 120 retain their previous non-visible behaviour. No source occupancy is
added. Later matching rectangles may protect or shade foreground details.

After decoding bounds to physical pixels, let
`rx=max((x1-x0)//2,1)`, `ry=max((y1-y0)//2,1)`,
`ex=min(x-x0,x1-x)` and `ey=min(y-y0,y1-y)`. With `minimum=component-1`, use
`min(7, minimum+(7-minimum)*min(ex*ry,ey*rx)//(rx*ry))`.
All division is integer division. The rectangle supplies both axes of the
falloff; source holes, black details and row spans do not move its centre.
Degenerate one-row or two-pixel-wide rectangles are defined without division
by zero. Reflected mode uses the existing reflected recipe coordinates.

### Literal inline colours in version 4

Only a `$C0 | count` recipe with material capability 4 may store profile-7 table
bytes 128..248. Bit 7 selects a literal compact colour: `colour=byte & 127`.
This returns that colour without edge-distance attenuation. Values 0..120 keep
the existing relative-shading computation. Values 121..127 and 249..255 reject
the entire displayed chain. A legacy `$80` recipe, including in version 4,
continues to reject every table entry above 120; versions 0..3 gain no new
palette interpretation. Table bounds and maximum index remain unchanged.

Source opaque black is retained before selecting either relative or literal
colour; literal 128 can turn a selected nonblack pixel black while keeping its
occupancy. Source transparent or non-visible pixels are not made visible.
Last-matching-rectangle precedence is unchanged. These bytes are software-owned
material data in the existing shared 16 KiB, without a new cache or game ID.

## Scenery revision19: opt-in elliptical indexed tints

Scenery capability19, stored at PLUS64 HOST snapshot header byte79, adds
style bit3 (`$08`, SDK `P64_TINT_ELLIPSE`) to existing flag5/7 indexed tints.
`P64_SCENERY_ELLIPSE_VERSION=19` and
`P64_SNAPSHOT_SCENERY_CAP_OFFSET=79` name that capability in the SDK.

Flag5 remains12 bytes and flag7 remains20. The x/y/w/h rectangle still uses
8-pixel character cells and must fit320x200; its pixel bounds define the
ellipse. Let u,v be the integer local pixel coordinates and w,h its pixel
width and height. A pixel centre belongs to the ellipse exactly when:

```text
dx = 2*u + 1 - w
dy = 2*v + 1 - h
dx*dx*h*h + dy*dy*w*w <= w*w*h*h
```

The implementation uses64-bit integer products. Outside points preserve
the current pixel. Inside points follow the unchanged native-black guard,
palette selection, preserve255, depth0..7, frontal bit5 and relative-colour
rules. Flag7's two conditions still gate the operation. Bit3 changes only
the footprint, not the lighting equation, palette or node ordering. It is
not FD9F bit3, which retains its post-sprite-window meaning.

With capability19 and style bit3 clear, tints remain rectangular. Restoring
a supported scenery profile through18 ignores style bit3 and reproduces
the historical rectangle even if the saved descriptor contains that bit.
Readers supporting at most18 reject19 before restoring. This feature adds
no RAM/registers/slots or snapshot bytes: protocol05, module1.0, payload
144776 bytes and the81920-byte guest budget remain unchanged. Dense
capabilities80/81/82 remain independently versioned; current materials82=4
are not upgraded or downgraded by this scene revision.

The matched runtime is required; retaining and reading descriptor/register
bytes is not a guest capability probe. The ellipse test uses only guest
geometry and tables, with no recognition of clouds or game assets. The
ordinary native-UI protection, source glyphs, sprite alpha and collisions
retain their existing rules. See the development addenda
[Italian](reference/addenda/ADDENDUM_ELLIPSE_TINT_IT.md) and
[English](reference/addenda/ADDENDUM_ELLIPSE_TINT_EN.md).

## Scenery revision20: keyed vertical palette ramps

Capability20 at HOST snapshot byte79 enables16-byte node9. SDK names are
`P64_NODE_PALETTE_RAMP=9`, `P64_SCENERY_PALETTE_RAMP_VERSION=20` and
`P64_RAMP_HOLD_BOTTOM=1`. Node9 keeps the common nextLE16 and x/y/w/h
character-cell bounds, but its remaining fields differ from tint5/7:

|Offset|Meaning|
|---|---|
|0..1|NextLE16;0 terminates|
|2..5|x,y,w,h in8-pixel cells|
|6..7|Palette pointerLE16 in mainRAM|
|8|Palette count1..32|
|9|Native TED key0..127|
|10|Native TED key mask0..127|
|11|Node type9|
|12|Start Y in local pixels|
|13|Nonzero span in local pixels|
|14|Bit0 holds final colour after span; other bits0|
|15|Reserved0|

The entire16-byte node and palette must fit mainRAM. Palette pointer0 is
valid, and pointer+count may equal65536. Geometry must be nonempty and fit
320x200; start+span must fit the pixel height of the rectangle. Invalid
key/mask values, count, geometry, reserved flags or byte15 skip the node.
Byte10 is a mask, not the style byte used by tint5/7; ellipse and lighting
style flags must not be applied to that field.

Let local=y-y0. Before start, preserve the current pixels. For
start<=local<start+span, choose index=floor((local-start)*count/span).
After that half-open interval, bit0 at byte14 chooses index=count-1;
without it the node preserves the current pixels. The selected palette
entry is compact0..120:0 paints black,255 preserves the row;121..254 also
preserve that selected row rather than changing other entries' behaviour.

For each in-bounds pixel, replace only when
`(current_pixel & mask) == (key & mask)`. Native black has no special guard:
it can be selected deliberately. This is distinct from tint5/7. The key is
a native TED code, while palette entries are compact colours. Key86/mask127
matches native sky$56 exactly and excludes local blue$36 and black. A zero
mask selects every current pixel in the rectangle. Filtering uses the
current line, so earlier linked nodes can affect matching. Existing
conditional owners, native-UI protection and layer ordering still apply.
Node9 runs before streamed scenery and sprites and does not modify RAM,
sprite alpha or collisions.

Supported profiles through19 ignore node9 and continue with its next link.
The20 reader keeps all older meanings, including ellipses introduced in19
and their ignored shape bit under profiles through18. Readers through19
reject snapshot20 before restoring it. No registers, payload bytes, image
pools or sprite slots are added. RAM protocol05, PLUS64 module1.0,
144776-byte payload, dense capabilities80/81/82 and81920 guest bytes remain
unchanged. Use the matching new executable; descriptor/register readback
is not a capability query.

A16-colour,72-pixel ramp has alternating5/4-pixel bands. The documented
Usagi sky example begins at globalY16 and ends before88, then holds its
last colour through111; node bounds preserve headerY0..15. Approved cloud
ellipses run earlier and no longer match the source sky key. Actual colour
visibility still depends on matching source pixels and occlusion. Full
layout, sample palette and assembly are in the
[Italian](reference/addenda/ADDENDUM_PALETTE_RAMP_IT.md) and
[English](reference/addenda/ADDENDUM_PALETTE_RAMP_EN.md) addenda.

## Scenery revision21: glyph-anchored foreground material

Capability21 at HOST snapshot byte79 enables **16-byte node10**. SDK names
are `P64_NODE_ANCHORED_FOREGROUND=10` and
`P64_SCENERY_ANCHORED_FOREGROUND_VERSION=21`. The node is explicit opt-in;
profiles through20 ignore it. It is eligible only on valid, active native
multicolour-text rows. It uses actual matrix characters and source bits,
including the native fine-scroll origin, without game-specific recognition.

|Offset|Meaning|
|---|---|
|0..1|NextLE16;0 terminates|
|2|Left anchor character code|
|3|Right anchor character code; must differ from byte2|
|4|Anchor matrix row0..24|
|5|Distance between anchor columns1..39|
|6..7|Rectangle stream pointerLE16 in mainRAM|
|8|Rectangle count1..16|
|9|Horizontal shading depth0..7, not greater than base luminance|
|10|Base compact colour1..120|
|11|Node type10|
|12|Included top canvasY|
|13|Excluded bottom canvasY; top<bottom<=200|
|14|Native source TED hue key1..15|
|15|Flags0|

The rectangle stream retains the existing `[nextLE16,lengthU8,payload]`
segments, with at most64 traversed segments. Each **six-byte** rectangle
is `[relativeXLE16, absoluteYU8, widthU8, heightU8, reserved0]`.
Width/height must be nonzero; X+width must fit the owner width
`(anchor distance+1)*8`; Y+height must fit200. The entire node and every
record are validated before it changes any pixel or mask. Invalid nodes
are ignored without applying partial rectangles.

The first left marker in the selected matrix row determines the left
origin. If absent, the first right marker minus the declared distance is
the fallback, allowing an owner partly outside the left edge. A simultaneous
marker pair is not required. Native source-origin minus overlay-origin adds
the actual fine-scroll offset; software owns marker uniqueness.

Tinting covers the owner width and `[top,bottom)` independently of the
rectangle union. Only pixels whose native hue equals byte14 are tinted.
For compact base colour C, `baseL=(C-1)/15`, `hue=1+(C-1)%15` and
`shade=min(depth,floor(localX*(depth+1)/ownerWidth))`; the native result is
`((baseL-shade)<<4)|hue`. The nonzero hue key excludes native black.

Rectangles select presentation foreground by intersecting their union with
the original native source foreground. MCM pairs00/01 remain background;
pairs10/11 remain foreground, including opaque black. The pass runs after
lighting/scenery and before sprites, retaining selected scanline colours.
Those colours are restored after sprite composition and before windows,
presentation blanking and border clipping. This works for **all sprite
formats**, including ordinary, RAW8 and dense, without changing `$FD95`,
actor priority among themselves, sprite alpha, or collision inputs/timing.

Saved colours/masks are transient host scanline data, not extra addressable
guest RAM, bitmap storage or a new sprite slot. Guest nodes, chunks, glyphs
and installers must fit the existing81920-byte budget. PLUS64 module1.0,
144776-byte payload, offsets and CRC remain unchanged; byte79 can contain21.
Older readers reject21 before applying the snapshot. New readers preserve
the recorded meaning of supported profiles through20. Complete examples
and integration rules are in the
[Italian](reference/addenda/ADDENDUM_ANCHORED_FOREGROUND_IT.md) and
[English](reference/addenda/ADDENDUM_ANCHORED_FOREGROUND_EN.md) addenda.
