# Camera P64B allineata alla sorgente TED — capacità 23

Questo addendum integra il manuale tecnico R8. Il nodo materiale di tipo 11
rimane di **24 byte in MAIN**, il programma P64B conserva l'ABI 5 e il
contenitore P64Z resta invariato. La memoria guest rimane **64+16 KiB**.

Nel nodo 11, il **bit 0 del byte 21** è ora
`CAMERA_SOURCE_ORIGIN`. In C il nome è
`P64B_NATIVE_CAMERA_SOURCE_ORIGIN`; nell'include SDK è
`P64_MATERIAL_CAMERA_SOURCE_ORIGIN`. I byte 22 e 23 devono restare zero.
Il bit è disponibile dalla capacità scenario
`P64B_NATIVE_CAMERA_CAPABILITY = 23`, esposta nell'SDK come
`P64_SCENERY_CAMERA_VERSION`.

Con il byte 21 a zero rimane valida la semantica precedente: la parola
unsigned a 16 bit indicata dai byte 12–13 rappresenta la coordinata X del
pixel logico zero, all'origine dell'overlay `gx`.

Con il nuovo bit attivo, la stessa parola indica la coordinata X del primo
pixel della **sorgente TED effettiva**, prima dello spostamento fine. Per una
matrice a caratteri il programma può quindi pubblicare la posizione
grossolana in pixel. L'adattatore usa la fase fine realmente visualizzata
dalla riga TED:

```text
camera_effettiva = camera_word - (row.source_origin - gx)
world_x = camera_effettiva + native_output_x - gx
```

La sottrazione usa aritmetica con segno. Una camera effettiva negativa è
valida: con parola zero e scorrimento fine 7 si ottiene −7, ma il clipping
inizia dall'origine sorgente e il primo pixel disponibile continua a
corrispondere a X=0 del mondo. Bordi chiusi, intervalli dello scorrimento
fine, righe oscurate e filtro delle modalità mantengono il comportamento
precedente.

Il programma deve ancora pubblicare la posizione grossolana corretta per
la matrice scelta. Il nuovo bit non ricava tale posizione dal contatore del
gioco e non sostituisce il protocollo di pubblicazione di un doppio buffer.
Il byte 19 e la maschera del byte 20 continuano a controllare il filtro delle
modalità; sono indipendenti dal nuovo byte 21.

Il runtime corrente pubblicizza la capacità scenario 23. La capacità 22
rifiuta un byte 21 non zero; i bit sconosciuti e i byte riservati non zero
sono rifiutati prima di modificare i pixel. I nodi precedenti con byte 21–23
a zero mantengono la semantica originaria.

Il modulo snapshot PLUS64 resta alla versione 1.0, con dimensioni, offset e
CRC invariati. Il byte 79 può ora contenere 23. I lettori aggiornati
ripristinano anche una capacità 22 registrata in precedenza; i lettori più
vecchi rifiutano 23 prima di applicare lo stato.

Questo bit non aggiunge RAM guest, registri, cache di immagini o nuove
allocazioni del lavoro P64B. Sorgenti completi e ricevute della versione
consegnata sono nell'archivio `SORGENTI`; le prove della R8 precedente sono
conservate come storico e non qualificano il nuovo eseguibile.
