# P64B camera aligned to the TED source — capability 23

This addendum extends the R8 developer manual. A type 11 material node still
occupies **24 bytes in MAIN**, P64B retains operator ABI 5, and the P64Z
container is unchanged. Guest memory remains **64+16 KiB**.

**Bit 0 of node byte 21** is now `CAMERA_SOURCE_ORIGIN`. Its C name is
`P64B_NATIVE_CAMERA_SOURCE_ORIGIN`; the SDK include names it
`P64_MATERIAL_CAMERA_SOURCE_ORIGIN`. Bytes 22 and 23 must remain zero.
The flag requires scenery capability
`P64B_NATIVE_CAMERA_CAPABILITY = 23`, named
`P64_SCENERY_CAMERA_VERSION` in the SDK.

When byte 21 is zero, the previous interpretation is retained: the unsigned
16-bit word addressed by bytes 12–13 gives the world X coordinate of logical
pixel zero at the overlay origin `gx`.

With the new flag enabled, that word instead gives the world X coordinate
at the **actual TED source origin**, before fine-scroll displacement. For a
character matrix, software may therefore publish the coarse position in
pixels. The adapter uses the fine phase actually displayed by each TED row:

```text
effective_camera = camera_word - (row.source_origin - gx)
world_x = effective_camera + native_output_x - gx
```

Subtraction uses signed arithmetic. A negative effective camera is valid:
word zero with fine phase 7 produces −7, but clipping begins at the source
origin, so the first available source pixel still addresses world X=0.
Closed borders, fine-scroll gaps, blank rows and mode filtering retain their
previous behavior.

Software must still publish the correct coarse position for the selected
matrix. This flag does not infer that position from a game's counters and
does not replace double-buffer publication. Node byte 19 and the byte 20
mode mask continue to control mode filtering independently of byte 21.

The current runtime advertises scenery capability 23. Capability 22 rejects
a nonzero byte 21; unknown camera bits and nonzero reserved bytes are
rejected before changing pixels. Previous nodes with bytes 21–23 all zero
retain their original coordinate meaning.

The PLUS64 snapshot module remains version 1.0 with unchanged size, offsets
and CRC layout. Byte 79 may now contain 23. Updated readers also restore a
previously recorded capability 22; earlier readers reject 23 before applying
state.

The flag adds no guest RAM, registers, image cache or new P64B frame-work
allocation. Complete corresponding source and current receipts are supplied
under `SORGENTI`; previous R8 evidence is retained as history and does not
qualify the updated executable.
