from __future__ import annotations
import re
def editorial_prose(text):
 """Copy-edit prose only; preserve fenced and inline code byte-for-byte."""
 fixes=[('Il discoUsagi','Il disco Usagi'),('TheUsagi','The Usagi'),('20file','20 file'),('20ordinary','20 ordinary'),
 ('I17pacchetti','I 17 pacchetti'),('The17','The 17'),('All17','All 17'),('7376bytes','7376 bytes'),('7376byte','7376 byte'),
 ('gli8825byte','gli 8825 byte'),('the8825bytes','the 8825 bytes'),('in032','in build 032'),('byteD798','byte D798'),
 ('libdeflate1.26','libdeflate 1.26'),('capitolo9','capitolo 9'),('chapter9','chapter 9'),('Chapter9','Chapter 9'),
 ('23 novembre2026','23 novembre 2026'),('23 November2026','23 November 2026'),('grafica178','grafica 178'),('Artwork178','Artwork 178'),
 ('resta1.0','resta 1.0'),('module1.0','module 1.0'),('scenery22','scenery 22'),('materiali8','materiali 8'),('materials8','materials 8'),
 ('FixtureC','Fixture C'),('stubCPU','stub CPU'),('Cfixtures','C fixtures'),('CPUstubs','CPU stubs'),
 ('è22','è 22'),('e1.','e 1.'),('è24 byte','è 24 byte'),('in(160','in (160'),('indici$6F','indici $6F'),('e$06','e $06'),
 ('è0..511','è 0..511'),('I63 byte','I 63 byte'),('esatto:1','esatto: 1'),('I14 bit','I 14 bit'),('Ygrezza','Y grezza'),
 ('in−50','in −50'),('e8/9','e 8/9'),('e2/3','e 2/3'),('è921','è 921'),('e500fotogrammi','e 500 fotogrammi'),
 ('è320×200','è 320×200'),('è16','è 16'),('e25 righe','e 25 righe'),('source16,48','source16, 48'),('è4.096','è 4.096'),
 ('in$2000','in $2000'),('below$8000','below $8000'),('at(160','at (160'),('Indices$6F','Indices $6F'),('and$06','and $06'),
 ('colours$76','colours $76'),('byte$241','byte $241'),('the$245marker','the $245 marker'),('FD90=0before','FD90=0 before'),
 ('121highlight','121 highlight'),('bank 2view','bank 2 view'),('entry$1100','entry $1100'),('end$1398','end $1398')]
 output=[];fenced=False
 for line in text.splitlines(keepends=True):
  if line.lstrip().startswith('```'):fenced=not fenced;output.append(line);continue
  if fenced:output.append(line);continue
  pieces=re.split(r'(`[^`]*`)',line)
  for i in range(0,len(pieces),2):
   for old,new in fixes:pieces[i]=pieces[i].replace(old,new)
  output.append(''.join(pieces))
 return ''.join(output)
