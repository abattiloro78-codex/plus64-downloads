# 2. Memoria, spazio CPU e porte I/O

Per scrivere un gioco occorre scegliere un profilo di memoria e mantenerlo
su entrambi gli ospiti. Il contratto corrente offre **64 KiB cartuccia e
16 KiB interni, 81.920 byte complessivi**. Le due viste disponibili non
espongono 80 KiB lineari alla CPU e non aggiungono un pool sprite.

Questo capitolo conserva il contratto RAM80 e le API memoria. Le identità finali sono nel capitolo 9; gli inventari della vecchia edizione sono conservati sotto `reference/history`, mentre `API_INDEX.json` e `SOURCE_INVENTORY.json` identificano le copie di sorgente di questa edizione.

## 2.1 I due profili disponibili

| Profilo | RAM del programma CPU/TED | Porta `$FDE8..$FDED` | Vista porta sprite e modem |
|---|---|---|---|
| `-plus64`, nativo | 16 KiB interni, imposti anche su Plus/4 | Quattro banchi cartuccia da 16 KiB | Sprite: banco cartuccia 2. Modem: banco 3, offset `$3E00..$3FFF` |
| `-plus64mainram` | 64 KiB cartuccia come RAM principale | Alias degli stessi 64 KiB | Sprite: 16 KiB interni. Modem: offset interni `$0000..$01FF` |

Nel primo profilo un programma come PRISM mantiene codice e bitmap sotto
`$4000` e trasferisce le risorse dalla cartuccia mediante la porta dati.
Cambiare banco SRAM non sposta codice CPU, stack, video TED o ROM. Scrivere
nel banco 2 modifica anche la vista letta dal circuito sprite: occorre
riservare esplicitamente gli intervalli usati.

Nel secondo profilo, usato da Impossible Mission, il setter
`plus64_set_main_ram()` seleziona `RamSize=64` e collega i quattro banchi
alla stessa `mem_ram` usata dal decoder CPU. I 16 KiB interni restano
separati e sono accessibili tramite la porta sprite `$FD96..$FD98`.
Disattivando MainRAM si torna al profilo CPU da 16 KiB. Il cambio ruota
in posto i cinque blocchi da 16 KiB, senza un buffer nascosto aggiuntivo;
preserva i contenuti cartuccia e interni. È rifiutato se ci sono sprite
abilitati, modem connesso/in chiamata, code RX/TX o comando parziale. [MEM-2]

**L'alias non è un'altra memoria da 64 KiB.** Con MainRAM una scrittura
alla porta che seleziona banco 0 e offset `$2345` cambia la stessa cella
`mem_ram[$2345]` usata dal decoder CPU. La porta accede anche alla RAM
sottostante ROM e I/O, perché usa direttamente il backing; non invia
comandi ai registri I/O presenti a quegli indirizzi CPU. [MEM-1, MEM-2]

Il modello è un contratto software corrente, non la dimostrazione di un
decoder elettrico della cartuccia. Le strutture del compositore host e le
copie temporanee di convalida snapshot non sono RAM accessibile al gioco.

## 2.2 C16 e Plus/4: un solo contratto software

Nel C16 con `RamSize=16`, il normale decoder RAM usa `indirizzo & $3FFF`:
quando non intervengono ROM o I/O, `$2000`, `$6000`, `$A000` e `$E000` sono
alias della stessa cella. Anche le basi RAM del TED vengono ricondotte ai
primi 16 KiB. Scrivere oltre `$3FFF` non crea memoria libera. [MEM-3]

Con plus/64 abilitato, il profilo nativo impone `RamSize=16` anche sul
Plus/4. Non basta scegliere il modello Plus/4 per ottenere altri 48 KiB.
I due ospiti verificano lo stesso contratto, non varianti del gioco con
capacità o regole diverse. Le espansioni RAM incompatibili sono rifiutate.

Con `-plus64mainram` entrambi usano la cartuccia da 64 KiB come RAM
principale. I 16 KiB interni distinti sono la vista della porta sprite,
non una seconda finestra lineare né un registro di banking inventato.
Configurare il modello e il profilo prima di avviare il programma e
controllare il protocollo `$05` prima di usare il contratto condiviso.

## 2.3 API SRAM: `$FDE8..$FDED`

La porta è registrata soltanto quando plus/64 è abilitato. Non ha specchi
aggiuntivi dichiarati. I sei indirizzi sono quelli della tabella seguente.
`R` indica lettura CPU, `W` scrittura CPU. [MEM-1, MEM-2]

| Indirizzo | Accesso | Significato |
|---|---|---|
| `$FDE8` | R/W | Byte basso dell'offset nel banco |
| `$FDE9` | R/W | Byte alto dell'offset; in scrittura valgono soltanto i bit 0–5; in lettura i bit 6–7 sono zero |
| `$FDEA` | R/W | Dato all'indice corrente; **ogni lettura CPU e ogni scrittura incrementa l'offset** |
| `$FDEB` | R/W | Banco 0–3; in scrittura `valore & 3`; cambiarlo conserva l'offset |
| `$FDEC` | R | Firma costante `$64`; le scritture non fanno nulla |
| `$FDED` | R | Versione protocollo costante `$05`; le scritture non fanno nulla |

La versione `$05` identifica il contratto condiviso 64+16 KiB; non è un
registro che riveli o cambi MainRAM. Il profilo resta un accordo fra runtime
e programma. La firma va verificata come coppia `$64,$05`.

Il calcolo esatto è:

```text
indice = (banco << 14) | (offset & $3FFF)
dopo DATA: offset = (offset + 1) & $3FFF
```

Dopo `$3FFF` si torna a `$0000` **nello stesso banco**. Non si passa al
banco successivo. Una copia di 64 KiB deve quindi selezionare esplicitamente
i quattro banchi. Scrivere il byte basso o alto dell'offset preserva l'altro
byte; selezionare un banco non azzera il puntatore.

Il callback interno `p64_memory_peek()` legge senza incrementare. Questo
**non** significa che `PEEK(65002)` in BASIC sia innocuo: BASIC esegue una
lettura CPU di `$FDEA`, e quindi incrementa. Il peek senza effetti collaterali
è quello del dispositivo usato dal debugger, quando il debugger lo richiede.

### Un esempio: 256 byte alla fine del banco 2

Esempio per il profilo nativo a porta SRAM, su una banca riservata dal gioco.
Scrive i valori 0–255 a offset `$3F00..$3FFF`; al termine il puntatore è
`$0000`, banco 2. Il blocco `PHP/SEI/PLP` evita che una routine IRQ che usa
la stessa porta cambi banco o puntatore durante il trasferimento.

```asm
        php
        sei
        lda #2
        sta $fdeb
        lda #0
        sta $fde8
        lda #$3f
        sta $fde9
        ldy #0
copia:  tya
        sta $fdea
        iny
        bne copia
        plp
        rts
```

Il codice non salva il puntatore precedente: la routine chiamante deve
definire se la porta è esclusiva oppure salvare e ripristinare banco e offset.
Non usare istruzioni read-modify-write come `INC $FDEA`: comportano accessi
ulteriori a una porta con autoincremento. Nel profilo `mainram` scegliere
anche un intervallo che non contenga codice o dati vivi, perché la porta è
un alias della memoria principale.

### Reset e conservazione

- L'inizializzazione `p64_memory_powerup()` azzera la struttura, inclusa la
  vista cartuccia e i registri di porta, preservando la RAM interna nativa.
  Viene chiamata quando si abilita plus/64 da disabilitato.
- Il reset del dispositivo esegue `p64_memory_reset_registers()`: banco e
  offset tornano a zero; il contenuto SRAM e il binding `mainram` restano.
- Il reset generale della macchina può comunque eseguire codice ROM che
  modifica la RAM nativa. La conservazione dei dati SRAM non garantisce
  quella dell'intero stato di un gioco. [MEM-1, MEM-2]

## 2.4 ROM, I/O e aree realmente utilizzabili

La CPU ha uno spazio di indirizzamento da 64 KiB anche quando il programma
dispone di viste bancate della memoria. Il numero di byte installati non elimina le
sovrapposizioni. Nel profilo nativo standard: [MEM-3, MEM-4]

| Area | Uso da considerare |
|---|---|
| `$0000/$0001` | Porta del processore ospite; non è il selettore ROM/I/O del C64 |
| `$0002..$00FF` | Zero page, condivisa con KERNAL/BASIC se si chiamano le ROM |
| `$0100..$01FF` | Stack CPU; non usarlo come buffer permanente |
| `$0200..$7FFF` | RAM nelle condizioni ordinarie, entro i limiti/alias del profilo |
| `$8000..$BFFF` | BASIC o ROM bassa selezionata quando ROM attive; RAM sottostante in lettura quando disattivate |
| `$C000..$FFFF` | KERNAL o ROM alta selezionata, con eccezioni I/O; RAM sottostante quando ROM disattivate |
| `$FD00..$FDFF`, `$FE00..$FEFF` | Decodifica I/O in entrambe le configurazioni ROM/RAM; include le porte plus/64 |
| `$FF00..$FF1F` | Registri TED, non RAM ordinaria |
| `$FF3E`, `$FF3F` | Strobe di selezione ROM/RAM; il valore scritto è irrilevante |

Una scrittura a `$FF3E` abilita la lettura delle ROM; una scrittura a
`$FF3F` seleziona la RAM sottostante. I registri I/O non spariscono.
`$FF20..$FFFF`, tranne i due strobe, seguono la configurazione prevista
dal decoder; ciò comprende i vettori CPU finali. Non nascondere il KERNAL e
poi eseguire una sua `JSR` o lasciare attivo un IRQ senza vettori e handler
validi in RAM. I normali store sotto le finestre ROM scrivono la RAM
sottostante; le aree I/O rimangono eccezioni. [MEM-3, MEM-4]

I fetch del TED hanno basi e selezioni proprie. La porta SRAM indipendente
non è una sorgente di fetch TED: prima di mostrare bitmap o caratteri
occorre copiarli nella RAM nativa prevista dalla modalità video. Il fatto
che il circuito sprite sovrapponga immagini al video non cambia questa regola.

## 2.5 Backing condivisi e buffer del compositore

Il codice mantiene esattamente due backing di payload:

| Backing/vista | Dimensione | Proprietà |
|---|---:|---|
| `mem_ram` | 65.536 byte | RAM CPU/TED interna da 16 KiB più tre banchi cartuccia nel profilo nativo; quattro banchi cartuccia nel profilo MainRAM |
| `p64_aux_ram` | 16.384 byte | Quarto banco cartuccia nel profilo nativo; RAM interna distinta nel profilo MainRAM |
| Vista sprite | 16.384 byte, già compresi sopra | Banco cartuccia 2 oppure RAM interna, secondo il profilo |
| Payload modem | 512 byte, già compresi sopra | RX128, TX128, comando256; offset secondo la tabella 2.1 |
| Overlay, alpha e riepiloghi raster | Buffer host | Nessun indirizzo guest e nessuna capacità RAM aggiuntiva per il gioco |

La somma dei backing è **81.920 byte**, non 96 KiB. Le due viste successive
non si sommano di nuovo. Anche i dati SID/audio residenti del programma
occupano questi stessi byte. Le dimensioni di eseguibili, dischi e snapshot
sono misure di file del PC, non della RAM disponibile al programma. [MEM-1, MEM-2, MEM-5]

Il reset del modem azzera indici e stato ma conserva i byte condivisi.
Quando il modem è usato il software deve riservare il suo payload. Impossible
Mission lo presta alle voci soltanto a modem inattivo; usare contemporaneamente
modem e quell'audio corromperebbe la proprietà dei dati.

Gli snapshot RAM80 salvano entrambi i backing: `PLUS4MEM` contiene i 64 KiB,
`PLUS64` i 16 KiB insieme ai registri e al video latched. Il contenitore VSF
è 2.1 con plus/64 attivo, il modulo PLUS64 è 1.0 e il formato scenery corrente
è 22: sono numeri distinti. Le dimensioni serializzate includono stato
periferiche e buffer host e non aumentano il budget guest. I vecchi snapshot
privi di stato RAM80 completo vengono rifiutati; collegamenti modem attivi
non sono ripristinabili e il salvataggio è rifiutato mentre connessi/in chiamata.

## 2.6 IRQ e timer: l'ospite rimane TED

plus/64 non aggiunge una CIA del C64. Non vi sono nuovi registri CIA a
`$DCxx/$DDxx`, né un NMI modem o SID. Per programmare interrupt utilizzare
le risorse native TED: [MEM-4, MEM-6]

| Registri | Funzione |
|---|---|
| `$FF00/$FF01` | Timer 1, byte basso/alto |
| `$FF02/$FF03` | Timer 2, byte basso/alto |
| `$FF04/$FF05` | Timer 3, byte basso/alto |
| `$FF09` | Flag IRQ: raster bit 1, timer 1 bit 3, timer 2 bit 4, timer 3 bit 6; bit 7 riassume l'IRQ abilitato attivo |
| `$FF0A` | Maschera IRQ nei medesimi bit; bit 0 contiene il bit alto della linea raster programmata |
| `$FF0B` | Byte basso della linea raster programmata |

Scrivere il byte basso di un timer lo ferma; scrivere quello alto lo avvia.
Il timer 1 si ricarica dal valore impostato; dopo il primo underflow i timer
2 e 3 proseguono con periodo 65.536. Il valore iniziale zero rappresenta
65.536. Il modello conta un tick ogni due clock base TED: PAL
`1.773.447 / 2 = 886.723,5 Hz`, non un generico ciclo istruzione 6502.
Le letture basso/alto separate non sono un latch atomico: se serve un
campione coerente, controllare il rollover, per esempio alto/basso/alto.

I flag TED si riconoscono scrivendo i bit da cancellare in `$FF09`; non
copiano la semantica dei flag CIA. Un IRQ TED resta mascherabile con `SEI`:
non sostituisce un NMI C64 che interrompeva anche con `I=1`. Driver audio o
loader C64 dipendenti da CIA/NMI richiedono un raccordo analizzato, non una
sostituzione indiscriminata di indirizzi.

## Riferimenti del capitolo

Gli inventari devono riferirsi alla stessa revisione dei sorgenti; i vecchi
numeri di riga dell'edizione 1.0 non sono riferimenti della versione corrente.

- **MEM-1:** `src/plus4/plus64_memory.c` e `.h`: `bind_views`, `p64_memory_bind_main_ram`, `p64_memory_read/write`, costanti dei backing.
- **MEM-2:** `src/plus4/plus64vice.c`: `plus64_set_enabled`, `plus64_set_main_ram`, `plus64vice_ram_size_allowed`, API snapshot.
- **MEM-3:** `src/plus4/plus4mem.c`: decoder RAM, profili nativo/MainRAM, blocco delle espansioni incompatibili.
- **MEM-4:** `src/plus4/ted-mem.c` e `plus4mem.c`: selezioni ROM/RAM e I/O.
- **MEM-5:** `src/plus4/plus64_sprite.h`, `plus64_modem.h` e relativo `.c`: viste condivise e payload modem.
- **MEM-6:** `src/plus4/ted-timer.c`, `ted-irq.c`, `ted-mem.c`: timer, IRQ e funzioni `ted09_store`, `ted0a_store`, `ted0b_store`.
