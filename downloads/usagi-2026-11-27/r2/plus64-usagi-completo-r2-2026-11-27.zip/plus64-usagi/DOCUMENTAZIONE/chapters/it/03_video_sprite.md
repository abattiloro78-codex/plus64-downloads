# 3. Video TED e sprite plus/64

Questo capitolo specifica il video dell'implementazione plus/64 mantenuta: contratto RAM80, protocollo memoria `$05`, revisione22 degli scenari e successiva funzionalità MCM densa al byte80 dell’intestazione snapshot. Le regole TED, i descrittori di base e gli esempi validi del manuale 1.0 sono conservati; i vecchi pool indipendenti e i registri allora riservati sono aggiornati. Il capitolo non specifica una futura implementazione elettrica della cartuccia. L'eseguibile e gli hash delle fonti della consegna sono identificati dal suo manifest corrente.

Le citazioni indicano file delle fonti mantenute, ricostruibili offline nella directory `reference/vice/src/plus4` del pacchetto. I numeri di riga della vecchia edizione sono rimossi: controllare le funzioni nominate o i rami corrispondenti nel file corrente. Per gli estesi, il capitolo8 contiene anche il riferimento dettagliato dei formati; il codice mantenuto decide le combinazioni supportate. Nessuna delle strutture HOST del renderer aggiunge RAM indirizzabile al programma6502.

## Profilo da scegliere per un nuovo gioco

Per iniziare, usare il formato normale con RAM nativa limitata a16KiB, SRAM della cartuccia tramite la sua porta e sprite raw8bpp nella vista condivisa. Le opzioni relative al video possono essere:

```text
xplus4.exe -default -model c16 -ramsize 16 -plus64 -plus64rastercollisions
```

`-default` ripristina le risorse iniziali; nel modello qui descritto `Plus64MainRAM`, `Plus64PackedCache`, `Plus64LeftMCM`, `Plus64MixedSprites` e `Plus64RasterCollisions` partono da0. L'ultima opzione abilita esplicitamente pubblicazione e collisioni per linea, mantenendo il formato raw. Le opzioni complete di disco, SID e input sono descritte negli altri capitoli. Non attivare `packedcache` o `leftmcm` soltanto perché il gioco usa più colori. (`plus64vice.c`)

Il percorso packed è un'estensione software per cache compatte, materiali e riuso di particolari cache C64. Non è necessario per un gioco nuovo e non è il formato originale0.94. Il suo funzionamento è documentato più avanti affinché i porting possano riprodurlo, senza attribuirlo a un dispositivo fisico già realizzato. (`plus64_sprite.h`; `plus64vice.c`)

## Configurare lo sfondo TED

Lo sfondo è configurato tramite i registri TED nativi, indipendenti da `$FD90..$FDCF`. Questa tabella riporta i campi applicati dal runtime; gli indirizzi di memoria risultanti rimangono soggetti al profilo RAM del capitolo 2.

| Registro | Campi utili per configurare il video |
| --- | --- |
| `$FF06` | Bit0–2: scroll verticale0..7; bit3:0=24righe,1=25righe; bit4: display enable; bit5:0=testo,1=bitmap; bit6: extended color mode. Bitmap multicolore: bit5=1, bit6=0 e `$FF07` bit4=1. |
| `$FF07` | Bit0–2: scroll orizzontale0..7; **bit3**:0=38colonne,1=40colonne; bit4: multicolore. Nel testo normale il bit7 seleziona0=128glifi con reverse tramite bit7 del codice carattere,1=256glifi senza tale reverse automatico. Non è un bit di inversione globale dello sfondo. |
| `$FF12` | Bit3–5: base bitmap `($FF12 AND $38) << 10`, quindi passi di$2000. **Bit3 non abilita il bitmap:** seleziona il primo bit della sua base. Bit2:0=fetch bitmap/glifi da RAM,1=percorso ROM; nel secondo caso una base inferiore a$8000 usa il percorso open-space del runtime. Bit0–1: parte alta della frequenza della voce0 TED; preservarli quando si cambia solo il video. Bit6–7 vengono letti come1 e non selezionano la base. |
| `$FF13` | Base glifi `($FF13 AND maschera) << 8`: maschera `$FC` normalmente, `$F8` se `$FF06` bit6 o `$FF07` bit7 è attivo. Bit1:0=CPU fast mode consentito,1=modo lento; non è un bit dell'indirizzo glifi. Bit0 non è modificabile scrivendo `$FF13`: riflette la selezione ROM/RAM aggiornata dagli strobe `$FF3E/$FF3F` e partecipa ai fetch di matrice e attributi. Non cambia il selettore bitmap/glifi di `$FF12` bit2. |
| `$FF14` | Base attributi `A = ($FF14 AND $F8) << 8`, allineata a$0800; seconda matrice a `A+$0400`. Nel bitmap dell'SDK sono rispettivamente luminanza e crominanza. I bit0–2 non spostano queste basi. |
| `$FF15` | Colore globale di sfondo; nel bitmap multicolore è il valore della coppia `00`. |
| `$FF16` | Primo colore globale aggiuntivo; nel bitmap multicolore è il valore della coppia `11`. |
| `$FF17/$FF18` | Secondo/terzo colore globale aggiuntivo: usati dai modi testo pertinenti, non dalle coppie del bitmap multicolore. In extended text `$FF15..$FF18` sono i quattro sfondi selezionati dai due bit alti del codice carattere. |
| `$FF19` | Colore del bordo. Come per `$FF15..$FF18`, bit0–3=tinta, bit4–6=luminanza; il bit7 scritto viene ignorato e in lettura vale 1. Tinta0 produce nero, quindi i128codici non rappresentano128colori distinti. |
| `$FF1C/$FF1D` | Contatore della linea corrente: `(($FF1C AND 1) << 8) OR $FF1D`; in `$FF1C` gli altri bit si leggono a1. Non sono la coppia di confronto IRQ `$FF0A/$FF0B`. Il runtime permette anche di scriverli e riposizionare il contatore: nel normale polling usare solo letture. |

I bit della modalità derivano da `ted.c`; scroll, display e finestra da `ted-mem.c`; reverse del testo da `ted-draw.c`. Per CSEL conta il ramo effettivo `value & $08`, non il commento storico che lo chiama bit4 a riga405. Basi e sorgenti: `ted.c`; scritture/letture condivise di `$FF12`: `ted-mem.c`, `ted-sound.c`. Selezione ROM e attributi: `ted-mem.c`. Colori e coppie: `ted-mem.c`, `ted-draw.c`; raster: `ted-mem.c`.

### Inizializzazione esatta dell'esempio SDK

La demo viene caricata normalmente dal KERNAL e poi usa queste scritture, in questo ordine (`demo.asm`):

```asm
        lda #$3b
        sta $ff06
        lda #$18
        sta $ff07
        lda $ff12
        and #$c3
        ora #$08
        sta $ff12
        lda #$18
        sta $ff14
        lda #0
        sta $ff15
        sta $ff16
        sta $ff19
```

Il risultato è bitmap multicolore,25righe,40colonne, scroll verticale3 e orizzontale0; base bitmap$2000, luminanza$1800, crominanza$1C00, sfondi globali e bordo neri. `$FF12` non riceve una costante universale: l'operazione preserva i due bit audio, azzera il selettore ROM e imposta i bit di base a$08; i bit6–7 riletti a1 vengono ignorati dal setter video. La demo non scrive `$FF13`, `$FF17` o `$FF18`: la base glifi non serve al suo bitmap e quei due colori aggiuntivi non vi sono usati. Non assumere che questa sequenza ripristini ogni stato TED di un programma precedente.

L'SDK inizializza1024byte per ciascuna matrice con le tabelle della palette, poi riempie8000byte di bitmap con `$55`, mostrando la coppia `01` in ogni campione; il colore viene quindi dagli attributi della cella (`demo.asm`; `ted-draw.c`). Il loop attende `$FF1D=240`, valore univoco nel frame PAL da312linee, senza scrivere il contatore (`demo.asm`). Per sincronizzazioni generiche sotto256 usare anche `$FF1C`, come spiegato nella sezione coordinate.

## Che cosa viene sovrapposto al TED

Il TED continua a produrre il proprio sfondo. Il runtime applica i pixel sprite alla fine dell'emulazione di ciascuna linea TED, nell'area logica320×200. I pixel trasparenti lasciano intatto il contenuto TED; un pixel sprite opaco sostituisce il colore di quel punto. Questo percorso non fornisce un framebuffer RGB né una priorità «dietro allo sfondo». (`ted.c`; `plus64_overlay.c`; `plus64_sprite.c`)

Gli otto slot condividono una **vista di16384byte della RAM esistente**, `sprite.ram`, accessibile dalla CPU tramite `$FD96`. In profilo nativo CPU/TED usano i16KiB interni e questa vista è un alias del banco2 della cartuccia; l'accesso SRAM a quel banco vede gli stessi byte. In `mainram`, CPU/TED usano i64KiB della cartuccia e la porta sprite vede i16KiB interni. Il totale resta64+16KiB: nessun pool sprite privato aggiuntivo. In profilo nativo non si possono usare altri48KiB del Plus/4. Il TED non legge la porta sprite come una propria finestra video: il programma deve rispettare la mappa del capitolo2. (`plus64_memory.c`, `bind_views`, `p64_memory_sprite_ram`; `plus64_sprite.h`)

La struttura `overlay`, la maschera `alpha` e il riepilogo collisioni per200linee sono buffer HOST dell'emulatore, non nuove aree indirizzabili dal programma6502. Non assegnare loro indirizzi della cartuccia. (`plus64vice.c`)

### Palette dei pixel sprite

Gli indici validi sono0..120. Per convertire un indice sprite `i` nel codice colore TED:

```text
i = 0:       TED = $00
1 <= i <=120:
    luminanza = (i - 1) div 15
    tinta     = (i - 1) mod 15 + 1
    TED       = luminanza * 16 + tinta
```

Sono120 combinazioni tinta/luminanza non nere più un nero. Non sono121 valori RGB scelti dal programma. La conversione del runtime è quella sopra; resa RGB, filtro e monitor dipendono dal percorso video. (`plus64_overlay.c`)

Nel formato raw8bpp,0 è **nero opaco**, non trasparenza. `$FF` è la sentinella trasparente consigliata; il codice attuale scarta in realtà tutti i valori121..255. Il nero opaco copre il TED e partecipa alle collisioni, mentre un pixel scartato non occupa la posizione. La maschera alpha permette di distinguerli. (`plus64_sprite.h`; `plus64_sprite.c`; `plus64_overlay.c`)

La disponibilità della palette sprite non elimina i limiti dei modi grafici nativi del TED: lo sfondo è ancora il segnale che il TED ha già renderizzato. Non esiste in questa API un registro «121colori per ogni cella dello sfondo». (`ted.c`; `plus64_overlay.c`)

## Mappa dei registri CPU

Il decoder sprite copre soltanto `$FD90..$FDCF`. La colonna reset descrive `plus64_reset`: i registri e il latch vengono azzerati, **non il backing RAM dei pattern**. Le opzioni HOST del formato sopravvivono come configurazione e sono risorse distinte, non registri di questa tabella. (`plus64_sprite.h`; `plus64_sprite.c`; `plus64vice.c`)

| Indirizzo | Accesso e reset | Significato effettivo |
| --- | --- | --- |
| `$FD90` | R/W,0 | Enable: bit `s` abilita lo slot `s`, per `s=0..7`. Con il profilo per linea, ogni scrittura pubblica lo stato corrente, anche se il valore non cambia. |
| `$FD91` | Lettura con azzeramento,0; scritture ignorate | Latch delle collisioni fra sprite: un bit per slot coinvolto. |
| `$FD92` | R/W,0 | Bit `s`:0=monocromatico;1=raw8bpp nel formato normale, oppure packed MCM quando `packedcache` è attivo. |
| `$FD93` | R/W,0 | Bit `s`: raddoppio orizzontale dello slot `s`. |
| `$FD94` | R/W,0 | Bit `s`: raddoppio verticale dello slot `s`. |
| `$FD95` | R/W,0 | Solo slot MCM densi abilitati: il bit s richiede priorità dietro al foreground nativo. Riservato per i formati precedenti/non densi e con funzionalità80=0. |
| `$FD96` | Porta dati R/W; puntatore iniziale0 | Legge o scrive un byte del backing condiviso e poi incrementa il puntatore `$FD98:$FD97`. Non è una normale cella di registro. |
| `$FD97` | R/W,0 | Byte basso del puntatore della porta dati. |
| `$FD98` | R/W,0 | Byte alto del puntatore della porta dati. Non è un selettore dei banchi SRAM esterni. |
| `$FD99..$FD9C` | R/W,0 | Con formati estesi: due selettori luce a4bit per byte, slot pari nel nibble basso; valori0..10 descritti sotto. |
| `$FD9D/$FD9E` | R/W,0 | Puntatore little-endian alla lista di livelli/materiali nella RAM principale esistente, per il profilo `mainram` esteso. |
| `$FD9F` | R/W,0 | Bit0: livelli attivi; bit1 o bit2: mascheramento nero di presentazione; bit3: finestra post-sprite dei nodi flag4. Bit4: ritaglio opzionale dei bordi nativi con revisione18; i profili precedenti lo ignorano. |
| `$FDA0..$FDCF` | R/W,0 | Otto descrittori da sei byte, elencati sotto. |

Riferimenti della tabella: accesso e auto-incremento `plus64_sprite.c`; enable, formato ed espansioni `plus64_sprite.c`; pubblicazione `$FD90` `plus64vice.c`. I commenti storici che chiamano `$FD92` «reserved» non descrivono il ramo effettivamente eseguito a `plus64_sprite.c`.

L'auto-incremento usa un contatore a16bit e aggiorna entrambi i registri. L'accesso fisico al pool usa `puntatore AND $3FFF`, quindi `$4000`, `$8000` e `$C000` sono alias di `$0000`, non altri banchi. Mantenere il puntatore nell'intervallo0..$3FFF evita di dipendere da tali alias. Un incremento da$FFFF riporta i due byte a0. (`plus64_sprite.c`)

**Regola SDK:** scrivere0 nei campi inutilizzati e non usare i registri riservati come RAM di lavoro. Il loro readback attuale non assegna loro una funzione pubblica aggiuntiva. (`plus64_sprite.c`)

### Gli otto descrittori

Per lo slot `s`, il primo indirizzo è `$FDA0 + 6*s`. I campi sono indipendenti: non si tratta della disposizione dei registri VIC-II. (`plus64_sprite.c`)

| Slot | X basso | Y | X alto | Colore | Pattern basso | Pattern alto |
| --- | --- | --- | --- | --- | --- | --- |
| 0 | `$FDA0` | `$FDA1` | `$FDA2` | `$FDA3` | `$FDA4` | `$FDA5` |
| 1 | `$FDA6` | `$FDA7` | `$FDA8` | `$FDA9` | `$FDAA` | `$FDAB` |
| 2 | `$FDAC` | `$FDAD` | `$FDAE` | `$FDAF` | `$FDB0` | `$FDB1` |
| 3 | `$FDB2` | `$FDB3` | `$FDB4` | `$FDB5` | `$FDB6` | `$FDB7` |
| 4 | `$FDB8` | `$FDB9` | `$FDBA` | `$FDBB` | `$FDBC` | `$FDBD` |
| 5 | `$FDBE` | `$FDBF` | `$FDC0` | `$FDC1` | `$FDC2` | `$FDC3` |
| 6 | `$FDC4` | `$FDC5` | `$FDC6` | `$FDC7` | `$FDC8` | `$FDC9` |
| 7 | `$FDCA` | `$FDCB` | `$FDCC` | `$FDCD` | `$FDCE` | `$FDCF` |

| Campo | Interpretazione |
| --- | --- |
| X basso, X alto | `X = basso + 256*(alto AND 1)`. I bit7..1 di X alto sono memorizzati ma ignorati dal renderer. |
| Y | Coordinata a8bit, normalmente senza segno:0..255. Le eccezioni signed sono esclusivamente quelle del profilo avanzato descritto sotto. |
| Colore | Nel modo monocromatico di base viene usato `colore AND $7F`; con materiali estesi il bit7 ha la funzione descritta sotto. In raw8bpp/MCM il colore ordinario viene dai pixel o dalle chiavi della cache. |
| Pattern | Nel formato base, indirizzo **in byte** nel backing condiviso: `(alto*256+basso) AND $3FFF`. Non è un numero di sprite da moltiplicare per64 o512. |

Il readback restituisce i byte scritti, anche quando alcuni bit sono ignorati nel disegno. Nel monocromatico usare solo indici colore0..120: i valori mascherati121..127 vengono convertiti in nero opaco dalla funzione palette, non in trasparenza. (`plus64_sprite.c`; `plus64_overlay.c`)

## Formati normali dei pattern

Con `packedcache=0` e `leftmcm=0` esistono questi due formati, selezionabili separatamente per ogni slot tramite `$FD92`. (`plus64_sprite.c`)

| `$FD92` bit dello slot | Dimensione visuale | Dati necessari | Interpretazione |
| --- | --- | --- | --- |
| 0 | 24×21 | 63byte | Tre byte per riga, bit7 a sinistra; bit uguale a0=trasparente, uguale a1=colore del descrittore. Nessun header. |
| 1 | 24×21 | 504byte | Un indice palette per pixel,24byte per riga,21righe. Nessun header e nessun requisito di allineamento. |

Qui raw8bpp ha24pixel indipendenti per riga: il nome MCM del bit **non dimezza** la risoluzione. Un record da512byte è una convenzione utile, non un requisito del decoder; gli ultimi8byte non vengono letti per l'immagine. Anche il passo64 del monocromatico è soltanto una convenzione. (`plus64_sprite.c`)

Otto slot sono otto istanze, non un limite di otto immagini memorizzate: gli slot possono condividere un puntatore e il programma può cambiare puntatore per animare un oggetto. (`plus64_sprite.c`)

Il fetch normale continua circolarmente entro il backing16KiB: un'immagine posta vicino a$3FFF legge i successivi byte dall'inizio del pool. Pianificare le allocazioni per non sovrapporre accidentalmente altri pattern. I formati packed hanno invece i controlli di allineamento descritti più avanti. (`plus64_sprite.c`)

Se il backing contiene0, in raw8bpp quei byte significano nero opaco; il reset del dispositivo non garantisce di ripulire una vista condivisa. Abilitare uno sprite raw senza averne inizializzato **tutti** i504byte può quindi produrre un rettangolo nero. Per un'immagine16×16 dentro uno slot24×21, inizializzare a$FF le otto colonne a destra, le cinque righe inferiori e ogni foro trasparente. (`plus64_sprite.c`)

### Esempio in byte: tre pixel e il nero opaco

L'esempio assume formato normale, slot0, nessuna espansione e porta dati disponibile in esclusiva. È una ricetta dei dati, non un nuovo programma da compilare. Disabilitare prima l'output scrivendo `$FD90=$00`. (`plus64_sprite.c`)

1. Impostare `$FD97=$00`, `$FD98=$00`; scrivere504volte `$FF` in `$FD96`.
2. Reimpostare il puntatore a$0000; scrivere `$6F,$00` nella porta: offset0 e 1.
3. Impostare il puntatore a$0018; scrivere `$06`: è il primo pixel della seconda riga, perché il passo è24byte.
4. Scrivere `$FD92=$01`, `$FD93=$00`, `$FD94=$00`, `$FD95=$00`.
5. Scrivere i sei byte sotto e infine `$FD90=$01`.

```text
Indirizzi: FDA0 FDA1 FDA2 FDA3 FDA4 FDA5
Valori:     A0   50   00   00   00   00
```

Il risultato atteso è: blu luminoso in (160,80), nero **opaco** in(161,80), blu scuro in (160,81). Gli altri501pixel dello slot sono trasparenti e lasciano vedere il TED. Gli indici $6F=111 e $06=6 si convertono rispettivamente nei colori TED$76 e $06. (`plus64_sprite.c`; `plus64_overlay.c`)

## Coordinate, bordi e frequenza

L'origine è l'angolo superiore sinistro dell'area logica320×200: X0..319 e Y0..199. Non aggiungere automaticamente gli offset degli sprite VIC-II di un programma C64. Nel formato normale X è 0..511 e Y0..255; le porzioni oltre il bordo destro o inferiore vengono tagliate. X511 non rappresenta−1, e Y255 non rappresenta−1. (`plus64_sprite.h`; `plus64_sprite.c`)

`$FD93` e `$FD94` replicano ogni pixel rispettivamente due volte in orizzontale e verticale:24×21 diventa48×21,24×42 o48×42. Il clipping si applica al risultato espanso. Il formato raw normale non offre coordinate negative a sinistra o in alto; un gioco può tenere una posizione logica esterna e pubblicare un pattern ritagliato aX0, oppure attendere l'ingresso nell'area visibile. Non esiste un ulteriore registro di offset negativo. (`plus64_sprite.c`)

Nel profilo PAL l'emulatore usa312linee da114clock TED, con1773447clock al secondo:35568clock per fotogramma, circa49,86Hz, normalmente indicati come50Hz. Non equivalgono a35568cicli di istruzioni6502 disponibili. (`plus4.h`; `ted-timing.h`; `ted-timing.c`)

Con la geometria PAL25righe usata qui, la linea overlayY0 corrisponde al contatore TED4. `$FF1D` contiene il byte basso del contatore e `$FF1C` il bit8; `$FF1D=4` da solo non distingue4 da260. Controllare il bit0 di `$FF1C` quando si sincronizza una pubblicazione. L'offset canvas PAL59 non va sommato a una coordinata del descrittore. (`tedtypes.h`; `ted-mem.c`; `ted.c`)

Il modo24righe, lo scroll e il bordo del TED possono cambiare il contenuto o la finestra che si vede sotto l'overlay: non trasformano questi descrittori in registri VIC-II. Per un nuovo modo video verificare il riferimento geometrico del runtime prima di portare una vecchia formula di proiezione. (`tedtypes.h`; `ted.c`; `plus64_overlay.c`)

## Pubblicazione e animazione senza immagini parziali

Le scritture di descrittori, formato, espansioni e dati dei pattern aggiornano il modello, ma non costituiscono da sole una transazione di display. Nel profilo predefinito, senza `-plus64rastercollisions`, il frame hook prepara l'intero overlay una volta per fotogramma. Nel profilo per linea, **ogni scrittura a `$FD90`** ricostruisce l'overlay corrente; non serve cambiare il valore dell'enable. (`plus64vice.c`)

La sequenza consigliata è: inizializzare/uploadare i dati con output disabilitato, scrivere formato, espansioni e descrittori, quindi scrivere la maschera enable in `$FD90` **per ultima**. Dopo la pubblicazione, preparare il successivo stato prima della sua scadenza video. Le linee già disegnate non vengono retroattivamente cambiate. Scrivere0 a `$FD90` disabilita le linee successive, ma non cancella il latch collisioni. (`plus64vice.c`; `plus64_sprite.c`)

Il frame hook continua a ricampionare i registri anche nel profilo per linea. Non considerare `$FD90` una doppia banca hardware di descrittori: una preparazione incompleta che attraversa il campionamento di fine frame può essere vista dal frame hook. Pianificare upload e staging, oppure mantenere l'output disabilitato durante l'inizializzazione. (`plus64vice.c`)

Il multiplex riusa uno slot in fasce verticali diverse: pubblicare la fascia corrente, preparare i descrittori successivi mentre la fascia è renderizzata, poi pubblicarli dopo la sua ultima linea. Gli otto slot restano otto per una stessa linea; non sono diciotto sprite simultanei orizzontali. Anche con `SEI` il TED e la scansione proseguono: misurare il codice completo, includendo input, collisioni, HUD e audio, prima della scadenza della fascia. (`plus64_sprite.c`; `plus64vice.c`; `ted.c`)

Una schermata statica non basta per qualificare un multiplex. Confrontare diverse immagini del framebuffer durante movimento, spari ed esplosioni; verificare che i pixel di tutti gli oggetti vivi siano presenti. Controllare anche gli intervalli fra aggiornamenti, distinguendo uno spostamento della linea di ritorno da un fotogramma effettivamente saltato. Questa è una regola di collaudo SDK, non una nuova funzione del dispositivo.

## Collisioni: soltanto fra sprite

Un pixel opaco di uno slot sovrapposto a quello di un altro produce i bit di **entrambi** nel latch `$FD91`. In sovrapposizioni multiple si accumulano tutti i partecipanti. Fra maschere visibili normali lo slot con indice minore ha priorità visiva, ma gli altri partecipano comunque alla collisione; il colore non definisce una hitbox rettangolare. (`plus64_sprite.c`)

Esempio: `$FD91=$05` significa che gli slot0 e2 hanno partecipato a collisioni dall'ultima lettura. Non identifica il punto, la coppia esatta fra più eventi o la direzione dell'urto. Una lettura CPU restituisce il byte e azzera l'intero latch; una scrittura non lo azzera. Una sovrapposizione ancora presente può generare nuovamente gli stessi bit alle linee o ai frame successivi. (`plus64_sprite.c`; `plus64vice.c`)

Non vengono campionati i pixel o le strutture logiche del TED per calcolare il latch: niente collisioni hardware contro pavimenti, muri, bitmap, caratteri o colori dello sfondo. Il gioco deve implementarle con le proprie mappe o geometrie. La funzione FD95 per i soli record densi cambia la presentazione, senza aggiungere collisioni con lo sfondo o un interrupt sprite equivalente a quello VIC-II. (`plus64_sprite.h`; `plus64_sprite.c`; `plus64vice.c`)

| Profilo collisioni | Momento e dominio |
| --- | --- |
| Predefinito: `rastercollisions=0`, `leftmcm=0` | Confronto dell'intero overlay durante la preparazione del frame; dominio visibile X0..319, Y0..199. |
| `rastercollisions=0`, `leftmcm=1` | Stessa preparazione per frame, ma vengono considerate anche le posizioni X−24..−1; dominio X−24..319, Y0..199. |
| `rastercollisions=1`, `leftmcm=0` | La preparazione non alza il latch; ogni linea completata aggiunge il proprio riepilogo. Per le collisioni si considera anche X320..511, pur senza disegnare il bordo. |
| `rastercollisions=1`, `leftmcm=1` | Stessa temporizzazione, con dominio orizzontale−24..511; la visualizzazione resta X0..319. Y fuori0..199 non produce collisioni. |

Riferimenti: `plus64_sprite.c`; `plus64vice.c`. La risorsa per linea si può cambiare soltanto con `$FD90=0`; il cambio scarta la vecchia rappresentazione alpha, ma conserva il latch già pendente. (`plus64vice.c`)

Quando uno slot viene riutilizzato per un altro nemico, il bit continua a identificare lo **slot**, non l'identità dell'oggetto del gioco. Consumare e attribuire gli eventi nella fascia corretta oppure usare collisioni software sugli oggetti logici. Non interpretare un vecchio bit rimasto nel latch come un urto del nuovo assegnatario. (`plus64_sprite.c`; `plus64vice.c`)

## Formati packed: riferimento avanzato sperimentale

Le seguenti opzioni sono risorse HOST già implementate, non nuovi registri CPU. Non sostituire `$FD98` o i bit riservati con presunti selettori del formato. (`plus64vice.c`)

| packedcache | leftmcm | `$FD92` dello slot=0 | `$FD92` dello slot=1 |
| --- | --- | --- | --- |
| 0 | 0 | Monocromatico normale63byte | Raw8bpp normale504byte |
| 1 | 0 | Monocromatico normale63byte | Packed MCM |
| 1 | 1 | Packed HIRES | Packed MCM |
| 0 | 1 | Configurazione rifiutata dal setter | Configurazione rifiutata dal setter |

La scelta è derivata da `plus64_sprite.c`; il vincolo su `leftmcm` è in `plus64vice.c`. Attivare `packedcache` **da solo non converte** i pattern monocromatici nel formato HIRES packed.

Ogni record packed precedente occupa una posizione allineata a1024byte nel backing16KiB: basi$0000,$0400,...,$3C00, per un massimo di16record. In questo formato senza tag il puntatore completo deve coincidere col suo valore mascherato a14bit: un alias$4000 non è accettato. Il distinto formato denso descritto sotto elimina il vincolo di allineamento. Un record non valido viene saltato dal renderer, senza assegnare un nuovo registro di errore. (`plus64_sprite.c`)

| Offset dalla base | Dati consumati dal decoder |
| --- | --- |
| `$200` | Byte63 del blocco RAW64 inverso: non è un pixel né un registro. Nel formato base è ignorato dal disegno; negli estesi può selezionare materiale, orientamento sparse o maschera invisibile. |
| `$201..$23F` | I63byte di immagine originali in ordine inverso: il byte logico `i` si legge a `base+$23F-i`, per `i=0..62`. |
| `$240` | MCM: deve essere0. HIRES packed: spostamento sorgente orizzontale0..23. |
| `$241` | Tipo esatto: 1 per MCM,0 per HIRES packed. Non è una maschera di bit liberamente combinabili. |
| `$242` | Indice palette per la coppia MCM `11`. |
| `$243` | Indice palette per la coppia MCM `10`. |
| `$244` | Indice palette per la coppia MCM `01`. |
| `$245` | Marker di validità: deve essere **esattamente `$A5`**. |

Riferimenti: `plus64_sprite.h`; `plus64_sprite.c`. Gli altri byte del record non sono letti da questi rami del renderer; questo non li dichiara automaticamente liberi se il motore usa la stessa area per una cache o un backup.

Nel motore C64 riutilizzato, il byte63 ha anche una funzione di tag di orientamento del motore. L'orientamento del motore appartiene al chiamante; il bridge conserva il byte nella chiave. Il formato base non lo usa come immagine, mentre le estensioni sottostanti ne interpretano tag precisi. Non trasferire i suoi eventuali bit in `$FD95` o nel byte tipo `$241`. (`engine/reuse/native_sprite_cpu.py`; `plus64_sprite.c`)

Nel packed MCM ogni byte contiene quattro coppie di bit, dalla più significativa. La coppia0 è trasparente;1,2,3 scelgono rispettivamente `$244,$243,$242`. Ogni coppia occupa **due pixel orizzontali** del formato24×21. Anche qui un indice chiave121..255 è scartato; l'indice0 rimane nero opaco. Nel formato base il colore del descrittore non sostituisce queste tre chiavi; i materiali estesi possono invece sostituirle o ombreggiarle senza cambiare la coppia0 trasparente. (`plus64_sprite.c`)

Nel packed HIRES si usano i bit dei63byte inversi e il colore del descrittore. Il decoder legge `source_x = pixel_x + record[$240]`; oltre23 scarta il pixel. È uno spostamento logico della sorgente, senza ricircolo dei bit persi a destra. Non è un cambiamento della posizione X del descrittore. (`plus64_sprite.c`)

### Proiezioni negative del profilo leftmcm

Queste regole non si applicano al normale raw8bpp. Con `packedcache=1` e `leftmcm=1`:

- Packed MCM: Xgrezza488..511 diventa−24..−1, anche senza espansioneX.
- Packed HIRES: la stessa conversione X avviene **solo quando l'espansioneX è attiva**; HIRES non espanso non interpreta488..511 come negativi.
- Per entrambi i tipi, Y grezza215..255 diventa−41..−1. I valori206..214 non fanno parte della conversione e restano positivi.

Sono proiezioni condizionali del publisher esistente, non una modalità signed generale a9/8bit. Le coordinate positive, l'espansione e il clipping continuano ad applicarsi dopo queste conversioni. (`plus64_sprite.c`)

### Cambiare profilo senza cache incoerenti

Prima del cambio scrivere `$FD90=0`. Un cambio di `packedcache` è rifiutato con output abilitato e invalida il marker `$245` di tutti i16record, **in entrambe le direzioni**. Il solo cambio risorsa non converte i dati: ricostruire o ricaricare i pattern nel formato nuovo prima di abilitarli. (`plus64_sprite.c`; `plus64vice.c`)

`leftmcm` si abilita solo con `packedcache` già attivo e output disabilitato; non si può disabilitare `packedcache` finché `leftmcm` o `mixedsprites` sono attivi. Il cambio di `rastercollisions` richiede anch'esso output disabilitato. Per tornare al formato normale: disabilitare l'output, togliere `mixedsprites`, togliere `leftmcm`, togliere `packedcache`, caricare i pattern raw/mono, impostare i descrittori e pubblicare `$FD90` per ultimo. (`plus64vice.c`)

## Formati grafici estesi correnti

Queste funzioni si attivano esplicitamente con le risorse HOST, prima di abilitare gli sprite:

```text
-plus64packedcache -plus64leftmcm -plus64mixedsprites
```

`mixedsprites` richiede `packedcache`; `leftmcm` serve al percorso HIRES packed. Il cambio formato con output attivo viene rifiutato. L'estensione non aggiunge slot o banchi. I materiali sprite funzionano anche nel profilo nativo16KiB; i livelli che leggono la RAM principale, descritti più sotto, richiedono `mainram`. Il decoder corrente è in `plus64_sprite.c`, `draw_masked_common`, con configurazione e snapshot in `plus64vice.c`.

### MCM denso: record da 70 byte e priorità sul foreground nativo

Il decoder corrente di sviluppo accetta anche i bit 15..14 del puntatore=`10`, tag `$8000`, con il bit dello slot `$FD92` impostato e le risorse `Plus64PackedCache` e `Plus64MixedSprites` abilitate. I 14 bit bassi indirizzano un record completo da 70 byte nella vista sprite esistente da 16 KiB. Non serve allineamento; l'ultimo indirizzo iniziale valido è `$3FBA`. Nessun byte può oltrepassare il fondo della vista.

| Offset | Significato |
|---|---|
| `$00` | Tag software del byte 63 sorgente, non visualizzato |
| `$01..$3F` | Byte bitmap originali 62..0 in ordine inverso |
| `$40`, `$41` | Altezza della testa 0=21 o 1..252 con funzionalità81; altrimenti shift 0. Modalità1 |
| `$42`, `$43`, `$44` | Inchiostri per le coppie sorgenti 3,2,1 rispettivamente |
| `$45` | Marcatore valido `$A5` |

Si elimina il bias `$200` del record precedente. La coppia 0 resta trasparente e l'inchiostro 0 resta nero opaco. Si riusano materiali, sfumatura diagonale, espansioni, clipping e collisioni fra sprite. Caricare tutto il record tramite `$FD96`, impostare il puntatore del descrittore a `$8000 | offset`, impostare il bit FD92 dello slot e pubblicare `$FD90` per ultimo. Gli altri tag e i formati non packed conservano il loro significato.

Per uno slot denso così abilitato, il suo bit `$FD95` richiede il passaggio dietro al foreground TED. Testo standard/ECM e bitmap hires usano i bit sorgenti impostati; celle di testo multicolore e bitmap multicolore considerano foreground le coppie `10/11`, background `00/01`. Le celle hires nel testo multicolore usano i singoli bit. Il testo standard rispetta caratteri inversi, lampeggio e cursore. Non si confrontano i colori: anche un foreground nero occlude. Lo sprite visibile con priorità più alta continua a prevalere; se nascosto, rivela il TED, non uno sprite successivo. Cambia la presentazione, non la copertura delle collisioni; non si aggiungono byte ospite, banchi o slot.

La classificazione corrente è qualificata per stato grafico stabile nella riga raster. I cambiamenti a precisione di ciclo di modo, font, scroll o bordo dentro una riga rimangono non qualificati; blank, idle e modi illegali non forniscono foreground grafico. Il byte 80 dell'intestazione snapshot versiona separatamente il formato denso e questa funzione FD95. Con 80=0 resta l'interpretazione precedente anche se i formati misti sono abilitati; i lettori precedenti rifiutano 80=1 attraverso la convalida dei byte riservati.

L'[addendum italiano di sviluppo](../../reference/addenda/ADDENDUM_DENSE_MCM_IT.md) contiene un esempio xa, l'hash esatto dell'eseguibile verificato e i limiti delle prove. L'estensione è indipendente dalla revisione 17 degli scenari e non modifica il pacchetto runtime/manuale già pubblicato.


### Altezza densa concatenata: funzionalità81

Il runtime corrente di sviluppo versiona separatamente l'altezza concatenata al byte 81 dell'intestazione snapshot. Nella testa densa, il byte `$40` vale 0 per le 21 righe originali oppure 1..252 per l'altezza logica richiesta;253..255 non sono validi. L'immagine usa `ceil(altezza/21)` parti consecutive da 70 byte. Ogni parte deve avere modalità1 e marcatore `$A5`; l'intera catena deve rientrare nella vista da 16 KiB senza wrap. Solo `$40` della testa sceglie l'altezza; lo stesso campo nelle parti successive non viene letto.

La riga sorgente `y` sceglie la parte `floor(y/21)` e la riga `y mod21`. Ogni parte conserva i propri tre inchiostri e il tag sorgente. Materiali e rettangolo della diagonale ripartono dentro ogni parte da 21 righe, come record precedenti sovrapposti in verticale, senza introdurre un nuovo profilo di ombreggiatura dell'intera colonna. L'espansione si applica dopo. Tutta la colonna usa ancora un solo slot e non assegna nuovi backing.

Con `Plus64LeftMCM`, un'altezza densa superiore a 21 proietta Y grezza 206..255 in −50..−1; le coordinate positive del publisher restano 0..205. I percorsi da 21 righe e precedenti conservano la vecchia proiezione Y215..255. Ripristinare la funzionalità81=0 conserva il precedente vincolo byte `$40` denso=0. La funzionalità81=1 richiede 80, formati misti e cache compatta; i lettori precedenti la rifiutano come byte riservato non nullo. Il byte82 versiona separatamente i materiali composti (0..8; source16 dalla5, grammatica condivisa dalla6, SVM4 dalla7 e frame bank dalla8; palette inline precedenti dalla versione3 e luce centrale rettangolare e voci letterali opzionali nella versione4); i byte83..127 restano riservati e nulli. Le capacità dense restano distinte dalla revisione18; modulo snapshot1.0 e protocollo RAM `$05` rimangono invariati.

### RAW8 misto e colore materiale

Con FD92 bit dello slot=1, un puntatore il cui bit14 è1 e bit15 è0 seleziona RAW8 misto: i14bit bassi indirizzano504byte nello stesso backing. Per esempio `$4800` significa RAW8 all'offset `$0800`. L'intera immagine deve rientrare nel banco, senza wrap. Un puntatore non taggato conserva il significato packed MCM. Espansioni e collisioni restano ordinarie. Con `leftmcm` attivo il RAW8 misto applica anche le proiezioni del publisher: Xgrezza488..511 diventa−24..−1 e Y grezza215..255 diventa−41..−1; queste eccezioni non si applicano al RAW8 normale con packedcache disattivo.

Per una maschera compatta valida, il bit7 del **colore del descrittore** richiede un materiale e i7bit bassi scelgono il colore0..120. Nel packed MCM si può anche usare il **byte63 sorgente** `$80 | colore`, cioè tag `$80..$F8`. Il RAW8 misto bypassa questi materiali. Il nero0 resta opaco: è la maschera a decidere dove esiste il pixel.

Il colore scelto è il massimo di luminanza, non soltanto la tinta. Per `c>0`, tinta=`1+(c-1) mod15`, luminanza massima=`(c-1) div15`. Il profilo radiale calcola `L=max(0,7-((x-lx)^2+(y-ly)^2) div40)` e poi `L=L*luminanza_massima div7`, con divisione intera. Il risultato compatto è `15*L+tinta`; `c=0` dà nero. Non si memorizza una seconda immagine per le ombre.

### Otto direzioni, fronte e diagonale per inchiostro

FD99 controlla slot0/1, FD9A slot2/3, FD9B slot4/5 e FD9C slot6/7. Lo slot pari usa il nibble basso. Per esempio `$FD99=$30` dà luce est allo slot1 e mantiene il profilo storico nello slot0.

| Valore | Luce | Punto nella griglia24×21 |
| --- | --- | --- |
|0|Storica, alto-sinistra|(6,5)|
|1|N|(12,0)|
|2|NE|(23,0)|
|3|E|(23,10)|
|4|SE|(23,20)|
|5|S|(12,20)|
|6|SW|(0,20)|
|7|W|(0,10)|
|8|NW|(0,0)|
|9|Frontale|(12,10)|
|10|Diagonale per inchiostro MCM|Usa i limiti opachi del fotogramma.|
|11..15|Riservati|Ripiego sul profilo storico.|

Le direzioni sono relative allo schermo; un mirror della sorgente non inverte il punto luce selezionato. La modalità10 conserva i tre inchiostri MCM e modifica soltanto la loro luminanza: aggiunge `2-floor(5*((x-xmin)*dy+(y-ymin)*dx)/(2*dx*dy))`, saturando0..7, con `dx,dy` almeno1. I limiti provengono dalle coppie opache della maschera corrente. RAW8 e HIRES non diventano MCM per effetto del selettore10.

### Maschere sparse con rettangoli di palette

Il colore descrittore `$F9`, su un record HIRES packed valido, seleziona un formato sparse. Non va confuso con il tag sorgente F9 del packed MCM. La rappresentazione **sorgente** ha magic `A7`, byte1=`S=3+4*N`, byte2=colore/materiale di base. Seguono `N` rettangoli da quattro byte: limiti little-endian a20bit `x0|(y0<<5)|(x1<<10)|(y1<<15)`, poi colore/materiale. I limiti sono inclusivi e devono stare entro24×21; gli ultimi rettangoli hanno precedenza solo sui pixel già opachi.

A byte `S`, otto byte di occupazione indicano quali byte bitmap sono nonzero, nell'ordine inverso62..0, bit alto per primo; seguono i valori nonzero nello stesso ordine. Tutte le letture devono rientrare nei byte0..62. Il bit7 del byte63 applica il mirror orizzontale alla maschera. Un record malformato non viene disegnato. La decodifica usa una maschera HOST transitoria di63byte, non una RAM ospite aggiuntiva.

Gli inchiostri0..120 sono solidi; bit7 in un colore richiede il materiale sui7bit bassi. Con selettore9 e profilo frontale sparse, il rilievo segue le estremità del tratto opaco di ogni riga, invece del solo centro del rettangolo. Un normale bitmap senza magic A7 ma con selettore F9 usa l'inchiostro shared1 conservato nella cache. I rettangoli di palette non possono introdurre pixel nuovi o modificarne le collisioni.

### Maschere invisibili e priorità

Nel packed MCM, byte63 sorgente F9 significa **collision-only** dal profilo15: la maschera continua a partecipare alle collisioni ma non emette pixel e non occupa priorità visiva. Il tag FA, dal profilo16, è invece una **maschera occludente invisibile**: continua a reclamare la priorità originale dello slot, nascondendo gli sprite successivi nei pixel coperti e lasciando visibile la scena sottostante. Non disegna nero o un colore di trasparenza; i63byte della maschera e le collisioni restano invariati.

Per questi profili, l'alpha di visualizzazione contiene soltanto gli sprite visibili. I riepiloghi separati per linea conservano anche le collisioni delle maschere invisibili. Un chiamante differito deve usare il riepilogo collisioni previsto, non ricavare tutte le collisioni dall'alpha visivo. I tag F9/FA restano tag ordinari nei vecchi profili che non ne dichiarano il supporto.

## Livelli di colore, scena e interfacce native

Nel profilo `mainram` esteso, FD9D/FD9E puntano a descrittori nella **RAM principale già esistente**; FD9F bit0 ne abilita l'interpretazione. Il renderer percorre al massimo32nodi per passaggio. Il campo `next` è little-endian; zero termina la lista. Il byte11 sceglie il tipo, e il resto dipende dal tipo: non si possono combinare liberamente flag diversi. Coordinate base x,y,w,h sono in celle8×8 e devono rientrare nel320×200.

| Tipo nel byte11 | Dimensione | Funzione |
| --- | --- | --- |
|0|12byte|Ombreggiatura diagonale di rettangolo, con chiave sfondo.|
|1|20byte|Stessa luce, limitata al foreground di caratteri attesi e bitmap/glifi correnti.|
|2|24byte|Scena/materiali con stream condivisi di luminanza e selettore di glifi.|
|3|12byte|Cornici e tasti dell'interfaccia da griglia compatta.|
|4|12byte|Finestra post-sprite controllata da due coordinate RAM.|
|5|12byte|Tinta tramite tavolozze compatte.|
|6|12byte|Link condizionale generico.|
|7|20byte|Tinta condizionale.|
|8|24byte|Scena come tipo2, con protezione dei caratteri dell'interfaccia nativa.|
|9|16 byte|Rampa verticale di palette con chiave TED, scenari20.|
|10|16 byte|Materiale e primo piano ancorati a caratteri della matrice, scenari21.|

Questa tabella è un indice, non sostituisce i layout completi del capitolo8. Il formato dei nodi è software, non nuovi registri o un pool texture. Il programma deve riservarne i byte nel proprio budget e mantenerli validi per tutta la durata dei fetch.

Per il tipo0, i byte6..9 sono xmin,ymin,xmax,ymax locali in pixel; byte10 è la chiave compatta di sfondo. La luminanza TED dei pixel nonneri viene modificata dalla formula diagonale con saturazione0..7, preservando la tinta. Il tipo1 aggiunge quattro puntatori LE16: font, caratteri vivi, attributi vivi e caratteri attesi del riquadro. Si modifica soltanto il foreground del glifo corrispondente; attributo bit3 seleziona coppie MCM, con coppia0 esclusa. Un carattere sostituito dall'interfaccia non viene reinterpretato come il vecchio oggetto.

Il tipo2 aggiunge due stream: sfondo e tile materiale. Gli stream sono concatenazioni di segmenti `[nextLE16,length8,payload]`; l'immagine comincia con larghezza e altezza LE16, poi bande `[ripetizioni,numero_token,token...]`. Ogni token contiene luminanza nei3bit alti e lunghezza meno1 nei5bit bassi. Il selettore software associa banchi/range di glifi ai materiali. Non si tratta di una bitmap RGB separata, né il renderer conosce indirizzi o classi di oggetti di un gioco specifico.

Il tipo8 condivide il layout24byte del tipo2. Byte12 impacchetta banco sorgente richiesto nei bit0..2 e ultimo glifo nativo nei bit3..7; byte13 conserva il byte alto della base font allineata. Byte22 impacchetta inchiostro testo nel nibble alto e tinta di ripiego nel basso; byte23 è il glifo del bordo pieno. Il puntatore di controllo nei byte20/21 sceglie il banco da `(RAM[controllo]>>1)&7`; il byte a `controllo-3` è l'enable sprite della vista logica standard.

La protezione nativa si attiva quando banco e vista corrispondono e **almeno un byte dell'intero intervallo font dei glifi configurati è nonzero**. Il primo byte o il primo glifo possono quindi essere vuoti. Una cella con inchiostro corrispondente e glifo nell'intervallo conserva foreground e sfondo solidi originali; il glifo di bordo è protetto se adiacente, anche in diagonale, a una cella di testo corrispondente. Questo include lati e angoli del bordo di una cella. Con banco errato o sprite sorgente disabilitati, il proprietario protetto sopprime scena e luci degli oggetti; un proprietario condizionale attivo può selezionare un'altra catena. I controlli sono su dati selezionati dal programma, non su costanti di un particolare titolo.

Con la revisione18, FD9F bit4 (`P64_SIDE_BORDER_CLIP=16`) ripristina i bordi TED nativi chiusi dopo tutta la composizione. Rispetta bordi aperti/disabilitati e blank stabile di riga; le collisioni rimangono invariate. Vedere l’[addendum sui bordi](../../reference/addenda/ADDENDUM_BORDER_CLIP_IT.md).

Il tipo4 si applica solo con FD9F bit3=1, dopo gli sprite. Byte6/7 e 8/9 puntano rispettivamente ai limiti superiore e inferiore in coordinate pixel globali Y; byte10 è un **codice TED0..127**, non un indice compatto sprite. Nell'intersezione del rettangolo e della banda `[alto,basso)` il nodo sostituisce i pixel con quel codice. Durante questa finestra la protezione UI del tipo8 è sospesa, così una maschera di apertura/chiusura può restare sopra a una scena migliorata anche se la vista sorgente cambia temporaneamente. FD9F bit1 o bit2 richiedono invece nero sull'intera area di presentazione.

L'ordine effettivo per linea è: rendering TED, luce dei livelli, materiali/scena, eventuale tinta e cattura del primo piano tipo10, sprite, ripristino dei pixel tipo10 selezionati, finestra tipo4, mascheramento nero di presentazione e infine ritaglio opzionale dei bordi nativi con profilo18/FD9F bit4. La protezione del testo o il colore di sfondo ordinari non cancellano uno sprite già emesso; il tipo10 abilita esplicitamente il primo piano selezionato. Le maschere FA possono invece occultare sprite con priorità inferiore secondo le regole descritte sopra. I livelli non scrivono la RAM sorgente né cambiano le collisioni.

Dal profilo scenari 19, il bit 3 (`P64_TINT_ELLIPSE=$08`) del byte di stile 10 dei nodi 5/7 seleziona una sagoma ellittica entro il rettangolo esistente. Il tipo 5 resta di 12 byte, il tipo 7 di 20. I profili fino a 18 ignorano il bit e conservano la sagoma rettangolare; con 19 il bit spento mantiene lo stesso comportamento. Sono preservati filtri di colore, nero, condizioni, protezione UI e ordine della composizione. È distinto dal bit 3 FD9F. Vedere l'[addendum sulle tinte ellittiche](../../reference/addenda/ADDENDUM_ELLIPSE_TINT_IT.md) per formula, esempio e compatibilità.

Dal profilo scenari 20, il nodo 9 da 16 byte campiona una palette compatta di 1..32 colori lungo un intervallo verticale in pixel locali. Chiave e maschera TED scelgono i pixel; un flag può mantenere l'ultimo colore dopo l'intervallo. I profili fino a 19 ignorano il nodo e proseguono nella lista. Non cambiano ellissi 19, sprite, registri o RAM disponibile. L'[addendum sulla rampa di palette](../../reference/addenda/ADDENDUM_PALETTE_RAMP_IT.md) definisce layout, estremi, colori non validi e un esempio di sedici fasce sottili.

Dal profilo scenari21, il nodo10 da16 byte segue due caratteri distinti scelti dal programma in una riga della matrice nativa, includendo lo scorrimento fine e il ripiego sul carattere destro quando il sinistro è fuori schermo. Una tinta TED seleziona la sfumatura orizzontale dell'oggetto; un flusso concatenato contiene 1..16 rettangoli da6 byte (`xLE16,y,larghezza,altezza,riservato0`). I rettangoli selezionano soltanto il primo piano dei bit sorgente: nel multicolore, coppie0/1 sfondo e 2/3 primo piano, nero compreso. I colori così conservati sono ripristinati dopo **tutti i formati sprite**, compresi ordinari, RAW8 e densi, prima di finestre e bordi. `$FD95`, alpha e collisioni originali non cambiano. Colori e maschere di linea sono dati HOST transitori, non RAM aggiuntiva indirizzabile dal programma; nodi, segmenti, font e installatore restano entro64+16KiB. Il [layout esatto del nodo10](../../FORMATI_GRAFICI.md#scenery-revision21-glyph-anchored-foreground-material) e l'[addendum tecnico italiano](../../reference/addenda/ADDENDUM_ANCHORED_FOREGROUND_IT.md) descrivono tutti i16 byte e le verifiche. I profili fino a20 ignorano il nodo; modulo snapshot1.0, payload144776 e CRC restano invariati.

### Versione serializzata e esempio corrente

Il contenitore PLUS64 conserva dimensione e backing del contratto RAM80. Nel suo header HOST, byte72 abilita i formati misti;73 la palette materiale completa;74 sparse;75 direzioni;76 rilievo frontale sparse;77 luci dei livelli;78 diagonale per inchiostro;79 versione della scena, attualmente21;80 MCM denso con la relativa priorità FD95. Il byte81 versiona l’altezza densa concatenata; il byte82 versiona separatamente i materiali composti (0..8; source16 dalla5, grammatica condivisa dalla6, SVM4 dalla7 e frame bank dalla8; palette inline precedenti dalla versione3 e luce centrale rettangolare e voci letterali opzionali nella versione4); i byte83..127 restano riservati e nulli. La funzionalità80=1 richiede formati misti e cache compatta;80=0 mantiene il significato precedente di puntatori e registro. Questi byte non sono registri6502. Le sezioni storiche che li dichiaravano riservati appartengono ai vecchi profili; non vanno applicate al formato corrente. Il reader convalida combinazioni e CRC prima del ripristino; un vecchio eseguibile può rifiutare un formato nuovo.

L'esempio aggiornato `sdk/materials/material-example.asm`, con include e builder forniti, mostra tutti i121 colori di highlight e le direzioni1,3,9 nel profilo nativo16KiB. Carica un'unica maschera nuova e generica nella vista del banco2 e seleziona le ombre via descrittore, senza un'immagine per ogni colore. Il PRG è 921byte, con ingresso `$1100` e fine codice/dati `$1398`; usa video TED entro `$3F3F` e riserva un record cache1KiB nel banco2. Il suo README spiega costruzione, avvio e diagnostica.

Le verifiche conservate coprono due build identici,363 combinazioni colore/direzione del renderer C, e 500 fotogrammi del programma su ciascun ospite C16 e Plus/4. Sono prove software specifiche dell'esempio e delle fonti indicate, non collaudo di circuiti fisici o di qualsiasi programma futuro.

## Debugger e limiti del collaudo

Una lettura CPU di `$FD91` azzera il latch e una lettura CPU di `$FD96` incrementa il puntatore. Il callback diagnostico **peek** restituisce invece il latch o il byte corrente senza tali effetti. Una vista del debugger che usa peek non dimostra che il programma abbia consumato una collisione; confrontare sempre il tipo di accesso. (`plus64_sprite.c`; `plus64vice.c`)

I comandi del monitor e gli eventuali helper di iniezione tastiera dei banchi di prova sono strumenti HOST, non istruzioni6502 o registri della cartuccia. Non trasformare una sequenza observer in un requisito del programma o dell'avviatore di produzione; il programma deve usare le normali periferiche di input.

Le prove CPU6502, le periferiche simulate, il runtime VICE normale, gli observer, Wine e una cartuccia fisica sono livelli distinti. Per il proprio gioco conservare almeno: hash di eseguibile e asset, opzioni effettive, stato degli slot, immagini reali in movimento e verifica del latch con le letture CPU previste. Un'immagine ricostruita direttamente dai descrittori finali non sostituisce il framebuffer per qualificare un multiplex: la funzione di disegno diretto legge uno stato corrente, mentre il percorso di visualizzazione applica pubblicazioni alle singole linee. (`plus64vice.c`)
