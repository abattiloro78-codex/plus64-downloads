# Costruire un gioco sulla piattaforma

## Una mappa iniziale riproducibile

L'esempio nativo impiega il bitmap TED multicolore nei primi16KiB. La
seguente disposizione è una scelta software degli esempi, non una nuova
decodifica della cartuccia:

| Area CPU | Uso consigliato nell'esempio |
| --- | --- |
| `$0000–$00FF` | Zero page: porti CPU e variabili; riservare esplicitamente quelle del gioco |
| `$0100–$01FF` | Stack6502; non depositare qui sprite o tabelle senza controllare la profondità |
| `$0200–$0FFF` | Area del sistema e workspace: non considerarla libera mentre si usa il KERNAL |
| `$1001…` | PRG con stub BASIC e programma dell'esempio, con limite prima di `$1800` |
| `$1800–$1BFF` | Attributi di luminanza TED,1024byte |
| `$1C00–$1FFF` | Attributi di crominanza TED,1024byte |
| `$2000–$3F3F` | Bitmap,8000byte |
| `$3F40–$3FFF` |192byte residui: utilizzabili solo se non già riservati dal proprio programma |

Altri giochi possono scegliere un layout diverso. Il programma deve
controllare che codice, stack, loader, buffer e video non si sovrascrivano.
Con il profilo plus/64 nativo il runtime impone **16 KiB CPU/TED sia al C16
sia al Plus/4**: non si può usare implicitamente la RAM interna aggiuntiva
del Plus/4. Un indirizzo alto può essere un alias della RAM bassa o una
finestra I/O/ROM, non spazio libero. Il profilo MainRAM è distinto: espone
i 64 KiB della cartuccia a CPU/TED e lascia i 16 KiB interni alla vista sprite.
In entrambi i casi il totale resta **81.920 byte**, con gli alias descritti
nel capitolo sulla memoria.

Un PRG contiene due byte iniziali con l'indirizzo di caricamento in ordine
low/high. Un PRG nativo caricato a `$1001` non può oltrepassare `$3FFF`
presumendo RAM interna aggiuntiva. Risorse più grandi richiedono una
strategia di caricamento nella SRAM già disponibile, non una scrittura
fuori dallo spazio nativo verificato.

## Sequenza di inizializzazione

1. Decidere quali servizi del sistema usare e quali variabili possiede il gioco.
2. Controllare `$FDEC=$64` e `$FDED=$05` prima di dipendere dagli alias RAM80.
   Se si usa il modem, verificare anche `$FDF6=$64`, `$FDF7=$03` e riservare
   i suoi 512 byte condivisi.
3. Disabilitare gli sprite durante il caricamento iniziale dei pattern.
4. Preparare bitmap e attributi TED.
5. Impostare puntatore di upload e caricare i pattern nella RAM sprite.
6. Inizializzare soltanto i registri SID necessari, con volume e gate noti.
7. Scrivere descrittori completi; pubblicare la maschera conFD90 per ultima.
8. Avviare il loop con un ritmo video esplicito.

I registri non documentati o riservati non devono essere usati come nuove
funzioni. Un valore che si rilegge correttamente non dimostra che il
renderer o un circuito lo utilizzi.

## Il loop principale

Un'organizzazione tipica è:

```text
attendi il prossimo fotogramma
leggi input e calcola i nuovi fronti dei pulsanti
aggiorna fisica e regole una sola volta
risolvi collisioni e conseguenze
prepara descrittori e avanzamento delle animazioni
aggiorna audio e HUD necessari
pubblica FD90
ripeti
```

Se il loop non raggiunge il proprio appuntamento raster, il gioco può
diventare lento o perdere parti degli sprite. Misurare il programma durante
colpi, esplosioni, ridisegno del punteggio e caricamenti, non soltanto quando
il protagonista è fermo.

L'emulatore può lavorare in Warp durante il caricamento automatico. Questa
è una funzione dell'ospite, non un clock della cartuccia e non un metodo
di sincronizzazione del gioco. Non usarla per compensare routine lente.

## Video TED e coordinate

Il rettangolo attivo è 320×200pixel fisici. Nel bitmap multicolore TED ogni
coppia di bit rappresenta due pixel orizzontali: il disegno ha quindi160
campioni orizzontali, mentre il sistema di coordinate sprite resta320.
Uno sprite16×16 del nostro SDK è 16pixel fisici di larghezza, non32.

Per la cella TED `(cx,cy)`, con40colonne e25righe, e la riga interna `dy`:

```text
cell = cy * 40 + cx
attributi: $1800 + cell e $1C00 + cell
byte bitmap: $2000 + cell * 8 + dy
```

Il significato dei quattro valori di pixel multicolore è:

| Coppia | Colore TED |
| --- | --- |
| `00` | Colore di sfondo globaleFF15 |
| `01` | Hue dal nibble alto della crominanza, luminanza dai bit0–2 dell'altro attributo |
| `10` | Hue dal nibble basso della crominanza, luminanza dai bit4–6 dell'altro attributo |
| `11` | Colore globaleFF16 |

Per usare121colori diversi nello stesso bitmap si scelgono attributi
diversi nelle celle; non si supera il numero di colori ammesso in una
singola cella. Le palette degli sprite usano invece il formato indicizzato
plus/64 descritto nel capitolo video.

## Input, sistema operativo e interrupt

L'SDK mostra il percorso effettivamente verificato per tastiera e joystick2.
Non copiare il polling CIA del C64: il C16/Plus/4 usa altri registri e
un diverso aggancio al TED. L'assenza di un joystick fisico nell'ospite
non impedisce l'uso del keyset configurato in VICE.

`SEI` disabilita IRQ, non NMI. Un gioco che disabilita gli IRQ deve curare
input, timer e avanzamento audio: l'orologio del KERNAL non va considerato
automaticamente in esecuzione. La cartuccia documentata non fornisce un
nuovo NMI equivalente a quello della CIA2 del C64.

Le routine KERNAL richiedono le proprie variabili e condizioni di ingresso.
Non chiamare LOAD, SAVE o stampa di sistema dopo averne sovrascritto lo
workspace, senza un protocollo di salvataggio e ripristino verificato.
L'esempio iniziale tiene le risorse essenziali nel programma e usa il
caricamento D64 normale, prima di entrare nel loop autonomo.

## Collisioni: disegno e regole sono due cose distinte

FD91 segnala sovrapposizioni fra sprite del dispositivo. Non rileva
piattaforme o muri TED, non applica penalità e non decide le regole del
gioco. Serve una politica software: rettangoli, maschere, collision map
oppure combinazioni delle tre.

Con artwork16×16 inserito in un record24×21, gli otto pixel a destra e le
cinque righe sotto sono trasparenti. Il rettangolo visibile può essere16×16;
non deve diventare24×21 soltanto perché il record ha quella dimensione.
Se si vuole collisione pixel per pixel, leggere le proprie maschere: un
semplice rettangolo include anche eventuali fori interni della sagoma.

Il latch hardware usa i numeri degli otto slot. Quando si multiplexano
più personaggi sugli stessi slot, lo slot non è l'identità del personaggio.
Occorre conoscere la fascia e l'istante del test o usare collisioni software.

## Risorse e livelli

La SRAM a registri è adatta a conservare stanze, bitmap, tabelle e dati
compressi. La CPU non esegue istruzioni attraverso `$FDEA`. Nel profilo
nativo, per eseguire una routine conservata nella cartuccia occorre copiarla
in un’area CPU eseguibile e verificarne le rilocazioni. Nel profilo MainRAM
la cartuccia è già esposta nello spazio CPU: il codice si può eseguire al
corrispondente indirizzo CPU, rispettando la visibilità di ROM e I/O, senza
passare dalla porta dati.

Le porte SRAM e sprite sono **viste con alias**, non due pool aggiuntivi.
Nel profilo nativo la porta sprite indirizza il banco cartuccia 2: una
scrittura a quel banco tramite `$FDEA` modifica anche i dati visibili allo
sprite decoder. Nel profilo MainRAM la porta SRAM accede agli stessi
64 KiB esposti alla CPU, mentre `$FD96` accede ai 16 KiB interni. Un gestore
di risorse deve quindi registrare il proprietario di ogni intervallo e
coordinare caricamenti, codice, pattern, modem e audio. Non sommare gli
alias come memoria disponibile separata.

L'autoincremento FDEA si arresta sul confine del banco mediante wrap;
non seleziona automaticamente il banco successivo. Separare blocchi e
descrittori di risorsa in modo che il loader gestisca esplicitamente
l'attraversamento di `$3FFF`.

## Pubblicare un gioco

Distribuire PRG o D64, il profilo runtime richiesto, le istruzioni dei
comandi e l'hash della build. Indicare se servono formato raw, packed,
aggiornamento raster, MainRAM o formati estesi. MainRAM è ora un profilo
del contratto RAM80 comune, non un modo per aggiungere un secondo blocco
CPU da 64 KiB.

Per i file modificabili, usare una copia di lavoro. Per esempio il
porting di Impossible Mission scrive la classifica nel proprio D64:
sostituirlo automaticamente con una nuova immagine perderebbe quei dati.
Un record tenuto soltanto in RAM, invece, dura fino al reset.


## Budget delle risorse e caricamenti per fase

Per ogni risorsa registrare indirizzo iniziale, lunghezza, profilo, alias e
fase in cui è viva. Il totale fisico è 65.536 + 16.384 byte, non 64 KiB più
una cache sprite da 16 KiB più altre RAM audio o modem. La compressione
riduce dati sorgente e trasferimenti; un decoder temporaneo non autorizza
una seconda bitmap residente fuori dal budget. Uno stesso intervallo può
essere riutilizzato da loader, grafica o audio solo quando il proprietario
precedente ha terminato, e prima che i dati siano richiesti di nuovo.

I descrittori di materiale, le regioni di palette e gli stream di luminanza
dei formati correnti devono essere conteggiati nella stessa mappa. Nel
modello software il compositore li legge dalla RAM emulata; il costo e il
percorso di accesso di un’eventuale implementazione fisica richiedono un
progetto esplicito, come precisato nel capitolo video.

## Checkpoint e dati su disco

Il runtime corrente supporta snapshot VSF completi di RAM80: memorizza
tutti gli 81.920 byte e lo stato locale dei dispositivi, inclusi gli alias,
i registri e lo stato video necessario alla continuazione. Il contenitore
VSF Plus/4 2.1, il modulo PLUS64 1.0, il protocollo SRAM `$05` e la revisione
video 17 sono numeri distinti. Un file VSF può essere più grande di 80 KiB
perché include anche CPU, drive, periferiche e strutture serializzate
dell’emulatore; non è memoria aggiuntiva accessibile al gioco.

I vecchi checkpoint incompleti non possono recuperare byte mai salvati e
vengono rifiutati quando devono descrivere uno stato plus/64 completo.
Per un checkpoint autosufficiente, includere le immagini disco nelle
opzioni di salvataggio; altrimenti conservare anche i D64 associati. Il
SAVE originale di un gioco resta una funzione distinta: in Impossible
Mission registra la classifica e non sostituisce il checkpoint VSF. Il
modem deve essere disconnesso e senza chiamata pendente prima del salvataggio
o del caricamento.
