# Building a game for the platform

## A reproducible initial map

The native example uses a multicolour TED bitmap within the first 16 KiB.
The following layout is a software choice made by the examples, not new
cartridge address decoding:

| CPU area | Suggested use in the example |
| --- | --- |
| `$0000–$00FF` | Zero page: CPU ports and variables; explicitly reserve those belonging to the game |
| `$0100–$01FF` | 6502 stack; do not put sprites or tables here without checking depth |
| `$0200–$0FFF` | System area and workspace: do not consider it free while using the KERNAL |
| `$1001…` | PRG with BASIC stub and example program, ending before `$1800` |
| `$1800–$1BFF` | TED luminance attributes, 1,024 bytes |
| `$1C00–$1FFF` | TED chrominance attributes, 1,024 bytes |
| `$2000–$3F3F` | Bitmap, 8,000 bytes |
| `$3F40–$3FFF` | Remaining 192 bytes: usable only if not already reserved by the program |

Other games may choose a different layout. The program must check that code,
stack, loader, buffers and video do not overwrite one another. In the native
plus/64 profile the runtime enforces **16 KiB CPU/TED RAM on both C16 and
Plus/4**: additional internal Plus/4 RAM cannot be used implicitly. A high
address may alias lower RAM or an I/O/ROM window rather than free storage.
MainRAM is a distinct profile: it exposes the cartridge’s 64 KiB to CPU/TED
and leaves the internal 16 KiB as the sprite view. In both cases the total
remains **81,920 bytes**, with the aliases described in the memory chapter.

A PRG starts with two bytes containing its load address in low/high order.
A native PRG loaded at `$1001` cannot extend beyond `$3FFF` by assuming extra
internal RAM. Larger resources require a loading strategy into the SRAM
already available, not writes outside the verified native address space.

## Initialization sequence

1. Decide which system services to use and which variables the game owns.
2. Check `$FDEC=$64` and `$FDED=$05` before depending on RAM80 aliases.
   If using the modem, also check `$FDF6=$64`, `$FDF7=$03` and reserve its
   512 shared bytes.
3. Disable sprites while initially loading patterns.
4. Prepare the TED bitmap and attributes.
5. Set the upload pointer and load patterns into the sprite view.
6. Initialize only the required SID registers, with known volume and gate.
7. Write complete descriptors; publish the mask through FD90 last.
8. Start the loop with an explicit video rhythm.

Undocumented or reserved registers must not be used as new features. A value
that reads back correctly does not prove that the renderer or a circuit uses it.

## The main loop

A typical organization is:

```text
wait for the next frame
read input and calculate new button edges
update physics and rules once
resolve collisions and their consequences
prepare descriptors and animation advancement
update the required audio and HUD state
publish FD90
repeat
```

If the loop misses its raster appointment, the game may become slow or lose
parts of sprites. Measure the program during shots, explosions, score
redrawing and loading, not only while the main character is standing still.

The emulator may use Warp during autostart loading. This is a host feature,
not a cartridge clock or a method of game synchronization. Do not use it to
compensate for slow routines.

## TED video and coordinates

The active rectangle is 320×200 physical pixels. In a multicolour TED bitmap,
each bit pair represents two horizontal pixels: artwork therefore has 160
horizontal samples, while sprite coordinates remain 320 pixels wide. The
SDK’s 16×16 sprite is 16 physical pixels wide, not 32.

For TED cell `(cx,cy)`, with 40 columns and 25 rows, and internal row `dy`:

```text
cell = cy * 40 + cx
attributes: $1800 + cell and $1C00 + cell
bitmap byte: $2000 + cell * 8 + dy
```

The four multicolour pixel values have the following meanings:

| Pair | TED colour |
| --- | --- |
| `00` | Global background colour FF15 |
| `01` | Hue from the high chrominance nibble, luminance from bits 0–2 of the other attribute |
| `10` | Hue from the low chrominance nibble, luminance from bits 4–6 of the other attribute |
| `11` | Global colour FF16 |

To use 121 different colours in the same bitmap, choose different attributes
in different cells; the number of colours available in an individual cell
is not increased. Sprite palettes instead use the indexed plus/64 format
described in the video chapter.

## Input, operating system and interrupts

The SDK demonstrates the path actually verified for the keyboard and joystick 2.
Do not copy C64 CIA polling: the C16/Plus/4 uses other registers and a different
TED connection. The absence of a physical joystick on the host does not
prevent use of the keyset configured in VICE.

`SEI` disables IRQ, not NMI. A game that disables IRQs must manage input,
timers and audio progression itself: do not assume the KERNAL clock is still
running automatically. The documented cartridge provides no new NMI
equivalent to the C64’s CIA2.

KERNAL routines require their own variables and entry conditions. Do not call
LOAD, SAVE or system printing after overwriting that workspace without a
verified save/restore protocol. The initial example keeps its essential
resources in the program and uses normal D64 loading before entering its
autonomous loop.

## Collisions: drawing and rules are separate

FD91 reports overlaps between device sprites. It does not detect TED platforms
or walls, apply penalties, or decide game rules. A software policy is needed:
rectangles, masks, a collision map, or combinations of these.

With 16×16 artwork placed in a 24×21 record, the eight pixels on the right
and five rows below are transparent. Its visible rectangle can be 16×16;
it need not become 24×21 simply because the record has that size. For
pixel-perfect collision, read your own masks: a simple rectangle also
includes any holes within the silhouette.

The hardware latch uses the numbers of the eight slots. When multiplexing
several characters onto the same slots, a slot is not a character identity.
The software must know the raster band and test instant, or use software
collision detection.

## Resources and levels

The register-addressed SRAM is useful for storing rooms, bitmaps, tables and
compressed data. The CPU does not execute instructions through `$FDEA`. In
the native profile, executing a routine stored in the cartridge requires
copying it into an executable CPU area and checking its relocations. In
MainRAM, the cartridge is already exposed in CPU address space: code can run
at the corresponding CPU address, subject to ROM and I/O visibility, without
going through the data port.

The SRAM and sprite ports are **aliasing views**, not two additional pools.
In the native profile, the sprite port addresses cartridge bank 2: a write to
that bank through `$FDEA` also changes data visible to the sprite decoder.
In MainRAM, the SRAM port accesses the same 64 KiB exposed to the CPU, while
`$FD96` accesses the internal 16 KiB. A resource manager must therefore
record the owner of each range and coordinate loading, code, patterns, modem
and audio. Do not add the aliases as separate available memory.

FDEA autoincrement wraps at the bank boundary; it does not select the next
bank automatically. Separate resource blocks and descriptors so the loader
handles crossing `$3FFF` explicitly.

## Publishing a game

Distribute a PRG or D64, the required runtime profile, control instructions
and the build hash. State whether RAW, packed, raster updates, MainRAM or
extended formats are required. MainRAM is now a profile of the common RAM80
contract, not a way to add a second 64 KiB CPU block.

Use a working copy for writable files. For example, the Impossible Mission
port writes its high-score table into its D64; automatically replacing that
disk with a new image would lose those data. A record kept only in RAM lasts
until reset.

## Resource budgets and loading by phase

For each resource, record starting address, length, profile, aliases and the
phase during which it is live. The physical total is 65,536 + 16,384 bytes,
not 64 KiB plus a 16 KiB sprite cache plus further audio or modem RAM.
Compression reduces source data and transfers; a temporary decoder does not
authorize a second resident bitmap outside the budget. The same range may
be reused for loading, graphics or audio only after its previous owner is
finished and before those data are needed again.

Material descriptors, palette regions and luminance streams in the current
formats belong in that same map. In the software model the compositor reads
them from emulated RAM; the access path and cost of a physical implementation
require an explicit design, as explained in the video chapter.

## Checkpoints and disk data

The current runtime supports complete RAM80 VSF snapshots: they store all
81,920 bytes and local device state, including aliases, registers and the
video state required for continuation. The Plus/4 VSF 2.1 container, PLUS64
1.0 module, SRAM protocol `$05` and video revision 17 are separate version
numbers. A VSF can exceed 80 KiB because it also includes CPU, drives,
peripherals and serialized emulator structures; this is not extra memory
available to the game.

Incomplete older checkpoints cannot recover bytes that were never saved and
are refused when they must describe complete plus/64 state. For a
self-contained checkpoint, include disk images in the save options;
otherwise preserve the associated D64 files too. A game’s original SAVE
remains separate: in Impossible Mission it records the high-score table
and does not replace a VSF checkpoint. The modem must be disconnected and
have no pending call before saving or loading.
