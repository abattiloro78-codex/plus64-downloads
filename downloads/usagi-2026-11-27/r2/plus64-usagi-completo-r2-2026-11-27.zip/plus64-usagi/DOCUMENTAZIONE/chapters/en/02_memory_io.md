# 2. Memory, CPU address space and I/O ports

Choose one memory profile for a game and retain it on both machines. The
current contract provides **64 KiB cartridge RAM and 16 KiB internal RAM,
81,920 bytes in total**. The two available views do not expose a linear
80 KiB CPU address space and do not add a sprite pool.

This chapter retains the RAM80 contract and memory APIs. Final identities are in chapter 9; previous-edition inventories are retained under `reference/history`, while `API_INDEX.json` and `SOURCE_INVENTORY.json` identify this edition’s source copies.

## 2.1 The two available profiles

| Profile | CPU/TED program RAM | `$FDE8..$FDED` port | Sprite-port and modem view |
|---|---|---|---|
| `-plus64`, native | Internal 16 KiB, enforced on Plus/4 too | Four 16 KiB cartridge banks | Sprites: cartridge bank 2. Modem: bank 3, offsets `$3E00..$3FFF` |
| `-plus64mainram` | Cartridge 64 KiB as main RAM | Alias of the same 64 KiB | Sprites: internal 16 KiB. Modem: internal offsets `$0000..$01FF` |

In the first profile a program such as PRISM keeps code and bitmap below
`$4000` and transfers resources from the cartridge through the data port.
Changing the SRAM bank does not move CPU code, stack, TED video or ROM.
Writing bank 2 also changes the view read by the sprite circuit: reserve
the intervals being used explicitly.

In the second profile, used by Impossible Mission, the
`plus64_set_main_ram()` setter selects `RamSize=64` and binds the four
banks to the same `mem_ram` used by the CPU decoder. The internal 16 KiB
remains distinct and is accessible through the sprite port `$FD96..$FD98`.
Disabling MainRAM returns to the 16 KiB CPU profile. A change rotates the
five 16 KiB blocks in place, without an additional hidden buffer; it
preserves both cartridge and internal contents. It is refused if sprites
are enabled, the modem is connected/dialing, RX/TX queues contain data or
a partial command is present. [MEM-2]

**An alias is not another 64 KiB memory.** With MainRAM, a port write
selecting bank 0 and offset `$2345` changes the same `mem_ram[$2345]` cell
used by the CPU decoder. The port also accesses RAM underneath ROM and I/O
because it uses the backing directly. It does not send commands to I/O
registers at those CPU addresses. [MEM-1, MEM-2]

The model is a current software contract, not a demonstration of an
electrical cartridge decoder. Host-compositor structures and temporary
snapshot-validation copies are not RAM accessible to the game.

## 2.2 C16 and Plus/4: one software contract

On a C16 with `RamSize=16`, the ordinary RAM decoder uses
`address & $3FFF`: where ROM or I/O does not intervene, `$2000`, `$6000`,
`$A000` and `$E000` alias the same cell. TED RAM bases are likewise reduced
to the first 16 KiB. Writing above `$3FFF` does not create free memory.
[MEM-3]

With plus/64 enabled, the native profile enforces `RamSize=16` on Plus/4
too. Selecting the Plus/4 model does not provide another 48 KiB. Both
machines check the same contract, rather than game variants with different
capacities or rules. Incompatible RAM expansions are refused.

With `-plus64mainram`, both use the 64 KiB cartridge as main RAM. The
separate internal 16 KiB is the sprite-port view, not another linear
window or an invented banking register. Configure the model and profile
before starting the program, and check protocol `$05` before using the
shared contract.

## 2.3 SRAM API: `$FDE8..$FDED`

The port is registered only while plus/64 is enabled. No additional mirrors
are declared. Its six addresses are listed below. `R` means CPU read and
`W` CPU write. [MEM-1, MEM-2]

| Address | Access | Meaning |
|---|---|---|
| `$FDE8` | R/W | Low byte of the bank offset |
| `$FDE9` | R/W | High offset byte; writes use bits 0–5 only; reads return bits 6–7 as zero |
| `$FDEA` | R/W | Data at the current index; **every CPU read and every write increments the offset** |
| `$FDEB` | R/W | Bank 0–3; writes use `value & 3`; changing it preserves the offset |
| `$FDEC` | R | Constant signature `$64`; writes have no effect |
| `$FDED` | R | Constant protocol version `$05`; writes have no effect |

Version `$05` identifies the shared 64+16 KiB contract. It is not a
register exposing or changing MainRAM. The profile remains an agreement
between runtime and program. Check the signature as the pair `$64,$05`.

The exact calculation is:

```text
index = (bank << 14) | (offset & $3FFF)
after DATA: offset = (offset + 1) & $3FFF
```

After `$3FFF`, the port returns to `$0000` **in the same bank**; it does
not advance to the next bank. A 64 KiB copy must therefore select the four
banks explicitly. Writing the low or high offset byte preserves the other
byte; selecting a bank does not reset the pointer.

The internal `p64_memory_peek()` callback reads without incrementing. This
**does not** make BASIC `PEEK(65002)` harmless: BASIC performs a CPU read of
`$FDEA`, which increments the pointer. A side-effect-free peek is the
device function used by the debugger when it requests that operation.

### Example: 256 bytes at the end of bank 2

This example is for the native SRAM-port profile, using a bank reserved
by the game. It writes values 0–255 at offsets `$3F00..$3FFF`; afterwards
the pointer is `$0000`, bank 2. `PHP/SEI/PLP` prevents an IRQ routine using
the same port from changing its bank or pointer during the transfer.

```asm
        php
        sei
        lda #2
        sta $fdeb
        lda #0
        sta $fde8
        lda #$3f
        sta $fde9
        ldy #0
copia:  tya
        sta $fdea
        iny
        bne copia
        plp
        rts
```

This code does not save the previous pointer. The caller must define
whether the port is exclusive, or save and restore bank and offset. Do not
use read-modify-write instructions such as `INC $FDEA`: they perform extra
accesses to an auto-incrementing port. With MainRAM, also choose an interval
that contains no live code or data, because the port aliases main memory.

### Reset and preservation

- `p64_memory_powerup()` initializes the structure, clears the cartridge
  view and port registers, and preserves native internal RAM. It is called
  when plus/64 is enabled from a disabled state.
- Device reset calls `p64_memory_reset_registers()`: bank and offset return
  to zero; SRAM contents and the MainRAM binding remain.
- General machine reset can still execute ROM code that modifies native
  RAM. Preserving SRAM does not guarantee preservation of a complete game
  state. [MEM-1, MEM-2]

## 2.4 ROM, I/O and usable areas

The CPU has a 64 KiB address space even when a program uses banked memory
views. Installed byte counts do not remove overlays. In the standard
native profile: [MEM-3, MEM-4]

| Area | Required consideration |
|---|---|
| `$0000/$0001` | Host processor port; not the C64 ROM/I/O selector |
| `$0002..$00FF` | Zero page, shared with KERNAL/BASIC if ROM calls are used |
| `$0100..$01FF` | CPU stack; not a permanent buffer |
| `$0200..$7FFF` | RAM under ordinary conditions, within profile limits/aliases |
| `$8000..$BFFF` | BASIC or selected low ROM while ROM is enabled; underlying RAM on reads when disabled |
| `$C000..$FFFF` | KERNAL or selected high ROM, with I/O exceptions; underlying RAM while ROM is disabled |
| `$FD00..$FDFF`, `$FE00..$FEFF` | I/O decoding in both ROM/RAM configurations, including plus/64 ports |
| `$FF00..$FF1F` | TED registers, not ordinary RAM |
| `$FF3E`, `$FF3F` | ROM/RAM selection strobes; written value is irrelevant |

A write to `$FF3E` enables ROM reads; a write to `$FF3F` selects underlying
RAM. I/O registers do not disappear. `$FF20..$FFFF`, except the two strobes,
follows the decoder's configuration, including the final CPU vectors. Do
not hide KERNAL and then call it with `JSR`, or leave IRQ enabled without
valid RAM vectors and handlers. Normal stores under ROM windows write
underlying RAM; I/O areas remain exceptions. [MEM-3, MEM-4]

TED fetches have their own bases and selections. The native SRAM port is
not a source for TED fetches: bitmap or character data must first be copied
into the native RAM required by the video mode. The sprite circuit's video
overlay does not change this rule.

## 2.5 Shared backings and compositor buffers

The implementation has exactly two payload backings:

| Backing/view | Size | Ownership |
|---|---:|---|
| `mem_ram` | 65,536 bytes | Internal 16 KiB CPU/TED RAM plus three cartridge banks in native mode; four cartridge banks in MainRAM |
| `p64_aux_ram` | 16,384 bytes | Fourth cartridge bank in native mode; separate internal RAM in MainRAM |
| Sprite view | 16,384 bytes, already counted above | Cartridge bank 2 or internal RAM, depending on profile |
| Modem payload | 512 bytes, already counted above | RX128, TX128, command256; offsets as in table 2.1 |
| Overlay, alpha and raster summaries | Host buffers | No guest address or additional game-RAM capacity |

The backings total **81,920 bytes**, not 96 KiB. The following two views
are not added again. A program's resident SID/audio data also occupies
these same bytes. Executable, disk and snapshot sizes measure PC files,
not RAM available to the program. [MEM-1, MEM-2, MEM-5]

Modem reset clears indices and state but preserves shared payload bytes.
Software must reserve that payload while using the modem. Impossible
Mission lends it to speech only while the modem is idle; using the modem
and that audio concurrently would corrupt data ownership.

RAM80 snapshots save both backings: `PLUS4MEM` contains the 64 KiB, and
`PLUS64` the 16 KiB together with registers and latched video. The VSF
container is 2.1 with plus/64 enabled, the PLUS64 module is 1.0, and the
current scenery format is22: these are distinct numbers. Serialized sizes
include peripheral state and host buffers and do not increase the guest
budget. Legacy snapshots lacking complete RAM80 state are refused. Active
modem connections cannot be restored; saving is refused while connected
or dialing.

## 2.6 IRQs and timers: the host remains TED

plus/64 does not add a C64 CIA. There are no new CIA registers at
`$DCxx/$DDxx`, or a modem/SID NMI. Use native TED resources for interrupts:
[MEM-4, MEM-6]

| Registers | Function |
|---|---|
| `$FF00/$FF01` | Timer 1, low/high byte |
| `$FF02/$FF03` | Timer 2, low/high byte |
| `$FF04/$FF05` | Timer 3, low/high byte |
| `$FF09` | IRQ flags: raster bit 1, timer 1 bit 3, timer 2 bit 4, timer 3 bit 6; bit 7 summarizes an active enabled IRQ |
| `$FF0A` | IRQ mask at the same bit positions; bit 0 contains the programmed raster line's high bit |
| `$FF0B` | Programmed raster line's low byte |

Writing a timer's low byte stops it; writing its high byte starts it.
Timer 1 reloads its configured value. After their first underflow, timers
2 and 3 continue with period 65,536. An initial zero means 65,536. The
model counts one tick every two TED base clocks: PAL
`1,773,447 / 2 = 886,723.5 Hz`, not one generic 6502 instruction cycle.
Separate low/high reads are not an atomic latch. If a consistent sample is
needed, check rollover, for example by reading high/low/high.

TED flags are acknowledged by writing the bits to clear to `$FF09`; they
do not copy CIA flag semantics. `SEI` masks a TED IRQ: it does not replace
a C64 NMI that could interrupt with `I=1`. C64 audio drivers or loaders
dependent on CIA/NMI require an analysed adapter, not indiscriminate
address substitution.

## Chapter references

Inventories must refer to the same source revision. Edition 1.0's old line
numbers are not references for the current version.

- **MEM-1:** `src/plus4/plus64_memory.c` and `.h`: `bind_views`, `p64_memory_bind_main_ram`, `p64_memory_read/write`, backing constants.
- **MEM-2:** `src/plus4/plus64vice.c`: `plus64_set_enabled`, `plus64_set_main_ram`, `plus64vice_ram_size_allowed`, snapshot API.
- **MEM-3:** `src/plus4/plus4mem.c`: RAM decoder, native/MainRAM profiles, rejection of incompatible expansions.
- **MEM-4:** `src/plus4/ted-mem.c` and `plus4mem.c`: ROM/RAM and I/O selections.
- **MEM-5:** `src/plus4/plus64_sprite.h`, `plus64_modem.h` and corresponding `.c`: shared views and modem payload.
- **MEM-6:** `src/plus4/ted-timer.c`, `ted-irq.c`, `ted-mem.c`: timers, IRQs and `ted09_store`, `ted0a_store`, `ted0b_store`.
