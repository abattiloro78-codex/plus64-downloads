# Debugging, tools and reuse of C64 code

## Keep the kinds of evidence separate

| Test | What it demonstrates |
| --- | --- |
| Python calculation | Data formats, addresses and transformations in the analysis program |
| 6502 simulation with peripheral stubs | Instruction execution and the contract of the stubs used |
| Actual C device modules | Register and renderer behaviour in the compiled functions |
| Native VICE | Interaction between guest CPU, TED and the model’s devices |
| Windows PE under Wine | Behaviour of that executable and the simulated host APIs |
| Native Windows | Execution on a real Windows system |
| Physical cartridge | Electrical and temporal behaviour measured on hardware |

A “PASS” line is meaningful only together with its version, inputs and scope.
A test using a prepared final state tests the ending; it does not demonstrate
a whole campaign won naturally. The SDK manifest lists tests actually run,
without promoting them to physical certification.

## A practical check for every new build

- Check that code and data remain within the common machine’s
  **65,536 + 16,384 bytes**, without double-counting aliases, caches,
  compressed sources and decoded buffers reused in different phases.
- Test first boot, reset and return to the title.
- Test boundaries: X255/256, X319, Y199 and data spanning an SRAM bank.
- Test an opaque sprite pixel 0 and transparent pixel 255 on the same background.
- Read the latch once, then check that it clears and records new events.
- Measure the rhythm during HUD updates, shots, collisions and scene changes.
- Check muting, note release and SID frequencies with the selected clock.
- Preserve the previous version and hashes of the executable and D64.

Do not automatically widen tolerances because a test fails: first distinguish
a program problem from observation or host configuration. For example,
missing audio output in a Wine test without an audio device does not prove
an error in SID registers.

## Monitor and captures

Use breakpoints at known functions, RAM captures and images of the VICE
canvas. For side-effecting registers, distinguish `read` from `peek`; the
monitor may deliberately avoid consuming FIFOs or latches. A CPU-read test
must execute a guest `LDA`.

Compare images with state from the same phase of the frame. If a sprite
changes descriptor halfway down the screen, a later RAM read does not by
itself reconstruct what has already been drawn in the upper lines. For
multiplexing, record the raster band, slot, pointer and published mask.

The diagnostic `@k` input used by some project tools must be interpreted
according to that tool’s contract or observer build: it is not a plus/64
register available to the program and must not be assumed to be a portable
command in a Windows distribution. Games read the emulated keyboard or
joystick, as in the SDK example.

## Why a C64 port is not a global address replacement

Data representing an address may occur as operands, pointer tables,
generated code or calculated values. A number equal to `$D400` inside a
bitmap is not thereby a SID write. Code may also depend on VIC-II, CIA,
ROMs, vectors or timing absent from the C16/Plus/4.

A useful procedure is:

1. Identify the input by hash and reconstruct its actual loading.
2. Disassemble from known entry points and follow control flow.
3. Mark indirect jumps and unresolved parts without guessing.
4. Separate hardware-independent logic from device accesses.
5. Define replacements for explicit sites and profiles, checking operands.
6. Preserve game behaviour and compare observable sequences.

The distributed toolkit includes `translate_core.py` for D64 inventory,
extraction and analysis, 6502 libraries and builders for known profiles.
The documented decoder covers the 151 official NMOS6502 opcodes; that is not
a promise that every game or undocumented opcode can be converted
automatically.

Patches for a known dump do not apply to a different copy simply because it
has the same name. The output of RAM analysis is not automatically a
bootable D64: loading, services, input, graphics, audio and game state must
be integrated and tested.

## A first learning path

Start with the SDK example; add a second sprite and a collision, then an
animation table in SRAM. Only then add loading, scrolling or multiplexing.
The manual and example describe current APIs; addresses or drivers of a
future physical implementation must be documented separately when they
are defined and verified.

## Snapshots, restoration and versions to check

A checkpoint test must compare all RAM80, not only the visible CPU window:
65,536 main bytes plus 16,384 internal bytes. First check immediate restore,
then continuation with the same inputs, preferably also in a fresh process
and on the other C16/Plus/4 model. Record the VSF container revision,
PLUS64 module, memory configuration and video features; a successful read
alone does not prove that the same profile was restored.

The current runtime uses Plus/4 VSF container 2.1 and PLUS64 module 1.0, with
SRAM protocol `$05`, modem `$03` and scenery revision22. Legacy checkpoints
missing required RAM80 bytes are refused. A connected or dialing modem
prevents saving and loading: the test must not promise to rewind a remote
peer. For SID, distinguish digital state and register writes from identity
of analogue PCM or host resampling history.

## Historical distribution identity (edition2.0)

The previous edition’s Windows executable without debug symbols is **6,617,154 bytes**
and has SHA256:

```text
08d3e87f84140fe13014213beb32bf7635de12b715769d995efc0658bf08ddfa
```

Removing debug symbols does not change the loaded code and data sections;
the distribution report preserves that comparison and provenance from the
complete build. The Impossible Mission REV8R D64 retains the code and data
of its qualified revision. Trials with pieces or a password already ready
are separate test states, not the normal game and not a natural win that
can certify the whole mission.

Linux C16/Plus/4 tests and Windows-executable tests through Wine remain
distinct from native Windows and physical hardware. Comparing RAM bytes
and registers does not itself qualify future bus arbitration, CPU/video
contention, compositor bandwidth or synchronization in a real cartridge.


This historical identity does not identify the new delivery. For C8 and scenery 22 use chapter 9 evidence; isolated bytecode, stubbed CPU loading and native gameplay are distinct levels. The final release report remains pending.
