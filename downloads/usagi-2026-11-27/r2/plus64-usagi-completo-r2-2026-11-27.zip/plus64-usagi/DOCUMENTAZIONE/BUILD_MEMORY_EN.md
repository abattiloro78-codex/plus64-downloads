# 9. Build, memory and release evidence

| Field|Value |
|---|---|
| Candidate | `033-approved178-r8` |
| MAIN SHA256 | `4035fde92fcec99cce803a8fe9e739f31b6ae2d9b241994dfc143433c2a9a321` |
| D64 SHA256 | `e7378e4e0d85588b300d668d62de675fa7d1a8fe165635fc3da2c096d9daa3a8` |
| Windows PE SHA256 | `8c3903f1b473034a174a8f6bd81af855a2d7830040998c863dbda45dc3634b40` |
| Linux headless SHA256 | `ea718e51a8b1b01972808ded9cd00cfc2bbb4ed0ec7d288efb40e01f498c3c2c` |
| Scenery / sprite material capability | 22 / 8 |
| MAIN / AUX / total | 65536 / 16384 / 81920 |
| Additional guest backing | 0 |
| P64Fv4 source archive | 10409 bytes, MAIN84D0..AD78 |
| SVM4 / P64Z method2 | 6294 bytes, AUX02E0..1B75 |
| Active BG packet capacity | 7376 bytes |
| Largest actual packet | 7376 bytes |
| All 17 packets on disk | 53802 bytes |
| BG MAIN half-open interval | [44409, 51785] |
| Loader half-open interval | [51785, 53063] |
| ROM-call stub half-open interval | [18308, 18405] |
| LOAD workspace saved | 3838 bytes |
| Temporary existing MAIN output-plane lease | 2848 bytes |
| Temporary existing AUX lease | 990 bytes |

The contract remains **64 KiB MAIN +16 KiB AUX =81,920 bytes**, with zero additional guest backing. Code, music, fonts, TED matrices, descriptors, compressed source and materials share these bytes. Memory views are aliases, not extra pools.

Backgrounds `B01`..`B17` are stored on disk, while only the active scene packet is loaded into its MAIN slot. A scene change may pause for loading; rendering never consults a host asset catalogue or file. The recovered 8825-byte MAIN region is shared by a 7376-byte background slot, 1278 bytes of resident loader code and a 171-byte reserve; these uses are counted once. During LOAD, KERNAL workspace is temporarily saved in the declared output-matrix and AUX leases. After restoration, the constructor rebuilds the matrices and preserves source byte D798 required for scrolling. Capacity and simultaneous peak use matter, not summed disk files or ZIP/EXE size.

The timer fix checks the TED beam again after IRQ arming, avoiding a full-frame wait if the deadline has passed. P64Z1 and its stored bytes are unchanged; libdeflate 1.26 accelerates zlib decompression in the runtime. Sprite views retain their single-call lifetime. Explicit P64B work may last until frame end, with a complete input-byte comparison before every reuse; it is discarded at frame end, reset, reconfiguration or snapshot loading. It retains no images or game catalogue between frames. Encoded input, expansion and index are temporary host work, not guest RAM.

The receipts below bind these hashes and distinguish isolated tests, actual D64 cold starts, real PC inputs and coverage limits. The native Linux build is headless for development/QA; the Linux GUI launchers use the same PE through Wine64. Wine is not native Windows or physical hardware. No completed campaign is claimed.

## Temporary host renderer work

x86_64 measurements and bounds exclude allocator headers and C stack. Declared row arrays add960bytes. These bytes are host emulator scratch, inaccessible to the game and discarded within the frame. They are not guest RAM or proof of electrical feasibility.

| Field|Bytes |
|---|---:|
| Maximum input | 65535 |
| Maximum expansion | 65535 |
| Validated index | 7184 |
| Context | 56 |
| M1 heap bound | 142694 |
| Conservative M2 heap bound | 196662 |
| Measured heap peak across17packets | 39198 |
| Heap held within a frame, measured maximum | 34814 |

- `reference/receipts/fix-00-QUALIFICATION_FINAL.json` — SHA256 `17d9acd1d0d6c5ec5d3958a25a4d39b8b12f7650c06ce6a8161444f9f5689819`
- `reference/receipts/fix-01-MULTILOAD_BUILD.json` — SHA256 `b4325e153db9afcb1e615969be6c65f268a86fe3ea3bd6fd33ba3e3d3c153e71`
- `reference/receipts/fix-02-MEMORY.json` — SHA256 `68cda8589b5e939b111cdda7398b4e17dc3fc1b81b9f5248fe88d00d922d021e`
- `reference/receipts/fix-03-NEW_CORE_NATURAL_L1_PROOF.json` — SHA256 `8127412a7e6e0d13d90528073d32dcea83e1877fe0a148e32502105c5beab914`
- `reference/receipts/fix-04-PROOF.json` — SHA256 `3543da1cc15f8aceedf1b4604f98f0cbcb5430c191a48f935c497acdd6a9717d`
- `reference/receipts/fix-05-LIFECYCLE.json` — SHA256 `98dbe5ba8c9a454983719882ab9b7db55566fa55102d5be8827faa75a7184ade`
- `reference/receipts/fix-06-PROOF.json` — SHA256 `0fcd8443634c0ad6d9b41c48590d27ae95175d2d7bf40954a52b0f490a6d1da8`
- `reference/receipts/fix-07-PROOF.json` — SHA256 `4bd91005feb90b14414f691be2260de990c17adaa7299afa49d39fa53f525deb`
- `reference/receipts/fix-08-REBUILD_PROOF.json` — SHA256 `fc2086a3e8ab10b8e07c1de6fa4b754375243114b45a1de95798adc3b1379c66`
- `reference/receipts/fix-09-VISIBLE_BLOOD_PROOF.json` — SHA256 `125855732e382b0dc5591acbd1a938e0404131c1b7a1071d314a06c5d6723e17`
- `reference/receipts/fix-10-ACTUAL_VS_PUBLISHED_COMPARISON.json` — SHA256 `7ee8a24f12ac43f4687f34f3dd57a70cf4d47d0470dcbbdc6bdf7dcbaf097db4`
- `reference/receipts/fix-11-LITERAL_PUBLISHED_PNG_PROOF.json` — SHA256 `99b2747a2ea83f86dc2b5f9aaac1cc3a6e296290befb4129cf0c27461c7281cd`
