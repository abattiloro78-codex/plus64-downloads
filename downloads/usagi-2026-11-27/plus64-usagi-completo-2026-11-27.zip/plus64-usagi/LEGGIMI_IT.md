# Usagi Yojimbo plus/64 — pacchetto completo, 27 novembre 2026

Questo ZIP contiene tutto l'occorrente per Windows: emulatore plus/64, ROM, librerie, ultimo USAGI.D64 con gli sfondi09/10 aggiornati, manuale tecnico per programmare plus/64 in italiano e inglese e sorgenti completi corrispondenti.

Estrai tutto lo ZIP in una nuova cartella scrivibile. Apri la cartella plus64-usagi e fai doppio clic su AVVIA_USAGI.cmd. AVVIA_USAGI_PLUS4.cmd seleziona l'ospite Plus/4; entrambi usano lo stesso gioco e64+16KiB. Non serve applicare gli aggiornamenti precedenti. Gli avviatori FLUIDO sono alias dello stesso profilo.

Nel menu: F1 seleziona GAME, F3 joystick/tastiera, F5 English/Italian, F7 o FIRE avvia. Joystick da tastiera: frecce e Spazio. In gioco F7 mette in pausa/riprende (rilascia il tasto fra le pressioni), F1 torna al menu. Comandi originali in modalità tastiera: Q su, P destra, I sinistra, Z giù, Spazio fire.

Contiene le correzioni già distribuite a scorrimento, alberi, contadini e colori; nel09 le parti nere fra i tronchi sono verdi scuri, nel10 tutti i12alberi usano i materiali approvati dello01. MAIN e runtime sono identici all'ultima versione consegnata; questo è un assemblaggio completo, senza ulteriori modifiche al gioco.

DOCUMENTAZIONE: manuali tecnici IT/EN e addendumcamera23 in AGGIORNAMENTI. SORGENTI: unica copia completa dei sorgenti attuali di emulatore e gioco; game-final/rebuild_final.py ricostruisce il disco. PROVE: verifiche attuali dell'archivio e dei due sfondi; STORICO_R8 contiene rapporti storici. Budget guest64KiB MAIN +16KiB AUX =81920byte, inclusi sprite/cache/audio; i file su disco non sono tutti residenti contemporaneamente.

Linux: gli script AVVIA_USAGI_LINUX.sh e AVVIA_USAGI_PLUS4_LINUX.sh usano Wine64, da installare separatamente. STRUMENTI_SVILUPPO_LINUX conserva strumenti storici di sviluppo/QA, non l'avviatore del gioco. Le verifiche documentate sono Linux/Wine e controlli di dati/ricostruzione; questo nuovo archivio non aggiunge una prova Windows nativa, su hardware fisico o di una campagna completa. Licenze e crediti originali sono conservati.
