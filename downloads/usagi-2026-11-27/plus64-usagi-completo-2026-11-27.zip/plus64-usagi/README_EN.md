# Usagi Yojimbo plus/64 — complete package, 27 November 2026

Everything required for Windows is included: plus/64 emulator, ROMs, libraries, the latest USAGI.D64 with scenery09/10 updates, Italian and English plus/64 programming manuals and complete corresponding sources.

Extract the entire ZIP into a new writable folder. Open plus64-usagi and double-click AVVIA_USAGI.cmd. AVVIA_USAGI_PLUS4.cmd selects the Plus/4 host; both run the same game with64+16KiB. No previous updates are needed. FLUIDO launchers are aliases for the same settings.

Menu: F1 selects GAME, F3 joystick/keyboard, F5 English/Italian, F7 or FIRE starts. Keyboard joystick: arrows and Space. In game F7 pauses/resumes (release between presses), F1 returns to the menu. Original keyboard mode: Q up, P right, I left, Z down, Space fire.

All previously delivered scrolling, tree, farmer and colour fixes are retained. Scenery09 replaces opaque black undergrowth with dark greens; all12trees in scenery10 use the approved scenery01 materials. MAIN and the runtime are identical to the latest delivered versions; this is a complete assembly with no further game-code changes.

DOCUMENTAZIONE contains the IT/EN technical manuals and scenery23 camera addenda in AGGIORNAMENTI. SORGENTI holds a single complete current emulator/game source archive; game-final/rebuild_final.py rebuilds the disk. PROVE contains current package/artwork checks and historical R8 reports. Guest memory remains64KiB MAIN+16KiB AUX=81920bytes, including sprites/cache/audio; disk files are not all resident at once.

Linux launchers use Wine64, installed separately. STRUMENTI_SVILUPPO_LINUX holds historical development/QA tools rather than the game launcher. Documented checks cover Linux/Wine, data and source rebuilds; this new archive does not add a Windows-native, physical-hardware or full-campaign playtest. Original licences and credits are retained.
