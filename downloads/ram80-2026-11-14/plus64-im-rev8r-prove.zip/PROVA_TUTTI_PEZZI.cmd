@echo off
setlocal
cd /d "%~dp0"
if not exist "xplus4.exe" goto missing
"xplus4.exe" -default -model c16 -directory "." -kernal kernal-318004-05.bin -ramsize 16 -plus64mainram -plus64packedcache -plus64leftmcm -plus64mixedsprites -plus64rastercollisions -drive8type 1541 -trapdevice8 -busdevice8 -sound -sidenginemodel 256 -sidcartaddress 0xFD40 -sidcartclock 0 -controlport2device 1 -joydev2 1 -initbreak 0x0200 -moncommands "PROVA_TUTTI_PEZZI.mon" -autostart "GIOCHI/IMPOSSIBLE_MISSION_PROVA_TUTTI_PEZZI.d64"
exit /b
:missing
echo Estrai questa prova nella cartella della REV8R, dove si trova xplus4.exe.
pause
exit /b 1
