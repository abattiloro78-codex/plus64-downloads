@echo off
setlocal
cd /d "%~dp0"
:menu
cls
echo plus/64 RAM80 - 64+16 KiB
 echo 1. Impossible Mission a colori REV8R
 echo 2. PRISM INVADERS
 echo 3. Demo SDK RAW8 e SID
 echo 4. Demo materiali 121 colori
 echo 5. Esci
choice /c 12345 /n /m "Scegli: "
if errorlevel 5 exit /b
if errorlevel 4 goto materiali
if errorlevel 3 goto sdk
if errorlevel 2 goto prism
call AVVIA_IMPOSSIBLE_MISSION.cmd
goto menu
:prism
call AVVIA_PRISM_INVADERS.cmd
goto menu
:sdk
call AVVIA_SDK_RAM80.cmd
goto menu
:materiali
call AVVIA_MATERIALI_RAM80.cmd
goto menu
