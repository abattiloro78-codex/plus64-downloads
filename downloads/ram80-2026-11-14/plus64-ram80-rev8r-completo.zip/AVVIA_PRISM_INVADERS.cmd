@echo off
setlocal DisableDelayedExpansion
set "PLUS64_RUNTIME=%~dp0"
set "PLUS64_DISK="
if not "%~1"=="" set "PLUS64_DISK=%~f1"
cd /d "%PLUS64_RUNTIME%"
if not exist "%PLUS64_RUNTIME%xplus4.exe" goto missing_runtime
if defined PLUS64_DISK goto check_disk
set "PLUS64_DISK=%PLUS64_RUNTIME%GIOCHI\PRISM_INVADERS.d64"
if exist "%PLUS64_DISK%" goto check_disk
set "PLUS64_DISK=%PLUS64_RUNTIME%PRISM_INVADERS.d64"
:check_disk
if not exist "%PLUS64_DISK%" goto missing_disk
for %%I in ("%PLUS64_DISK%") do if /I not "%%~xI"==".d64" goto wrong_disk
"%PLUS64_RUNTIME%xplus4.exe" -default -model c16 -ramsize 16 -plus64 -plus64rastercollisions -directory "%PLUS64_RUNTIME%." -kernal kernal-318004-05.bin -sound -soundbufsize 64 -sidenginemodel 256 -sidcartaddress 0xFD40 -sidcartclock 0 -controlport2device 1 -joydev2 1 -drive8type 1541 -trapdevice8 -busdevice8 -autostart "%PLUS64_DISK%"
if not "%errorlevel%"=="0" goto failed
exit /b 0
:missing_runtime
echo Estrai tutto plus64-vice-runtime.zip prima di avviare il gioco.
echo Extract the whole runtime ZIP before starting the game.
goto error
:missing_disk
echo Copia PRISM_INVADERS.d64 nella cartella GIOCHI del runtime.
echo Oppure trascina il tuo file D64 su questo avviatore.
echo Put PRISM_INVADERS.d64 in GIOCHI, or drop the D64 onto this launcher.
goto error
:wrong_disk
echo Questo avviatore richiede un'immagine disco .d64.
echo This launcher requires a .d64 disk image.
goto error
:failed
echo VICE non ha completato l'avvio. Conserva il messaggio di errore.
echo VICE did not complete startup. Keep its error message.
:error
pause
exit /b 1
