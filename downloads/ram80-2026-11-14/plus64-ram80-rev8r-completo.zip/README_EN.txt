PLUS/64 RAM80 - REV8R DISTRIBUTION

Extract program and library ZIPs into the SAME new writable folder.
The complete ZIP already combines both. Launch AVVIA_PLUS64.cmd or
AVVIA_IMPOSSIBLE_MISSION.cmd. Use this modified VICE, not stock VICE.

Included: enhanced Impossible Mission, PRISM INVADERS, RAW8/SID SDK demo
and native16K material demo. Optional test saves are a separate download.
The separate technical manual/SDK contains programming docs and source.

Impossible Mission uses numeric keypad8/2/4/6 for directions and keypad0
for FIRE; F12 opens the menu. Alt+S/L save/load a complete VSF snapshot.
The original game's disk SAVE records high scores, not a full checkpoint.

Exactly64KiB cartridge+16KiB internal=81920guest bytes. Sprite/audio/modem
payloads share this storage. EXE/archive/snapshot sizes are not guestRAM.
Software prototype only. Linux C16/Plus4 and Windows-under-Wine tests;
no nativeWindows, physicalhardware or naturally completed mission claim.
Only debug information was removed from the qualified Win64 executable.
An intermittent robot-shock report during searching remains unchanged by
agreement. Licences included; full GPL sources supplied separately.
