@echo off
setlocal DisableDelayedExpansion
set "PLUS64_RUNTIME=%~dp0"
set "PLUS64_DISK="
if not "%~1"=="" set "PLUS64_DISK=%~f1"
cd /d "%PLUS64_RUNTIME%"
if not exist "%PLUS64_RUNTIME%xplus4.exe" goto missing_runtime
if defined PLUS64_DISK goto check_disk
set "PLUS64_WORK=%PLUS64_RUNTIME%SALVATAGGI\IMPOSSIBLE_MISSION_SCENARI_REV8R_RAM80_PARTITA.d64"
if exist "%PLUS64_WORK%" goto use_work
set "PLUS64_BASE=%PLUS64_RUNTIME%GIOCHI\IMPOSSIBLE_MISSION_SCENARI.d64"
if exist "%PLUS64_BASE%" goto make_work
set "PLUS64_BASE=%PLUS64_RUNTIME%IMPOSSIBLE_MISSION_SCENARI.d64"
if not exist "%PLUS64_BASE%" goto missing_disk
:make_work
if not exist "%PLUS64_RUNTIME%SALVATAGGI" mkdir "%PLUS64_RUNTIME%SALVATAGGI"
if not exist "%PLUS64_RUNTIME%SALVATAGGI" goto copy_failed
if exist "%PLUS64_WORK%" goto use_work
copy /b "%PLUS64_BASE%" "%PLUS64_WORK%" >nul
if errorlevel 1 goto copy_failed
echo Creata la copia di lavoro in SALVATAGGI. Sara' riutilizzata ai prossimi avvii.
echo A working disk was created in SALVATAGGI and will be reused next time.
:use_work
set "PLUS64_DISK=%PLUS64_WORK%"
:check_disk
if not exist "%PLUS64_DISK%" goto missing_disk
for %%I in ("%PLUS64_DISK%") do if /I not "%%~xI"==".d64" goto wrong_disk
"%PLUS64_RUNTIME%xplus4.exe" -default -model c16 -directory "%PLUS64_RUNTIME%." -kernal kernal-318004-05.bin -ramsize 16 -plus64mainram -plus64packedcache -plus64leftmcm -plus64mixedsprites -plus64rastercollisions -drive8type 1541 -trapdevice8 -busdevice8 -sound -sidenginemodel 256 -sidcartaddress 0xFD40 -sidcartclock 0 -controlport2device 1 -joydev2 1 -autostart "%PLUS64_DISK%"
if not "%errorlevel%"=="0" goto failed
exit /b 0
:missing_runtime
echo Estrai tutto plus64-vice-runtime.zip prima di avviare il gioco.
echo Extract the whole runtime ZIP before starting the game.
goto error
:missing_disk
echo Copia IMPOSSIBLE_MISSION_SCENARI.d64 nella cartella GIOCHI del runtime.
echo Oppure trascina il tuo file D64 su questo avviatore.
echo Put IMPOSSIBLE_MISSION_SCENARI.d64 in GIOCHI, or drop the D64 onto this launcher.
goto error
:wrong_disk
echo Questo avviatore richiede un'immagine disco .d64.
echo This launcher requires a .d64 disk image.
goto error
:copy_failed
echo Impossibile creare la copia di lavoro. Estrai il runtime in una cartella scrivibile.
echo Cannot create the working disk. Extract the runtime into a writable folder.
goto error
:failed
echo VICE non ha completato l'avvio. Conserva il messaggio di errore.
echo VICE did not complete startup. Keep its error message.
:error
pause
exit /b 1
