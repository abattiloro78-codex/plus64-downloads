@echo off
setlocal
cd /d "%~dp0"
"xplus4.exe" -default -model c16 -ramsize 16 -plus64 -plus64packedcache -plus64leftmcm -plus64mixedsprites -plus64rastercollisions -directory "." -kernal kernal-318004-05.bin -drive8type 1541 -trapdevice8 -busdevice8 -autostart "SDK_MATERIALI/MATERIAL.d64"
