# Corresponding source for the active sprite-format executable

The active `xplus4.exe` includes the optional mixed-RAW8 and compact-material
extension. The previous archives and manifests remain the baseline history;
they do not describe the active executable by themselves.

1. Reconstruct the original RAM80 snapshot source using `SOURCE_REBUILD.md`.
2. From the resulting `vice-3.10` source root, apply the final overlay:

```sh
patch --batch --fuzz=0 -p1 -i /absolute/runtime/licenses/vice-plus64-source/sprite-formats/from-ram80-snapshot.patch
```

`licenses/vice-plus64-source/sprite-formats/SOURCE_CHANGES.json` gives the
before/after SHA256 for every changed source file and the active executable
SHA256. Complete copies of those four changed sources are beside it. The
original GPL source archive, all other unchanged source, and licence notices
remain supplied in the original corresponding-source bundle.

`WINDOWS_BUILD.json` records the fresh Win64 cross-build, toolchain versions,
configure flags and complete input-file hashes. Unlike the historical
incremental recipe, this active executable was built without old objects or
archives. The repository also provides the cold recipes
`cloud/native/build_native.py` and `cloud/cross/build_windows.py`.

The extension defaults off. The new colour launcher enables it and uses the
new sphere disk. Original launchers keep their previous format selection.
The active executable passed Linux game A/B and Win64-under-Wine checks on
C16 and Plus/4. Native Windows and physical hardware were not tested.

La revisione palette corrente REV3 corregge i massimi di tuta e pettorale;
il confronto va fatto con gli screenshot effettivi, non con le tavole RGB.
