/* plus/64 adapter for VICE xplus4 -- experimental integration. */
#ifndef PLUS64_VICE_H
#define PLUS64_VICE_H
#include <stddef.h>
#include <stdint.h>
int plus64vice_resources_init(void);
int plus64vice_main_ram_enabled(void);
int plus64vice_native_ram_enabled(void);
/* Resource guard and test/snapshot views; no additional guest registers. */
int plus64vice_ram_size_allowed(int size);
int plus64vice_memory_hack_allowed(int value);
/* Snapshot-only resource setup must rebuild decode tables without a reset. */
int plus64vice_snapshot_restoring(void);
size_t plus64vice_memory_budget(void);
uint8_t *plus64vice_host_ram(void);
uint8_t *plus64vice_cart_bank(unsigned bank);
int plus64vice_cmdline_options_init(void);
void plus64vice_shutdown(void);
void plus64vice_reset(void);
void plus64vice_frame(void);
struct raster_s;
void plus64vice_overlay_line(struct raster_s *raster, unsigned int line);
/* Backward-compatible standalone indexed render entry. */
void plus64vice_draw_indexed_frame(uint8_t *pixels,size_t stride);
struct snapshot_s;
int plus64vice_snapshot_write_allowed(void);
int plus64vice_snapshot_write_module(struct snapshot_s *s);
/* Validate/stage before any CPU/TED/resource mutation. */
int plus64vice_snapshot_prepare_read(struct snapshot_s *s, const char *filename);
int plus64vice_snapshot_has_pending_read(void);
int plus64vice_snapshot_configure_read(void);
void plus64vice_snapshot_apply_read(void);
void plus64vice_snapshot_discard_read(void);
int plus64vice_background_lighting(void);
#endif
