# 4. SID and modem

The SID produces audio; the modem exposes a polled byte stream. Neither
provides a CIA or an NMI interrupt to the program. The addresses and clocks
below belong to the current RAM80 implementation, distributed with PE SHA256
`08d3e87f84140fe13014213beb32bf7635de12b715769d995efc0658bf08ddfa`
(6,617,154 bytes, with debug symbols removed without changing the loaded code
and data sections). The previous manual’s `SID_API.json` and `MODEM_API.json`
inventories remain historical evidence; the current source and the updated
statements in this chapter define current capacities and protocols.

## 4.1 Enabling a SID with reproducible settings

Enabling plus/64 activates VICE’s SIDcart if it is not already active, without
overwriting a SIDcart configured by the user. A launcher must therefore
specify its address, model and clock after `-default` and the machine-model
selection. For the audio profile used by the distributed games:

```text
-sound -sidenginemodel 256 -sidcartaddress 0xFD40 -sidcartclock 0
```

`256` selects reSID/MOS6581; `257` selects reSID/MOS8580. These are not registers
that a game can change by writing a byte. The two models differ in analogue
behaviour, filters and digital-sample behaviour: choose one and test the game
with that model. [SID-1, SID-2]

### The actual window ends at `$FD5D`

The VICE device registers **`$FD40..$FD5D`**, with internal mask `$1F` and
`IO_MIRROR_NONE`. This SIDcart does not decode `$FD5E` or `$FD5F` as SID
registers. Do not use those addresses as mirrors or new registers. The
conventional description “32 SID registers” does not extend the actual
registered window. An alternative configuration exists at `$FE80..$FE9D`,
but it is not the plus/64 profile used here. [SID-1]

## 4.2 SID register map

The three voices share the same seven-register layout. `b` is the voice base:
`$FD40`, `$FD47` or `$FD4E`. The offsets below are relative to that base, not
to the C64’s `$D400`. [SID-3]

| Register | Voice 1 | Voice 2 | Voice 3 | Bits and use |
|---|---|---|---|---|
| `b+0` | `$FD40` | `$FD47` | `$FD4E` | Frequency, low byte |
| `b+1` | `$FD41` | `$FD48` | `$FD4F` | Frequency, high byte |
| `b+2` | `$FD42` | `$FD49` | `$FD50` | Pulse width, bits 0–7 |
| `b+3` | `$FD43` | `$FD4A` | `$FD51` | Pulse width, bits 8–11 in bits 0–3; other bits do not change the width |
| `b+4` | `$FD44` | `$FD4B` | `$FD52` | Waveform and gate control |
| `b+5` | `$FD45` | `$FD4C` | `$FD53` | Attack in bits 7–4, decay in bits 3–0 |
| `b+6` | `$FD46` | `$FD4D` | `$FD54` | Sustain in bits 7–4, release in bits 3–0 |

The control register uses these bits:

| Bit | Mask | Function |
|---:|---:|---|
| 0 | `$01` | GATE: a 0→1 edge starts attack; a 1→0 edge starts release |
| 1 | `$02` | Oscillator SYNC to the source voice |
| 2 | `$04` | Ring modulation for the triangle component |
| 3 | `$08` | TEST: oscillator control/reset, not a general ADSR reset |
| 4 | `$10` | Triangle |
| 5 | `$20` | Sawtooth |
| 6 | `$40` | Pulse, with 12-bit width |
| 7 | `$80` | Noise |

Selecting several waveforms produces the SID’s combined waveforms, not an
arbitrary sum of generators. SYNC and ring modulation use the circular voice
connection; they require deliberate configuration of the source voice too.
For a new note, genuinely leave GATE low before the rising edge: rewriting
`$11` while GATE is already one does not start a new attack. Do not expect
TEST to clear the envelope counter. [SID-3]

### ADSR

Each A/D/S/R parameter is a nibble from 0 to 15. Sustain selects a level of
`nibble × $11`, from `$00` to `$FF`; it is not a duration. Attack, decay and
release select envelope rates. The reSID code preserves these rate-counter
comparison values:

| Nibble | reSID comparison value | Nominal attack stated in model comments |
|---:|---:|---:|
| 0 | 8 | 2 ms |
| 1 | 31 | 8 ms |
| 2 | 62 | 16 ms |
| 3 | 94 | 24 ms |
| 4 | 148 | 38 ms |
| 5 | 219 | 56 ms |
| 6 | 266 | 68 ms |
| 7 | 312 | 80 ms |
| 8 | 391 | 100 ms |
| 9 | 976 | 250 ms |
| A | 1953 | 500 ms |
| B | 3125 | 800 ms |
| C | 3906 | 1 s |
| D | 11719 | 3 s |
| E | 19531 | 5 s |
| F | 31250 | 8 s |

These times are nominal, not exact millisecond deadlines: they depend on the
clock and the counter’s state. Decay and release also use piecewise
exponential divisions, so do not use the attack column as their duration.
An ADSR change during a note can encounter the rate counter’s behaviour,
including the known ADSR delay. [SID-4]

### Filter, volume and reads

| Address | Use |
|---|---|
| `$FD55` | Low cutoff: bits 0–2 only |
| `$FD56` | High cutoff: eight bits; `cutoff = (high << 3) | (low & 7)` |
| `$FD57` | Resonance in bits 7–4; voice 1/2/3 and external-input routing into the filter in bits 0/1/2/3 |
| `$FD58` | Volume in bits 3–0; low-pass bit 4, band-pass bit 5, high-pass bit 6; bit 7 excludes voice 3 from the direct path |
| `$FD59` | POTX read, dependent on emulated inputs/configuration |
| `$FD5A` | POTY read, under the same constraint |
| `$FD5B` | Voice-3 oscillator output read |
| `$FD5C` | Voice-3 envelope read |
| `$FD5D` | SID offset `$1D`, without a defined synthesis function |
| `$FD5E/$FD5F` | Outside the registered SIDcart window |

The 11-bit cutoff is not a universal linear conversion to hertz: the filter
and chip model matter. The external-input bit does not demonstrate that an
analogue input path has already been built in a physical cartridge. Zero
volume silences the output without necessarily stopping oscillators or the
music sequence. [SID-3, SID-5]

Synthesis registers are **writable, not ordinary readable RAM cells**. A CPU
read from a write-only register returns the emulated SID bus behaviour, not
a reliable copy of its programmed value. Keep a RAM shadow of your values;
use `STA`, not `INC/ASL`, on SID registers. The emulator also models the
additional writes of read-modify-write instructions.

Debugger peek is different: `sid_peek_chip()` returns the `siddata` array of
last writes and does not actually sample OSC3/ENV3. With sound disabled, CPU
reads have a software fallback: do not use them to demonstrate an active
oscillator or as a random source independent of audio configuration. [SID-6]

## 4.3 Clocks: C64, TED and the “native” setting

For a periodic waveform, with 16-bit frequency value `N`:

```text
note_frequency = N × SID_clock_frequency / 2^24
N = round(note_frequency × 2^24 / SID_clock_frequency)
```

With `-sidcartclock 0`, the runtime initializes the PAL SID at **985,248 Hz**
(NTSC: 1,022,730 Hz). The bridge converts VICE’s base clocks into the SID
domain using a rational ratio and a retained remainder, even when only part
of the audio buffer is consumed. This does not make C64 and TED CPU-code
timing identical. [SID-1, SID-7]

**Pay attention to the meaning of `-sidcartclock 1` in this build:** the code
passes the machine’s `cycles_per_sec` value to the SID, which is
**1,773,447 Hz** in PAL. The option’s “PLUS4/native clock” name does not mean
886 kHz here. That is instead `1,773,447 / 2 = 886,723.5 Hz`, the TED timer
tick rate and one possible slow physical-clock choice; it is not the value
passed to the SID by option 1 of the preserved runtime. Do not copy 886 kHz
note tables into that profile. [SID-1, SID-7]

For example, A4 at approximately 440 Hz in the C64 PAL profile uses
`N=7493=$1D45`, with a calculated actual frequency of about **440.029 Hz**.
The low byte is `$45`, the high byte `$1D`. At initialization of a program
that owns the SID, a triangle note on the first voice can be set up as follows:

```asm
        lda #0
        sta $fd44       ; GATE low, no selected waveform
        sta $fd57       ; no filter routing in this example
        lda #$09
        sta $fd45       ; attack 0, decay 9
        lda #$f4
        sta $fd46       ; sustain F, release 4
        lda #$45
        sta $fd40
        lda #$1d
        sta $fd41
        lda #$0f
        sta $fd58       ; maximum volume, direct paths
        lda #$11
        sta $fd44       ; triangle + rising GATE edge
        rts
; Release the note in a later tick:
rilascio:
        lda #$10
        sta $fd44       ; same waveform, GATE low
        rts
```

The other two voices must be initialized or managed by your own driver.
The sample does not allocate a timer or impose a duration: the game tick
must decide when to call `rilascio`. If a music IRQ writes to the same SID,
coordinate writes with that driver.

VICE’s audio-buffer size, for example `-soundbufsize 64`, changes host latency,
not the note formula or IRQ frequency. A C64 conversion that used CIA/NMI
must adapt its scheduler separately: the SID does not generate those
interrupts.

## 4.4 Modem registers and state

The modem is available at `$FDF0..$FDF7` when plus/64 is enabled. It exposes a
**128-byte RX FIFO**, a **128-byte TX FIFO**, and a **256-byte command buffer**:
**512 bytes in total**, all included in the **80 KiB = 64 KiB cartridge plus
16 KiB internal RAM**. It is not an ACIA and contains no CIA registers.
The current backend uses the host computer’s TCP sockets. [MOD-1]

The FIFOs are not private modem memory. In the native profile they alias
cartridge bank 3, offsets `$3E00..$3FFF`; in MainRAM they alias the internal
16 KiB at offsets `$0000..$01FF`, also accessible through the sprite port.
The program must reserve the region before using the modem and avoid
concurrent writes from sprites, audio or other owners. While the modem is
disconnected, with no call, queues or partial command pending, a program
that performs no modem I/O may lend the region to other resources. It must
return it before starting commands or connections.

| Address | CPU read | CPU write |
|---|---|---|
| `$FDF0` DATA | Removes one RX byte; returns zero if empty | Feeds the parser in command mode; queues one TX byte when connected |
| `$FDF1` STATUS | Status bits in the next table | Ignored |
| `$FDF2` CONTROL | Always zero | Bit 0 reset; otherwise bit 1 disconnect; bit 2 clears overrun |
| `$FDF3` BAUD | Always `$04`, descriptive “9600” value | Ignored: it does not regulate a real serial port |
| `$FDF4` RX COUNT | Queued RX bytes, 0–128 | Ignored |
| `$FDF5` TX COUNT | Queued TX bytes, 0–128; not free space | Ignored |
| `$FDF6` | Signature `$64` | Ignored |
| `$FDF7` | Shared-protocol version `$03` | Ignored |

| STATUS bit | Mask | Meaning when set |
|---:|---:|---|
| 0 | `$01` | RX contains at least one byte |
| 1 | `$02` | TX has room for at least one byte, even while disconnected |
| 2 | `$04` | Connected |
| 3 | `$08` | Connection in progress |
| 4 | `$10` | Latched overrun: a local write or response exceeded available space |
| 5 | `$20` | Neither connected nor dialing; offline state, not a latched event |
| 6–7 | `$C0` | Zero in the current version |

An RX zero byte is valid data. Test STATUS bit 0 before reading DATA, without
interpreting zero as “FIFO empty”. Reading STATUS clears no flag. A device
peek at DATA shows the next byte without consuming it; an ordinary BASIC
`PEEK` is a CPU read and consumes it. Counts describe bytes actually queued
in the 128-byte buffers; the previous private capacity of 8 KiB per queue
no longer exists. [MOD-1]

CONTROL is a set of actions, not stored state: `$01` resets; `$02` interrupts
the link and puts `OK` in RX; `$04` clears only overrun. If both bits 0 and 1
are present, reset takes precedence; bit 2 is still processed afterwards.
There is no IRQ enable. Disconnect clears TX but preserves RX; reset empties
both FIFOs and the partial command, clears overrun, disconnects, and restores
echo-off. Reset changes indices and device state: **it does not zero the
shared RAM bank**. [MOD-1]

## 4.5 AT commands actually implemented

Send **ASCII** bytes, ending the command with CR (`$0D`). LF is ignored.
The parser is case-insensitive for commands but preserves the host name.
Responses take the form `CR LF text CR LF`. No network connection is needed
to test `AT`. [MOD-2]

| Command | Result |
|---|---|
| `AT` | `OK` |
| `ATE0` / `ATE1` | Disables/enables local byte echo in command mode; `OK` |
| `ATZ` | Modem reset and `OK` |
| `ATH` | Disconnect and `OK` when the parser is in command mode |
| `ATDhost` / `ATDThost` | Attempts TCP connection to port 23 |
| `ATDhost:port` / `ATDThost:port` | Decimal port 1–65535; nonempty host, at most 219 bytes |

Immediate connection or completion at the next poll produces `CONNECT 9600`.
Failure or link loss produces `NO CARRIER`. Unsupported commands or invalid
syntax produce `ERROR`. Do not assume `ATH0`, `+++` escape, S registers,
numeric response mode or concatenated command sequences: they are not
implemented.

The command buffer holds at most 255 printable characters; one more
character causes `ERROR`, clears the length, and is discarded. Backspace
(`$08`) and DEL (`$7F`) remove one character when present. With echo enabled,
control characters are queued too, before processing.

**When connected, every byte written to DATA is outgoing traffic.** The
string `ATH` is not interpreted locally, and `+++` does not change modes.
To close a connection from the program, use CONTROL bit 1. The parser stays
active while dialing: the program can cancel using CONTROL or `ATH`.

## 4.6 Polling, Telnet and backend limits

`machine_vsync_hook()` calls `plus64vice_frame()`, which polls the modem once
per video update. Reading STATUS does not force a poll. The poll advances
a pending connection, sends a contiguous portion of TX, and receives only
into the free contiguous span of the RX queue: at most 128 bytes, often less
because of occupancy or ring wrapping. A full RX queue prevents a socket
read and therefore applies backpressure to the transport. The “9600” speed
is descriptive: UART baud rate, serial bits, RTS/CTS and electrical timing
are not simulated. Provide game timeouts, frequent RX draining and overrun
checks. [MOD-3]

Input always passes through minimal Telnet handling:

- `IAC IAC` (`$FF $FF`) delivers one `$FF` byte to the game.
- `WILL` and `DO` are refused with `DONT` and `WONT`; `WONT/DONT` are consumed.
- Subnegotiations are discarded up to `IAC SE`.
- Ordinary data become RX bytes: there is no ASCII/PETSCII conversion.

This is not completely transparent binary TCP transport. Outgoing code queues
application bytes without automatically doubling `$FF`; a protocol with a
Telnet peer must handle that escape deliberately. The modem contains no
TLS, service authentication or HTTP protocol.

The socket is nonblocking, but name resolution through `getaddrinfo()` is
synchronous: an ATD command with a problematic name can temporarily stop
the emulator UI. For reproducible tests, use a local test service and a
timeout; do not interpret a DNS pause as a game timer. [MOD-4]

### Two nonblocking primitives

The caller retains a byte to send and retries on a later tick when TX is
full. A single component of the game must own the modem.

```asm
; A contains the byte on entry. Carry clear if accepted, set to retry.
modem_prova_tx:
        pha
        lda $fdf1
        and #$02
        beq tx_piena
        pla
        sta $fdf0
        clc
        rts
tx_piena:
        pla
        sec
        rts

; Carry set if A contains valid data, including $00; clear if empty.
modem_prova_rx:
        lda $fdf1
        and #$01
        beq rx_vuota
        lda $fdf0
        sec
        rts
rx_vuota:
        clc
        rts
```

In command mode, “accepted” means passed to the parser, not sent over TCP.
In data mode it means queued: it does not confirm receipt by the peer.
After a group of sends, also check overrun, connection state and responses.
For a local parser test, send `$41 $54 $0D` and collect the response without
an infinite wait loop.

## 4.7 What the model proves and what remains hardware work

Current VSF checkpoints preserve local state, indices and all shared RAM80
bytes. Saving and loading are refused while the modem is connected or
dialing because the external TCP peer cannot be rewound. Loading does not
automatically reconnect that peer.

The model documents registers, shared FIFOs and host socket APIs. It contains
no cartridge MCU firmware, electrical serial modem, measured SID clock,
analogue power circuitry or additional interrupt circuit. A physical
cartridge must satisfy the same visible behaviour; those implementations
and their memory budget require their own design and tests. This source
audit does not perform remote connections, a new Windows listening test,
or physical qualification.

## Chapter references

The following paths are relative to `reference/vice/` in the manual package
and identify current source. Historical inventories and version-1.0 tests
do not replace the distribution’s RAM80 and format-17 reports.

- **SID-1:** `src/plus4/cart/plus4-sidcart.c`, SIDcart I/O decoder,
  `sidcart_sound_machine_init`, enable and clock resources;
  `src/plus4/plus64vice.c`, plus/64 integration and configuration.
- **SID-2:** `src/sid/sid-cmdline-options.c`, SID engine/model selection.
- **SID-3:** `src/resid/sid.cc`, register reads and writes;
  `src/resid/wave.cc`, `wave.h` and `voice.cc`, waveform control,
  synchronization and ring modulation.
- **SID-4:** `src/resid/envelope.cc`, ADSR counters, tables and writes.
- **SID-5:** `src/resid/filter.cc`, cutoff, resonance and mode registers.
- **SID-6:** `src/sid/sid.c` and `src/resid/sid.cc`, read/peek paths,
  bus values and `siddata`.
- **SID-7:** `src/plus4/cart/plus64_sid_clock_ratio.h`, rational ratio;
  `src/plus4/plus4.h`, `plus4.c`, `src/sound.c`, `src/sid/sid.c` and
  `src/sid/resid.cc`, audio clock constants and bridge.
- **MOD-1:** `src/plus4/plus64_modem.h`, `P64_RX_CAP`, `P64_TX_CAP`,
  `P64_CMD_CAP`, shared-storage views and API; `plus64_modem.c`,
  `p64_modem_init/reset`, `status`, `p64_modem_peek/read/store`.
- **MOD-2:** `src/plus4/plus64_modem.c`, `command` and
  `stream_from_device` functions.
- **MOD-3:** `src/plus4/plus64_modem.c`, `telnet_in` and `p64_modem_poll`;
  `plus64vice.c`, call to `p64_modem_poll` in the video path.
- **MOD-4:** `src/plus4/plus64_net.c`, `net_open`, `net_state`, `net_send`
  and `net_recv`.
