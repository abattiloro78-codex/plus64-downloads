# How to use this manual

This manual is intended for writing new games for the **plus/64 software
model** implemented by the VICE runtime distributed with the project. It
describes the addresses actually decoded, the formats actually read by the
renderer, and the conventions checked by the examples. Access to an online
repository is not assumed: examples, constants and references are included
in the package.

**RAM80 documentation edition 2.0 — 14 November 2026. Meck project.**
The current reference is the 6,617,154-byte Windows runtime `xplus4.exe`,
SHA256 `08d3e87f84140fe13014213beb32bf7635de12b715769d995efc0658bf08ddfa`.
Debug sections have been removed from the final distribution; its executable
code is identical to the tested reference build. The edition number belongs
to the manual, not to a new electrical cartridge revision. The current RAM
port reports protocol `$05`; the PLUS64 snapshot module remains version 1.0,
and the current scenery format is 17.

## What the platform provides

The C16 or Plus/4 continues to supply the CPU, TED, keyboard, joystick and
KERNAL. Within the emulated model, plus/64 adds SID, a port accessing 64 KiB
of SRAM, eight sprite descriptors composited over TED video, and a register
modem. Sprites have a palette of 121 colours; TED retains its own palette
of 121 distinct colours. Each TED bitmap cell remains subject to the limits
of its video mode: 121 does not mean 121 colours per cell.

One `xplus4.exe` emulates both C16 and Plus/4. The program's name does not
identify a game version intended only for Plus/4. A program can use the same
API and memory budget on both machines. The native profile enforces 16 KiB
of CPU RAM even on Plus/4; MainRAM enforces 64 KiB of cartridge RAM as CPU
RAM. Total memory available to the program is always **64+16 KiB, or
81,920 bytes**.

## Two profiles to distinguish

| Profile | Use | Observable memory |
| --- | --- | --- |
| Native, recommended initially | New games and this manual's SDK | Code and TED use the internal 16 KiB; 64 KiB cartridge RAM is accessed through `$FDE8..$FDED`; the sprite port sees cartridge bank 2 |
| MainRAM | The Impossible Mission C64-engine adapter and advanced programs | CPU/TED and the SRAM port see the same 64 KiB cartridge RAM; the sprite port sees the separate internal 16 KiB |

The implementation has two payload backings: `mem_ram[65536]` and
`p64_aux_ram[16384]`. SRAM, sprite and modem views alias these bytes; they
are not additional pools. In the native profile the modem uses the last
512 bytes of cartridge bank 3; in MainRAM it uses the first 512 bytes of
internal RAM. Every program must reserve the shared areas it uses. Do not
add another SRAM, private sprite RAM or modem FIFO to the budget: the total
remains 80 KiB.

A profile change is a runtime setting, not a new CPU register. It rotates
the five 16 KiB blocks in place, preserving their contents. It requires
disabled sprites and an idle modem with empty queues and command buffer.
The software profile does not demonstrate a physical cartridge decoder.

## Status of the information

| Label | Meaning |
| --- | --- |
| Current API | Behaviour present in the reference runtime source |
| Checked in VICE | Guest CPU instructions or pixels actually produced in the emulator |
| Experimental format | An existing opt-in feature with specific options and layouts |
| Open hardware question | A feature that must not be assumed available on a physical cartridge |

The cartridge described here is **emulated inside VICE**. New materials and
scenery read emulated RAM structures directly through host code: physical
circuitry still needs a defined data-access path, contention policy and
video synchronization. A possible external compositor/genlock requires its
own design and validation; these tests do not establish it. This is not a
simple ROM/CRT image usable in official VICE, or certified physical
circuitry. Software tests do not measure power delivery, bus contention,
electrical timing or analogue video quality.

## Requirements

- The previously distributed plus/64 Windows runtime, to run PRGs or games.
- To assemble the example: Python 3 and the `xa` assembler; see `sdk/README.md`.
- Initially: familiarity with 6502 registers, addressing, stack and branches.
- For VICE diagnostics: system ROMs and an executable with matching plus/64
  support. The SDK does not contain another emulator.

The added modules do not emulate a complete Commodore 64. In particular,
do not assume VIC-II, CIA, C64 raster IRQs, C64 sprite DMA or a programmable
NMI merely because SID and additional graphics are present.

## Notation

Addresses beginning with `$` are hexadecimal; `0x` is equivalent in Python/C
tools. Binary values use `%`. A byte is 0–255 and a KiB is 1,024 bytes.
Tables distinguish reads and writes.

A CPU register read is not always equivalent to inspecting it in the
monitor: the monitor may use a side-effect-free `peek` callback. An ordinary
`LDA` or BASIC `PEEK` is a program read and can advance a pointer, consume
a modem byte or clear a latch.

References to files in `reference` refer to the frozen copies included in
the package. Their hashes are recorded in the manifest. The citations do
not require access to private repositories.

# Quick start

## Directory organization

Extract the manual and SDK while preserving subdirectories. Use the existing
runtime to execute the demo: neither game D64s nor a saved game is required.
To assemble it, run from the manual directory:

```sh
python sdk/build.py --out build-demo
```

The destination must be new. `xa` must be in PATH; if necessary set `XA`
to its path. The SDK README describes the details and actual outputs. The
`sdk-current` material adds a current-materials example without replacing
the baseline program. Complete example source is supplied; it is not an
unfinished pseudoprogram.

## Native execution profile

The essential options for initial development are:

```text
-default -model c16 -ramsize 16
-plus64 -plus64rastercollisions
-sound -soundbufsize 64
-sidenginemodel 256 -sidcartaddress 0xFD40 -sidcartclock 0
```

`-plus64` enables the devices. `-plus64rastercollisions` enables the scanline
path and immediate publication on an FD90 write. It does not add a register.
For the other machine replace `-model c16` with `-model plus4`, retaining
the internal 16 KiB limit.

For this example leave `plus64mainram`, `plus64packedcache`,
`plus64mixedsprites` and `plus64leftmcm` disabled: they belong to the
advanced profile. `-default` prevents accidentally inheriting the options
of a previous game.

`-directory` must point to the runtime resource directory. KERNAL, BASIC,
1541 ROM and keymap must be those of the working distribution. For a D64,
retain the distributed launcher's 1541-drive and bus/trap options. Do not
change the SID clock to accelerate loading or animation.

## Expected result

The demo displays TED graphics and a coloured sprite with transparent
pixels, moved by the controls documented in the SDK. A control triggers
a SID note. Publishing descriptors does not erase the bitmap. Separate
diagnostics check device reads and writes; they must not be confused with
a complete game.
