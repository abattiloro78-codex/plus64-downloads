# 3. TED video and plus/64 sprites

This chapter specifies video in the maintained plus/64 implementation: the RAM80 contract, memory protocol `$05`, and extended graphics formats through version17. Valid TED rules, base descriptors and examples from manual1.0 are retained; the former independent pools and then-reserved registers are updated. This is not a specification for a future electrical cartridge implementation. The delivery's current manifest identifies its executable and source hashes.

References name maintained source files, reproducible offline in the package's `reference/vice/src/plus4` directory. The previous edition's line numbers have been removed: consult the named functions or corresponding branches in the current file. Chapter8 also contains the detailed extended-format reference; the maintained implementation determines the supported combinations. None of the renderer's HOST structures adds RAM addressable by a6502 program.

## Choosing a profile for a new game

Start with the normal format, native RAM limited to 16 KiB, cartridge SRAM through its port, and raw8bpp sprites in the shared view. Suitable video options are:

```text
xplus4.exe -default -model c16 -ramsize 16 -plus64 -plus64rastercollisions
```

`-default` restores initial resources; in this model `Plus64MainRAM`, `Plus64PackedCache`, `Plus64LeftMCM`, `Plus64MixedSprites` and `Plus64RasterCollisions` start at 0. The final option explicitly enables publication and collisions per scanline while retaining the raw format. Complete disk, SID and input options are described in other chapters. Do not enable `packedcache` or `leftmcm` merely because a game uses more colours. (`plus64vice.c`)

The packed path is a software extension for compact caches, materials and reuse of particular C64 caches. A new game does not require it, and it is not the original0.94 format. Its operation is documented below so that ports can reproduce it without implying that a physical device has already been built. (`plus64_sprite.h`; `plus64vice.c`)

## Configuring the TED background

Native TED registers configure the background independently of `$FD90..$FDCF`. This table lists fields applied by the runtime; resulting memory addresses remain subject to the RAM profile in chapter2.

| Register | Useful video-configuration fields |
| --- | --- |
| `$FF06` | Bits0–2: vertical scroll0..7; bit 3:0=24 rows,1=25 rows; bit 4: display enable; bit 5:0=text,1=bitmap; bit 6: extended colour mode. Multicolour bitmap: bit 5=1, bit 6=0 and `$FF07` bit 4=1. |
| `$FF07` | Bits0–2: horizontal scroll0..7; **bit 3**:0=38 columns,1=40 columns; bit 4: multicolour. In normal text, bit 7 selects0=128glyphs with reverse through character-code bit 7, or1=256glyphs without automatic reverse. It is not a global background-inversion bit. |
| `$FF12` | Bits3–5: bitmap base `($FF12 AND $38) << 10`, in$2000 steps. **Bit3 does not enable bitmap mode:** it selects the first bit of its base. Bit2:0=fetch bitmap/glyphs from RAM,1=ROM path; in the latter case a base below$8000 uses the runtime's open-space path. Bits0–1: high frequency bits of TED voice0; preserve them when changing video only. Bits6–7 read as1 and do not select the base. |
| `$FF13` | Glyph base `($FF13 AND mask) << 8`: mask `$FC` normally, `$F8` when `$FF06` bit 6 or `$FF07` bit 7 is active. Bit1:0=CPU fast mode permitted,1=slow mode; it is not a glyph-address bit. Bit0 cannot be changed by writing `$FF13`: it reflects ROM/RAM selection updated by `$FF3E/$FF3F` strobes and participates in matrix and attribute fetches. It does not change the bitmap/glyph selector in `$FF12` bit 2. |
| `$FF14` | Attribute base `A = ($FF14 AND $F8) << 8`, aligned to$0800; the second matrix is at `A+$0400`. In the SDK bitmap these are luminance and chrominance respectively. Bits0–2 do not move these bases. |
| `$FF15` | Global background colour; the value of pair `00` in multicolour bitmap mode. |
| `$FF16` | First additional global colour; the value of pair `11` in multicolour bitmap mode. |
| `$FF17/$FF18` | Second/third additional global colours: used by relevant text modes, not multicolour-bitmap pairs. In extended text `$FF15..$FF18` are the four backgrounds selected by the character code's two high bits. |
| `$FF19` | Border colour. As with `$FF15..$FF18`, bits 0–3=hue, bits 4–6=luminance; written bit 7 is ignored and reads as1. Hue0 produces black, so128 codes do not represent128distinct colours. |
| `$FF1C/$FF1D` | Current-line counter: `(($FF1C AND 1) << 8) OR $FF1D`; the other bits of `$FF1C` read as1. These are not the IRQ-compare pair `$FF0A/$FF0B`. The runtime also permits writing them to reposition the counter; use reads only for ordinary polling. |

Mode bits follow `ted.c`; scrolling, display and window follow `ted-mem.c`; text reverse follows `ted-draw.c`. CSEL is determined by the actual `value & $08` branch, rather than the historical comment calling it bit 4. Bases and fetch sources are in `ted.c`; shared reads/writes of `$FF12` are in `ted-mem.c` and `ted-sound.c`. ROM selection and attributes are in `ted-mem.c`. Colours and pixel pairs are in `ted-mem.c` and `ted-draw.c`; the raster counter is in `ted-mem.c`.

### Exact initialisation of the SDK example

After normal KERNAL loading, the demo performs these writes in this order (`demo.asm`):

```asm
        lda #$3b
        sta $ff06
        lda #$18
        sta $ff07
        lda $ff12
        and #$c3
        ora #$08
        sta $ff12
        lda #$18
        sta $ff14
        lda #0
        sta $ff15
        sta $ff16
        sta $ff19
```

The result is multicolour bitmap mode,25 rows,40 columns, vertical scroll3 and horizontal scroll0; bitmap base$2000, luminance$1800, chrominance$1C00, and black global backgrounds and border. `$FF12` is not assigned a universal constant: this operation preserves its two audio bits, clears the ROM selector and sets base bits to$08; bits 6–7 read back as1 are ignored by the video setter. The demo does not write `$FF13`, `$FF17` or `$FF18`: glyph base is unnecessary for its bitmap, and the two additional colours are not used there. Do not assume this sequence restores every TED state left by a previous program.

The SDK initialises1024 bytes for each attribute matrix using palette tables, then fills8000bitmap bytes with `$55`, displaying pair `01` at every sample; its colour therefore comes from cell attributes (`demo.asm`; `ted-draw.c`). The loop waits for `$FF1D=240`, a unique value in a312-line PAL frame, without writing the counter (`demo.asm`). For generic synchronisation below 256, also use `$FF1C`, as explained in the coordinates section.

## What is composited over TED

TED continues producing its own background. The runtime applies sprite pixels after emulating each TED scanline, within the logical320×200 area. Transparent pixels leave TED content unchanged; an opaque sprite pixel replaces the colour at that point. This path does not provide an RGB framebuffer or a behind-background priority setting. (`ted.c`; `plus64_overlay.c`; `plus64_sprite.c`)

The eight slots share a **16384-byte view of existing RAM**, `sprite.ram`, accessible by the CPU through `$FD96`. In native mode CPU/TED use internal16 KiB RAM and this view aliases cartridge bank2; SRAM access to that bank sees the same bytes. In `mainram`, CPU/TED use the cartridge64 KiB and the sprite port views internal16 KiB RAM. The total remains64+16 KiB: there is no additional private sprite pool. Native mode cannot use another48 KiB from a Plus/4. TED does not read the sprite port as its own video window: programs must respect chapter2's memory map. (`plus64_memory.c`, `bind_views`, `p64_memory_sprite_ram`; `plus64_sprite.h`)

The `overlay` structure, `alpha` mask and 200-line collision summary are emulator HOST buffers, not additional areas addressable by a6502 program. Do not assign cartridge addresses to them. (`plus64vice.c`)

### Sprite-pixel palette

Valid indices are 0..120. Convert sprite index `i` to a TED colour code as follows:

```text
i = 0:       TED = $00
1 <= i <=120:
    luminance = (i - 1) div 15
    hue       = (i - 1) mod 15 + 1
    TED       = luminance * 16 + hue
```

These are 120 nonblack hue/luminance combinations plus black, not 121 RGB values chosen by the program. The runtime conversion is the one above; RGB appearance, filtering and monitor output depend on the video path. (`plus64_overlay.c`)

In raw8bpp,0 is **opaque black**, not transparency. `$FF` is the recommended transparent sentinel; current code actually discards all values121..255. Opaque black covers TED and participates in collisions, whereas a discarded pixel occupies no position. The alpha mask distinguishes them. (`plus64_sprite.h`; `plus64_sprite.c`; `plus64_overlay.c`)

The sprite palette does not remove limits of native TED graphics modes: the background remains the signal already rendered by TED. This API has no register requesting121 colours for every background cell. (`ted.c`; `plus64_overlay.c`)

## CPU register map

The sprite decoder covers only `$FD90..$FDCF`. The reset column describes `plus64_reset`: registers and the latch are cleared, **not the pattern RAM backing**. HOST format options survive as configuration and are resources distinct from these registers. (`plus64_sprite.h`; `plus64_sprite.c`; `plus64vice.c`)

| Address | Access and reset | Actual meaning |
| --- | --- | --- |
| `$FD90` | R/W,0 | Enable: bit `s` enables slot `s`, for `s=0..7`. With the per-line profile, every write publishes current state even if the value is unchanged. |
| `$FD91` | Read-clear,0; writes ignored | Sprite-collision latch: one bit for each participating slot. |
| `$FD92` | R/W,0 | Bit `s`:0=monochrome;1=raw8bpp in the normal format, or packed MCM when `packedcache` is active. |
| `$FD93` | R/W,0 | Bit `s`: horizontal doubling of slot `s`. |
| `$FD94` | R/W,0 | Bit `s`: vertical doubling of slot `s`. |
| `$FD95` | R/W,0 | Reserved. The byte is retained and readable, but does not apply background priority. |
| `$FD96` | R/W data port; initial pointer0 | Reads or writes a shared-backing byte, then increments pointer `$FD98:$FD97`. It is not an ordinary register cell. |
| `$FD97` | R/W,0 | Data-port pointer low byte. |
| `$FD98` | R/W,0 | Data-port pointer high byte. It is not an external-SRAM bank selector. |
| `$FD99..$FD9C` | R/W,0 | With extended formats: two4-bit light selectors per byte, even slot in the low nibble; values0..10 are described below. |
| `$FD9D/$FD9E` | R/W,0 | Little-endian pointer to the layer/material list in existing main RAM, for extended `mainram`. |
| `$FD9F` | R/W,0 | Bit0: layers enabled; bit 1 or bit 2: black presentation masking; bit 3: post-sprite window from flag4 nodes. Other bits have no assigned function here. |
| `$FDA0..$FDCF` | R/W,0 | Eight six-byte descriptors, listed below. |

Register access, auto-increment, enable, format and expansion are implemented in `plus64_sprite.c`; FD90 publication is in `plus64vice.c`. Historical comments describing FD92 as reserved do not describe the current executed branch.

Auto-increment uses a16-bit counter and updates both registers. Access to the backing uses `pointer AND $3FFF`, so `$4000`, `$8000` and `$C000` alias `$0000`, rather than selecting more banks. Keep the pointer within 0..$3FFF to avoid depending on these aliases. Incrementing$FFFF wraps both bytes to 0. (`plus64_sprite.c`)

**SDK rule:** write0 to unused fields and do not use reserved registers as scratch RAM. Current readback does not give them an additional public function. (`plus64_sprite.c`)

### The eight descriptors

Slot `s` starts at `$FDA0 + 6*s`. Fields are independent; this is not the VIC-II register layout. (`plus64_sprite.c`)

| Slot | X low | Y | X high | Colour | Pattern low | Pattern high |
| --- | --- | --- | --- | --- | --- | --- |
| 0 | `$FDA0` | `$FDA1` | `$FDA2` | `$FDA3` | `$FDA4` | `$FDA5` |
| 1 | `$FDA6` | `$FDA7` | `$FDA8` | `$FDA9` | `$FDAA` | `$FDAB` |
| 2 | `$FDAC` | `$FDAD` | `$FDAE` | `$FDAF` | `$FDB0` | `$FDB1` |
| 3 | `$FDB2` | `$FDB3` | `$FDB4` | `$FDB5` | `$FDB6` | `$FDB7` |
| 4 | `$FDB8` | `$FDB9` | `$FDBA` | `$FDBB` | `$FDBC` | `$FDBD` |
| 5 | `$FDBE` | `$FDBF` | `$FDC0` | `$FDC1` | `$FDC2` | `$FDC3` |
| 6 | `$FDC4` | `$FDC5` | `$FDC6` | `$FDC7` | `$FDC8` | `$FDC9` |
| 7 | `$FDCA` | `$FDCB` | `$FDCC` | `$FDCD` | `$FDCE` | `$FDCF` |

| Field | Interpretation |
| --- | --- |
| X low, X high | `X = low + 256*(high AND 1)`. X-high bits 7..1 are stored but ignored by the renderer. |
| Y |8-bit coordinate, normally unsigned:0..255. Signed exceptions belong exclusively to the advanced profile below. |
| Colour | Base monochrome uses `colour AND $7F`; with extended materials bit 7 has the function described below. Ordinary raw8bpp/MCM obtains colour from pixels or cache keys. |
| Pattern | In the base format, a **byte address** in the shared backing: `(high*256+low) AND $3FFF`. It is not a sprite number multiplied by 64 or512. |

Readback returns written bytes even when rendering ignores certain bits. Use only monochrome indices0..120: masked values121..127 convert to opaque black through the palette function, rather than to transparency. (`plus64_sprite.c`; `plus64_overlay.c`)

## Normal pattern formats

With `packedcache=0` and `leftmcm=0`, these two formats can be selected independently per slot through FD92. (`plus64_sprite.c`)

| Slot's FD92 bit | Visual size | Required data | Interpretation |
| --- | --- | --- | --- |
| 0 |24×21|63 bytes|Three bytes per row, bit 7 on the left;0 bit=transparent,1 bit=descriptor colour. No header.|
| 1 |24×21|504 bytes|One palette index per pixel,24 bytes per row,21 rows. No header or alignment requirement.|

Raw8bpp has24 independent pixels per row: the bit's MCM name **does not halve** resolution. A512-byte record is a useful convention, not a decoder requirement; its final eight bytes are not read as image data. A monochrome64-byte stride is also only a convention. (`plus64_sprite.c`)

Eight slots are eight instances, not a limit of eight stored images: slots may share a pointer, and software may change pointers to animate an object. (`plus64_sprite.c`)

Normal fetch wraps within the 16 KiB backing: an image near$3FFF reads subsequent bytes from the start. Plan allocations to avoid accidentally overlapping other patterns. Packed formats instead have the alignment checks described below. (`plus64_sprite.c`)

If backing contains0, those raw8bpp bytes mean opaque black; device reset does not guarantee that a shared view has been cleared. Enabling a raw sprite without initialising **all 504 bytes** can therefore produce a black rectangle. For a16×16 image within a24×21 slot, initialise the eight rightmost columns, five bottom rows and every transparent hole to$FF. (`plus64_sprite.c`)

### Byte example: three pixels and opaque black

Assume normal format, slot 0, no expansion, and exclusive access to the data port. This is a data recipe, not another program to assemble. First disable output with `$FD90=$00`. (`plus64_sprite.c`)

1. Set `$FD97=$00`, `$FD98=$00`; write `$FF` to `$FD96`504times.
2. Reset the pointer to$0000; write `$6F,$00` through the port: offsets0 and 1.
3. Set the pointer to$0018; write `$06`: the first pixel of row2, because the stride is24 bytes.
4. Write `$FD92=$01`, `$FD93=$00`, `$FD94=$00`, `$FD95=$00`.
5. Write the six descriptor bytes below, then `$FD90=$01` last.

```text
Addresses: FDA0 FDA1 FDA2 FDA3 FDA4 FDA5
Values:      A0   50   00   00   00   00
```

Expected output: bright blue at(160,80), **opaque** black at(161,80), and dark blue at(160,81). The slot's other501 pixels are transparent and preserve TED. Indices$6F=111 and$06=6 convert to TED colours$76 and$06 respectively. (`plus64_sprite.c`; `plus64_overlay.c`)

## Coordinates, borders and frequency

The origin is the upper-left corner of the logical320×200 area: X 0..319 and Y 0..199. Do not automatically add VIC-II sprite offsets from a C64 program. Normal-format X is0..511 and Y 0..255; portions outside the right or bottom edge are clipped. X 511 does not mean−1, and Y 255 does not mean−1. (`plus64_sprite.h`; `plus64_sprite.c`)

FD93 and FD94 repeat each pixel twice horizontally or vertically:24×21becomes48×21,24×42or48×42. Clipping applies to the expanded result. Normal raw format has no negative left/top coordinates; a game may retain a logical offscreen position and publish a cropped pattern at X 0, or wait until it enters the visible area. There is no additional negative-offset register. (`plus64_sprite.c`)

In PAL the emulator uses312 lines of 114TED clocks at 1773447clocks/second:35568clocks/frame, approximately49.86Hz, usually called50Hz. This is not 35568available6502 instruction cycles. (`plus4.h`; `ted-timing.h`; `ted-timing.c`)

With the PAL25-row geometry used here, overlay line Y 0 corresponds to TED counter4. FF1D contains the counter's low byte and FF1C its bit 8; FF1D=4 alone does not distinguish4 from260. Check FF1C bit 0 when synchronising publication. Do not add PAL canvas offset59 to a descriptor coordinate. (`tedtypes.h`; `ted-mem.c`; `ted.c`)

TED's24-row mode, scrolling and border may alter content or the window visible below the overlay: they do not turn these descriptors into VIC-II registers. For a new video mode, verify the runtime's geometric reference before adapting an older projection formula. (`tedtypes.h`; `ted.c`; `plus64_overlay.c`)

## Publication and animation without partial images

Writes to descriptors, formats, expansion and pattern data update the model but do not by themselves form a display transaction. In the default profile without `-plus64rastercollisions`, the frame hook prepares the whole overlay once per frame. In the per-line profile, **every write to FD90** rebuilds the current overlay; the enable value need not change. (`plus64vice.c`)

Recommended sequence: initialise/upload data with output disabled; write format, expansion and descriptors; then write the enable mask to FD90 **last**. After publication, prepare the next state before its video deadline. Already-drawn lines are not changed retroactively. Writing0 to FD90 disables subsequent lines but does not clear the collision latch. (`plus64vice.c`; `plus64_sprite.c`)

The frame hook continues sampling registers in the per-line profile too. FD90 is not a hardware double bank of descriptors: partially prepared state crossing the end-of-frame sample may be observed by that hook. Schedule upload and staging, or keep output disabled throughout initialisation. (`plus64vice.c`)

Multiplexing reuses a slot in separate vertical bands: publish the current band, prepare subsequent descriptors while it is being rendered, then publish them after its last line. There are still eight slots on one line, not eighteen horizontally simultaneous sprites. Even with SEI, TED and scanning continue: measure the complete code, including input, collisions, HUD and audio, against the band deadline. (`plus64_sprite.c`; `plus64vice.c`; `ted.c`)

A static screenshot does not qualify multiplexing. Compare several framebuffer images during movement, firing and explosions; verify the pixels of every live object are present. Also check update intervals, distinguishing a shifted return line from a genuinely skipped frame. This is an SDK testing rule, not another device feature.

## Collisions: between sprites only

An opaque slot pixel overlapping another slot sets **both** participants' bits in FD91. Multiple overlaps accumulate every participant. Among normal visible masks, the lower-numbered slot has display priority, but others still participate in collisions; colour does not define a rectangular hitbox. (`plus64_sprite.c`)

For example, FD91=$05 means slots 0 and 2 have participated in collisions since the previous read. It does not identify the position, exact pair among multiple events, or impact direction. A CPU read returns the byte and clears the entire latch; a write does not clear it. An overlap that remains present can generate the same bits on subsequent lines or frames. (`plus64_sprite.c`; `plus64vice.c`)

The latch does not sample TED pixels or logical structures: there are no hardware collisions against floors, walls, bitmaps, characters or background colours. Software must implement those through its maps or geometry. FD95 does not add such a feature, and there is no VIC-II-equivalent sprite interrupt here. (`plus64_sprite.h`; `plus64_sprite.c`; `plus64vice.c`)

| Collision profile | Time and domain |
| --- | --- |
| Default: `rastercollisions=0`, `leftmcm=0` | Whole-overlay comparison during frame preparation; visible domain X 0..319,Y 0..199. |
| `rastercollisions=0`, `leftmcm=1` | Same frame preparation, additionally considering X−24..−1; domain X−24..319,Y 0..199. |
| `rastercollisions=1`, `leftmcm=0` | Preparation does not raise the latch; each completed line contributes its summary. Collisions also consider X 320..511 without drawing the border. |
| `rastercollisions=1`, `leftmcm=1` | Same timing with horizontal domain−24..511; display remains X 0..319. Y outside0..199 produces no collisions. |

See `plus64_sprite.c` and `plus64vice.c`. Change the per-line resource only with FD90=0; changing it discards the former alpha representation but retains the already-pending latch. (`plus64vice.c`)

When a slot is reassigned to another enemy, its bit still identifies the **slot**, not the game object's identity. Consume and attribute events within the correct band, or use software collisions between logical objects. Do not interpret a stale latched bit as an impact involving the new assignee. (`plus64_sprite.c`; `plus64vice.c`)

## Packed formats: advanced software reference

These options are implemented HOST resources, not new CPU registers. Do not substitute FD98 or reserved bits with supposed format selectors. (`plus64vice.c`)

| packedcache | leftmcm | Slot's FD92=0 | Slot's FD92=1 |
| --- | --- | --- | --- |
|0|0|Normal63-byte monochrome|Normal504-byte raw8bpp|
|1|0|Normal63-byte monochrome|Packed MCM|
|1|1|Packed HIRES|Packed MCM|
|0|1|Rejected by the setter|Rejected by the setter|

Selection is implemented in `plus64_sprite.c`; the leftmcm constraint is in `plus64vice.c`. Enabling packedcache **alone does not convert** monochrome patterns into packed HIRES.

Each packed record occupies a1024-byte-aligned position in the 16 KiB backing: bases$0000,$0400,...,$3C00, up to 16 records. The complete pointer must equal its14-bit-masked value: alias$4000 is not accepted. The renderer skips invalid records without assigning another error register. (`plus64_sprite.c`)

| Offset from base | Data consumed by the decoder |
| --- | --- |
| `$200` | Byte63 of the inverse RAW64 block: not a pixel or register. Base rendering ignores it; extensions may select material, sparse orientation or an invisible mask. |
| `$201..$23F` | Original63 image bytes in reverse order: logical byte `i` is at `base+$23F-i`, for `i=0..62`. |
| `$240` | MCM: must be0. Packed HIRES: horizontal source shift0..23. |
| `$241` | Exact type:1=MCM,0=packed HIRES. Not freely combinable flags. |
| `$242` | Palette index for MCM pair `11`. |
| `$243` | Palette index for MCM pair `10`. |
| `$244` | Palette index for MCM pair `01`. |
| `$245` | Validity marker: must be **exactly$A5**. |

See `plus64_sprite.h` and `plus64_sprite.c`. Other record bytes are not read by these decoder branches; this does not automatically make them free when an engine uses the same area as cache or backup.

In the reused C64 engine, byte 63 also acts as an engine orientation tag. Engine orientation belongs to the caller; the bridge retains the byte in its key. Base format does not render it as image data, whereas the extensions below interpret specific tags. Do not transfer its bits into FD95 or type byte$241. (`engine/reuse/native_sprite_cpu.py`; `plus64_sprite.c`)

Packed MCM bytes hold four bit pairs, most significant first. Pair0 is transparent;1,2,3 select `$244,$243,$242`. Each pair occupies **two horizontal pixels** in 24×21. Key indices121..255 are also discarded;0 remains opaque black. Base-format descriptor colour does not replace these three keys; extended materials may replace or shade them without changing transparent pair0. (`plus64_sprite.c`)

Packed HIRES uses the inverse63-byte bits and descriptor colour. The decoder reads `source_x = pixel_x + record[$240]`, discarding beyond23. This shifts the logical source without wrapping lost right-hand bits; it does not change descriptor X position. (`plus64_sprite.c`)

### Negative projections in leftmcm

These rules do not apply to normal raw8bpp. With packedcache=1 and leftmcm=1:

- Packed MCM: raw X 488..511 becomes−24..−1 even without X expansion.
- Packed HIRES: the same X conversion applies **only with X expansion enabled**; unexpanded HIRES does not interpret488..511as negative.
- Both types: raw Y 215..255 becomes−41..−1. Values206..214 are outside this conversion and remain positive.

These are conditional projections of the existing publisher, not a general signed9-/8-bit mode. Positive coordinates, expansion and clipping continue after conversion. (`plus64_sprite.c`)

### Changing profile without incoherent caches

Write FD90=0before changing profile. Changing packedcache with output enabled is rejected; an accepted change invalidates the$245marker in all 16 records, **in either direction**. Changing a resource does not convert data: rebuild or reload patterns in the new format before enabling them. (`plus64_sprite.c`; `plus64vice.c`)

Enable leftmcm only after packedcache and with output disabled. Packedcache cannot be disabled while leftmcm or mixedsprites is active. Changing rastercollisions also requires output disabled. To return to normal format: disable output, remove mixedsprites, remove leftmcm, remove packedcache, load raw/mono patterns, set descriptors and publish FD90 last. (`plus64vice.c`)

## Current extended graphics formats

Enable these features explicitly through HOST resources before enabling sprites:

```text
-plus64packedcache -plus64leftmcm -plus64mixedsprites
```

Mixedsprites requires packedcache; leftmcm is needed for the packed HIRES path. Changing formats with output active is rejected. The extension adds no slots or banks. Sprite materials also work in native16 KiB mode; layers reading main RAM, described below, require mainram. The current decoder is `plus64_sprite.c`, `draw_masked_common`, with configuration and snapshots in `plus64vice.c`.

### Mixed RAW8 and material colour

With a slot's FD92 bit=1, a pattern pointer with bit 14=1 and bit 15=0selects mixed RAW8: its lower14 bits address504 bytes in the same backing. For example,$4800 means RAW8 at offset$0800. The entire image must fit inside the bank without wrapping. An untagged pointer retains packed MCM semantics. Expansion and collisions remain ordinary. With leftmcm active, mixed RAW8 also applies the publisher projections: raw X 488..511 becomes−24..−1 and raw Y 215..255 becomes−41..−1; these exceptions do not apply to normal RAW8 with packedcache disabled.

For a valid compact mask, bit 7 of the **descriptor colour** requests a material and the lower seven bits select colour 0..120. Packed MCM may also use **source byte 63** `$80 | colour`, tags$80..$F8. Mixed RAW8 bypasses these materials. Black0 remains opaque: the mask determines whether a pixel exists.

The selected colour is the maximum luminance, rather than hue alone. For `c>0`, hue=`1+(c-1) mod15` and maximum luminance=`(c-1) div15`. The radial profile computes `L=max(0,7-((x-lx)^2+(y-ly)^2) div40)`, then `L=L*maximum_luminance div7`, with integer division. Compact output is `15*L+hue`; `c=0` produces black. No second image is stored for shading.

### Eight directions, front and per-ink diagonal light

FD99 controls slots 0/1, FD9A slots 2/3, FD9B slots 4/5 and FD9C slots 6/7. The even slot uses the low nibble. For example, FD99=$30 gives east light to slot 1 while retaining slot 0's historical profile.

| Value | Light | Point in the 24×21 grid |
| --- | --- | --- |
|0|Historical upper-left|(6,5)|
|1|N|(12,0)|
|2|NE|(23,0)|
|3|E|(23,10)|
|4|SE|(23,20)|
|5|S|(12,20)|
|6|SW|(0,20)|
|7|W|(0,10)|
|8|NW|(0,0)|
|9|Front|(12,10)|
|10|Per-ink MCM diagonal|Uses the frame's opaque bounds.|
|11..15|Reserved|Historical-profile fallback.|

Directions are screen-relative; mirroring the source does not reverse the selected light point. Mode10 retains the three MCM inks and changes only luminance: it adds `2-floor(5*((x-xmin)*dy+(y-ymin)*dx)/(2*dx*dy))`, clamped to 0..7, with dx/dy at least 1. Bounds come from opaque pairs in the current mask. RAW8 and HIRES do not become MCM because selector 10 is chosen.

### Sparse masks with palette rectangles

Descriptor colour$F9 on a valid packed HIRES record selects sparse format. Do not confuse this with the packed-MCM source tag F9. The **source** representation has magic A7, byte 1=`S=3+4*N`, byte 2=base colour/material. Next are N four-byte rectangles: little-endian20-bit bounds `x0|(y0<<5)|(x1<<10)|(y1<<15)`, followed by colour/material. Bounds are inclusive and must fit24×21; later rectangles take precedence only on pixels already opaque.

At byte S, eight occupancy bytes identify nonzero bitmap bytes in reverse order62..0, high bit first; nonzero values follow in that order. Every read must fit bytes 0..62. Bit7 of byte 63horizontally mirrors the mask. Malformed records draw nothing. Decoding uses a temporary63-byte HOST mask, not additional guest RAM.

Inks0..120 are solid; bit 7 in a colour requests the material selected by its lower seven bits. With selector 9 and the sparse frontal profile, relief follows the ends of each row's opaque span instead of only the rectangle's centre. An ordinary bitmap without A7 magic but with F9 selector uses the cache's shared1 ink. Palette rectangles cannot introduce pixels or change their collisions.

### Invisible masks and priority

In packed MCM, source byte 63=F9 means **collision-only** from profile 15: the mask still participates in collisions but emits no pixels and claims no display priority. From profile 16, tag FA instead selects an **invisible occluding mask**: it retains the slot's original priority, hides later sprites at covered pixels, and leaves the underlying scene visible. It does not draw black or a transparency colour; all 63mask bytes and collisions are unchanged.

For these profiles, display alpha contains only visible sprites. Separate scanline summaries retain collisions from invisible masks too. Deferred callers must use the provided collision-summary path rather than deriving every collision from visual alpha. F9/FA remain ordinary tags in older profiles that do not declare their interpretation.

## Colour layers, scenery and native interfaces

In extended mainram mode, FD9D/FD9E point to descriptors in **existing main RAM**; FD9F bit 0enables them. The renderer walks at most32 nodes per pass. The next field is little-endian; zero terminates a list. Byte11selects node type, and the remaining layout depends on type: flags cannot be combined freely. Basic x,y,w,hcoordinates are in 8×8cells and must fit320×200.

| Type in byte 11 | Size | Function |
| --- | --- | --- |
|0|12 bytes|Diagonal rectangle shading with a background key.|
|1|20 bytes|The same light restricted to expected-character foreground and current bitmap/glyph data.|
|2|24 bytes|Scene/materials using shared luminance streams and a glyph selector.|
|3|12 bytes|Interface frames and keys from a compact grid.|
|4|12 bytes|Post-sprite window controlled by two RAM coordinates.|
|5|12 bytes|Tint through compact palettes.|
|6|12 bytes|Generic conditional link.|
|7|20 bytes|Conditional tint.|
|8|24 bytes|Type2scene with protection of native-interface characters.|

This is an index, not a replacement for chapter8's complete layouts. Nodes are software data, not new registers or a texture pool. Programs must reserve their bytes within their own budget and keep them valid for the entire fetch period.

In type0, bytes 6..9 are local pixel xmin,ymin,xmax,ymax; byte 10 is the compact background key. Nonblack TED pixels have their luminance adjusted by the diagonal formula, clamped0..7, preserving hue. Type1adds four LE16pointers: font, live characters, live attributes and expected rectangle characters. Only the matching glyph's foreground is modified; attribute bit 3selects MCM pairs, excluding pair0. A character replaced by an interface is not reinterpreted as the former object.

Type2adds two streams: background and material tile. Streams concatenate segments `[nextLE16,length8,payload]`; the image starts with LE16width/height, followed by bands `[repetitions,token_count,tokens...]`. Each token stores luminance in its three high bits and length minus1 in its five low bits. A software selector associates banks/glyph ranges with materials. This is not a separate RGB bitmap, and the renderer does not know specific game addresses or object classes.

Type8shares type2's 24-byte layout. Byte12 packs the required source bank in bits 0..2 and final native glyph in bits 3..7; byte 13 retains the high byte of the aligned font base. Byte22 packs text ink in the high nibble and fallback hue in the low nibble; byte 23 is the solid-border glyph. The control pointer in bytes 20/21selects bank `(RAM[control]>>1)&7`; the byte at control−3 is the standard logical view's sprite enable.

Native protection is active when bank/view match and **at least one byte in the entire configured glyph-font range is nonzero**. The first byte or first glyph may therefore be empty. A cell with matching ink and a glyph in range retains its original solid foreground/background; the border glyph is protected when adjacent, including diagonally, to a matching text cell. This includes sides and corners of a one-cell frame. A wrong bank or disabled source sprites cause the protected owner to suppress scene/object lighting; an active conditional owner may select another chain. These checks use program-selected data, not constants from a particular title.

Type4applies only with FD9F bit 3=1, after sprites. Bytes6/7and8/9point to the top and bottom limits in global pixel Ycoordinates; byte 10 is a **TED code 0..127**, not a compact sprite index. Where rectangle and `[top,bottom)` band intersect, the node replaces pixels with that code. During this window, type8UI protection is suspended so an opening/closing mask can remain above enhanced scenery while the source view changes temporarily. FD9F bit 1or bit 2instead requests black across the whole presentation area.

Actual per-line order is TED rendering, layer lighting, scene/materials, sprites, type4window, then black presentation masking. Text protection or background colour therefore does not erase an already-emitted sprite. FA masks may instead hide lower-priority sprites according to the preceding rules. Layers do not write source RAM or change collisions.

### Serialized version and current example

The PLUS64 container retains the size/backing of the RAM80 contract. Its HOST header uses byte 72 for mixed formats;73 for the full material palette;74 for sparse masks;75 for directions;76 for sparse frontal relief;77 for layer lighting;78 for per-ink diagonal light; and 79 for scene version, currently17. These are not 6502registers. Historical sections calling them reserved describe older profiles and must not be applied to current format. The reader validates combinations and CRC before restoring; an older executable may reject a newer format.

The supplied updated example `sdk-current/material-example.asm`, include and builder show all 121highlight colours and directions1,3,9 in native16 KiB mode. One new generic mask is uploaded into the bank2view; descriptors select its shading, without an image per colour. The PRG is921 bytes, entry$1100, code/data end$1398; it uses TED video below$3F40 and reserves one1 KiB bank2cache record. Its README explains building, launching and diagnostics.

Retained checks cover two identical builds,363 colour/direction cases of the C renderer, and 500program frames on each C16/Plus4host. These qualify the specific sample and identified software sources, not physical circuitry or every future program.

## Debugger and test limitations

A CPU read of FD91 clears the latch; a CPU read of FD96 increments its pointer. The diagnostic **peek** callback instead returns the latch or current byte without these side effects. A debugger view using peek does not prove that software consumed a collision; always compare access types. (`plus64_sprite.c`; `plus64vice.c`)

Monitor commands and any test-bench keyboard-injection helpers are HOST tools, not 6502instructions or cartridge registers. Do not turn observer sequences into a requirement for the program or production launcher; software must use ordinary input peripherals.

6502CPU tests, simulated peripherals, ordinary VICE runtime, observers, Wine and physical cartridges are distinct levels. For a game, retain at least executable/asset hashes, actual options, slot state, real moving images, and checks of the intended CPU latch reads. An image reconstructed directly from final descriptors cannot replace the framebuffer when qualifying multiplexing: direct drawing reads current state, whereas display applies publication at individual scanlines. (`plus64vice.c`)
