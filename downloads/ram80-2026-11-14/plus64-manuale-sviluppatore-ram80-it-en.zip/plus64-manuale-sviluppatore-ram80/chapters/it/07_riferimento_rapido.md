# 7. Riferimento rapido

Promemoria del runtime documentato, PE `08d3e87f…` (6.617.154 byte, debug rimosso). I dettagli, le eccezioni
e gli hash delle fonti sono nei capitoli 2–4 e negli inventari API JSON.
Le tabelle descrivono il software disponibile, non una cartuccia fisica già
certificata. `R` = lettura CPU, `W` = scrittura CPU.

## Profili e mappa generale

| Profilo | Contratto del programma |
|---|---|
| Nuovo gioco nativo | CPU/TED nei **16 KiB interni**, imposti anche su Plus/4; **64 KiB cartuccia** tramite porta; la vista sprite è il banco cartuccia 2 |
| `-plus64mainram` | CPU, TED e porta SRAM condividono i **64 KiB cartuccia**; la porta sprite vede i **16 KiB interni** distinti |
| Budget corrente | **65.536 + 16.384 = 81.920 byte**; nessuna RAM sprite/FIFO aggiuntiva |

Nel profilo nativo gli indirizzi RAM ordinari sono mascherati con `$3FFF`;
i quarti alti sono alias, anche sul Plus/4 configurato da plus/64 a 16 KiB.
La porta sprite e il modem condividono il budget: riservare i loro byte.
Il cambio di profilo richiede sprite disabilitati, modem inattivo e code/comando
vuoti. Sono risorse del runtime, non nuovi registri guest. **Vedi capitolo 2.**

| Range | Dispositivo o area |
|---|---|
| `$FD40..$FD5D` | SIDcart al suo indirizzo standard; `$FD5E/$FD5F` non sono SID |
| `$FD90..$FDCF` | Sprite, porta dati e otto descrittori |
| `$FDE8..$FDED` | Porta SRAM: banco, offset, dati e firma |
| `$FDF0..$FDF7` | Modem a polling |
| `$FF00..$FF1F` | TED: timer, video, input e IRQ nativi |
| `$FF3E/$FF3F` | Strobe ROM attive / RAM sottostante; valore scritto irrilevante |

`$FDxx/$FExx` rimangono I/O anche con ROM disattivate. BASIC occupa normalmente
`$8000..$BFFF`; KERNAL/ROM alta `$C000..$FFFF`, con eccezioni I/O. Zero page,
stack e vettori restano responsabilità del programma. Non usare `$0001`
come selettore di banking C64.

## SRAM: sei registri e un wrap nel banco

| Registro | R | W |
|---|---|---|
| `$FDE8` | Offset basso | Imposta basso, conserva alto |
| `$FDE9` | Offset alto, bit 6–7 zero | Imposta alto con `valore & $3F` |
| `$FDEA` | Dato, poi incremento | Scrive dato, poi incremento |
| `$FDEB` | Banco 0–3 | `valore & 3`; conserva offset |
| `$FDEC` | `$64` | Ignorata |
| `$FDED` | `$05` | Ignorata |

`indice = (banco << 14) | offset`. Dopo DATA: `offset = (offset+1) & $3FFF`.
**Il banco non cambia** passando da `$3FFF` a `$0000`. Per attraversare
64 KiB selezionare esplicitamente i quattro banchi.

Il peek diagnostico non incrementa; una lettura CPU, incluso `PEEK` BASIC,
incrementa. La firma non rivela il flag `mainram`. Coordinare la porta con
gli IRQ e non usare istruzioni RMW su DATA. **Vedi capitolo 2.**

## Sprite: slot, coordinate, palette e pubblicazione

| Registro | Funzione |
|---|---|
| `$FD90` | Enable, un bit per slot; scriverlo **per ultimo** |
| `$FD91` | Collisioni fra sprite, un bit per slot; R azzera tutto, W ignorata |
| `$FD92` | Bit per slot: 0 monocromatico, 1 raw8bpp nel profilo normale |
| `$FD93/$FD94` | Espansione X / Y ×2, un bit per slot |
| `$FD95` | **Riservato**, non realizza priorità dietro il TED |
| `$FD96` | Porta RAM sprite, R/W con autoincremento |
| `$FD97/$FD98` | Puntatore dati basso / alto a 16 bit |
| `$FD99..$FD9C` | Selettori luce, due nibble per registro |
| `$FD9D/$FD9E` | Puntatore lista illuminazione/scenery in RAM principale |
| `$FD9F` | bit0 abilita, bit1/2 oscuramento, bit3 finestra di presentazione |
| `$FDA0..$FDCF` | Otto descrittori, sei byte per slot |

Per slot `s=0..7`, base `b=$FDA0+6*s`:

| Offset | Campo |
|---:|---|
| 0 | X basso |
| 1 | Y |
| 2 | X alto: soltanto bit 0 contribuisce |
| 3 | Colore locale o selettore materiale/formato nel profilo esteso |
| 4–5 | Indirizzo **in byte** del pattern nel pool, basso/alto |

Origine `(0,0)` in alto a sinistra dell'area **320×200**. In raw normale:
`X=basso+256*(alto&1)`, intervallo 0–511; Y 0–255. Il bordo taglia i pixel:
X=511 e Y=255 non significano −1. Le proiezioni signed di `leftmcm`
appartengono soltanto al profilo avanzato packed. **Vedi capitolo 3.**

| Formato normale | Dati | Trasparenza |
|---|---:|---|
| Monocromatico | 63 byte, 24×21, tre byte per riga, bit alto a sinistra | Bit 0 trasparente; bit 1 colore del descrittore |
| Raw8bpp | 504 byte, 24×21, 24 byte per riga | `$FF` consigliato; il renderer scarta tutti i valori 121–255 |

Uno sprite visibile 16×16 occupa ancora uno slot 24×21: inizializzare
padding e fori a `$FF`. In raw, **indice 0 = nero opaco**, non trasparenza.
Gli indici 0–120 rappresentano un nero e 120 combinazioni:

```text
indice 0 -> TED $00
indice i da 1 a 120:
    L = (i-1) div 15
    H = (i-1) mod 15 + 1
    colore TED = 16*L + H
```

Esempi: indice 6 → TED `$06`, indice 111 → `$76`, indice 106 → `$71`.
La palette non elimina i vincoli delle celle/modi video TED dello sfondo.

La RAM sprite usa `puntatore & $3FFF`, ma il **contatore della porta è a
16 bit**: dopo `$3FFF` registra `$4000`, che accede nuovamente all'offset 0;
solo dopo `$FFFF` i registri tornano a zero. Questo differisce dalla porta
SRAM a offset 14 bit. Anche il fetch raw/mono ricircola nel pool di 16 KiB.

Con `-plus64rastercollisions`, scrivere `$FD90` pubblica descrittori e
pattern anche a metà frame; disabilitare con zero prima di riutilizzare
gli slot. Le linee già disegnate non cambiano. Il latch contiene collisioni
fra pixel opachi degli slot, non contro il TED: nessuna collisione hardware
con muri o piattaforme. Lo slot più basso ha priorità visiva. I bit restano
legati agli **slot**, non alle identità dei nemici multiplexati.

### Formati estesi e luce

`Plus64MixedSprites` richiede `Plus64PackedCache`. Record packed allineati
da 1 KiB: sorgente64 inversa a `$200..$23F`, shift a `$240`, MCM a `$241`,
tre inchiostri a `$242..$244`, validità `$A5` a `$245`. Sono viste dei byte
condivisi, non altri 16 KiB. Il tag puntatore `$4000`, con bit15 zero,
seleziona RAW8 misto all'offset basso14bit; i 504 byte devono entrare senza wrap.

Sparse HIRES: colore descrittore `$F9`, magic sorgente `$A7`, maschera e
rettangoli cromatici. Un materiale usa `$80|colore` dove previsto e conserva
la maschera. Selettori nei nibble basso/alto per sprite pari/dispari:
0 storico; 1..8 N, NE, E, SE, S, SW, W, NW; 9 frontale; 10 diagonale MCM
per inchiostro. FA è un tag MCM di occlusione invisibile fra sprite virtuali,
non una priorità arbitraria dietro i caratteri TED. **Vedi capitolo 3 e FORMAT.**

## SID: note, gate e indirizzi effettivi

Profilo riproducibile: `-sound -sidenginemodel 256 -sidcartaddress 0xFD40
-sidcartclock 0`. `256` = reSID 6581; `257` = reSID 8580.
Clock SID 0: **985.248 Hz PAL**, 1.022.730 Hz NTSC. Nel runtime conservato
clock 1 passa invece **1.773.447 Hz PAL** al SID, non 886 kHz.
**Vedi capitolo 4.**

| Base voce | `+0/+1` | `+2/+3` | `+4` | `+5` | `+6` |
|---|---|---|---|---|---|
| `$FD40`, `$FD47`, `$FD4E` | Frequenza basso/alto | Pulse width 12 bit | Controllo | A alto / D basso | S alto / R basso |

CONTROL: `$01` gate, `$02` sync, `$04` ring, `$08` test, `$10` triangolare,
`$20` sega, `$40` impulso, `$80` rumore. Per riarticolare una nota serve
un fronte gate 0→1; TEST non azzera il rate counter ADSR.

| Registro | Uso |
|---|---|
| `$FD55/$FD56` | Cutoff: `(alto<<3) | (basso&7)` |
| `$FD57` | Risonanza alto nibble; routing voci 1/2/3/esterno nei bit 0–3 |
| `$FD58` | Volume 0–15; LP `$10`, BP `$20`, HP `$40`, voce 3 fuori dal diretto `$80` |
| `$FD59/$FD5A` | POTX/POTY, letture dipendenti dagli ingressi/configurazione |
| `$FD5B/$FD5C` | Letture oscillatore / inviluppo della voce 3 |
| `$FD5D` | Offset decodificato senza funzione di sintesi definita |
| `$FD5E/$FD5F` | **Non decodificati come SID** |

`N=round(Hz*2^24/clockSID)`: La4 PAL con clock 0 → `$1D45`, scrivere basso
`$45`, alto `$1D`, circa 440,029 Hz. Tenere un'ombra RAM dei registri
write-only; non recuperarli con letture o RMW. Il peek SID del debugger
mostra le ultime scritture, non necessariamente OSC3/ENV3 vivi.
Il buffer audio host modifica la latenza, non la frequenza delle note.

## Modem: polling, FIFO e comandi

| Registro | Lettura / scrittura |
|---|---|
| `$FDF0` | R estrae RX, zero se vuota; W alimenta AT finché non connesso, poi TX |
| `$FDF1` | STATUS; W ignorata |
| `$FDF2` | R zero; W bit 0 reset, altrimenti bit 1 disconnette; bit 2 cancella overrun |
| `$FDF3` | R `$04`, scrittura ignorata: «9600» descrittivo, non baud programmabile |
| `$FDF4/$FDF5` | Byte pendenti RX / TX, 0..128 nel modello corrente |
| `$FDF6/$FDF7` | Firma `$64` / protocollo `$03` |

STATUS: `$01` RX pronta, `$02` TX con spazio, `$04` connesso, `$08` chiamata
in corso, `$10` overrun latched, `$20` offline. Dopo reset: `$22`.
RX/TX hanno **128 byte ciascuna**, con comando da 256 byte: **512 byte
complessivi già nel budget**. In ricezione da rete il backend applica
backpressure quando RX è piena; scritture CPU non accettabili impostano overrun.
Leggere STATUS non cancella flag. Un byte RX `$00` è valido: controllare
prima `$01`. Il peek del dispositivo non estrae; `PEEK` BASIC estrae.

AT supportati: `AT`, `ATE0`, `ATE1`, `ATZ`, `ATH`, `ATDhost[:porta]`,
`ATDThost[:porta]`, terminati da CR ASCII `$0D`. Porta predefinita 23;
risposte `OK`, `ERROR`, `CONNECT 9600`, `NO CARRIER`, racchiuse in CR/LF.
Da connesso `ATH` e `+++` sono dati, non comandi: chiudere con `$FDF2=$02`.

Il backend è TCP host, con Telnet minimo in ingresso: non è un trasporto
binario completamente trasparente e non ha TLS. Non genera IRQ/NMI.
Il poll avviene nel callback video, non leggendo STATUS; usare timeout e
gestire l'overrun. La risoluzione DNS è sincrona. **Vedi capitolo 4.**

## TED, IRQ e reset: promemoria operativo

| Registro | Funzione nativa |
|---|---|
| `$FF00/01`, `$FF02/03`, `$FF04/05` | Timer 1/2/3; W basso ferma, W alto avvia |
| `$FF06/$FF07` | Modalità e controllo video TED |
| `$FF08` | Campionamento input TED; non è una CIA C64 |
| `$FF09` | Flag IRQ; scrivere i bit da riconoscere |
| `$FF0A/$FF0B` | Maschera IRQ e confronto raster; bit 0 di `$FF0A` = linea bit 8 |
| `$FF12..$FF14` | Selezioni/basi della memoria video nativa; rispettare i bit condivisi |
| `$FF15..$FF19` | Colori video, ausiliari e bordo secondo il modo TED |
| `$FF1C/$FF1D` | Contatore raster alto/basso |

IRQ: raster `$02`, T1 `$08`, T2 `$10`, T3 `$40`. I timer contano a metà del
clock base: **886.723,5 tick/s PAL**. Zero iniziale vale 65.536; T1 ricarica
il valore impostato, T2/T3 ricaricano 65.536 dopo il primo underflow.
Letture a due byte non atomiche; se necessario usare alto/basso/alto.
`SEI` maschera gli IRQ: non fornisce l'equivalente di un NMI CIA2.

| Azione | Effetto da ricordare |
|---|---|
| Reset registri SRAM | Banco/offset zero; conserva dati e binding `mainram` |
| Abilitazione plus/64 da disabilitato | Inizializza le viste e azzera la cartuccia, preservando la RAM interna nativa |
| Reset sprite | Azzera registri e latch, conserva il backing condiviso; inizializzare esplicitamente ogni immagine |
| Reset modem, `$FDF2=$01` | Disconnette, azzera indici/comando e overrun, conserva il payload condiviso; echo disattivato |
| Disconnessione, `$FDF2=$02` | Scarta TX, conserva RX e inserisce `OK` |
| Inizializzazione audio | Definire esplicitamente gate, forme, ADSR e volume; non leggerli da write-only |

Per i dettagli consultare i capitoli 2–4; per programmi completi e collaudi,
capitoli 5–6 e il kit SDK. Le prove C host non equivalgono a prove CPU6502,
VICE, Windows reale o hardware fisico.

## Snapshot e proprietà RAM80

VSF con plus/64 attivo: contenitore 2.1, modulo PLUS64 1.0. I 64 KiB sono
in `PLUS4MEM`; i 16 KiB e lo stato dispositivo sono in `PLUS64`. Byte72..78
versionano i formati estesi; byte79 è la revisione scenery, corrente17.
I lettori correnti accettano 0,1,3..17; il prototipo2 è rifiutato. I vecchi
lettori possono rifiutare le nuove versioni; nessun caricamento parziale
silenzioso. Modem connesso/in chiamata: salvataggio e caricamento rifiutati.

Il payload modem è nel banco cartuccia3 `$3E00..$3FFF` in nativo o nella
RAM interna `$0000..$01FF` in MainRAM. Riservarlo prima di usare il modem;
Impossible Mission lo presta alle voci solo quando il modem è inattivo.
Le copie video/snapshot del PC non sono RAM guest. Il compositore scenery
legge la RAM emulata direttamente: per hardware fisico/genlock servono un
percorso dati, sincronizzazione e contesa verificati, non impliciti nell'API.
