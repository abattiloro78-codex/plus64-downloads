# 4. SID e modem

Il SID produce audio; il modem espone un flusso a polling. Nessuno dei due
fornisce una CIA o un interrupt NMI al programma. Gli indirizzi e i clock
seguenti appartengono all’implementazione corrente RAM80, distribuita con
PE SHA256 `08d3e87f84140fe13014213beb32bf7635de12b715769d995efc0658bf08ddfa`
(6.617.154 byte, simboli di debug rimossi senza cambiare le sezioni di codice
e dati caricate). Gli inventari `SID_API.json` e `MODEM_API.json` del manuale
precedente restano evidenze storiche; per capacità e protocolli correnti
fanno fede i sorgenti e le indicazioni aggiornate di questo capitolo.

## 4.1 Attivare un SID con impostazioni riproducibili

Abilitare plus/64 attiva il SIDcart di VICE se non è già attivo, senza
sovrascrivere un SIDcart configurato dall'utente. Pertanto un launcher deve
specificare indirizzo, modello e clock, dopo `-default` e la scelta
dell'ospite. Per il profilo audio usato dai giochi distribuiti:

```text
-sound -sidenginemodel 256 -sidcartaddress 0xFD40 -sidcartclock 0
```

`256` seleziona reSID/MOS6581; `257` seleziona reSID/MOS8580. Non sono
registri che il gioco può cambiare scrivendo un byte. I due modelli hanno
differenze analogiche, di filtro e di comportamento dei campioni digitali:
sceglierne uno e collaudare il gioco con quello. [SID-1, SID-2]

### La finestra effettiva finisce a `$FD5D`

Il dispositivo VICE registra **`$FD40..$FD5D`**, con maschera interna `$1F`
e `IO_MIRROR_NONE`. `$FD5E` e `$FD5F` non sono decodificati come SID da questo
SIDcart. Non usare quegli indirizzi come specchi o come nuovi registri.
La notazione convenzionale «32 registri SID» non estende la finestra
effettivamente registrata. Esiste una configurazione alternativa a
`$FE80..$FE9D`, ma non è il profilo plus/64 adottato qui. [SID-1]

## 4.2 Mappa dei registri SID

Le tre voci hanno lo stesso schema di sette registri. `b` è la base della
voce: `$FD40`, `$FD47` oppure `$FD4E`. Gli offset indicati sono relativi a
questa base, non a `$D400` del C64. [SID-3]

| Registro | Voce 1 | Voce 2 | Voce 3 | Bit e uso |
|---|---|---|---|---|
| `b+0` | `$FD40` | `$FD47` | `$FD4E` | Frequenza, byte basso |
| `b+1` | `$FD41` | `$FD48` | `$FD4F` | Frequenza, byte alto |
| `b+2` | `$FD42` | `$FD49` | `$FD50` | Pulse width, bit 0–7 |
| `b+3` | `$FD43` | `$FD4A` | `$FD51` | Pulse width, bit 8–11 nei bit 0–3; gli altri bit non modificano la larghezza |
| `b+4` | `$FD44` | `$FD4B` | `$FD52` | Controllo forma d'onda e gate |
| `b+5` | `$FD45` | `$FD4C` | `$FD53` | Attack nei bit 7–4, decay nei bit 3–0 |
| `b+6` | `$FD46` | `$FD4D` | `$FD54` | Sustain nei bit 7–4, release nei bit 3–0 |

Il registro di controllo usa questi bit:

| Bit | Maschera | Funzione |
|---:|---:|---|
| 0 | `$01` | GATE: fronte 0→1 avvia l'attacco, fronte 1→0 avvia il rilascio |
| 1 | `$02` | SYNC dell'oscillatore rispetto alla voce sorgente |
| 2 | `$04` | Ring modulation per la componente triangolare |
| 3 | `$08` | TEST: controllo/reset dell'oscillatore; non è un reset generale ADSR |
| 4 | `$10` | Triangolare |
| 5 | `$20` | Dente di sega |
| 6 | `$40` | Impulso, con larghezza a 12 bit |
| 7 | `$80` | Rumore |

Più forme selezionate producono forme combinate proprie del SID, non una
somma arbitraria di generatori. SYNC e ring modulation usano il collegamento
circolare delle voci; richiedono una configurazione consapevole anche della
voce sorgente. Per una nota nuova, lasciare realmente basso GATE prima del
fronte alto: riscrivere `$11` quando GATE è già uno non genera un nuovo
attacco. Non aspettarsi che TEST azzeri il contatore dell'inviluppo. [SID-3]

### ADSR

Ogni parametro A/D/S/R è un nibble 0–15. Il sustain seleziona un livello
`nibble × $11`, da `$00` a `$FF`; non è una durata. Attack, decay e release
selezionano velocità dell'inviluppo. Il codice reSID conserva i confronti
del rate counter seguenti:

| Nibble | Valore di confronto reSID | Attacco nominale indicato nei commenti del modello |
|---:|---:|---:|
| 0 | 8 | 2 ms |
| 1 | 31 | 8 ms |
| 2 | 62 | 16 ms |
| 3 | 94 | 24 ms |
| 4 | 148 | 38 ms |
| 5 | 219 | 56 ms |
| 6 | 266 | 68 ms |
| 7 | 312 | 80 ms |
| 8 | 391 | 100 ms |
| 9 | 976 | 250 ms |
| A | 1953 | 500 ms |
| B | 3125 | 800 ms |
| C | 3906 | 1 s |
| D | 11719 | 3 s |
| E | 19531 | 5 s |
| F | 31250 | 8 s |

Questi tempi sono nominali, non scadenze esatte in millisecondi: dipendono
dal clock e dallo stato del contatore. Decay e release usano inoltre
divisioni esponenziali a tratti, quindi non adottare la colonna «attacco»
come loro durata. Un cambio ADSR durante una nota può incontrare il
comportamento del rate counter, incluso il noto ritardo ADSR. [SID-4]

### Filtro, volume e letture

| Indirizzo | Uso |
|---|---|
| `$FD55` | Cutoff basso: soltanto bit 0–2 |
| `$FD56` | Cutoff alto: otto bit; `cutoff = (alto << 3) | (basso & 7)` |
| `$FD57` | Risonanza bit 7–4; invio al filtro di voce 1/2/3 e ingresso esterno nei bit 0/1/2/3 |
| `$FD58` | Volume bit 3–0; low-pass bit 4, band-pass bit 5, high-pass bit 6; bit 7 esclude la voce 3 dal percorso diretto |
| `$FD59` | Lettura POTX, dipendente dagli ingressi/configurazione emulata |
| `$FD5A` | Lettura POTY, stesso vincolo |
| `$FD5B` | Lettura uscita oscillatore della voce 3 |
| `$FD5C` | Lettura inviluppo della voce 3 |
| `$FD5D` | Offset SID `$1D` senza funzione di sintesi definita |
| `$FD5E/$FD5F` | Fuori dalla finestra SIDcart registrata |

Il cutoff a 11 bit non corrisponde a una conversione lineare universale in
hertz: filtro e modello del chip contano. Il bit di ingresso esterno non
dimostra che una cartuccia fisica disponga già di un percorso analogico
realizzato. Volume zero silenzia l'uscita, senza fermare necessariamente gli
oscillatori o la sequenza musicale. [SID-3, SID-5]

I registri di sintesi sono **scrivibili, non normali celle RAM leggibili**.
Una lettura CPU di un registro write-only restituisce il comportamento del
bus SID emulato, non una copia affidabile del valore impostato. Conservare
un'ombra RAM dei propri valori; usare `STA`, non `INC/ASL` sui registri SID.
L'emulatore modella anche le scritture ulteriori delle istruzioni RMW.

Il peek del debugger è diverso: `sid_peek_chip()` restituisce l'array
`siddata` delle ultime scritture e non campiona realmente OSC3/ENV3. Con il
suono disabilitato, le letture CPU hanno un fallback software: non usarle
per dimostrare un oscillatore attivo o per una sorgente casuale indipendente
dalla configurazione audio. [SID-6]

## 4.3 Clock: C64, TED e impostazione «native»

Per una forma periodica, con valore di frequenza `N` a 16 bit:

```text
f_nota = N × f_clock_SID / 2^24
N = arrotonda(f_nota × 2^24 / f_clock_SID)
```

Con `-sidcartclock 0`, il runtime inizializza il SID PAL a **985.248 Hz**
(NTSC: 1.022.730 Hz). Il ponte converte i clock base VICE nel dominio SID
con rapporto razionale e resto conservato, anche quando il buffer audio
viene consumato solo in parte. Questo non rende identiche le temporizzazioni
del codice CPU C64 e TED. [SID-1, SID-7]

**Attenzione al significato di `-sidcartclock 1` in questa build:** il codice
passa al SID il valore `cycles_per_sec` della macchina, che in PAL è
**1.773.447 Hz**. Il nome «PLUS4/native clock» dell'opzione non indica qui
886 kHz. Quest'ultimo è il valore `1.773.447 / 2 = 886.723,5 Hz` dei tick dei
timer TED e di una possibile scelta di clock fisico lento; non è il valore
passato al SID dall'opzione 1 del runtime conservato. Non copiare tabelle
di note per 886 kHz su quel profilo. [SID-1, SID-7]

Esempio La4, circa 440 Hz, con il profilo C64 PAL: `N=7493=$1D45`, frequenza
effettiva calcolata circa **440,029 Hz**. Il byte basso è `$45`, quello alto
`$1D`. Una nota triangolare sulla prima voce, all'inizializzazione di un
programma che possiede il SID, può essere impostata così:

```asm
        lda #0
        sta $fd44       ; GATE basso, nessuna forma selezionata
        sta $fd57       ; nessun invio al filtro per questo esempio
        lda #$09
        sta $fd45       ; attacco 0, decay 9
        lda #$f4
        sta $fd46       ; sustain F, release 4
        lda #$45
        sta $fd40
        lda #$1d
        sta $fd41
        lda #$0f
        sta $fd58       ; volume massimo, percorsi diretti
        lda #$11
        sta $fd44       ; triangolare + fronte GATE alto
        rts
; In un tick successivo, per rilasciare la nota:
rilascio:
        lda #$10
        sta $fd44       ; stessa forma, GATE basso
        rts
```

Le altre due voci devono essere inizializzate o gestite dal proprio driver.
Il campione non assegna un timer e non impone una durata: il tick del gioco
deve decidere quando chiamare `rilascio`. Se un IRQ musicale scrive lo
stesso SID, coordinare le scritture con quel driver.

La dimensione del buffer audio VICE, per esempio `-soundbufsize 64`, cambia
la latenza host, non la formula delle note e non la frequenza degli IRQ.
Una conversione C64 che usava CIA/NMI deve adattare separatamente il proprio
scheduler: il SID non genera quegli interrupt.

## 4.4 Modem: registri e stato

Il modem è disponibile a `$FDF0..$FDF7` quando plus/64 è abilitato.
Espone una FIFO RX da **128 byte**, una FIFO TX da **128 byte** e un buffer
comandi da **256 byte**: **512 byte complessivi**, tutti compresi negli
**80 KiB = 64 KiB cartuccia + 16 KiB interni**. Non è una ACIA e non contiene
registri CIA. Il backend attuale usa socket TCP del computer host. [MOD-1]

Le FIFO non sono memoria privata del modem. Nel profilo nativo sono alias
del banco cartuccia 3, offset `$3E00..$3FFF`; nel profilo MainRAM sono alias
dei 16 KiB interni, offset `$0000..$01FF`, accessibili anche dalla porta sprite.
Il programma deve riservare l’area prima di usare il modem ed evitare
scritture concorrenti da parte di sprite, audio o altri utilizzatori. Quando
il modem è disconnesso, senza chiamata, code o comando parziale, un programma
che non esegue I/O modem può prestare l’area ad altre risorse. Deve però
restituirgliela prima di avviare comandi o connessioni.

| Indirizzo | Lettura CPU | Scrittura CPU |
|---|---|---|
| `$FDF0` DATA | Estrae un byte RX; se vuota restituisce zero | In modalità comandi alimenta il parser; connesso accoda un byte TX |
| `$FDF1` STATUS | Bit di stato della tabella seguente | Ignorata |
| `$FDF2` CONTROL | Sempre zero | Bit 0 reset; altrimenti bit 1 disconnessione; bit 2 cancella overrun |
| `$FDF3` BAUD | Sempre `$04`, valore descrittivo «9600» | Ignorata: non regola una seriale reale |
| `$FDF4` RX COUNT | Byte pendenti RX, 0–128 | Ignorata |
| `$FDF5` TX COUNT | Byte pendenti TX, 0–128; non è lo spazio libero | Ignorata |
| `$FDF6` | Firma `$64` | Ignorata |
| `$FDF7` | Versione protocollo condiviso `$03` | Ignorata |

| STATUS bit | Maschera | Significato quando è 1 |
|---:|---:|---|
| 0 | `$01` | RX contiene almeno un byte |
| 1 | `$02` | TX ha spazio per almeno un byte, anche quando non si è connessi |
| 2 | `$04` | Connesso |
| 3 | `$08` | Connessione in corso |
| 4 | `$10` | Overrun latched: una scrittura o risposta locale ha superato lo spazio disponibile |
| 5 | `$20` | Né connesso né in chiamata; stato offline, non un evento latched |
| 6–7 | `$C0` | Zero nella versione attuale |

Un byte RX zero è un dato valido. Controllare STATUS bit 0 prima di leggere
DATA, senza interpretare zero come «FIFO vuota». Leggere STATUS non cancella
alcun flag. Un peek del dispositivo su DATA mostra il prossimo byte senza
consumarlo; il normale `PEEK` BASIC è invece una lettura CPU e lo consuma.
I contatori descrivono i byte effettivamente accodati nei buffer da 128 byte;
non esiste la precedente capacità privata di 8 KiB per coda. [MOD-1]

CONTROL è un insieme di azioni, non uno stato memorizzato: `$01` fa reset;
`$02` interrompe il collegamento e inserisce `OK` in RX; `$04` cancella solo
l'overrun. Se sono presenti sia bit 0 sia bit 1, prevale il reset; bit 2 viene
poi gestito comunque. Non esiste un enable IRQ. La disconnessione svuota TX
ma conserva RX; il reset svuota entrambe le FIFO, il comando parziale e
l’overrun, disconnette e ripristina echo disattivato. Il reset modifica
indici e stato del dispositivo: **non azzera il banco di RAM condiviso**. [MOD-1]

## 4.5 Comandi AT effettivamente implementati

Inviare byte **ASCII**, terminando il comando con CR (`$0D`). LF viene
ignorato. Il parser è case-insensitive per i comandi, ma conserva il nome
host. Le risposte hanno forma `CR LF testo CR LF`. Non serve connettersi
a una rete per provare `AT`. [MOD-2]

| Comando | Risultato |
|---|---|
| `AT` | `OK` |
| `ATE0` / `ATE1` | Disattiva/attiva echo locale dei byte in modalità comandi; `OK` |
| `ATZ` | Reset del modem e `OK` |
| `ATH` | Disconnessione e `OK`, quando il parser è in modalità comandi |
| `ATDhost` / `ATDThost` | Tenta TCP verso porta 23 |
| `ATDhost:porta` / `ATDThost:porta` | Porta decimale 1–65535; host non vuoto, massimo 219 byte |

Connessione immediata o completata al poll successivo: `CONNECT 9600`.
Fallimento o perdita del collegamento: `NO CARRIER`. Comandi non supportati
o sintassi non ammessa: `ERROR`. Non assumere `ATH0`, escape `+++`, registri
S, modalità numerica delle risposte o sequenze di comandi concatenate:
non sono implementati.

Il buffer comando contiene al massimo 255 caratteri stampabili; un ulteriore
carattere causa `ERROR`, azzera la lunghezza e viene scartato. Backspace
(`$08`) e DEL (`$7F`) cancellano un carattere, se presente. Con echo attivo
anche i caratteri di controllo vengono accodati prima dell'elaborazione.

**Quando connesso, ogni byte scritto su DATA è traffico da trasmettere.**
La stringa `ATH` non viene interpretata localmente e `+++` non cambia
modalità. Per chiudere dal programma usare CONTROL bit 1. Durante la fase
di chiamata il parser resta attivo: il programma può interromperla tramite
CONTROL oppure `ATH`.

## 4.6 Polling, Telnet e limiti del backend

`machine_vsync_hook()` chiama `plus64vice_frame()`, che esegue il poll modem
una volta per aggiornamento video. La lettura di STATUS non forza il poll.
Il poll prova l'avanzamento della connessione, invia una porzione contigua
di TX e riceve soltanto nello spazio contiguo libero della coda RX: al massimo
128 byte, spesso meno per occupazione o avvolgimento del ring. Con RX piena
non legge dal socket e applica così backpressure al trasporto. La velocità
«9600» è descrittiva: non vengono simulati un baud rate UART, bit seriali,
RTS/CTS o tempi elettrici. Prevedere timeout del gioco, drain frequente di
RX e controllo dell'overrun. [MOD-3]

L'ingresso passa sempre attraverso una gestione Telnet minima:

- `IAC IAC` (`$FF $FF`) consegna un solo byte `$FF` al gioco.
- `WILL` e `DO` vengono rifiutati con `DONT` e `WONT`; `WONT/DONT` sono consumati.
- Le sottonegoziazioni vengono scartate fino a `IAC SE`.
- I dati ordinari sono byte in RX: non avviene conversione ASCII/PETSCII.

Non è un trasporto binario TCP totalmente trasparente. In uscita il codice
accoda i byte dell'applicazione senza raddoppiare automaticamente `$FF`;
un protocollo con peer Telnet deve gestire consapevolmente quell'escape.
Non vi sono TLS, autenticazione di servizio o protocollo HTTP nel modem.

Il socket è non bloccante, ma la risoluzione del nome con `getaddrinfo()`
è sincrona: una chiamata ATD con un nome problematico può fermare
temporaneamente l'interfaccia dell'emulatore. Per i collaudi riproducibili
usare un servizio di test locale e un timeout; non interpretare una pausa
DNS come un timer del gioco. [MOD-4]

### Due primitive non bloccanti

Il chiamante conserva il byte da inviare e riprova in un tick successivo
quando TX è piena. Un solo componente del gioco deve possedere il modem.

```asm
; Entrata A contiene il byte. Carry zero se consegnato, uno per riprovare.
modem_prova_tx:
        pha
        lda $fdf1
        and #$02
        beq tx_piena
        pla
        sta $fdf0
        clc
        rts
tx_piena:
        pla
        sec
        rts

; Carry uno se A contiene un byte valido, anche $00. Carry zero se vuoto.
modem_prova_rx:
        lda $fdf1
        and #$01
        beq rx_vuota
        lda $fdf0
        sec
        rts
rx_vuota:
        clc
        rts
```

In modalità comandi, «consegnato» significa passato al parser, non inviato
su TCP. In modalità dati significa accodato: non conferma che il peer lo
abbia ricevuto. Dopo un gruppo di invii controllare anche overrun, stato
connesso e risposte. Per una prova locale del parser inviare `$41 $54 $0D`
e raccogliere la risposta senza loop di attesa infinito.

## 4.7 Cosa prova il modello e cosa resta hardware

I checkpoint VSF correnti conservano stato locale, indici e tutti i byte RAM80
condivisi. Salvataggio e caricamento vengono rifiutati con modem connesso o
in chiamata, perché lo stato del peer TCP esterno non può essere riavvolto.
Un caricamento non riconnette automaticamente il peer.

Il modello documenta registri, FIFO condivise e API socket host. Non contiene un
firmware MCU della cartuccia, un modem seriale elettrico, un clock SID
misurato, alimentazioni analogiche o un circuito di interrupt aggiuntivo.
La cartuccia fisica deve rispettare il medesimo comportamento visibile;
quelle implementazioni e il relativo budget di memoria richiedono un
progetto e prove propri. Questo audit dei sorgenti non esegue connessioni
remote, un nuovo ascolto su Windows o un collaudo fisico.

## Riferimenti del capitolo

I percorsi seguenti sono relativi a `reference/vice/` nel pacchetto del
manuale e identificano i sorgenti correnti. Gli inventari storici e le prove
1.0 non sostituiscono i rapporti RAM80 e formato 17 della distribuzione.

- **SID-1:** `src/plus4/cart/plus4-sidcart.c`, decoder I/O SIDcart,
  `sidcart_sound_machine_init`, risorse di attivazione e clock;
  `src/plus4/plus64vice.c`, integrazione e configurazione plus/64.
- **SID-2:** `src/sid/sid-cmdline-options.c`, selezione engine/modello SID.
- **SID-3:** `src/resid/sid.cc`, letture e scritture dei registri;
  `src/resid/wave.cc`, `wave.h` e `voice.cc`, controllo delle forme d’onda,
  sincronizzazione e ring modulation.
- **SID-4:** `src/resid/envelope.cc`, contatori, tabelle e scritture ADSR.
- **SID-5:** `src/resid/filter.cc`, registri di cutoff, risonanza e modalità.
- **SID-6:** `src/sid/sid.c` e `src/resid/sid.cc`, percorsi read/peek,
  valori di bus e `siddata`.
- **SID-7:** `src/plus4/cart/plus64_sid_clock_ratio.h`, rapporto razionale;
  `src/plus4/plus4.h`, `plus4.c`, `src/sound.c`, `src/sid/sid.c` e
  `src/sid/resid.cc`, costanti e raccordo dei clock audio.
- **MOD-1:** `src/plus4/plus64_modem.h`, definizioni `P64_RX_CAP`, `P64_TX_CAP`,
  `P64_CMD_CAP`, viste sullo storage condiviso e API; `plus64_modem.c`,
  `p64_modem_init/reset`, `status`, `p64_modem_peek/read/store`.
- **MOD-2:** `src/plus4/plus64_modem.c`, funzioni `command` e
  `stream_from_device`.
- **MOD-3:** `src/plus4/plus64_modem.c`, `telnet_in` e `p64_modem_poll`;
  `plus64vice.c`, chiamata a `p64_modem_poll` nel percorso video.
- **MOD-4:** `src/plus4/plus64_net.c`, `net_open`, `net_state`, `net_send` e
  `net_recv`.
