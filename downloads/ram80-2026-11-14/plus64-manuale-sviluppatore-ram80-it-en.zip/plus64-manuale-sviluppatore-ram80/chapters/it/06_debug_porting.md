# Debug, strumenti e riuso di codice C64

## Le prove da tenere separate

| Prova | Cosa dimostra |
| --- | --- |
| Calcolo Python | Formati, indirizzi e trasformazioni dei dati nel programma di analisi |
| Simulazione6502 con periferiche stub | Esecuzione delle istruzioni e contratto degli stub usati |
| Moduli C reali del dispositivo | Comportamento di registri e renderer nelle funzioni compilate |
| VICE nativo | Interazione di CPU guest, TED e dispositivi del modello |
| PE Windows sotto Wine | Comportamento di quell'eseguibile e delle API ospiti simulate |
| Windows nativo | Esecuzione su un sistema Windows reale |
| Cartuccia fisica | Comportamento elettrico e temporale misurato su hardware |

Una riga «PASS» ha senso soltanto insieme a versione, input e ambito.
Un test con stato finale predisposto verifica il finale, non dimostra una
campagna intera vinta naturalmente. Il manifesto dell'SDK elenca le prove
effettivamente eseguite senza promuoverle a certificazione fisica.

## Un controllo pratico per ogni nuova build

- Verificare che codice e dati restino nei **65.536 + 16.384 byte** della
  macchina comune, senza contare due volte alias, cache, sorgenti compressi
  e buffer decodificati riutilizzati in fasi diverse.
- Provare primo avvio, reset e rientro al titolo.
- Provare i bordi: X255/256, X319, Y199 e dati a cavallo di un banco SRAM.
- Provare un pixel sprite0 opaco e uno255 trasparente sullo stesso sfondo.
- Leggere il latch una volta, poi verificarne l'azzeramento e i nuovi eventi.
- Misurare il ritmo durante HUD, spari, collisioni e cambio scena.
- Verificare mute, rilascio delle note e frequenze SID con il clock scelto.
- Conservare la versione precedente e gli hash dell'eseguibile e del D64.

Non allargare automaticamente le tolleranze perché un test fallisce:
prima distinguere un problema del programma, dell'osservazione o della
configurazione dell'ospite. Per esempio un'uscita audio assente nel banco
Wine senza dispositivo sonoro non prova un errore dei registri SID.

## Monitor e acquisizioni

Usare breakpoint su funzioni note, acquisizioni RAM e immagini della canvas
VICE. Per i registri con effetti collaterali tenere conto del percorso
`read` rispetto a `peek`; il monitor può deliberatamente non consumare
FIFO o latch. Una prova della lettura CPU deve eseguire una `LDA` guest.

Le immagini vanno confrontate con lo stato della stessa fase del frame.
Se lo sprite cambia descrittore a metà schermo, una lettura RAM successiva
non ricostruisce da sola ciò che era già stato disegnato nelle righe alte.
Per il multiplex annotare fascia raster, slot, puntatore e maschera pubblicata.

L’input diagnostico `@k` usato da alcuni strumenti del progetto va letto
insieme al contratto di quello strumento o build osservatore: non è un
registro plus/64 disponibile al programma e non va assunto come comando
portabile di una distribuzione Windows. I giochi leggono
la tastiera o il joystick emulati, come nell'esempio SDK.

## Perché un porting C64 non è una sostituzione globale di indirizzi

I dati che rappresentano un indirizzo possono comparire come operandi,
tabelle di puntatori, codice generato o valori calcolati. Un numero uguale
a `$D400` dentro un bitmap non è per questo una scrittura SID.
Il codice può inoltre dipendere da VIC-II, CIA, ROM, vettori o temporizzazioni
non presenti sul C16/Plus/4.

Una procedura utile è:

1. Identificare con hash l'input e ricostruire il caricamento effettivo.
2. Disassemblare dagli ingressi noti e seguire il controllo di flusso.
3. Segnalare salti indiretti e parti non ancora risolte, senza indovinare.
4. Separare le logiche già indipendenti dall'hardware dagli accessi ai dispositivi.
5. Definire sostituzioni per siti e profili espliciti, verificando gli operandi.
6. Conservare il comportamento del gioco e confrontare le sequenze osservabili.

Il toolkit distribuito contiene `translate_core.py` per inventario D64,
estrazione e analisi, librerie6502 e builder per profili noti. Il decoder
documentato copre i151opcode ufficiali NMOS6502; non è la promessa che
qualsiasi gioco o opcode non documentato sia convertibile automaticamente.

Le patch disponibili per un dump noto non si applicano a una copia diversa
soltanto perché porta lo stesso nome. L'output di un'analisi RAM non è
automaticamente un D64 avviabile: loader, servizi, input, grafica, audio
e stato della partita devono essere integrati e collaudati.

## Primo percorso di apprendimento

Partire dall'esempio SDK; aggiungere un secondo sprite e una collisione,
poi una tabella di animazione nella SRAM. Solo dopo aggiungere caricamenti,
scroll o multiplex. Il manuale e l'esempio descrivono API correnti; gli
indirizzi o driver di una futura implementazione fisica andranno documentati
separatamente, quando definiti e verificati.


## Snapshot, ripristino e versioni da verificare

Un test di checkpoint deve confrontare tutta la RAM80, non soltanto la
finestra CPU visibile: 65.536 byte principali più 16.384 byte interni.
Verificare prima il ripristino immediato, poi la continuazione con gli
stessi input, preferibilmente anche in un nuovo processo e sull’altro
modello C16/Plus/4. Registrare revisione del contenitore VSF, modulo PLUS64,
configurazione di memoria e feature video; una lettura riuscita non basta
a provare che sia stato ripristinato lo stesso profilo.

Il runtime corrente usa contenitore Plus/4 VSF 2.1 e modulo PLUS64 1.0, con
protocollo SRAM `$05`, modem `$03` e revisione di scenario 17. I checkpoint
legacy privi dei byte RAM80 richiesti vengono rifiutati. Un modem connesso
o in chiamata impedisce salvataggio e caricamento: il test non deve
promettere di riavvolgere un peer remoto. Per il SID distinguere stato
digitale e scritture ai registri dall’identità del PCM analogico o della
storia del ricampionamento host.

## Identità della distribuzione finale

L’eseguibile Windows finale senza simboli di debug occupa **6.617.154 byte**
e ha SHA256:

```text
08d3e87f84140fe13014213beb32bf7635de12b715769d995efc0658bf08ddfa
```

La rimozione dei simboli di debug non cambia le sezioni caricate di codice
e dati; il rapporto di distribuzione conserva il confronto e la provenienza
dalla build completa. Il D64 Impossible Mission REV8R conserva codice e
dati della revisione qualificata. Le prove con pezzi o password già pronti
sono stati di test separati, non la partita normale e non una vittoria
naturale utilizzabile come certificazione di tutta la missione.

Le prove Linux C16/Plus/4 e quelle dell’eseguibile Windows tramite Wine
restano distinte da Windows nativo e dall’hardware fisico. Il controllo dei
byte RAM e dei registri non qualifica da solo il futuro arbitraggio del bus,
la contesa fra CPU e video, la banda del compositore o la sincronizzazione
di una cartuccia reale.
