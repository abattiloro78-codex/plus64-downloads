# Come usare questo manuale

Questo manuale serve a scrivere nuovi giochi per il **modello software
plus/64** eseguito dal runtime VICE distribuito con il progetto. Descrive
gli indirizzi effettivamente decodificati, i formati realmente letti dal
renderer e le convenzioni verificate dagli esempi. Non presuppone l'accesso
a un repository online: esempi, costanti e riferimenti sono nel pacchetto.

**Edizione documentale 2.0 RAM80 — 14 novembre 2026. Progetto Meck.**
Il riferimento corrente è il runtime Windows `xplus4.exe` da 6.617.154 byte,
con SHA256 `08d3e87f84140fe13014213beb32bf7635de12b715769d995efc0658bf08ddfa`. La distribuzione finale ha le sezioni debug
rimosse; il codice eseguibile è identico alla build di riferimento verificata.
Il numero dell'edizione riguarda il manuale, non una nuova revisione elettrica
della cartuccia. La porta RAM corrente dichiara il protocollo `$05`; il formato
del modulo snapshot PLUS64 resta 1.0 e la versione scenery corrente è 17.

## Che cosa offre la piattaforma

Il C16 o Plus/4 continua a fornire CPU, TED, tastiera, joystick e KERNAL.
plus/64 aggiunge, nel modello emulato, SID, una porta per64KiB di SRAM,
otto descrittori sprite composti sopra il video TED e un modem a registri.
Gli sprite hanno una tavolozza di121 colori; il TED mantiene la propria
tavolozza di121 colori distinti. Ogni singola cella del bitmap TED rimane
soggetta ai limiti del suo modo video:121 non significa121 colori per cella.

Un solo `xplus4.exe` emula sia C16 sia Plus/4. Il nome del programma non
identifica una versione del gioco destinata soltanto al Plus/4. Lo stesso
programma può usare la stessa API e lo stesso budget di memoria sui due
ospiti. Il profilo nativo impone 16 KiB di RAM CPU anche sul Plus/4; il profilo
MainRAM impone 64 KiB di cartuccia come RAM CPU. La memoria complessiva
disponibile al programma è sempre **64+16 KiB, cioè 81.920 byte**.

## Due profili da distinguere

| Profilo | Impiego | Memoria osservabile |
| --- | --- | --- |
| Nativo, consigliato per iniziare | Nuovi giochi e SDK di questo manuale | Codice e TED nei 16 KiB interni; 64 KiB cartuccia tramite `$FDE8..$FDED`; la porta sprite vede il banco cartuccia 2 |
| MainRAM | Raccordo del motore C64 di Impossible Mission e programmi avanzati | CPU/TED e porta SRAM vedono gli stessi 64 KiB cartuccia; la porta sprite vede i 16 KiB interni distinti |

Il codice implementa due backing: `mem_ram[65536]` e `p64_aux_ram[16384]`.
Le viste SRAM, sprite e modem sono alias di questi byte, non pool aggiuntivi.
Nel profilo nativo il modem usa gli ultimi 512 byte del banco cartuccia 3;
in MainRAM usa i primi 512 byte della RAM interna. Ogni programma deve
riservare le aree condivise che utilizza. Non sommare una seconda SRAM,
RAM sprite privata o FIFO modem al budget: il totale resta 80 KiB.

Il cambio di profilo è un'impostazione del runtime, non un nuovo registro
CPU. Riordina in posto i cinque blocchi da 16 KiB preservandone i dati;
richiede sprite disabilitati e modem inattivo, con code e comando vuoti.
Il profilo software non dimostra un decoder fisico della cartuccia.

## Stato delle informazioni

| Etichetta | Significato |
| --- | --- |
| API corrente | Comportamento presente nei sorgenti del runtime di riferimento |
| Verificato in VICE | Istruzioni della CPU guest o pixel realmente prodotti nell'emulatore |
| Formato sperimentale | Funzione opt-in già presente, con opzioni e layout specifici |
| Questione hardware aperta | Non è una funzione da presumere disponibile su una cartuccia fisica |

La cartuccia qui descritta è **emulata dentro VICE**. I nuovi materiali e
scenari leggono direttamente le strutture RAM emulata tramite il codice
host: un circuito fisico deve ancora definire accesso ai dati, contesa e
sincronizzazione video. Un eventuale compositor/genlock esterno richiede
un progetto e verifiche propri, non impliciti in questi test. Non è una semplice
immagine ROM/CRT caricabile nel VICE ufficiale, né un circuito fisico
certificato. I test software non misurano alimentazione, contesa sul bus,
temporizzazioni elettriche o qualità del video analogico.

## Cosa occorre

- Il runtime Windows plus/64 già distribuito, per giocare o eseguire i PRG.
- Per compilare l'esempio: Python3 e assembler `xa`; vedere `sdk/README.md`.
- Per partire: familiarità con registri6502, indirizzamento, stack e salti.
- Per usare i diagnostici VICE: ROM del sistema e un eseguibile con il
  supporto plus/64 corrispondente. L'SDK non contiene un nuovo emulatore.

I moduli aggiunti non emulano un Commodore64 completo. In particolare non
si devono presumere VIC-II, CIA, raster IRQ C64, sprite DMA C64 o un NMI
programmabile soltanto perché sono presenti SID e grafica aggiuntiva.

## Convenzioni di scrittura

Gli indirizzi con `$` sono esadecimali; `0x` è equivalente negli strumenti
Python/C. I valori binari sono indicati con `%`. Un byte vale0–255,
un KiB1024byte. Le tabelle specificano separatamente lettura e scrittura.

Una lettura CPU di un registro non equivale sempre a guardarlo con il
monitor: il monitor può usare una funzione `peek` senza effetti collaterali.
Una normale `LDA` o `PEEK` BASIC è invece una lettura del programma e può
far avanzare un puntatore, consumare un byte del modem o azzerare un latch.

Le citazioni a file della cartella `reference` si riferiscono alle copie
congelate incluse nel pacchetto. I loro hash sono riportati nel manifest.
Le citazioni non richiedono un collegamento a repository privati.

# Avvio rapido

## Organizzazione della cartella

Estrarre il manuale e l'SDK conservando le sottocartelle. Per eseguire la
demo, usare il runtime già distribuito: non sono necessari i D64 dei giochi
né una loro partita salvata. Per compilare, dalla cartella del manuale:

```sh
python sdk/build.py --out build-demo
```

La destinazione deve essere nuova. `xa` deve essere nel PATH; se serve,
impostare la variabile `XA` al suo percorso. I dettagli e gli output effettivi
sono descritti nel README dell'SDK. Il materiale `sdk-current` aggiunge
un esempio dei materiali correnti senza sostituire il programma base. Il codice sorgente dell'esempio è
fornito integralmente, non è uno pseudoprogramma da completare.

## Profilo di esecuzione nativo

Le opzioni essenziali per lo sviluppo iniziale sono:

```text
-default -model c16 -ramsize 16
-plus64 -plus64rastercollisions
-sound -soundbufsize 64
-sidenginemodel 256 -sidcartaddress 0xFD40 -sidcartclock 0
```

`-plus64` abilita i dispositivi. `-plus64rastercollisions` abilita il
percorso per scanline e la pubblicazione immediata alla scrittura diFD90.
Non aggiunge un registro. Per l'altro ospite sostituire `-model c16` con
`-model plus4`, mantenendo il limite interno16KiB.

Per questo esempio lasciare disattivati `plus64mainram`, `plus64packedcache`,
`plus64mixedsprites` e `plus64leftmcm`: appartengono al profilo avanzato. Usare `-default`
evita di ereditare accidentalmente le opzioni di un gioco precedente.

`-directory` deve indicare la cartella delle risorse del runtime; KERNAL,
BASIC, ROM1541 e keymap devono essere quelli della distribuzione funzionante.
Per un D64, mantenere anche le opzioni di unità1541 e bus/trap del launcher
distribuito. Non cambiare clock SID per accelerare caricamenti o animazioni.

## Risultato atteso

La demo mostra grafica TED e uno sprite colorato trasparente, mosso dai
comandi documentati nell'SDK. Un comando attiva una nota SID. La pubblicazione
dei descrittori non cancella il bitmap. I diagnostici separati verificano
lettura/scrittura dei dispositivi: non vanno confusi con un gioco completo.
