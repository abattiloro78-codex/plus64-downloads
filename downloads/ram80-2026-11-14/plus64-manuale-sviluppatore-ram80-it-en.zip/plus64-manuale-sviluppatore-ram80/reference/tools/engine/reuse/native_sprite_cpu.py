"""Emit the native 6502 VIC-image to existing plus/64 sprite bridge.

Patterns are read at runtime, after original animation/mirroring code. Byte
63 is an engine orientation tag, not image data; it is neither read nor
changed here. The caller supplies compact overlay palette bytes at D450
by default; source-register and palette addresses can be relocated.
This is a paused-frame output adapter, not VIC raster/collision emulation.
"""

PALETTE = 0xd450
SLOT, MASK, OFFSET, ENABLE = range(0xd460, 0xd464)
XLOW, XHIGH, YPOS, BYTE = range(0xd464, 0xd468)
COLORS = 0xd468
PAIRS = 0xd46c
ROW = 0xd46d
SHIFT = 0xd470
STATUS = 0xd47f


def emit_sprites(asm, label_prefix='sprite', *, vic_base=0xd000,
                 palette_address=PALETTE):
    """Append an inline bridge; return its labels and byte length.

    IRQs must be masked and decimal mode clear. F8/F9 and source RAM are
    preserved; A/X/Y and D460..D47F are scratch. D47F is zero on success,
    1 for an unsupported negative X (multicolor or expanded), 2 for negative
    Y, and 3 for a visible behind-background sprite. Unsupported output leaves FD90=0.
    Fully invisible left/top sprites are omitted without changing D015.
    Negative X in nonexpanded hires is clipped by shifting a temporary
    three-byte row, preserving every source byte and its orientation tag.
    ``vic_base`` supplies a 47-byte software view of D000..D02E; rebasing
    this view does not move hardware registers, source images or scratch.
    ``palette_address`` supplies the 16 compact overlay color indices.

    The existing private sprite RAM receives at most 8*504 bytes in fixed
    512-byte slots; its physical cartridge budget is not certified here.
    """
    if not 0 <= vic_base <= 65536 - 47:
        raise ValueError('the 47-byte VIC register view must fit in RAM')
    if not 0 <= palette_address <= 65536 - 16:
        raise ValueError('the 16-byte palette must fit in RAM')
    start = len(asm.code)
    targets = []

    def label(name):
        asm.label(label_prefix + '-' + name)

    def branch(opcode, name):
        asm.branch(opcode, label_prefix + '-' + name)

    def jump(name):
        asm.emit(0x4c, 0, 0)
        targets.append((len(asm.code) - 2, label_prefix + '-' + name))

    def load(address):
        asm.absolute(0xad, address)

    def vic_absolute(opcode, address):
        asm.absolute(opcode, vic_base + address - 0xd000)

    def load_vic(address):
        vic_absolute(0xad, address)

    def store(address):
        asm.absolute(0x8d, address)

    def immediate(value):
        asm.emit(0xa9, value)

    # Preserve the two indirect-address temporaries in the original state.
    asm.emit(0xa5, 0xf8, 0x48, 0xa5, 0xf9, 0x48)
    immediate(0)
    for address in (0xfd90, ENABLE, STATUS, SLOT):
        store(address)
    immediate(1); store(MASK)
    label('slot')
    load_vic(0xd015); asm.absolute(0x2d, MASK)
    branch(0xd0, 'enabled'); jump('next')
    label('enabled')
    immediate(0); store(SHIFT)
    load(SLOT); asm.emit(0x0a, 0xa8)  # Y = 2*slot.
    vic_absolute(0xb9, 0xd001); asm.emit(0x38, 0xe9, 50)
    store(YPOS); branch(0xb0, 'y-ready')
    # A sprite above the viewport can be wholly hidden, including expanded Y.
    load_vic(0xd017); asm.absolute(0x2d, MASK)
    branch(0xf0, 'unexpanded-y')
    immediate(8); branch(0xd0, 'y-limit')
    label('unexpanded-y'); immediate(29)
    label('y-limit')
    vic_absolute(0xd9, 0xd001)  # CMP rawY: threshold>=Y means invisible.
    branch(0x90, 'bad-y'); jump('next')
    label('bad-y'); immediate(2); jump('fail')
    label('y-ready')
    load(YPOS); asm.emit(0xc9, 200)
    branch(0x90, 'above-bottom'); jump('next')
    label('above-bottom')
    load_vic(0xd010); asm.absolute(0x2d, MASK)
    asm.emit(0xc9, 1, 0xa9, 0, 0x2a); store(XHIGH)
    vic_absolute(0xb9, 0xd000); asm.emit(0x38, 0xe9, 24); store(XLOW)
    load(XHIGH); asm.emit(0xe9, 0); store(XHIGH)
    branch(0x10, 'x-ready')
    # Unexpanded rawX=0 is wholly hidden. Other negative hires X positions
    # are represented exactly by a shifted row at overlay coordinate zero.
    load_vic(0xd01d); asm.absolute(0x2d, MASK)
    branch(0xd0, 'bad-x')
    vic_absolute(0xb9, 0xd000); branch(0xd0, 'partial-left'); jump('next')
    label('partial-left')
    load_vic(0xd01c); asm.absolute(0x2d, MASK); branch(0xd0, 'bad-x')
    immediate(24); asm.emit(0x38); vic_absolute(0xf9, 0xd000); store(SHIFT)
    immediate(0); store(XLOW); store(XHIGH); branch(0xf0, 'x-ready')
    label('bad-x'); immediate(1); jump('fail')
    label('x-ready')
    load(XHIGH); branch(0xf0, 'inside-right')
    load(XLOW); asm.emit(0xc9, 64)
    branch(0x90, 'inside-right'); jump('next')
    label('inside-right')
    load_vic(0xd01b); asm.absolute(0x2d, MASK)
    branch(0xf0, 'priority-ready'); immediate(3); jump('fail')
    label('priority-ready')
    # Y = 6*slot for the six existing per-sprite output registers.
    load(SLOT); asm.emit(0x0a, 0x18); asm.absolute(0x6d, SLOT)
    asm.emit(0x0a, 0xa8); store(OFFSET)
    for source, target in ((XLOW, 0xfda0), (YPOS, 0xfda1), (XHIGH, 0xfda2)):
        load(source); asm.absolute(0x99, target)
    asm.absolute(0xae, SLOT); vic_absolute(0xbd, 0xd027)
    asm.emit(0x29, 15, 0xaa); asm.absolute(0xbd, palette_address)
    store(COLORS + 2); asm.absolute(0x99, 0xfda3)
    immediate(0); store(0xfd97); asm.absolute(0x99, 0xfda4)
    load(SLOT); asm.emit(0x0a); store(0xfd98); asm.absolute(0x99, 0xfda5)
    asm.absolute(0xae, SLOT); immediate(0); asm.emit(0x85, 0xf8)
    asm.absolute(0xbd, 0x43f8)
    asm.emit(0x4a, 0x66, 0xf8, 0x4a, 0x66, 0xf8, 0x09, 0x40, 0x85, 0xf9)
    load_vic(0xd01c); asm.absolute(0x2d, MASK)
    branch(0xd0, 'multi')
    asm.emit(0xa0, 0)
    label('hires')
    for column in range(3):
        asm.emit(0xb1, 0xf8); store(ROW + column); asm.emit(0xc8)
    asm.absolute(0xae, SHIFT); branch(0xf0, 'hires-write')
    label('hires-shift')
    asm.absolute(0x0e, ROW + 2); asm.absolute(0x2e, ROW + 1); asm.absolute(0x2e, ROW)
    asm.emit(0xca); branch(0xd0, 'hires-shift')
    label('hires-write')
    for column in range(3):
        load(ROW + column); store(0xfd96)
    asm.emit(0xc0, 63); branch(0xd0, 'hires'); jump('uploaded')
    label('multi')
    immediate(255); store(COLORS)
    for source, target in ((0xd025, COLORS + 1), (0xd026, COLORS + 3)):
        load_vic(source); asm.emit(0x29, 15, 0xaa)
        asm.absolute(0xbd, palette_address); store(target)
    asm.emit(0xa0, 0)
    label('byte')
    asm.emit(0xb1, 0xf8); store(BYTE)
    immediate(4); store(PAIRS)
    label('pair')
    immediate(0); asm.absolute(0x0e, BYTE); asm.emit(0x2a)
    asm.absolute(0x0e, BYTE); asm.emit(0x2a, 0xaa)
    asm.absolute(0xbd, COLORS); store(0xfd96); store(0xfd96)
    asm.absolute(0xce, PAIRS); branch(0xd0, 'pair')
    asm.emit(0xc8, 0xc0, 63); branch(0xd0, 'byte')
    label('uploaded')
    load(ENABLE); asm.absolute(0x0d, MASK); store(ENABLE)
    label('next')
    asm.absolute(0x0e, MASK); asm.absolute(0xee, SLOT)
    load(SLOT); asm.emit(0xc9, 8); branch(0xb0, 'finish'); jump('slot')
    label('finish')
    for source, target in ((0xd01c, 0xfd92), (0xd01d, 0xfd93), (0xd017, 0xfd94), (ENABLE, 0xfd90)):
        if 0xd000 <= source <= 0xd02e:
            load_vic(source)
        else:
            load(source)
        store(target)
    jump('done')
    label('fail'); store(STATUS)
    label('done')
    asm.emit(0x68, 0x85, 0xf9, 0x68, 0x85, 0xf8)
    for position, target in targets:
        asm.code[position:position + 2] = asm.labels[target].to_bytes(2, 'little')
    return {'length':len(asm.code) - start,
            'status':STATUS, 'palette':palette_address,
            'labels':{name:address for name, address in asm.labels.items()
                      if name.startswith(label_prefix + '-')}}
