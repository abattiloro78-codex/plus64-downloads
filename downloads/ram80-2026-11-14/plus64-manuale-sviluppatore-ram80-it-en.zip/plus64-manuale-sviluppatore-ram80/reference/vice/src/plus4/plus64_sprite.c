#include "plus64_sprite.h"
#include <string.h>

int plus64_set_extended_formats(plus64_t *p, int enable) {
    if (p->regs[0]) return -1;
    p->extended_formats=(uint8_t)(enable!=0);
    p->collision_only_formats=enable?2u:0u;
    p->material_full_palette=(uint8_t)(enable!=0);
    p->sparse_formats=(uint8_t)(enable!=0);
    p->light_directions=(uint8_t)(enable!=0);
    p->front_mask_profile=(uint8_t)(enable!=0);
    p->tile_lighting=(uint8_t)(enable!=0);
    p->diagonal_lighting=(uint8_t)(enable!=0);
    return 0;
}

/* Selectable material profile in the video circuit. No texture RAM, game IDs,
 * sprite IDs or game addresses. Hue comes from the descriptor; occupancy
 * always comes from the ordinary source mask. Integer math is deterministic.
 * Legacy highlight at the upper-left quarter; optional eight directions plus front. */
static unsigned light_direction(const plus64_t *p, unsigned slot) {
    unsigned value=(p->regs[9u+slot/2u]>>((slot&1u)*4u))&15u;
    return p->light_directions && value<=9u ? value : 0u;
}

/* Preserve each original MCM ink and change only its luminance. Equal
 * levels lie on diagonals, using the actual opaque source bounding box. */
static uint8_t diagonal_colour(uint8_t ink,int x,int y,int xmin,int ymin,int xmax,int ymax) {
    int dx=xmax-xmin,dy=ymax-ymin,level;
    if (!ink || ink>120u) return ink;
    if (!dx)dx=1;if(!dy)dy=1;
    level=((int)ink-1)/15+2-5*((x-xmin)*dy+(y-ymin)*dx)/(2*dx*dy);
    if(level<0)level=0;if(level>7)level=7;
    return (uint8_t)(1u+((unsigned)ink-1u)%15u+15u*(unsigned)level);
}

static uint8_t tone_colour(const plus64_t *p, unsigned slot, uint8_t base, int px, int py, int full_palette) {
    static const int8_t light_x[10]={6,12,23,23,23,12,0,0,0,12};
    static const int8_t light_y[10]={5,0,0,10,20,20,20,10,0,10};
    unsigned direction=light_direction(p,slot);
    int dx=px-light_x[direction], dy=py-light_y[direction];
    int level=7-(dx*dx+dy*dy)/40;
    if (base==0 || base>120) return base;
    if (level<0) level=0;
    /* The chosen colour is the highlight. Legacy snapshots retain the
       original hue-only ramp; new materials honour its luminance too. */
    if (full_palette) level=level*((base-1)/15)/7;
    return (uint8_t)(15*level+1+(base-1)%15);
}

/* Frontal light follows each occupied row span, rather than putting a
 * bright spot in the centre of an entire sparse record. Thin faces/arms
 * keep their selected highlight; broad spans have shaded edges. This is a
 * generic mask profile, with no knowledge of body parts or game addresses. */
static uint8_t front_mask_colour(uint8_t base, const uint8_t mask[63], int x, int y) {
    int left=x,right=x,level=7;
    if (base==0 || base>120) return base;
    while(left>0 && (mask[y*3+(left-1)/8]&(128u>>((left-1)&7)))) --left;
    while(right<23 && (mask[y*3+(right+1)/8]&(128u>>((right+1)&7)))) ++right;
    int width=right-left+1;
    if(width>2) {
        int distance=x-left<right-x ? x-left : right-x;
        int radius=(width-1)/2;
        level=6+distance/radius;
    }
    return (uint8_t)(15*(level*((base-1)/15)/7)+1+(base-1)%15);
}

/* Sparse RAW64: 63 bitmap bytes compressed by zero-byte omission, with
 * optional inclusive palette rectangles. All data is in the existing inverse
 * RAW64 cache metadata; no texture bank, game IDs or guest RAM is added.
 * Header A7, occupancy offset (3+4*n), base colour/material; n rectangles
 * packed20-bit x0/y0/x1/y1, colour/material; eight occupancy bytes in reverse bitmap-byte
 * order, then the nonzero values in that order. Byte63 is orientation1/80.
 * Decode into a transient host mask, never a second guest payload. */
static int sparse_mask(const plus64_t *p, unsigned at, uint8_t mask[63], unsigned *rects) {
    unsigned start=p->ram[at+0x23eu], value, n;
    if (p->ram[at+0x23fu]!=0xa7u || start<3u || (start-3u)%4u) return -1;
    n=(start-3u)/4u;
    if (n>10u || start+8u>63u) return -1;
    for (unsigned i=0;i<n;i++) {
        unsigned r=at+0x23cu-4u*i;
        unsigned bounds=(unsigned)p->ram[r]|((unsigned)p->ram[r-1u]<<8)|((unsigned)p->ram[r-2u]<<16);
        unsigned x0=bounds&31u, y0=(bounds>>5)&31u;
        unsigned x1=(bounds>>10)&31u, y1=(bounds>>15)&31u;
        if (bounds>>20 || x0>x1 || y0>y1 || x1>23u || y1>20u
            || (p->ram[r-3u]&127u)>120u) return -1;
    }
    if ((p->ram[at+0x23du]&127u)>120u) return -1;
    value=start+8u;
    for (unsigned i=0;i<63u;i++) {
        unsigned flags=p->ram[at+0x23fu-start-i/8u];
        mask[62u-i]=0;
        if (flags & (128u>>(i&7u))) {
            if (value>=63u) return -1;
            mask[62u-i]=p->ram[at+0x23fu-value++];
        }
    }
    *rects=n;
    return 0;
}

void plus64_bind_ram(plus64_t *p, uint8_t *ram) { p->ram=ram; }
void plus64_reset(plus64_t *p) { memset(p->regs,0,sizeof(p->regs)); p->collision=0; }

void plus64_write(plus64_t *p, uint16_t a, uint8_t v) {
    if (a < PLUS64_BASE || a > PLUS64_END) return;
    unsigned r = a - PLUS64_BASE;
    if (r == 1) return;  /* collision latch is read-only */
    p->regs[r] = v;
    if (r == 6) { /* $FD96: sprite RAM data, with auto-increment */
        unsigned at = (unsigned)p->regs[7] | ((unsigned)p->regs[8] << 8);
        if (p->ram) p->ram[at & (PLUS64_RAM_SIZE - 1)] = v;
        ++at;
        p->regs[7] = (uint8_t)at;
        p->regs[8] = (uint8_t)(at >> 8);
    }
}

uint8_t plus64_read(plus64_t *p, uint16_t a) {
    if (a < PLUS64_BASE || a > PLUS64_END) return 0xff;
    unsigned r = a - PLUS64_BASE;
    if (r == 1) { uint8_t v = p->collision; p->collision = 0; return v; }
    if (r == 6) {
        unsigned at = (unsigned)p->regs[7] | ((unsigned)p->regs[8] << 8);
        uint8_t v = p->ram ? p->ram[at & (PLUS64_RAM_SIZE - 1)] : 0xff;
        ++at;
        p->regs[7] = (uint8_t)at;
        p->regs[8] = (uint8_t)(at >> 8);
        return v;
    }
    return p->regs[r];
}

static void draw_masked_common(plus64_t *p, uint8_t *frame, uint8_t *alpha, size_t stride, int packed_cache, int deferred, uint8_t *line_collisions, int left_mcm) {
    /* Registered sprites overlap by per-pixel occupancy. Earlier sprite wins.
       $FD90: enable; $FD92: multi mask reserved; $FD93: expand X;
       $FD94: expand Y; $FD95: behind-background reserved.
       8 sprites x 6 registers starting $FDA0, pattern 63 bytes each.
       Screen coordinates are 320x200 logical pixels, not PAL beam clocks. */
    const unsigned left_margin=left_mcm ? 24u : 0u;
    const unsigned collision_width=(line_collisions ? 512u : PLUS64_WIDTH)+left_margin;
    uint8_t occupied[collision_width * PLUS64_HEIGHT];
    uint16_t visible[collision_width * PLUS64_HEIGHT];
    if (line_collisions) memset(line_collisions,0,PLUS64_HEIGHT);
    memset(occupied, 0, sizeof(occupied));
    memset(visible, 0, sizeof(visible));
    /* Collision latch remains set until CPU reads $FD91. */
    if (alpha) memset(alpha, 0, stride*PLUS64_HEIGHT);
    if (!p->ram) return;
    for (unsigned s=0; s<8; ++s) {
        if (!(p->regs[0] & (1u << s))) continue;
        const unsigned b=0x10u + s*6u;
        int x=(int)p->regs[b] + ((p->regs[b+2] & 1u) ? 256 : 0);
        int y=p->regs[b+1];
        uint8_t col=p->regs[b+3] & 0x7fu;
        unsigned pattern=((unsigned)p->regs[b+4] | ((unsigned)p->regs[b+5]<<8)) & (PLUS64_RAM_SIZE-1);
        /* New opt-in only. Do not round an arbitrary pointer to a record.
           Existing HIRES pointer/color semantics remain below, unchanged. */
        unsigned raw_pattern=(unsigned)p->regs[b+4] | ((unsigned)p->regs[b+5]<<8);
        int raw8_mixed = p->extended_formats && packed_cache
            && (p->regs[2] & (1u<<s))
            && (raw_pattern & 0xc000u)==PLUS64_RAW8_TAG;
        uint8_t tone_base=col;
        int tonal = p->extended_formats && packed_cache && !raw8_mixed
            && (p->regs[b+3] & PLUS64_TONE_MASK);
        int packed = packed_cache && !raw8_mixed && (p->regs[2] & (1u<<s));
        int diagonal = packed && p->extended_formats && p->diagonal_lighting
            && p->light_directions && ((p->regs[9u+s/2u]>>((s&1u)*4u))&15u)==10u;
        int collision_only=0,occluding=0;
        int xmin=23,ymin=20,xmax=0,ymax=0;
        int hires_packed = left_mcm && packed_cache && !(p->regs[2] & (1u<<s));
        int sparse=hires_packed && p->sparse_formats && p->regs[b+3]==0xf9u;
        uint8_t sparse_bits[63]; unsigned sparse_rects=0;
        /* Tagged RAW8 must fit; never wrap a partial image across the bank. */
        if (raw8_mixed && pattern>PLUS64_RAM_SIZE-504u) continue;
        /* The opted-in publisher maps VIC Y to (rawY-50) modulo256.
           Its positive outputs never exceed205. Values215..255 are
           therefore the unambiguous top-partial range -41..-1, including
           expanded21-row images. Keep every default path unchanged. */
        if (left_mcm && packed_cache && y>=215) y-=256;
        if (hires_packed) {
            unsigned raw_pattern=(unsigned)p->regs[b+4] | ((unsigned)p->regs[b+5]<<8);
            if (raw_pattern != pattern || (pattern & 1023u) != 0
                || p->ram[pattern+0x245u] != 0xa5
                || p->ram[pattern+0x241u] != 0
                || p->ram[pattern+0x240u] > 23) continue;
        }
        if (sparse) {
            tonal=0;
            /* The game's ordinary bitmap/death buffers can retain this
               descriptor selector while using a plain mask. Their fallback
               ink is the existing cached shared1 colour. */
            if (p->ram[pattern+0x23fu]!=0xa7u) {
                sparse=0;
                col=p->ram[pattern+0x242u];
                if (col>120u) continue;
            } else if (sparse_mask(p,pattern,sparse_bits,&sparse_rects)<0) continue;
        }
        if (packed) {
            unsigned raw_pattern=(unsigned)p->regs[b+4] | ((unsigned)p->regs[b+5]<<8);
            if (raw_pattern != pattern || (pattern & 1023u) != 0
                || p->ram[pattern+0x245u] != 0xa5
                || p->ram[pattern+0x241u] != 1
                || p->ram[pattern+0x240u] != 0) continue;
            /* Explicit opt-in projection of original raw VIC X0..23.
               Valid unexpanded source descriptors otherwise use X0..487. */
            if (left_mcm && x>=488) x-=512;
        }
        /* Software-owned byte63: new 80..F8 tags select colour0..120.
           Legacy snapshots retain 81..8F hue tags. FF orientation remains
           ordinary data in both formats; all64 bytes stay in the key. */
        if (packed && p->extended_formats) {
            uint8_t tag=p->ram[pattern+0x200u];
            occluding=p->collision_only_formats>=2u && tag==0xfau;
            collision_only=occluding || (p->collision_only_formats && tag==0xf9u);
            if (p->material_full_palette) {
                if (tag>=0x80u && tag<=0xf8u) {
                    tonal=1;
                    tone_base=tag & 0x7fu;
                }
            } else if ((tag & 0xf0u)==0x80u && (tag & 15u)) {
                tonal=1;
                tone_base=tag & 15u;
            }
        }
        if (diagonal) {
            int found=0;
            tonal=0; /* profile10 preserves all three original inks */
            for (int my=0;my<21;my++) for(int mx=0;mx<24;mx+=2) {
                unsigned i=(unsigned)my*3u+(unsigned)mx/8u;
                unsigned pair=(p->ram[pattern+0x23fu-i]>>(6u-2u*(((unsigned)mx&7u)/2u)))&3u;
                if(!pair)continue;
                if(mx<xmin)xmin=mx;if(mx+1>xmax)xmax=mx+1;
                if(my<ymin)ymin=my;if(my>ymax)ymax=my;found=1;
            }
            if(!found)continue;
        }
        if (tonal && tone_base>120u) continue;
        if (raw8_mixed && left_mcm && x>=488) x-=512;
        int sx=(p->regs[3] & (1u<<s)) ? 2 : 1;
        /* Original raw VIC X0..23 projects to -24..-1. Expanded HIRES
           beams have visible pixels even at rawX0. Positive native
           descriptors from this publisher never exceed487. Keep the
           existing packed-MCM validity and all default paths unchanged. */
        if (left_mcm && packed_cache && !(p->regs[2] & (1u<<s))
            && sx==2 && x>=488) x-=512;
        int sy=(p->regs[4] & (1u<<s)) ? 2 : 1;
        for (int py=0; py<21; ++py) for (int px=0; px<24; ++px) {
            if (p->regs[2] & (1u<<s)) {
                if (packed) {
                    unsigned i=(unsigned)py*3u + (unsigned)px/8u;
                    uint8_t raw=p->ram[pattern+0x23fu-i];
                    unsigned pair=(raw >> (6u-2u*(((unsigned)px&7u)/2u))) & 3u;
                    /* pair0 is transparent; preserve full8-bit key colors.
                       Tag63 at+200 is not an image byte. */
                    /* A selected material replaces the three source inks. Its
                       opacity depends only on pair0, never on a source ink
                       that software may tag as an extended descriptor. */
                    col=pair ? (tonal ? 0 : p->ram[pattern+0x245u-pair]) : 255;
                } else {
                    unsigned byte=(pattern + py*24u + (unsigned)px) & (PLUS64_RAM_SIZE-1);
                    col=p->ram[byte];
                }
                if (col>120) continue;
            } else if (hires_packed) {
                /* Existing inverse RAW64 metadata: no second bitmap upload.
                   Reproduce the old CPU's logical left shift exactly; the
                   shifted-out right tail is transparent, not wrapped. */
                unsigned source_x=(unsigned)px+p->ram[pattern+0x240u];
                if (source_x>=24) continue;
                unsigned material_x=source_x;
                if (sparse && (p->ram[pattern+0x200u]&128u)) material_x=23u-source_x;
                unsigned i=(unsigned)py*3u+material_x/8u;
                uint8_t bits=sparse ? sparse_bits[i] : p->ram[pattern+0x23fu-i];
                if (!(bits & (0x80u>>(material_x&7u)))) continue;
                if (sparse) {
                    uint8_t material=p->ram[pattern+0x23du];
                    for (unsigned r=0;r<sparse_rects;r++) {
                        unsigned q=pattern+0x23cu-4u*r;
                        unsigned bounds=(unsigned)p->ram[q]|((unsigned)p->ram[q-1u]<<8)|((unsigned)p->ram[q-2u]<<16);
                        if (material_x>=(bounds&31u) && (unsigned)py>=((bounds>>5)&31u)
                            && material_x<=((bounds>>10)&31u) && (unsigned)py<=((bounds>>15)&31u)) material=p->ram[q-3u];
                    }
                    if ((material&128u) && p->front_mask_profile && light_direction(p,s)==9u)
                        col=front_mask_colour(material&127u,sparse_bits,(int)material_x,py);
                    else col=(material&128u) ? tone_colour(p,s,material&127u,light_direction(p,s) ? px : (int)material_x,py,1) : material;
                }
            } else {
                unsigned byte=(pattern + py*3u + (unsigned)px/8u) & (PLUS64_RAM_SIZE-1);
                if (!(p->ram[byte] & (0x80u >> (px&7)))) continue;
            }
            if (diagonal) col=diagonal_colour(col,px,py,xmin,ymin,xmax,ymax);
            if (tonal) col=tone_colour(p,s,tone_base,px,py,p->material_full_palette);
            for (int ey=0; ey<sy; ++ey) for (int ex=0; ex<sx; ++ex) {
                int xx=x+px*sx+ex, yy=y+py*sy+ey;
                if (xx<-(int)left_margin || xx>=(int)(collision_width-left_margin) || yy<0 || yy>=PLUS64_HEIGHT) continue;
                unsigned off=(unsigned)yy * collision_width + (unsigned)(xx+(int)left_margin);
                if (occupied[off]) {
                    if (line_collisions) line_collisions[yy] |= (uint8_t)(occupied[off] | (1u << s));
                    if (!deferred) p->collision |= (uint8_t)(occupied[off] | (1u << s));
                }
                if (!collision_only && !visible[off] && xx>=0 && xx<PLUS64_WIDTH) {
                    /* First enabled sprite has display priority. */
                    frame[(size_t)yy * stride + (size_t)xx] = col;
                    if (alpha) alpha[(size_t)yy * stride + (size_t)xx] = 1;
                }
                /* Still track every sprite for three-way overlaps. */
                occupied[off] |= (uint8_t)(1u << s);
                /* A hidden occluder retains display priority without emitting
                   alpha: later sprites reveal the original scene behind it. */
                if (occluding && !visible[off]) visible[off]=256u;
                if (!collision_only && !(visible[off]&256u)) visible[off] |= (uint8_t)(1u << s);
                if (alpha && deferred && xx>=0 && xx<PLUS64_WIDTH) alpha[(size_t)yy * stride + (size_t)xx] = (uint8_t)visible[off];
            }
        }
    }
}

void plus64_draw_masked(plus64_t *p, uint8_t *frame, uint8_t *alpha, size_t stride) {
    draw_masked_common(p,frame,alpha,stride,0,0,NULL,0);
}

void plus64_draw_masked_packed_cache(plus64_t *p, uint8_t *frame, uint8_t *alpha, size_t stride) {
    draw_masked_common(p,frame,alpha,stride,1,0,NULL,0);
}

void plus64_draw_masked_deferred(plus64_t *p, uint8_t *frame, uint8_t *alpha, size_t stride, int packed_cache) {
    draw_masked_common(p,frame,alpha,stride,packed_cache != 0,1,NULL,0);
}

void plus64_draw_masked_left_mcm(plus64_t *p, uint8_t *frame, uint8_t *alpha, size_t stride, int packed_cache, int deferred, uint8_t *line_collisions) {
    draw_masked_common(p,frame,alpha,stride,packed_cache != 0,deferred,line_collisions,1);
}

void plus64_draw_masked_deferred_border(plus64_t *p, uint8_t *frame, uint8_t *alpha, size_t stride, int packed_cache, uint8_t *line_collisions) {
    draw_masked_common(p,frame,alpha,stride,packed_cache != 0,1,line_collisions,0);
}

void plus64_latch_masked_line(plus64_t *p, const uint8_t *masks, size_t stride, unsigned int y) {
    if (!masks || stride < PLUS64_WIDTH || y >= PLUS64_HEIGHT) return;
    const uint8_t *line=masks+(size_t)y*stride;
    for (unsigned x=0; x<PLUS64_WIDTH; ++x) {
        uint8_t m=line[x];
        if (m & (uint8_t)(m-1u)) p->collision |= m;
    }
}

int plus64_prepare_packed_cache_switch(plus64_t *p) {
    if (p->regs[0] != 0) return -1;
    if (p->ram) for (unsigned r=0; r<16; ++r) p->ram[r*1024u+0x245u]=0;
    return 0;
}

void plus64_draw(plus64_t *p, uint8_t *frame, size_t stride) {
    plus64_draw_masked(p,frame,NULL,stride);
}
