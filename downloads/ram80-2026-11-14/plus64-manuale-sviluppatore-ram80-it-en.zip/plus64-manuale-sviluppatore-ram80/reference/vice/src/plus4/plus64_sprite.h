#ifndef PLUS64_H
#define PLUS64_H
#include <stdint.h>
#include <stddef.h>
#define PLUS64_WIDTH 320
#define PLUS64_HEIGHT 200
#define PLUS64_RAM_SIZE 16384
#define PLUS64_BASE 0xFD90
#define PLUS64_END 0xFDCF

typedef struct {
    uint8_t regs[0x40];
    uint8_t *ram; /* view of caller-owned 16K; never separate sprite RAM */
    uint8_t collision;
    uint8_t collision_only_formats; /* HOST: 0=legacy,1=F9,2=F9/occluding FA */
    uint8_t material_full_palette; /* versioned HOST material configuration */
    uint8_t diagonal_lighting; /* versioned per-ink MCM diagonal profile */
    uint8_t tile_lighting; /* versioned opt-in background lighting */
    uint8_t front_mask_profile; /* HOST snapshot shading version */
    uint8_t light_directions; /* HOST snapshot format version */
    uint8_t sparse_formats; /* HOST format version, not guest RAM */
    uint8_t extended_formats; /* HOST configuration, not guest payload RAM */
} plus64_t;
#define PLUS64_RAW8_TAG 0x4000u
#define PLUS64_TONE_MASK 0x80u
/* FD99..FD9C: low nibble even slot, high nibble odd slot. Zero keeps
 * the original profile; 1..8=N,NE,E,SE,S,SW,W,NW; 9=front; 10=per-ink MCM diagonal; 11..15 reserved. */
#define PLUS64_LIGHT_BASE 0xFD99u
int plus64_set_extended_formats(plus64_t *p, int enable);
void plus64_bind_ram(plus64_t *p, uint8_t *ram);
/* Reset registers/latches only; preserve backing and its payload. */
void plus64_reset(plus64_t *p);
void plus64_write(plus64_t *p, uint16_t address, uint8_t value);
uint8_t plus64_read(plus64_t *p, uint16_t address);
/* Draws pixel-index overlay into an existing 320x200 frame (index 0-127),
 * no TED access implied. A bit set in occupancy denotes sprite coverage. */
/* FD92 bits enable 8-bit-per-pixel TED palette sprite images, 504 bytes each.
 * Color indices 0..120; 255=transparent. alpha disambiguates black 0.
 */
void plus64_draw_masked(plus64_t *p, uint8_t *frame, uint8_t *alpha, size_t stride);
void plus64_draw(plus64_t *p, uint8_t *frame, size_t stride);
/* NEW experimental format: FD92 MCM slots read exact global-cache metadata.
 * Requires aligned1024 records, raw64 inverse+200/key5 inverse+240/valid245.
 * This is not the0.94 format or an existing physical cartridge capability. */
void plus64_draw_masked_packed_cache(plus64_t *p, uint8_t *frame, uint8_t *alpha, size_t stride);
/* Configuration change only: refuse enabled output; invalidate all16 markers. */
int plus64_prepare_packed_cache_switch(plus64_t *p);
/* Experimental frozen-frame scanline latch. Alpha contains sprite bit masks;
 * its nonzero coverage and visible pixels match the corresponding old draw.
 * Preparing a frame does NOT create collisions. Fold each completed line. */
void plus64_draw_masked_deferred(plus64_t *p, uint8_t *frame, uint8_t *alpha, size_t stride, int packed_cache);
/* The optional 200-byte host summary includes hidden horizontal pixels
 * in the existing nine-bit descriptor domain. It never draws the border. */
void plus64_draw_masked_deferred_border(plus64_t *p, uint8_t *frame, uint8_t *alpha, size_t stride, int packed_cache, uint8_t *line_collisions);
void plus64_latch_masked_line(plus64_t *p, const uint8_t *masks, size_t stride, unsigned int y);
/* Separate opt-in signed projection for packed MCM X488..511 only. */
void plus64_draw_masked_left_mcm(plus64_t *p, uint8_t *frame, uint8_t *alpha, size_t stride, int packed_cache, int deferred, uint8_t *line_collisions);
#endif
