/* plus/64 0.5: indexed video overlay compositing - independent of VICE. */
#ifndef PLUS64_OVERLAY_H
#define PLUS64_OVERLAY_H
#include <stdint.h>
#include <stddef.h>
/* plus/64 color indices 0..120 correspond to 121 DISTINCT TED colors.
   The VICE TED raster buffer uses 0..127 indices, with black repeated at
   0,16,32,...112. Convert without discarding the last 7 colors. */
uint8_t p64_ted_color(uint8_t index);
/* Compose one 320x200 logical sprite scanline over an existing indexed TED
   scanline. framebuffer/mask are 320x200; line is a logical TED raster line.
   gfx_x/y are VICE gfx origin within the raster geometry. */
void p64_overlay_scanline(uint8_t *ted_line, size_t ted_width, int line,
                          int gfx_x, int gfx_y, const uint8_t *overlay,
                          const uint8_t *alpha);
/* FD9D/E linked-list head in existing main RAM; FD9F bit0 enables.
 * Nodes: next16, x/y/w/h in character cells, xmin/ymin/xmax/ymax in
 * local pixels, compact transparent colour, flags (0). Maximum32 nodes.
 * Changes only TED luminance; apply before sprite composition. */
void p64_light_scanline(uint8_t *line, size_t width, int y, int gx,
                         const uint8_t *ram, const uint8_t *regs);
/* Versioned streamed scenery node (flag2). Source image and material bytes
 * stay in guest-owned linked segments; only a transient scanline is decoded. */
void p64_scene_scanline(uint8_t *line, size_t width, int y, int gx,
                         const uint8_t *ram, const uint8_t *regs);

/* Flag4 node: guest-selected top/bottom bounds, applied after sprites. */
void p64_window_scanline(uint8_t *line,size_t width,int y,int gx,
                         const uint8_t *ram,const uint8_t *regs);

#endif
