#!/usr/bin/env python3
"""Assemble Meck's complete developer manual 2.0, Italian and English, offline."""
from pathlib import Path
import argparse,hashlib,json,re,shutil,subprocess,zipfile,importlib.util
R=Path(__file__).resolve().parents[1]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def cp(a,b):b.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(a,b)
def build(original,source,out,xa):
 out.mkdir(parents=True,exist_ok=False);P=out/'plus64-manuale-sviluppatore-ram80';P.mkdir();shutil.copytree(source/'chapters',P/'chapters');shutil.copytree(source/'assets',P/'assets');cp(source/'manual.css',P/'manual.css');cp(source/'ORIGINAL_MANUAL.json',P/'ORIGINAL_MANUAL.json')
 # Preserve the user's original chapter structure and update references to the current implementation.
 old=json.loads((original/'SOURCE_MANIFEST.json').read_text());paths={i.get('path',i.get('file'))for i in old['files']if i.get('path',i.get('file','')).startswith('src/')};paths.update('src/plus4/'+f for f in ['plus64_memory.h','plus64_sprite.h','plus64_overlay.h','plus64_modem.h','plus64_snapshot_format.h'])
 for f in sorted(paths):
  p=R/'vendor/vice-source'/f
  if p.is_file():cp(p,P/'reference/vice'/f)
 for p in (original/'reference/tools').rglob('*'):
  if p.is_file():cp(p,P/'reference/tools'/p.relative_to(original/'reference/tools'))
 cp(R/'vendor/vice-source/COPYING',P/'reference/COPYING_VICE_GPL.txt')
 for n in ['MEMORY_API.json','MODEM_API.json','SPRITE_API.json','SID_API.json']:cp(source/n,P/n)
 cp(R/'emulator/experimental/sprite-formats/FORMAT.md',P/'FORMATI_GRAFICI.md');cp(R/'emulator/experimental/ram80-snapshot/FORMAT.md',P/'SNAPSHOT_FORMAT.md');cp(R/'emulator/experimental/ram80/MEMORY_LAYOUT.json',P/'MEMORY_LAYOUT.json')
 files=[dict(path=str(p.relative_to(P/'reference/vice')),bundle_path=str(p.relative_to(P)),sha256=sha(p),bytes=p.stat().st_size,line_count=len(p.read_text().splitlines()))for p in sorted((P/'reference/vice').rglob('*'))if p.is_file()];manifest=dict(edition='2.0 RAM80',scope='Current byte-exact source excerpts, not full VICE tree; historical instrumentation is separate under reference/tools.',runtime_PE_sha256='08d3e87f84140fe13014213beb32bf7635de12b715769d995efc0658bf08ddfa',files=files)
 for n in ['SOURCE_MANIFEST.json','SOURCE_REFERENCE_LIST.json']:(P/n).write_text(json.dumps(manifest,indent=2)+'\n')
 # Rebuild the baseline sample against current include names, retaining identical executable bytes.
 for p in (R/'runtime/SDK_RAM80/source').rglob('*'):
  if p.is_file()and '__pycache__'not in p.parts:cp(p,P/'sdk'/p.relative_to(R/'runtime/SDK_RAM80/source'))
 cp(R/'docs/developers/sdk-current/include/plus64.inc',P/'sdk/include/plus64.inc');subprocess.run(['python3',str(P/'sdk/build.py'),'--xa',str(xa),'--out',str(P/'sdk/prebuilt')],check=True,capture_output=True)
 for n in ['DEMO_PLUS64.prg','DEMO_PLUS64.d64']:assert (P/'sdk/prebuilt'/n).read_bytes()==(R/'runtime/SDK_RAM80'/n).read_bytes()
 cp(original/'sdk/evidence/demo.png',P/'sdk/evidence/demo.png')
 sdk=R/'docs/developers/sdk-current'
 for p in sdk.rglob('*'):
  rel=p.relative_to(sdk)
  if not p.is_file()or '__pycache__'in p.parts or rel.parts[0]in ['qa-render-001','qa-native-001','rebuild-proof']:continue
  cp(p,P/'sdk/materials'/rel)
 for q in ['qa-render-001','qa-native-001']:cp(sdk/q/'PROOF.json',P/'sdk/evidence'/('MATERIAL_'+q+'.json'))
 cp(sdk/'REPRODUCIBILITY.json',P/'sdk/evidence/MATERIAL_REPRODUCIBILITY.json')
 (P/'sdk/README.md').write_text('''# SDK RAM80 corrente / Current RAM80 SDK

Il codice nativo usa16KiB CPU/TED su C16 e Plus/4; i dati sprite sono alias
del banco cartuccia2. Non esiste RAM sprite aggiuntiva. Firme SRAM64/05,
modem64/03. Native CPU/TED uses16KiB on both hosts; sprite data aliases
cartridge bank2, without additional sprite RAM.

Build: `python3 build.py --xa /path/to/xa --out build-new`.
Prebuilt: `prebuilt/DEMO_PLUS64.d64`, identical to the currently tested SDK.
The raw8 example runs without packed/mixed options; see the technical manual.
Material example, sources and independent build: `materials/README.md`.
The current source include names FD99..FD9F, light directions and protocols.
Proof summaries are under `evidence/`; they distinguish nativeLinux, Wine,
rendererC and assembly checks. Physical and nativeWindows tests are not claimed.
''')
 # A portable renderer copy is part of the editable document sources.
 cp(R/'tools-release/manual_html_renderer.py',P/'manual_html_renderer.py');cp(R/'tools-release/build_developer_manual.py',P/'PACKAGING_SOURCE.py')
 spec=importlib.util.spec_from_file_location('manual_render',P/'manual_html_renderer.py');render=importlib.util.module_from_spec(spec);spec.loader.exec_module(render)
 documentation=[];texts={}
 for lang in ['it','en']:
  chapters=sorted((P/'chapters'/lang).glob('[0-9][0-9]_*.md'));assert len(chapters)==7,(lang,chapters);chunks=[]
  for i,path in enumerate(chapters,1):
   text=path.read_text();text=re.sub(r'^# (?:[0-9]+\. )?',f'# {i}. ',text,count=1)
   if i==1:
    text=text.replace('# Avvio rapido','## Avvio rapido').replace('# Quick start','## Quick start')
   chunks.append(text.strip())
  title='Manuale sviluppatore plus/64 RAM80'if lang=='it'else'plus/64 RAM80 Developer Manual';render.LANG=lang;render.TITLE=title;render.QUICK='Riferimento rapido plus/64 RAM80'if lang=='it'else'plus/64 RAM80 Quick Reference'
  extra_it='''# 8. Materiali e shader programmabili nel budget RAM80

L'esempio completo `sdk/materials/material-example.asm` usa una maschera
HIRES generica e121 colori di evidenziazione; passa fra luce nord, est e
frontale. Eseguibile e D64 sono in `sdk/materials/prebuilt/`.

```sh
python3 sdk/materials/build_material.py --xa /path/to/xa --out build-material
```

Carica a `$1001`, entra a `$1100`, termina a `$1398` escluso. Riserva un
solo record da1KiB nel banco cartuccia2, già compreso nei64KiB. Zero page,
stack, codice e bitmap TED restano nei16KiB interni. Le prove hanno osservato
i121 colori e le tre luci per500 fotogrammi su ciascuno degli ospiti.
Non richiede Python per eseguire il D64 già costruito.

La specifica completa dei record e dei layer è in [FORMATI_GRAFICI.md](FORMATI_GRAFICI.md),
la serializzazione in [SNAPSHOT_FORMAT.md](SNAPSHOT_FORMAT.md). Le parti
storiche dei formati vanno lette con le sezioni successive della stessa
specifica: la revisione corrente supporta la scenery17. Nella REV8R i dati
del vecchio font inutilizzato sono copiati nelle pagine di staging ritirate
`$0600..$07FF` prima di ripristinare tutti i glifi della stanza.

Il compositore legge font e dati della RAM emulata. Questa possibilità
software non dimostra un accesso gratuito della cartuccia fisica alla RAM
TED: pubblicazione, arbitraggio, sincronismo e costo hardware restano da
progettare. Le maschere FA gestiscono la priorità fra sprite virtuali, non
una priorità arbitraria dietro i caratteri TED; FD95 rimane riservato.
'''
  extra_en='''# 8. Programmable materials within the RAM80 budget

The complete `sdk/materials/material-example.asm` uses a generic HIRES mask
and121 selected highlights, switching between north, east and frontal
light. Its executable and D64 are under `sdk/materials/prebuilt/`.

```sh
python3 sdk/materials/build_material.py --xa /path/to/xa --out build-material
```

It loads at `$1001`, enters at `$1100`, and ends at `$1398` exclusive.
It reserves one1KiB record in cartridge bank2, already within64KiB. Zero
page, stack, code and TED bitmap remain within internal16KiB. Tests observed
all121 colours and three lights over500 frames on each host. Running the
prebuilt D64 does not require Python.

The full record and layer specification is in [FORMATI_GRAFICI.md](FORMATI_GRAFICI.md),
and serialization in [SNAPSHOT_FORMAT.md](SNAPSHOT_FORMAT.md). Historical
format sections are superseded by later sections in the same specification;
the current implementation supports scenery17. In REV8R, data formerly
placed in unused font glyphs is copied to retired `$0600..$07FF` staging
pages before restoring all original room glyphs.

The compositor reads fonts and data from emulated RAM. That software access
does not establish free physical-cartridge access to TED RAM: publication,
arbitration, synchronization and hardware cost remain to be designed. FA
masks implement priority between virtual sprites, not arbitrary priority
behind TED characters; FD95 remains reserved.
'''
  ledger=(R/'docs/developers'/('MANUALE_TECNICO_PLUS64_RAM80.md'if lang=='it'else'PLUS64_RAM80_CURRENT.md')).read_text();marker='## Appendice'if lang=='it'else'## Appendix';pos=ledger.find(marker)
  if pos>=0:
   ledger=ledger[pos:];ledger=re.sub(r'\[([^\]]+)\]\(../../build/[^)]+\)',r'`MANIFEST.json`',ledger);ledger=ledger.replace('## Appendice','# 9. Appendice').replace('## Appendix','# 9. Appendix')
  else:ledger=''
  appendix=(extra_it if lang=='it'else extra_en)+'\n\n'+ledger
  (P/'appendices').mkdir(exist_ok=True);(P/'appendices'/(lang+'.md')).write_text(appendix)
  full=render.prose_spaces('\n\n'.join(chunks)+'\n\n'+appendix)
  # Data source paths are relative to this offline package, not a private checkout.
  for target in re.findall(r'!?\[[^\]]*\]\(([^)]+)\)',full):
   if not re.match(r'(?:https?://|#|mailto:)',target):assert (P/target.split('#')[0]).exists(),(lang,target)
  name='Manuale_Sviluppatore_PLUS64_RAM80_IT'if lang=='it'else'PLUS64_RAM80_Developer_Manual_EN';documentation.append(render.render(P,P,name,full,True));quick='Riferimento_Rapido_PLUS64_RAM80_IT'if lang=='it'else'PLUS64_RAM80_Quick_Reference_EN';documentation.append(render.render(P,P,quick,chunks[6],False));texts[lang]=full
 cp(R/'tools-release/rebuild_packaged_manual.py',P/'build_manual.py')
 # Retain independently current API inventories and verify every referenced source digest.
 for n in ['MEMORY_API.json','MODEM_API.json','SPRITE_API.json','SID_API.json']:
  j=json.loads((P/n).read_text())
  for item in j['sources']:
   assert sha(P/item['bundle_path'])==item['sha256'],(n,item)
 proof=dict(status='PASS-manual-2.0-IT-and-full-English',edition='2.0 RAM80',runtime_PE_sha256=manifest['runtime_PE_sha256'],documentation=documentation,original_chapters_per_language=7,complete_English_copy=True,original_attachment_sha256='dec6693eabd88414a84db7a61ab6669d4cdcd7c246065e6d9ac6ef3a91454938',source_hashes_exact=True,all_local_links_exist=True,SDK_baseline_executable_byte_identical=True,material_SDK_render_cases=363,material_SDK_native_frames_per_host=500,guest_RAM_bytes=81920,native_Windows_tests=0,physical_tests=0)
 (P/'VALIDATION.json').write_text(json.dumps(proof,indent=2)+'\n');(P/'README.txt').write_text('''MANUALE TECNICO PLUS/64 RAM80 - EDIZIONE2.0 - MECK

Manuale completo e riferimento rapido, in ITALIANO e INGLESE, PDF e HTML.
Le copie inglesi sono integrali, non riassunti. I sorgenti dei capitoli sono
in chapters/it e chapters/en. Il manuale serve a PROGRAMMARE plus/64.

Aggiornato dal manuale1.0 fornito dall'autore: profili RAM80, firme05/03,
allocazioni condivise, formati sprite, luci, scenery, snapshot ed esempi.
Sprite, voci e modem condividono64+16KiB; nessun banco aggiuntivo.

sdk/: esempio RAW8/SID e include aggiornato, build conPython3+xa6502.
sdk/materials/: maschera generica,121colori e luciN/E/frontale, con build
indipendente e D64 pronto. Le due demo usano profili differenti: vedi README.
Per rigenerare PDF/HTML fuori dalla cartella sorgente: python3 build_manual.py
--out ../manuale-rigenerato. Richiede pandoc, Chromium e i moduli Python
playwright, Pillow e pypdf; nessuna rete viene usata per il rendering.

reference/vice/: estratti byte-esatti del sorgente corrente; non un intero
albero VICE. Gli strumenti storici in reference/tools non sono qualifiche
nuove. Sorgenti GPL completi VICE nell'archivio separato della distribuzione.

VALIDATION.json separa prove documentali, assembly, renderer e runtime.
Nessuna qualifica di hardware fisico o Windows nativo viene dichiarata.
''')
 (P/'SHA256SUMS.txt').write_text(''.join(sha(p)+'  '+str(p.relative_to(P))+'\n'for p in sorted(P.rglob('*'))if p.is_file()and p.name!='SHA256SUMS.txt'and '__pycache__'not in p.parts))
 target=out/'plus64-manuale-sviluppatore-ram80-it-en.zip'
 with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
  for p in sorted(P.rglob('*')):
   if p.is_file()and '__pycache__'not in p.parts:z.write(p,p.relative_to(out))
 with zipfile.ZipFile(target)as z:assert z.testzip()is None
 print(json.dumps(dict(file=str(target),bytes=target.stat().st_size,sha256=sha(target),documentation=documentation),indent=2))
if __name__=='__main__':
 q=argparse.ArgumentParser();q.add_argument('--original',type=Path,required=True);q.add_argument('--source',type=Path,default=R/'docs/developers/manual-current');q.add_argument('--out',type=Path,required=True);q.add_argument('--xa',type=Path,default=R/'tools-game/bin/xa');a=q.parse_args();build(a.original.resolve(),a.source.resolve(),a.out.resolve(),a.xa.resolve())
