MANUALE TECNICO PLUS/64 RAM80 - EDIZIONE2.0 - MECK

Manuale completo e riferimento rapido, in ITALIANO e INGLESE, PDF e HTML.
Le copie inglesi sono integrali, non riassunti. I sorgenti dei capitoli sono
in chapters/it e chapters/en. Il manuale serve a PROGRAMMARE plus/64.

Aggiornato dal manuale1.0 fornito dall'autore: profili RAM80, firme05/03,
allocazioni condivise, formati sprite, luci, scenery, snapshot ed esempi.
Sprite, voci e modem condividono64+16KiB; nessun banco aggiuntivo.

sdk/: esempio RAW8/SID e include aggiornato, build conPython3+xa6502.
sdk/materials/: maschera generica,121colori e luciN/E/frontale, con build
indipendente e D64 pronto. Le due demo usano profili differenti: vedi README.
Per rigenerare PDF/HTML fuori dalla cartella sorgente: python3 build_manual.py
--out ../manuale-rigenerato. Richiede pandoc, Chromium e i moduli Python
playwright, Pillow e pypdf; nessuna rete viene usata per il rendering.

reference/vice/: estratti byte-esatti del sorgente corrente; non un intero
albero VICE. Gli strumenti storici in reference/tools non sono qualifiche
nuove. Sorgenti GPL completi VICE nell'archivio separato della distribuzione.

VALIDATION.json separa prove documentali, assembly, renderer e runtime.
Nessuna qualifica di hardware fisico o Windows nativo viene dichiarata.
