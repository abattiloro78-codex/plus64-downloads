# 7. Quick reference

A reminder for the documented runtime, PE `08d3e87f…` (6,617,154 bytes,
debug sections removed). Details, exceptions and source hashes are in
chapters 2–4 and the API JSON inventories. These tables describe available
software, not a certified physical cartridge. `R` = CPU read, `W` = CPU write.

## Profiles and general map

| Profile | Program contract |
|---|---|
| New native game | CPU/TED use the **internal 16 KiB**, enforced on Plus/4 too; **64 KiB cartridge RAM** through the port; sprite view is cartridge bank 2 |
| `-plus64mainram` | CPU, TED and SRAM port share **64 KiB cartridge RAM**; sprite port sees the separate **internal 16 KiB** |
| Current budget | **65,536 + 16,384 = 81,920 bytes**; no additional sprite/FIFO RAM |

In the native profile ordinary RAM addresses are masked with `$3FFF`;
upper quarters are aliases, including on a Plus/4 configured to 16 KiB by
plus/64. The sprite port and modem share the budget: reserve their bytes.
Changing profile requires disabled sprites, an idle modem and empty queues
and command buffer. These are runtime resources, not new guest registers.
**See chapter 2.**

| Range | Device or area |
|---|---|
| `$FD40..$FD5D` | SIDcart at its standard address; `$FD5E/$FD5F` are not SID |
| `$FD90..$FDCF` | Sprites, data port and eight descriptors |
| `$FDE8..$FDED` | SRAM port: bank, offset, data and signature |
| `$FDF0..$FDF7` | Polled modem |
| `$FF00..$FF1F` | TED: native timers, video, input and IRQs |
| `$FF3E/$FF3F` | ROM-enabled / underlying-RAM strobes; written value irrelevant |

`$FDxx/$FExx` remain I/O with ROM disabled. BASIC normally occupies
`$8000..$BFFF`; KERNAL/high ROM occupies `$C000..$FFFF`, with I/O exceptions.
Zero page, stack and vectors remain the program's responsibility. Do not
use `$0001` as a C64-style banking selector.

## SRAM: six registers and same-bank wrapping

| Register | R | W |
|---|---|---|
| `$FDE8` | Offset low | Set low, preserve high |
| `$FDE9` | Offset high, bits 6–7 zero | Set high using `value & $3F` |
| `$FDEA` | Data, then increment | Write data, then increment |
| `$FDEB` | Bank 0–3 | `value & 3`; preserve offset |
| `$FDEC` | `$64` | Ignored |
| `$FDED` | `$05` | Ignored |

`index = (bank << 14) | offset`. After DATA: `offset = (offset+1) & $3FFF`.
**The bank does not change** on crossing `$3FFF` to `$0000`. Select all four
banks explicitly to traverse 64 KiB.

A diagnostic peek does not increment; a CPU read, including BASIC `PEEK`,
does. The signature does not expose the MainRAM flag. Coordinate port use
with IRQ routines and avoid RMW instructions on DATA. **See chapter 2.**

## Sprites: slots, coordinates, palette and publication

| Register | Function |
|---|---|
| `$FD90` | Enable, one bit per slot; write it **last** |
| `$FD91` | Sprite collisions, one bit per slot; R clears all, W ignored |
| `$FD92` | Per-slot bit: 0 monochrome, 1 RAW8 in the ordinary profile |
| `$FD93/$FD94` | X / Y expansion ×2, one bit per slot |
| `$FD95` | **Reserved**; does not implement behind-TED priority |
| `$FD96` | Sprite-view RAM port, R/W with auto-increment |
| `$FD97/$FD98` | 16-bit data pointer low / high |
| `$FD99..$FD9C` | Light selectors, two nibbles per register |
| `$FD9D/$FD9E` | Main-RAM lighting/scenery list pointer |
| `$FD9F` | Bit 0 enable, bits 1/2 blanking, bit 3 presentation window |
| `$FDA0..$FDCF` | Eight descriptors, six bytes per slot |

For slot `s=0..7`, base `b=$FDA0+6*s`:

| Offset | Field |
|---:|---|
| 0 | X low |
| 1 | Y |
| 2 | X high: only bit 0 contributes |
| 3 | Local colour or extended-profile material/format selector |
| 4–5 | **Byte** pattern address in the view, low/high |

Origin `(0,0)` is at the top left of the **320×200** area. In ordinary RAW:
`X=low+256*(high&1)`, range 0–511; Y is 0–255. The border clips pixels:
X=511 and Y=255 do not mean −1. The `leftmcm` signed projections apply
only to the advanced packed profile. **See chapter 3.**

| Ordinary format | Data | Transparency |
|---|---:|---|
| Monochrome | 63 bytes, 24×21, three bytes per row, high bit at left | Bit 0 transparent; bit 1 uses descriptor colour |
| RAW8 | 504 bytes, 24×21, 24 bytes per row | `$FF` recommended; renderer discards every value 121–255 |

A visible 16×16 sprite still occupies a 24×21 slot: initialize padding and
holes to `$FF`. In RAW8, **index 0 is opaque black**, not transparency.
Indices 0–120 encode one black and 120 combinations:

```text
index 0 -> TED $00
index i from 1 to 120:
    L = (i-1) div 15
    H = (i-1) mod 15 + 1
    TED colour = 16*L + H
```

Examples: index 6 → TED `$06`, index 111 → `$76`, index 106 → `$71`.
The palette does not remove TED background-cell/video-mode limits.

Sprite-view RAM uses `pointer & $3FFF`, but the **port counter is 16-bit**:
after `$3FFF` it records `$4000`, which accesses offset 0 again. Only after
`$FFFF` do its registers return to zero. This differs from the SRAM port's
14-bit offset. Ordinary RAW/mono fetches also wrap within the 16 KiB view.

With `-plus64rastercollisions`, writing `$FD90` publishes descriptors and
patterns even midway through a frame; disable with zero before reusing
slots. Already drawn lines remain unchanged. The latch contains collisions
between opaque slot pixels, not collisions against TED: no hardware
wall/platform collision is supplied. Lower-numbered slots have visual
priority. Bits belong to **slots**, not to identities of multiplexed enemies.

### Extended formats and lighting

`Plus64MixedSprites` requires `Plus64PackedCache`. Aligned 1 KiB packed
records contain inverse source64 at `$200..$23F`, shift at `$240`, MCM at
`$241`, three inks at `$242..$244`, and valid marker `$A5` at `$245`. These
are views of shared bytes, not another 16 KiB. Pointer tag `$4000`, with
bit 15 zero, selects mixed RAW8 at the low-14-bit offset; all 504 bytes
must fit without wrapping.

Sparse HIRES uses descriptor colour `$F9`, source magic `$A7`, a mask and
colour rectangles. Where supported, a material uses `$80|colour` and
preserves the mask. Light selectors use low/high nibbles for even/odd
sprites: 0 historical; 1–8 N, NE, E, SE, S, SW, W, NW; 9 front; 10 per-ink
diagonal MCM. FA is an invisible MCM occlusion tag between virtual sprites,
not arbitrary priority behind TED characters. **See chapter 3 and FORMAT.**

## SID: notes, gate and actual addresses

Reproducible profile: `-sound -sidenginemodel 256 -sidcartaddress 0xFD40
-sidcartclock 0`. `256` = reSID 6581; `257` = reSID 8580. SID clock 0:
**985,248 Hz PAL**, 1,022,730 Hz NTSC. In the preserved runtime, clock 1
instead supplies **1,773,447 Hz PAL** to SID, not 886 kHz. **See chapter 4.**

| Voice base | `+0/+1` | `+2/+3` | `+4` | `+5` | `+6` |
|---|---|---|---|---|---|
| `$FD40`, `$FD47`, `$FD4E` | Frequency low/high | 12-bit pulse width | Control | A high / D low | S high / R low |

CONTROL: `$01` gate, `$02` sync, `$04` ring, `$08` test, `$10` triangle,
`$20` sawtooth, `$40` pulse, `$80` noise. Rearticulating a note requires a
0→1 gate edge; TEST does not reset the ADSR rate counter.

| Register | Use |
|---|---|
| `$FD55/$FD56` | Cutoff: `(high<<3) | (low&7)` |
| `$FD57` | Resonance high nibble; voice 1/2/3/external routing at bits 0–3 |
| `$FD58` | Volume 0–15; LP `$10`, BP `$20`, HP `$40`, voice 3 excluded from direct output `$80` |
| `$FD59/$FD5A` | POTX/POTY, reads depending on inputs/configuration |
| `$FD5B/$FD5C` | Voice-3 oscillator / envelope reads |
| `$FD5D` | Decoded offset with no defined synthesis function |
| `$FD5E/$FD5F` | **Not decoded as SID** |

`N=round(Hz*2^24/SIDclock)`: A4 PAL with clock 0 → `$1D45`; write low `$45`,
high `$1D`, approximately 440.029 Hz. Keep RAM shadows of write-only
registers; do not recover them through reads or RMW. SID debugger peek shows
last writes, not necessarily live OSC3/ENV3 values. The host audio buffer
changes latency, not note frequency.

## Modem: polling, FIFOs and commands

| Register | Read / write |
|---|---|
| `$FDF0` | R removes RX, zero if empty; W feeds AT while offline, then TX when connected |
| `$FDF1` | STATUS; W ignored |
| `$FDF2` | R zero; W bit 0 reset, otherwise bit 1 disconnect; bit 2 clears overrun |
| `$FDF3` | R `$04`, writes ignored: descriptive “9600”, not programmable baud |
| `$FDF4/$FDF5` | RX / TX pending bytes, 0–128 in the current model |
| `$FDF6/$FDF7` | Signature `$64` / protocol `$03` |

STATUS: `$01` RX ready, `$02` TX has room, `$04` connected, `$08` dialing,
`$10` latched overrun, `$20` offline. After reset: `$22`. RX/TX have
**128 bytes each**, with a 256-byte command buffer: **512 bytes total,
already inside the budget**. Network reception applies backpressure while
RX is full; CPU writes that cannot be accepted set overrun. Reading STATUS
does not clear flags. RX byte `$00` is valid: check `$01` first. Device
peek does not remove a byte; BASIC `PEEK` does.

Supported AT commands: `AT`, `ATE0`, `ATE1`, `ATZ`, `ATH`, `ATDhost[:port]`,
`ATDThost[:port]`, terminated by ASCII CR `$0D`. Default port 23; responses
`OK`, `ERROR`, `CONNECT 9600`, `NO CARRIER`, enclosed in CR/LF. When connected,
`ATH` and `+++` are data, not commands: close using `$FDF2=$02`.

The backend is host TCP with minimal incoming Telnet handling; it is not a
fully binary-transparent transport and has no TLS. It generates no IRQ/NMI.
Polling occurs in the video callback, not on reading STATUS. Use timeouts
and handle overrun. DNS resolution is synchronous. **See chapter 4.**

## TED, IRQs and reset: operational reminder

| Register | Native function |
|---|---|
| `$FF00/01`, `$FF02/03`, `$FF04/05` | Timers 1/2/3; W low stops, W high starts |
| `$FF06/$FF07` | TED video mode and control |
| `$FF08` | TED input sampling; not a C64 CIA |
| `$FF09` | IRQ flags; write bits to acknowledge |
| `$FF0A/$FF0B` | IRQ mask and raster comparison; `$FF0A` bit 0 = line bit 8 |
| `$FF12..$FF14` | Native video-memory selections/bases; respect shared bits |
| `$FF15..$FF19` | Video, auxiliary and border colours according to TED mode |
| `$FF1C/$FF1D` | Raster counter high/low |

IRQ: raster `$02`, T1 `$08`, T2 `$10`, T3 `$40`. Timers count at half the
base clock: **886,723.5 ticks/s PAL**. Initial zero means 65,536; T1 reloads
its configured value, T2/T3 reload 65,536 after the first underflow. Two-byte
reads are not atomic; use high/low/high if necessary. `SEI` masks IRQs: it
does not provide the equivalent of a CIA2 NMI.

| Action | Effect to remember |
|---|---|
| SRAM register reset | Bank/offset zero; preserves contents and MainRAM binding |
| Enabling plus/64 from disabled | Initializes views and clears cartridge RAM, preserving native internal RAM |
| Sprite reset | Clears registers and latch, preserves shared backing; initialize every image explicitly |
| Modem reset, `$FDF2=$01` | Disconnects, clears indices/command and overrun, preserves shared payload; echo disabled |
| Disconnect, `$FDF2=$02` | Discards TX, preserves RX and inserts `OK` |
| Audio initialization | Set gate, waveforms, ADSR and volume explicitly; do not read them from write-only registers |

For details see chapters 2–4; for complete programs and checks see chapters
5–6 and the SDK. Host C tests do not equal CPU6502, VICE, native Windows or
physical-hardware tests.

## Snapshots and RAM80 ownership

VSF with plus/64 enabled: container 2.1, PLUS64 module 1.0. The 64 KiB is
in `PLUS4MEM`; the 16 KiB and device state are in `PLUS64`. Bytes 72–78
version extended formats; byte 79 is the scenery revision, currently 17.
Current readers accept 0, 1 and 3–17; withdrawn prototype 2 is refused.
Older readers may refuse new versions; there is no silent partial restore.
With a connected/dialing modem, save and load are refused.

Modem payload occupies cartridge bank 3 `$3E00..$3FFF` in native mode or
internal RAM `$0000..$01FF` in MainRAM. Reserve it before using the modem.
Impossible Mission lends it to speech only while the modem is idle. PC
video/snapshot copies are not guest RAM. The scenery compositor reads
emulated RAM directly: physical hardware/genlock needs a verified data
path, synchronization and contention policy, not assumptions implicit in
the API.