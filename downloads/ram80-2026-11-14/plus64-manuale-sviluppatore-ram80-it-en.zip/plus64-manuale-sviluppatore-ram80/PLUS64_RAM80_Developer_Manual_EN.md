# 1. How to use this manual

This manual is intended for writing new games for the **plus/64 software
model** implemented by the VICE runtime distributed with the project. It
describes the addresses actually decoded, the formats actually read by the
renderer, and the conventions checked by the examples. Access to an online
repository is not assumed: examples, constants and references are included
in the package.

**RAM80 documentation edition 2.0 — 14 November 2026. Meck project.**
The current reference is the 6,617,154-byte Windows runtime `xplus4.exe`,
SHA256 `08d3e87f84140fe13014213beb32bf7635de12b715769d995efc0658bf08ddfa`.
Debug sections have been removed from the final distribution; its executable
code is identical to the tested reference build. The edition number belongs
to the manual, not to a new electrical cartridge revision. The current RAM
port reports protocol `$05`; the PLUS64 snapshot module remains version 1.0,
and the current scenery format is 17.

## What the platform provides

The C16 or Plus/4 continues to supply the CPU, TED, keyboard, joystick and
KERNAL. Within the emulated model, plus/64 adds SID, a port accessing 64 KiB
of SRAM, eight sprite descriptors composited over TED video, and a register
modem. Sprites have a palette of 121 colours; TED retains its own palette
of 121 distinct colours. Each TED bitmap cell remains subject to the limits
of its video mode: 121 does not mean 121 colours per cell.

One `xplus4.exe` emulates both C16 and Plus/4. The program's name does not
identify a game version intended only for Plus/4. A program can use the same
API and memory budget on both machines. The native profile enforces 16 KiB
of CPU RAM even on Plus/4; MainRAM enforces 64 KiB of cartridge RAM as CPU
RAM. Total memory available to the program is always **64+16 KiB, or
81,920 bytes**.

## Two profiles to distinguish

| Profile | Use | Observable memory |
| --- | --- | --- |
| Native, recommended initially | New games and this manual's SDK | Code and TED use the internal 16 KiB; 64 KiB cartridge RAM is accessed through `$FDE8..$FDED`; the sprite port sees cartridge bank 2 |
| MainRAM | The Impossible Mission C64-engine adapter and advanced programs | CPU/TED and the SRAM port see the same 64 KiB cartridge RAM; the sprite port sees the separate internal 16 KiB |

The implementation has two payload backings: `mem_ram[65536]` and
`p64_aux_ram[16384]`. SRAM, sprite and modem views alias these bytes; they
are not additional pools. In the native profile the modem uses the last
512 bytes of cartridge bank 3; in MainRAM it uses the first 512 bytes of
internal RAM. Every program must reserve the shared areas it uses. Do not
add another SRAM, private sprite RAM or modem FIFO to the budget: the total
remains 80 KiB.

A profile change is a runtime setting, not a new CPU register. It rotates
the five 16 KiB blocks in place, preserving their contents. It requires
disabled sprites and an idle modem with empty queues and command buffer.
The software profile does not demonstrate a physical cartridge decoder.

## Status of the information

| Label | Meaning |
| --- | --- |
| Current API | Behaviour present in the reference runtime source |
| Checked in VICE | Guest CPU instructions or pixels actually produced in the emulator |
| Experimental format | An existing opt-in feature with specific options and layouts |
| Open hardware question | A feature that must not be assumed available on a physical cartridge |

The cartridge described here is **emulated inside VICE**. New materials and
scenery read emulated RAM structures directly through host code: physical
circuitry still needs a defined data-access path, contention policy and
video synchronization. A possible external compositor/genlock requires its
own design and validation; these tests do not establish it. This is not a
simple ROM/CRT image usable in official VICE, or certified physical
circuitry. Software tests do not measure power delivery, bus contention,
electrical timing or analogue video quality.

## Requirements

- The previously distributed plus/64 Windows runtime, to run PRGs or games.
- To assemble the example: Python 3 and the `xa` assembler; see `sdk/README.md`.
- Initially: familiarity with 6502 registers, addressing, stack and branches.
- For VICE diagnostics: system ROMs and an executable with matching plus/64
  support. The SDK does not contain another emulator.

The added modules do not emulate a complete Commodore 64. In particular,
do not assume VIC-II, CIA, C64 raster IRQs, C64 sprite DMA or a programmable
NMI merely because SID and additional graphics are present.

## Notation

Addresses beginning with `$` are hexadecimal; `0x` is equivalent in Python/C
tools. Binary values use `%`. A byte is 0–255 and a KiB is 1,024 bytes.
Tables distinguish reads and writes.

A CPU register read is not always equivalent to inspecting it in the
monitor: the monitor may use a side-effect-free `peek` callback. An ordinary
`LDA` or BASIC `PEEK` is a program read and can advance a pointer, consume
a modem byte or clear a latch.

References to files in `reference` refer to the frozen copies included in
the package. Their hashes are recorded in the manifest. The citations do
not require access to private repositories.

## Quick start

## Directory organization

Extract the manual and SDK while preserving subdirectories. Use the existing
runtime to execute the demo: neither game D64s nor a saved game is required.
To assemble it, run from the manual directory:

```sh
python sdk/build.py --out build-demo
```

The destination must be new. `xa` must be in PATH; if necessary set `XA`
to its path. The SDK README describes the details and actual outputs. The
`sdk-current` material adds a current-materials example without replacing
the baseline program. Complete example source is supplied; it is not an
unfinished pseudoprogram.

## Native execution profile

The essential options for initial development are:

```text
-default -model c16 -ramsize 16
-plus64 -plus64rastercollisions
-sound -soundbufsize 64
-sidenginemodel 256 -sidcartaddress 0xFD40 -sidcartclock 0
```

`-plus64` enables the devices. `-plus64rastercollisions` enables the scanline
path and immediate publication on an FD90 write. It does not add a register.
For the other machine replace `-model c16` with `-model plus4`, retaining
the internal 16 KiB limit.

For this example leave `plus64mainram`, `plus64packedcache`,
`plus64mixedsprites` and `plus64leftmcm` disabled: they belong to the
advanced profile. `-default` prevents accidentally inheriting the options
of a previous game.

`-directory` must point to the runtime resource directory. KERNAL, BASIC,
1541 ROM and keymap must be those of the working distribution. For a D64,
retain the distributed launcher's 1541-drive and bus/trap options. Do not
change the SID clock to accelerate loading or animation.

## Expected result

The demo displays TED graphics and a coloured sprite with transparent
pixels, moved by the controls documented in the SDK. A control triggers
a SID note. Publishing descriptors does not erase the bitmap. Separate
diagnostics check device reads and writes; they must not be confused with
a complete game.

# 2. Memory, CPU address space and I/O ports

Choose one memory profile for a game and retain it on both machines. The
current contract provides **64 KiB cartridge RAM and 16 KiB internal RAM,
81,920 bytes in total**. The two available views do not expose a linear
80 KiB CPU address space and do not add a sprite pool.

This chapter describes the RAM80 2.0 runtime, PE SHA256
`08d3e87f84140fe13014213beb32bf7635de12b715769d995efc0658bf08ddfa`
(6,617,154 bytes, debug sections removed). `MEMORY_API.json` accompanies the
current reference; historical inventories reporting protocol `$04` do not
describe RAM80 memory ownership. Cited filenames are relative to the VICE
source supplied with the runtime.

## 2.1 The two available profiles

| Profile | CPU/TED program RAM | `$FDE8..$FDED` port | Sprite-port and modem view |
|---|---|---|---|
| `-plus64`, native | Internal 16 KiB, enforced on Plus/4 too | Four 16 KiB cartridge banks | Sprites: cartridge bank 2. Modem: bank 3, offsets `$3E00..$3FFF` |
| `-plus64mainram` | Cartridge 64 KiB as main RAM | Alias of the same 64 KiB | Sprites: internal 16 KiB. Modem: internal offsets `$0000..$01FF` |

In the first profile a program such as PRISM keeps code and bitmap below
`$4000` and transfers resources from the cartridge through the data port.
Changing the SRAM bank does not move CPU code, stack, TED video or ROM.
Writing bank 2 also changes the view read by the sprite circuit: reserve
the intervals being used explicitly.

In the second profile, used by Impossible Mission, the
`plus64_set_main_ram()` setter selects `RamSize=64` and binds the four
banks to the same `mem_ram` used by the CPU decoder. The internal 16 KiB
remains distinct and is accessible through the sprite port `$FD96..$FD98`.
Disabling MainRAM returns to the 16 KiB CPU profile. A change rotates the
five 16 KiB blocks in place, without an additional hidden buffer; it
preserves both cartridge and internal contents. It is refused if sprites
are enabled, the modem is connected/dialing, RX/TX queues contain data or
a partial command is present. [MEM-2]

**An alias is not another 64 KiB memory.** With MainRAM, a port write
selecting bank 0 and offset `$2345` changes the same `mem_ram[$2345]` cell
used by the CPU decoder. The port also accesses RAM underneath ROM and I/O
because it uses the backing directly. It does not send commands to I/O
registers at those CPU addresses. [MEM-1, MEM-2]

The model is a current software contract, not a demonstration of an
electrical cartridge decoder. Host-compositor structures and temporary
snapshot-validation copies are not RAM accessible to the game.

## 2.2 C16 and Plus/4: one software contract

On a C16 with `RamSize=16`, the ordinary RAM decoder uses
`address & $3FFF`: where ROM or I/O does not intervene, `$2000`, `$6000`,
`$A000` and `$E000` alias the same cell. TED RAM bases are likewise reduced
to the first 16 KiB. Writing above `$3FFF` does not create free memory.
[MEM-3]

With plus/64 enabled, the native profile enforces `RamSize=16` on Plus/4
too. Selecting the Plus/4 model does not provide another 48 KiB. Both
machines check the same contract, rather than game variants with different
capacities or rules. Incompatible RAM expansions are refused.

With `-plus64mainram`, both use the 64 KiB cartridge as main RAM. The
separate internal 16 KiB is the sprite-port view, not another linear
window or an invented banking register. Configure the model and profile
before starting the program, and check protocol `$05` before using the
shared contract.

## 2.3 SRAM API: `$FDE8..$FDED`

The port is registered only while plus/64 is enabled. No additional mirrors
are declared. Its six addresses are listed below. `R` means CPU read and
`W` CPU write. [MEM-1, MEM-2]

| Address | Access | Meaning |
|---|---|---|
| `$FDE8` | R/W | Low byte of the bank offset |
| `$FDE9` | R/W | High offset byte; writes use bits 0–5 only; reads return bits 6–7 as zero |
| `$FDEA` | R/W | Data at the current index; **every CPU read and every write increments the offset** |
| `$FDEB` | R/W | Bank 0–3; writes use `value & 3`; changing it preserves the offset |
| `$FDEC` | R | Constant signature `$64`; writes have no effect |
| `$FDED` | R | Constant protocol version `$05`; writes have no effect |

Version `$05` identifies the shared 64+16 KiB contract. It is not a
register exposing or changing MainRAM. The profile remains an agreement
between runtime and program. Check the signature as the pair `$64,$05`.

The exact calculation is:

```text
index = (bank << 14) | (offset & $3FFF)
after DATA: offset = (offset + 1) & $3FFF
```

After `$3FFF`, the port returns to `$0000` **in the same bank**; it does
not advance to the next bank. A 64 KiB copy must therefore select the four
banks explicitly. Writing the low or high offset byte preserves the other
byte; selecting a bank does not reset the pointer.

The internal `p64_memory_peek()` callback reads without incrementing. This
**does not** make BASIC `PEEK(65002)` harmless: BASIC performs a CPU read of
`$FDEA`, which increments the pointer. A side-effect-free peek is the
device function used by the debugger when it requests that operation.

### Example: 256 bytes at the end of bank 2

This example is for the native SRAM-port profile, using a bank reserved
by the game. It writes values 0–255 at offsets `$3F00..$3FFF`; afterwards
the pointer is `$0000`, bank 2. `PHP/SEI/PLP` prevents an IRQ routine using
the same port from changing its bank or pointer during the transfer.

```asm
        php
        sei
        lda #2
        sta $fdeb
        lda #0
        sta $fde8
        lda #$3f
        sta $fde9
        ldy #0
copia:  tya
        sta $fdea
        iny
        bne copia
        plp
        rts
```

This code does not save the previous pointer. The caller must define
whether the port is exclusive, or save and restore bank and offset. Do not
use read-modify-write instructions such as `INC $FDEA`: they perform extra
accesses to an auto-incrementing port. With MainRAM, also choose an interval
that contains no live code or data, because the port aliases main memory.

### Reset and preservation

- `p64_memory_powerup()` initializes the structure, clears the cartridge
  view and port registers, and preserves native internal RAM. It is called
  when plus/64 is enabled from a disabled state.
- Device reset calls `p64_memory_reset_registers()`: bank and offset return
  to zero; SRAM contents and the MainRAM binding remain.
- General machine reset can still execute ROM code that modifies native
  RAM. Preserving SRAM does not guarantee preservation of a complete game
  state. [MEM-1, MEM-2]

## 2.4 ROM, I/O and usable areas

The CPU has a 64 KiB address space even when a program uses banked memory
views. Installed byte counts do not remove overlays. In the standard
native profile: [MEM-3, MEM-4]

| Area | Required consideration |
|---|---|
| `$0000/$0001` | Host processor port; not the C64 ROM/I/O selector |
| `$0002..$00FF` | Zero page, shared with KERNAL/BASIC if ROM calls are used |
| `$0100..$01FF` | CPU stack; not a permanent buffer |
| `$0200..$7FFF` | RAM under ordinary conditions, within profile limits/aliases |
| `$8000..$BFFF` | BASIC or selected low ROM while ROM is enabled; underlying RAM on reads when disabled |
| `$C000..$FFFF` | KERNAL or selected high ROM, with I/O exceptions; underlying RAM while ROM is disabled |
| `$FD00..$FDFF`, `$FE00..$FEFF` | I/O decoding in both ROM/RAM configurations, including plus/64 ports |
| `$FF00..$FF1F` | TED registers, not ordinary RAM |
| `$FF3E`, `$FF3F` | ROM/RAM selection strobes; written value is irrelevant |

A write to `$FF3E` enables ROM reads; a write to `$FF3F` selects underlying
RAM. I/O registers do not disappear. `$FF20..$FFFF`, except the two strobes,
follows the decoder's configuration, including the final CPU vectors. Do
not hide KERNAL and then call it with `JSR`, or leave IRQ enabled without
valid RAM vectors and handlers. Normal stores under ROM windows write
underlying RAM; I/O areas remain exceptions. [MEM-3, MEM-4]

TED fetches have their own bases and selections. The native SRAM port is
not a source for TED fetches: bitmap or character data must first be copied
into the native RAM required by the video mode. The sprite circuit's video
overlay does not change this rule.

## 2.5 Shared backings and compositor buffers

The implementation has exactly two payload backings:

| Backing/view | Size | Ownership |
|---|---:|---|
| `mem_ram` | 65,536 bytes | Internal 16 KiB CPU/TED RAM plus three cartridge banks in native mode; four cartridge banks in MainRAM |
| `p64_aux_ram` | 16,384 bytes | Fourth cartridge bank in native mode; separate internal RAM in MainRAM |
| Sprite view | 16,384 bytes, already counted above | Cartridge bank 2 or internal RAM, depending on profile |
| Modem payload | 512 bytes, already counted above | RX128, TX128, command256; offsets as in table 2.1 |
| Overlay, alpha and raster summaries | Host buffers | No guest address or additional game-RAM capacity |

The backings total **81,920 bytes**, not 96 KiB. The following two views
are not added again. A program's resident SID/audio data also occupies
these same bytes. Executable, disk and snapshot sizes measure PC files,
not RAM available to the program. [MEM-1, MEM-2, MEM-5]

Modem reset clears indices and state but preserves shared payload bytes.
Software must reserve that payload while using the modem. Impossible
Mission lends it to speech only while the modem is idle; using the modem
and that audio concurrently would corrupt data ownership.

RAM80 snapshots save both backings: `PLUS4MEM` contains the 64 KiB, and
`PLUS64` the 16 KiB together with registers and latched video. The VSF
container is 2.1 with plus/64 enabled, the PLUS64 module is 1.0, and the
current scenery format is 17: these are distinct numbers. Serialized sizes
include peripheral state and host buffers and do not increase the guest
budget. Legacy snapshots lacking complete RAM80 state are refused. Active
modem connections cannot be restored; saving is refused while connected
or dialing.

## 2.6 IRQs and timers: the host remains TED

plus/64 does not add a C64 CIA. There are no new CIA registers at
`$DCxx/$DDxx`, or a modem/SID NMI. Use native TED resources for interrupts:
[MEM-4, MEM-6]

| Registers | Function |
|---|---|
| `$FF00/$FF01` | Timer 1, low/high byte |
| `$FF02/$FF03` | Timer 2, low/high byte |
| `$FF04/$FF05` | Timer 3, low/high byte |
| `$FF09` | IRQ flags: raster bit 1, timer 1 bit 3, timer 2 bit 4, timer 3 bit 6; bit 7 summarizes an active enabled IRQ |
| `$FF0A` | IRQ mask at the same bit positions; bit 0 contains the programmed raster line's high bit |
| `$FF0B` | Programmed raster line's low byte |

Writing a timer's low byte stops it; writing its high byte starts it.
Timer 1 reloads its configured value. After their first underflow, timers
2 and 3 continue with period 65,536. An initial zero means 65,536. The
model counts one tick every two TED base clocks: PAL
`1,773,447 / 2 = 886,723.5 Hz`, not one generic 6502 instruction cycle.
Separate low/high reads are not an atomic latch. If a consistent sample is
needed, check rollover, for example by reading high/low/high.

TED flags are acknowledged by writing the bits to clear to `$FF09`; they
do not copy CIA flag semantics. `SEI` masks a TED IRQ: it does not replace
a C64 NMI that could interrupt with `I=1`. C64 audio drivers or loaders
dependent on CIA/NMI require an analysed adapter, not indiscriminate
address substitution.

## Chapter references

Inventories must refer to the same source revision. Edition 1.0's old line
numbers are not references for the current version.

- **MEM-1:** `src/plus4/plus64_memory.c` and `.h`: `bind_views`, `p64_memory_bind_main_ram`, `p64_memory_read/write`, backing constants.
- **MEM-2:** `src/plus4/plus64vice.c`: `plus64_set_enabled`, `plus64_set_main_ram`, `plus64vice_ram_size_allowed`, snapshot API.
- **MEM-3:** `src/plus4/plus4mem.c`: RAM decoder, native/MainRAM profiles, rejection of incompatible expansions.
- **MEM-4:** `src/plus4/ted-mem.c` and `plus4mem.c`: ROM/RAM and I/O selections.
- **MEM-5:** `src/plus4/plus64_sprite.h`, `plus64_modem.h` and corresponding `.c`: shared views and modem payload.
- **MEM-6:** `src/plus4/ted-timer.c`, `ted-irq.c`, `ted-mem.c`: timers, IRQs and `ted09_store`, `ted0a_store`, `ted0b_store`.

# 3. TED video and plus/64 sprites

This chapter specifies video in the maintained plus/64 implementation: the RAM80 contract, memory protocol `$05`, and extended graphics formats through version17. Valid TED rules, base descriptors and examples from manual1.0 are retained; the former independent pools and then-reserved registers are updated. This is not a specification for a future electrical cartridge implementation. The delivery's current manifest identifies its executable and source hashes.

References name maintained source files, reproducible offline in the package's `reference/vice/src/plus4` directory. The previous edition's line numbers have been removed: consult the named functions or corresponding branches in the current file. Chapter8 also contains the detailed extended-format reference; the maintained implementation determines the supported combinations. None of the renderer's HOST structures adds RAM addressable by a 6502 program.

## Choosing a profile for a new game

Start with the normal format, native RAM limited to 16 KiB, cartridge SRAM through its port, and raw8bpp sprites in the shared view. Suitable video options are:

```text
xplus4.exe -default -model c16 -ramsize 16 -plus64 -plus64rastercollisions
```

`-default` restores initial resources; in this model `Plus64MainRAM`, `Plus64PackedCache`, `Plus64LeftMCM`, `Plus64MixedSprites` and `Plus64RasterCollisions` start at 0. The final option explicitly enables publication and collisions per scanline while retaining the raw format. Complete disk, SID and input options are described in other chapters. Do not enable `packedcache` or `leftmcm` merely because a game uses more colours. (`plus64vice.c`)

The packed path is a software extension for compact caches, materials and reuse of particular C64 caches. A new game does not require it, and it is not the original0.94 format. Its operation is documented below so that ports can reproduce it without implying that a physical device has already been built. (`plus64_sprite.h`; `plus64vice.c`)

## Configuring the TED background

Native TED registers configure the background independently of `$FD90..$FDCF`. This table lists fields applied by the runtime; resulting memory addresses remain subject to the RAM profile in chapter2.

| Register | Useful video-configuration fields |
| --- | --- |
| `$FF06` | Bits0–2: vertical scroll0..7; bit 3:0=24 rows,1=25 rows; bit 4: display enable; bit 5:0=text,1=bitmap; bit 6: extended colour mode. Multicolour bitmap: bit 5=1, bit 6=0 and `$FF07` bit 4=1. |
| `$FF07` | Bits0–2: horizontal scroll0..7; **bit 3**:0=38 columns,1=40 columns; bit 4: multicolour. In normal text, bit 7 selects0=128glyphs with reverse through character-code bit 7, or1=256glyphs without automatic reverse. It is not a global background-inversion bit. |
| `$FF12` | Bits3–5: bitmap base `($FF12 AND $38) << 10`, in$2000 steps. **Bit3 does not enable bitmap mode:** it selects the first bit of its base. Bit2:0=fetch bitmap/glyphs from RAM,1=ROM path; in the latter case a base below$8000 uses the runtime's open-space path. Bits0–1: high frequency bits of TED voice0; preserve them when changing video only. Bits6–7 read as1 and do not select the base. |
| `$FF13` | Glyph base `($FF13 AND mask) << 8`: mask `$FC` normally, `$F8` when `$FF06` bit 6 or `$FF07` bit 7 is active. Bit1:0=CPU fast mode permitted,1=slow mode; it is not a glyph-address bit. Bit0 cannot be changed by writing `$FF13`: it reflects ROM/RAM selection updated by `$FF3E/$FF3F` strobes and participates in matrix and attribute fetches. It does not change the bitmap/glyph selector in `$FF12` bit 2. |
| `$FF14` | Attribute base `A = ($FF14 AND $F8) << 8`, aligned to$0800; the second matrix is at `A+$0400`. In the SDK bitmap these are luminance and chrominance respectively. Bits0–2 do not move these bases. |
| `$FF15` | Global background colour; the value of pair `00` in multicolour bitmap mode. |
| `$FF16` | First additional global colour; the value of pair `11` in multicolour bitmap mode. |
| `$FF17/$FF18` | Second/third additional global colours: used by relevant text modes, not multicolour-bitmap pairs. In extended text `$FF15..$FF18` are the four backgrounds selected by the character code's two high bits. |
| `$FF19` | Border colour. As with `$FF15..$FF18`, bits 0–3=hue, bits 4–6=luminance; written bit 7 is ignored and reads as1. Hue0 produces black, so128 codes do not represent128distinct colours. |
| `$FF1C/$FF1D` | Current-line counter: `(($FF1C AND 1) << 8) OR $FF1D`; the other bits of `$FF1C` read as1. These are not the IRQ-compare pair `$FF0A/$FF0B`. The runtime also permits writing them to reposition the counter; use reads only for ordinary polling. |

Mode bits follow `ted.c`; scrolling, display and window follow `ted-mem.c`; text reverse follows `ted-draw.c`. CSEL is determined by the actual `value & $08` branch, rather than the historical comment calling it bit 4. Bases and fetch sources are in `ted.c`; shared reads/writes of `$FF12` are in `ted-mem.c` and `ted-sound.c`. ROM selection and attributes are in `ted-mem.c`. Colours and pixel pairs are in `ted-mem.c` and `ted-draw.c`; the raster counter is in `ted-mem.c`.

### Exact initialisation of the SDK example

After normal KERNAL loading, the demo performs these writes in this order (`demo.asm`):

```asm
        lda #$3b
        sta $ff06
        lda #$18
        sta $ff07
        lda $ff12
        and #$c3
        ora #$08
        sta $ff12
        lda #$18
        sta $ff14
        lda #0
        sta $ff15
        sta $ff16
        sta $ff19
```

The result is multicolour bitmap mode,25 rows,40 columns, vertical scroll3 and horizontal scroll0; bitmap base $2000, luminance$1800, chrominance$1C00, and black global backgrounds and border. `$FF12` is not assigned a universal constant: this operation preserves its two audio bits, clears the ROM selector and sets base bits to$08; bits 6–7 read back as1 are ignored by the video setter. The demo does not write `$FF13`, `$FF17` or `$FF18`: glyph base is unnecessary for its bitmap, and the two additional colours are not used there. Do not assume this sequence restores every TED state left by a previous program.

The SDK initialises1024 bytes for each attribute matrix using palette tables, then fills8000bitmap bytes with `$55`, displaying pair `01` at every sample; its colour therefore comes from cell attributes (`demo.asm`; `ted-draw.c`). The loop waits for `$FF1D=240`, a unique value in a 312-line PAL frame, without writing the counter (`demo.asm`). For generic synchronisation below 256, also use `$FF1C`, as explained in the coordinates section.

## What is composited over TED

TED continues producing its own background. The runtime applies sprite pixels after emulating each TED scanline, within the logical320×200 area. Transparent pixels leave TED content unchanged; an opaque sprite pixel replaces the colour at that point. This path does not provide an RGB framebuffer or a behind-background priority setting. (`ted.c`; `plus64_overlay.c`; `plus64_sprite.c`)

The eight slots share a **16384-byte view of existing RAM**, `sprite.ram`, accessible by the CPU through `$FD96`. In native mode CPU/TED use internal16 KiB RAM and this view aliases cartridge bank2; SRAM access to that bank sees the same bytes. In `mainram`, CPU/TED use the cartridge64 KiB and the sprite port views internal16 KiB RAM. The total remains64+16 KiB: there is no additional private sprite pool. Native mode cannot use another48 KiB from a Plus/4. TED does not read the sprite port as its own video window: programs must respect chapter2's memory map. (`plus64_memory.c`, `bind_views`, `p64_memory_sprite_ram`; `plus64_sprite.h`)

The `overlay` structure, `alpha` mask and 200-line collision summary are emulator HOST buffers, not additional areas addressable by a 6502 program. Do not assign cartridge addresses to them. (`plus64vice.c`)

### Sprite-pixel palette

Valid indices are 0..120. Convert sprite index `i` to a TED colour code as follows:

```text
i = 0:       TED = $00
1 <= i <=120:
    luminance = (i - 1) div 15
    hue       = (i - 1) mod 15 + 1
    TED       = luminance * 16 + hue
```

These are 120 nonblack hue/luminance combinations plus black, not 121 RGB values chosen by the program. The runtime conversion is the one above; RGB appearance, filtering and monitor output depend on the video path. (`plus64_overlay.c`)

In raw8bpp,0 is **opaque black**, not transparency. `$FF` is the recommended transparent sentinel; current code actually discards all values121..255. Opaque black covers TED and participates in collisions, whereas a discarded pixel occupies no position. The alpha mask distinguishes them. (`plus64_sprite.h`; `plus64_sprite.c`; `plus64_overlay.c`)

The sprite palette does not remove limits of native TED graphics modes: the background remains the signal already rendered by TED. This API has no register requesting121 colours for every background cell. (`ted.c`; `plus64_overlay.c`)

## CPU register map

The sprite decoder covers only `$FD90..$FDCF`. The reset column describes `plus64_reset`: registers and the latch are cleared, **not the pattern RAM backing**. HOST format options survive as configuration and are resources distinct from these registers. (`plus64_sprite.h`; `plus64_sprite.c`; `plus64vice.c`)

| Address | Access and reset | Actual meaning |
| --- | --- | --- |
| `$FD90` | R/W,0 | Enable: bit `s` enables slot `s`, for `s=0..7`. With the per-line profile, every write publishes current state even if the value is unchanged. |
| `$FD91` | Read-clear,0; writes ignored | Sprite-collision latch: one bit for each participating slot. |
| `$FD92` | R/W,0 | Bit `s`:0=monochrome;1=raw8bpp in the normal format, or packed MCM when `packedcache` is active. |
| `$FD93` | R/W,0 | Bit `s`: horizontal doubling of slot `s`. |
| `$FD94` | R/W,0 | Bit `s`: vertical doubling of slot `s`. |
| `$FD95` | R/W,0 | Reserved. The byte is retained and readable, but does not apply background priority. |
| `$FD96` | R/W data port; initial pointer0 | Reads or writes a shared-backing byte, then increments pointer `$FD98:$FD97`. It is not an ordinary register cell. |
| `$FD97` | R/W,0 | Data-port pointer low byte. |
| `$FD98` | R/W,0 | Data-port pointer high byte. It is not an external-SRAM bank selector. |
| `$FD99..$FD9C` | R/W,0 | With extended formats: two4-bit light selectors per byte, even slot in the low nibble; values0..10 are described below. |
| `$FD9D/$FD9E` | R/W,0 | Little-endian pointer to the layer/material list in existing main RAM, for extended `mainram`. |
| `$FD9F` | R/W,0 | Bit0: layers enabled; bit 1 or bit 2: black presentation masking; bit 3: post-sprite window from flag4 nodes. Other bits have no assigned function here. |
| `$FDA0..$FDCF` | R/W,0 | Eight six-byte descriptors, listed below. |

Register access, auto-increment, enable, format and expansion are implemented in `plus64_sprite.c`; FD90 publication is in `plus64vice.c`. Historical comments describing FD92 as reserved do not describe the current executed branch.

Auto-increment uses a 16-bit counter and updates both registers. Access to the backing uses `pointer AND $3FFF`, so `$4000`, `$8000` and `$C000` alias `$0000`, rather than selecting more banks. Keep the pointer within 0..$3FFF to avoid depending on these aliases. Incrementing$FFFF wraps both bytes to 0. (`plus64_sprite.c`)

**SDK rule:** write0 to unused fields and do not use reserved registers as scratch RAM. Current readback does not give them an additional public function. (`plus64_sprite.c`)

### The eight descriptors

Slot `s` starts at `$FDA0 + 6*s`. Fields are independent; this is not the VIC-II register layout. (`plus64_sprite.c`)

| Slot | X low | Y | X high | Colour | Pattern low | Pattern high |
| --- | --- | --- | --- | --- | --- | --- |
| 0 | `$FDA0` | `$FDA1` | `$FDA2` | `$FDA3` | `$FDA4` | `$FDA5` |
| 1 | `$FDA6` | `$FDA7` | `$FDA8` | `$FDA9` | `$FDAA` | `$FDAB` |
| 2 | `$FDAC` | `$FDAD` | `$FDAE` | `$FDAF` | `$FDB0` | `$FDB1` |
| 3 | `$FDB2` | `$FDB3` | `$FDB4` | `$FDB5` | `$FDB6` | `$FDB7` |
| 4 | `$FDB8` | `$FDB9` | `$FDBA` | `$FDBB` | `$FDBC` | `$FDBD` |
| 5 | `$FDBE` | `$FDBF` | `$FDC0` | `$FDC1` | `$FDC2` | `$FDC3` |
| 6 | `$FDC4` | `$FDC5` | `$FDC6` | `$FDC7` | `$FDC8` | `$FDC9` |
| 7 | `$FDCA` | `$FDCB` | `$FDCC` | `$FDCD` | `$FDCE` | `$FDCF` |

| Field | Interpretation |
| --- | --- |
| X low, X high | `X = low + 256*(high AND 1)`. X-high bits 7..1 are stored but ignored by the renderer. |
| Y |8-bit coordinate, normally unsigned:0..255. Signed exceptions belong exclusively to the advanced profile below. |
| Colour | Base monochrome uses `colour AND $7F`; with extended materials bit 7 has the function described below. Ordinary raw8bpp/MCM obtains colour from pixels or cache keys. |
| Pattern | In the base format, a **byte address** in the shared backing: `(high*256+low) AND $3FFF`. It is not a sprite number multiplied by 64 or512. |

Readback returns written bytes even when rendering ignores certain bits. Use only monochrome indices0..120: masked values121..127 convert to opaque black through the palette function, rather than to transparency. (`plus64_sprite.c`; `plus64_overlay.c`)

## Normal pattern formats

With `packedcache=0` and `leftmcm=0`, these two formats can be selected independently per slot through FD92. (`plus64_sprite.c`)

| Slot's FD92 bit | Visual size | Required data | Interpretation |
| --- | --- | --- | --- |
| 0 |24×21|63 bytes|Three bytes per row, bit 7 on the left;0 bit=transparent,1 bit=descriptor colour. No header.|
| 1 |24×21|504 bytes|One palette index per pixel,24 bytes per row,21 rows. No header or alignment requirement.|

Raw8bpp has24 independent pixels per row: the bit's MCM name **does not halve** resolution. A512-byte record is a useful convention, not a decoder requirement; its final eight bytes are not read as image data. A monochrome64-byte stride is also only a convention. (`plus64_sprite.c`)

Eight slots are eight instances, not a limit of eight stored images: slots may share a pointer, and software may change pointers to animate an object. (`plus64_sprite.c`)

Normal fetch wraps within the 16 KiB backing: an image near$3FFF reads subsequent bytes from the start. Plan allocations to avoid accidentally overlapping other patterns. Packed formats instead have the alignment checks described below. (`plus64_sprite.c`)

If backing contains0, those raw8bpp bytes mean opaque black; device reset does not guarantee that a shared view has been cleared. Enabling a raw sprite without initialising **all 504 bytes** can therefore produce a black rectangle. For a 16×16 image within a 24×21 slot, initialise the eight rightmost columns, five bottom rows and every transparent hole to$FF. (`plus64_sprite.c`)

### Byte example: three pixels and opaque black

Assume normal format, slot 0, no expansion, and exclusive access to the data port. This is a data recipe, not another program to assemble. First disable output with `$FD90=$00`. (`plus64_sprite.c`)

1. Set `$FD97=$00`, `$FD98=$00`; write `$FF` to `$FD96`504times.
2. Reset the pointer to$0000; write `$6F,$00` through the port: offsets0 and 1.
3. Set the pointer to$0018; write `$06`: the first pixel of row2, because the stride is24 bytes.
4. Write `$FD92=$01`, `$FD93=$00`, `$FD94=$00`, `$FD95=$00`.
5. Write the six descriptor bytes below, then `$FD90=$01` last.

```text
Addresses: FDA0 FDA1 FDA2 FDA3 FDA4 FDA5
Values:      A0   50   00   00   00   00
```

Expected output: bright blue at(160,80), **opaque** black at(161,80), and dark blue at(160,81). The slot's other501 pixels are transparent and preserve TED. Indices$6F=111 and$06=6 convert to TED colours$76 and$06 respectively. (`plus64_sprite.c`; `plus64_overlay.c`)

## Coordinates, borders and frequency

The origin is the upper-left corner of the logical320×200 area: X 0..319 and Y 0..199. Do not automatically add VIC-II sprite offsets from a C64 program. Normal-format X is0..511 and Y 0..255; portions outside the right or bottom edge are clipped. X 511 does not mean−1, and Y 255 does not mean−1. (`plus64_sprite.h`; `plus64_sprite.c`)

FD93 and FD94 repeat each pixel twice horizontally or vertically:24×21becomes48×21,24×42or48×42. Clipping applies to the expanded result. Normal raw format has no negative left/top coordinates; a game may retain a logical offscreen position and publish a cropped pattern at X 0, or wait until it enters the visible area. There is no additional negative-offset register. (`plus64_sprite.c`)

In PAL the emulator uses312 lines of 114TED clocks at 1773447clocks/second:35568clocks/frame, approximately49.86 Hz, usually called50 Hz. This is not 35568available6502 instruction cycles. (`plus4.h`; `ted-timing.h`; `ted-timing.c`)

With the PAL25-row geometry used here, overlay line Y 0 corresponds to TED counter4. FF1D contains the counter's low byte and FF1C its bit 8; FF1D=4 alone does not distinguish4 from260. Check FF1C bit 0 when synchronising publication. Do not add PAL canvas offset 59 to a descriptor coordinate. (`tedtypes.h`; `ted-mem.c`; `ted.c`)

TED's24-row mode, scrolling and border may alter content or the window visible below the overlay: they do not turn these descriptors into VIC-II registers. For a new video mode, verify the runtime's geometric reference before adapting an older projection formula. (`tedtypes.h`; `ted.c`; `plus64_overlay.c`)

## Publication and animation without partial images

Writes to descriptors, formats, expansion and pattern data update the model but do not by themselves form a display transaction. In the default profile without `-plus64rastercollisions`, the frame hook prepares the whole overlay once per frame. In the per-line profile, **every write to FD90** rebuilds the current overlay; the enable value need not change. (`plus64vice.c`)

Recommended sequence: initialise/upload data with output disabled; write format, expansion and descriptors; then write the enable mask to FD90 **last**. After publication, prepare the next state before its video deadline. Already-drawn lines are not changed retroactively. Writing0 to FD90 disables subsequent lines but does not clear the collision latch. (`plus64vice.c`; `plus64_sprite.c`)

The frame hook continues sampling registers in the per-line profile too. FD90 is not a hardware double bank of descriptors: partially prepared state crossing the end-of-frame sample may be observed by that hook. Schedule upload and staging, or keep output disabled throughout initialisation. (`plus64vice.c`)

Multiplexing reuses a slot in separate vertical bands: publish the current band, prepare subsequent descriptors while it is being rendered, then publish them after its last line. There are still eight slots on one line, not eighteen horizontally simultaneous sprites. Even with SEI, TED and scanning continue: measure the complete code, including input, collisions, HUD and audio, against the band deadline. (`plus64_sprite.c`; `plus64vice.c`; `ted.c`)

A static screenshot does not qualify multiplexing. Compare several framebuffer images during movement, firing and explosions; verify the pixels of every live object are present. Also check update intervals, distinguishing a shifted return line from a genuinely skipped frame. This is an SDK testing rule, not another device feature.

## Collisions: between sprites only

An opaque slot pixel overlapping another slot sets **both** participants' bits in FD91. Multiple overlaps accumulate every participant. Among normal visible masks, the lower-numbered slot has display priority, but others still participate in collisions; colour does not define a rectangular hitbox. (`plus64_sprite.c`)

For example, FD91=$05 means slots 0 and 2 have participated in collisions since the previous read. It does not identify the position, exact pair among multiple events, or impact direction. A CPU read returns the byte and clears the entire latch; a write does not clear it. An overlap that remains present can generate the same bits on subsequent lines or frames. (`plus64_sprite.c`; `plus64vice.c`)

The latch does not sample TED pixels or logical structures: there are no hardware collisions against floors, walls, bitmaps, characters or background colours. Software must implement those through its maps or geometry. FD95 does not add such a feature, and there is no VIC-II-equivalent sprite interrupt here. (`plus64_sprite.h`; `plus64_sprite.c`; `plus64vice.c`)

| Collision profile | Time and domain |
| --- | --- |
| Default: `rastercollisions=0`, `leftmcm=0` | Whole-overlay comparison during frame preparation; visible domain X 0..319,Y 0..199. |
| `rastercollisions=0`, `leftmcm=1` | Same frame preparation, additionally considering X−24..−1; domain X−24..319,Y 0..199. |
| `rastercollisions=1`, `leftmcm=0` | Preparation does not raise the latch; each completed line contributes its summary. Collisions also consider X 320..511 without drawing the border. |
| `rastercollisions=1`, `leftmcm=1` | Same timing with horizontal domain−24..511; display remains X 0..319. Y outside0..199 produces no collisions. |

See `plus64_sprite.c` and `plus64vice.c`. Change the per-line resource only with FD90=0; changing it discards the former alpha representation but retains the already-pending latch. (`plus64vice.c`)

When a slot is reassigned to another enemy, its bit still identifies the **slot**, not the game object's identity. Consume and attribute events within the correct band, or use software collisions between logical objects. Do not interpret a stale latched bit as an impact involving the new assignee. (`plus64_sprite.c`; `plus64vice.c`)

## Packed formats: advanced software reference

These options are implemented HOST resources, not new CPU registers. Do not substitute FD98 or reserved bits with supposed format selectors. (`plus64vice.c`)

| packedcache | leftmcm | Slot's FD92=0 | Slot's FD92=1 |
| --- | --- | --- | --- |
|0|0|Normal63-byte monochrome|Normal504-byte raw8bpp|
|1|0|Normal63-byte monochrome|Packed MCM|
|1|1|Packed HIRES|Packed MCM|
|0|1|Rejected by the setter|Rejected by the setter|

Selection is implemented in `plus64_sprite.c`; the leftmcm constraint is in `plus64vice.c`. Enabling packedcache **alone does not convert** monochrome patterns into packed HIRES.

Each packed record occupies a 1024-byte-aligned position in the 16 KiB backing: bases$0000,$0400,...,$3C00, up to 16 records. The complete pointer must equal its14-bit-masked value: alias$4000 is not accepted. The renderer skips invalid records without assigning another error register. (`plus64_sprite.c`)

| Offset from base | Data consumed by the decoder |
| --- | --- |
| `$200` | Byte63 of the inverse RAW64 block: not a pixel or register. Base rendering ignores it; extensions may select material, sparse orientation or an invisible mask. |
| `$201..$23F` | Original63 image bytes in reverse order: logical byte `i` is at `base+$23F-i`, for `i=0..62`. |
| `$240` | MCM: must be0. Packed HIRES: horizontal source shift0..23. |
| `$241` | Exact type:1=MCM,0=packed HIRES. Not freely combinable flags. |
| `$242` | Palette index for MCM pair `11`. |
| `$243` | Palette index for MCM pair `10`. |
| `$244` | Palette index for MCM pair `01`. |
| `$245` | Validity marker: must be **exactly$A5**. |

See `plus64_sprite.h` and `plus64_sprite.c`. Other record bytes are not read by these decoder branches; this does not automatically make them free when an engine uses the same area as cache or backup.

In the reused C64 engine, byte 63 also acts as an engine orientation tag. Engine orientation belongs to the caller; the bridge retains the byte in its key. Base format does not render it as image data, whereas the extensions below interpret specific tags. Do not transfer its bits into FD95 or type byte$241. (`engine/reuse/native_sprite_cpu.py`; `plus64_sprite.c`)

Packed MCM bytes hold four bit pairs, most significant first. Pair0 is transparent;1,2,3 select `$244,$243,$242`. Each pair occupies **two horizontal pixels** in 24×21. Key indices121..255 are also discarded;0 remains opaque black. Base-format descriptor colour does not replace these three keys; extended materials may replace or shade them without changing transparent pair0. (`plus64_sprite.c`)

Packed HIRES uses the inverse63-byte bits and descriptor colour. The decoder reads `source_x = pixel_x + record[$240]`, discarding beyond23. This shifts the logical source without wrapping lost right-hand bits; it does not change descriptor X position. (`plus64_sprite.c`)

### Negative projections in leftmcm

These rules do not apply to normal raw8bpp. With packedcache=1 and leftmcm=1:

- Packed MCM: raw X 488..511 becomes−24..−1 even without X expansion.
- Packed HIRES: the same X conversion applies **only with X expansion enabled**; unexpanded HIRES does not interpret488..511as negative.
- Both types: raw Y 215..255 becomes−41..−1. Values206..214 are outside this conversion and remain positive.

These are conditional projections of the existing publisher, not a general signed9-/8-bit mode. Positive coordinates, expansion and clipping continue after conversion. (`plus64_sprite.c`)

### Changing profile without incoherent caches

Write FD90=0before changing profile. Changing packedcache with output enabled is rejected; an accepted change invalidates the$245marker in all 16 records, **in either direction**. Changing a resource does not convert data: rebuild or reload patterns in the new format before enabling them. (`plus64_sprite.c`; `plus64vice.c`)

Enable leftmcm only after packedcache and with output disabled. Packedcache cannot be disabled while leftmcm or mixedsprites is active. Changing rastercollisions also requires output disabled. To return to normal format: disable output, remove mixedsprites, remove leftmcm, remove packedcache, load raw/mono patterns, set descriptors and publish FD90 last. (`plus64vice.c`)

## Current extended graphics formats

Enable these features explicitly through HOST resources before enabling sprites:

```text
-plus64packedcache -plus64leftmcm -plus64mixedsprites
```

Mixedsprites requires packedcache; leftmcm is needed for the packed HIRES path. Changing formats with output active is rejected. The extension adds no slots or banks. Sprite materials also work in native16 KiB mode; layers reading main RAM, described below, require mainram. The current decoder is `plus64_sprite.c`, `draw_masked_common`, with configuration and snapshots in `plus64vice.c`.

### Mixed RAW8 and material colour

With a slot's FD92 bit=1, a pattern pointer with bit 14=1 and bit 15=0selects mixed RAW8: its lower14 bits address504 bytes in the same backing. For example,$4800 means RAW8 at offset $0800. The entire image must fit inside the bank without wrapping. An untagged pointer retains packed MCM semantics. Expansion and collisions remain ordinary. With leftmcm active, mixed RAW8 also applies the publisher projections: raw X 488..511 becomes−24..−1 and raw Y 215..255 becomes−41..−1; these exceptions do not apply to normal RAW8 with packedcache disabled.

For a valid compact mask, bit 7 of the **descriptor colour** requests a material and the lower seven bits select colour 0..120. Packed MCM may also use **source byte 63** `$80 | colour`, tags$80..$F8. Mixed RAW8 bypasses these materials. Black0 remains opaque: the mask determines whether a pixel exists.

The selected colour is the maximum luminance, rather than hue alone. For `c>0`, hue=`1+(c-1) mod15` and maximum luminance=`(c-1) div15`. The radial profile computes `L=max(0,7-((x-lx)^2+(y-ly)^2) div40)`, then `L=L*maximum_luminance div7`, with integer division. Compact output is `15*L+hue`; `c=0` produces black. No second image is stored for shading.

### Eight directions, front and per-ink diagonal light

FD99 controls slots 0/1, FD9A slots 2/3, FD9B slots 4/5 and FD9C slots 6/7. The even slot uses the low nibble. For example, FD99=$30 gives east light to slot 1 while retaining slot 0's historical profile.

| Value | Light | Point in the 24×21 grid |
| --- | --- | --- |
|0|Historical upper-left|(6,5)|
|1|N|(12,0)|
|2|NE|(23,0)|
|3|E|(23,10)|
|4|SE|(23,20)|
|5|S|(12,20)|
|6|SW|(0,20)|
|7|W|(0,10)|
|8|NW|(0,0)|
|9|Front|(12,10)|
|10|Per-ink MCM diagonal|Uses the frame's opaque bounds.|
|11..15|Reserved|Historical-profile fallback.|

Directions are screen-relative; mirroring the source does not reverse the selected light point. Mode10 retains the three MCM inks and changes only luminance: it adds `2-floor(5*((x-xmin)*dy+(y-ymin)*dx)/(2*dx*dy))`, clamped to 0..7, with dx/dy at least 1. Bounds come from opaque pairs in the current mask. RAW8 and HIRES do not become MCM because selector 10 is chosen.

### Sparse masks with palette rectangles

Descriptor colour$F9 on a valid packed HIRES record selects sparse format. Do not confuse this with the packed-MCM source tag F9. The **source** representation has magic A7, byte 1=`S=3+4*N`, byte 2=base colour/material. Next are N four-byte rectangles: little-endian20-bit bounds `x0|(y0<<5)|(x1<<10)|(y1<<15)`, followed by colour/material. Bounds are inclusive and must fit24×21; later rectangles take precedence only on pixels already opaque.

At byte S, eight occupancy bytes identify nonzero bitmap bytes in reverse order62..0, high bit first; nonzero values follow in that order. Every read must fit bytes 0..62. Bit7 of byte 63horizontally mirrors the mask. Malformed records draw nothing. Decoding uses a temporary63-byte HOST mask, not additional guest RAM.

Inks0..120 are solid; bit 7 in a colour requests the material selected by its lower seven bits. With selector 9 and the sparse frontal profile, relief follows the ends of each row's opaque span instead of only the rectangle's centre. An ordinary bitmap without A7 magic but with F9 selector uses the cache's shared1 ink. Palette rectangles cannot introduce pixels or change their collisions.

### Invisible masks and priority

In packed MCM, source byte 63=F9 means **collision-only** from profile 15: the mask still participates in collisions but emits no pixels and claims no display priority. From profile 16, tag FA instead selects an **invisible occluding mask**: it retains the slot's original priority, hides later sprites at covered pixels, and leaves the underlying scene visible. It does not draw black or a transparency colour; all 63mask bytes and collisions are unchanged.

For these profiles, display alpha contains only visible sprites. Separate scanline summaries retain collisions from invisible masks too. Deferred callers must use the provided collision-summary path rather than deriving every collision from visual alpha. F9/FA remain ordinary tags in older profiles that do not declare their interpretation.

## Colour layers, scenery and native interfaces

In extended mainram mode, FD9D/FD9E point to descriptors in **existing main RAM**; FD9F bit 0enables them. The renderer walks at most32 nodes per pass. The next field is little-endian; zero terminates a list. Byte11selects node type, and the remaining layout depends on type: flags cannot be combined freely. Basic x,y,w,hcoordinates are in 8×8cells and must fit320×200.

| Type in byte 11 | Size | Function |
| --- | --- | --- |
|0|12 bytes|Diagonal rectangle shading with a background key.|
|1|20 bytes|The same light restricted to expected-character foreground and current bitmap/glyph data.|
|2|24 bytes|Scene/materials using shared luminance streams and a glyph selector.|
|3|12 bytes|Interface frames and keys from a compact grid.|
|4|12 bytes|Post-sprite window controlled by two RAM coordinates.|
|5|12 bytes|Tint through compact palettes.|
|6|12 bytes|Generic conditional link.|
|7|20 bytes|Conditional tint.|
|8|24 bytes|Type2scene with protection of native-interface characters.|

This is an index, not a replacement for chapter8's complete layouts. Nodes are software data, not new registers or a texture pool. Programs must reserve their bytes within their own budget and keep them valid for the entire fetch period.

In type0, bytes 6..9 are local pixel xmin,ymin,xmax,ymax; byte 10 is the compact background key. Nonblack TED pixels have their luminance adjusted by the diagonal formula, clamped0..7, preserving hue. Type1adds four LE16pointers: font, live characters, live attributes and expected rectangle characters. Only the matching glyph's foreground is modified; attribute bit 3selects MCM pairs, excluding pair0. A character replaced by an interface is not reinterpreted as the former object.

Type2adds two streams: background and material tile. Streams concatenate segments `[nextLE16,length8,payload]`; the image starts with LE16width/height, followed by bands `[repetitions,token_count,tokens...]`. Each token stores luminance in its three high bits and length minus1 in its five low bits. A software selector associates banks/glyph ranges with materials. This is not a separate RGB bitmap, and the renderer does not know specific game addresses or object classes.

Type8shares type2's 24-byte layout. Byte12 packs the required source bank in bits 0..2 and final native glyph in bits 3..7; byte 13 retains the high byte of the aligned font base. Byte22 packs text ink in the high nibble and fallback hue in the low nibble; byte 23 is the solid-border glyph. The control pointer in bytes 20/21selects bank `(RAM[control]>>1)&7`; the byte at control−3 is the standard logical view's sprite enable.

Native protection is active when bank/view match and **at least one byte in the entire configured glyph-font range is nonzero**. The first byte or first glyph may therefore be empty. A cell with matching ink and a glyph in range retains its original solid foreground/background; the border glyph is protected when adjacent, including diagonally, to a matching text cell. This includes sides and corners of a one-cell frame. A wrong bank or disabled source sprites cause the protected owner to suppress scene/object lighting; an active conditional owner may select another chain. These checks use program-selected data, not constants from a particular title.

Type4applies only with FD9F bit 3=1, after sprites. Bytes6/7and8/9point to the top and bottom limits in global pixel Ycoordinates; byte 10 is a **TED code 0..127**, not a compact sprite index. Where rectangle and `[top,bottom)` band intersect, the node replaces pixels with that code. During this window, type8UI protection is suspended so an opening/closing mask can remain above enhanced scenery while the source view changes temporarily. FD9F bit 1or bit 2instead requests black across the whole presentation area.

Actual per-line order is TED rendering, layer lighting, scene/materials, sprites, type4window, then black presentation masking. Text protection or background colour therefore does not erase an already-emitted sprite. FA masks may instead hide lower-priority sprites according to the preceding rules. Layers do not write source RAM or change collisions.

### Serialized version and current example

The PLUS64 container retains the size/backing of the RAM80 contract. Its HOST header uses byte 72 for mixed formats;73 for the full material palette;74 for sparse masks;75 for directions;76 for sparse frontal relief;77 for layer lighting;78 for per-ink diagonal light; and 79 for scene version, currently17. These are not 6502registers. Historical sections calling them reserved describe older profiles and must not be applied to current format. The reader validates combinations and CRC before restoring; an older executable may reject a newer format.

The supplied updated example `sdk-current/material-example.asm`, include and builder show all 121highlight colours and directions1,3,9 in native16 KiB mode. One new generic mask is uploaded into the bank2view; descriptors select its shading, without an image per colour. The PRG is921 bytes, entry$1100, code/data end$1398; it uses TED video below$3F40 and reserves one1 KiB bank2cache record. Its README explains building, launching and diagnostics.

Retained checks cover two identical builds,363 colour/direction cases of the C renderer, and 500program frames on each C16/Plus4host. These qualify the specific sample and identified software sources, not physical circuitry or every future program.

## Debugger and test limitations

A CPU read of FD91 clears the latch; a CPU read of FD96 increments its pointer. The diagnostic **peek** callback instead returns the latch or current byte without these side effects. A debugger view using peek does not prove that software consumed a collision; always compare access types. (`plus64_sprite.c`; `plus64vice.c`)

Monitor commands and any test-bench keyboard-injection helpers are HOST tools, not 6502instructions or cartridge registers. Do not turn observer sequences into a requirement for the program or production launcher; software must use ordinary input peripherals.

6502CPU tests, simulated peripherals, ordinary VICE runtime, observers, Wine and physical cartridges are distinct levels. For a game, retain at least executable/asset hashes, actual options, slot state, real moving images, and checks of the intended CPU latch reads. An image reconstructed directly from final descriptors cannot replace the framebuffer when qualifying multiplexing: direct drawing reads current state, whereas display applies publication at individual scanlines. (`plus64vice.c`)

# 4. SID and modem

The SID produces audio; the modem exposes a polled byte stream. Neither
provides a CIA or an NMI interrupt to the program. The addresses and clocks
below belong to the current RAM80 implementation, distributed with PE SHA256
`08d3e87f84140fe13014213beb32bf7635de12b715769d995efc0658bf08ddfa`
(6,617,154 bytes, with debug symbols removed without changing the loaded code
and data sections). The previous manual’s `SID_API.json` and `MODEM_API.json`
inventories remain historical evidence; the current source and the updated
statements in this chapter define current capacities and protocols.

## 4.1 Enabling a SID with reproducible settings

Enabling plus/64 activates VICE’s SIDcart if it is not already active, without
overwriting a SIDcart configured by the user. A launcher must therefore
specify its address, model and clock after `-default` and the machine-model
selection. For the audio profile used by the distributed games:

```text
-sound -sidenginemodel 256 -sidcartaddress 0xFD40 -sidcartclock 0
```

`256` selects reSID/MOS6581; `257` selects reSID/MOS8580. These are not registers
that a game can change by writing a byte. The two models differ in analogue
behaviour, filters and digital-sample behaviour: choose one and test the game
with that model. [SID-1, SID-2]

### The actual window ends at `$FD5D`

The VICE device registers **`$FD40..$FD5D`**, with internal mask `$1F` and
`IO_MIRROR_NONE`. This SIDcart does not decode `$FD5E` or `$FD5F` as SID
registers. Do not use those addresses as mirrors or new registers. The
conventional description “32 SID registers” does not extend the actual
registered window. An alternative configuration exists at `$FE80..$FE9D`,
but it is not the plus/64 profile used here. [SID-1]

## 4.2 SID register map

The three voices share the same seven-register layout. `b` is the voice base:
`$FD40`, `$FD47` or `$FD4E`. The offsets below are relative to that base, not
to the C64’s `$D400`. [SID-3]

| Register | Voice 1 | Voice 2 | Voice 3 | Bits and use |
|---|---|---|---|---|
| `b+0` | `$FD40` | `$FD47` | `$FD4E` | Frequency, low byte |
| `b+1` | `$FD41` | `$FD48` | `$FD4F` | Frequency, high byte |
| `b+2` | `$FD42` | `$FD49` | `$FD50` | Pulse width, bits 0–7 |
| `b+3` | `$FD43` | `$FD4A` | `$FD51` | Pulse width, bits 8–11 in bits 0–3; other bits do not change the width |
| `b+4` | `$FD44` | `$FD4B` | `$FD52` | Waveform and gate control |
| `b+5` | `$FD45` | `$FD4C` | `$FD53` | Attack in bits 7–4, decay in bits 3–0 |
| `b+6` | `$FD46` | `$FD4D` | `$FD54` | Sustain in bits 7–4, release in bits 3–0 |

The control register uses these bits:

| Bit | Mask | Function |
|---:|---:|---|
| 0 | `$01` | GATE: a 0→1 edge starts attack; a 1→0 edge starts release |
| 1 | `$02` | Oscillator SYNC to the source voice |
| 2 | `$04` | Ring modulation for the triangle component |
| 3 | `$08` | TEST: oscillator control/reset, not a general ADSR reset |
| 4 | `$10` | Triangle |
| 5 | `$20` | Sawtooth |
| 6 | `$40` | Pulse, with 12-bit width |
| 7 | `$80` | Noise |

Selecting several waveforms produces the SID’s combined waveforms, not an
arbitrary sum of generators. SYNC and ring modulation use the circular voice
connection; they require deliberate configuration of the source voice too.
For a new note, genuinely leave GATE low before the rising edge: rewriting
`$11` while GATE is already one does not start a new attack. Do not expect
TEST to clear the envelope counter. [SID-3]

### ADSR

Each A/D/S/R parameter is a nibble from 0 to 15. Sustain selects a level of
`nibble × $11`, from `$00` to `$FF`; it is not a duration. Attack, decay and
release select envelope rates. The reSID code preserves these rate-counter
comparison values:

| Nibble | reSID comparison value | Nominal attack stated in model comments |
|---:|---:|---:|
| 0 | 8 | 2 ms |
| 1 | 31 | 8 ms |
| 2 | 62 | 16 ms |
| 3 | 94 | 24 ms |
| 4 | 148 | 38 ms |
| 5 | 219 | 56 ms |
| 6 | 266 | 68 ms |
| 7 | 312 | 80 ms |
| 8 | 391 | 100 ms |
| 9 | 976 | 250 ms |
| A | 1953 | 500 ms |
| B | 3125 | 800 ms |
| C | 3906 | 1 s |
| D | 11719 | 3 s |
| E | 19531 | 5 s |
| F | 31250 | 8 s |

These times are nominal, not exact millisecond deadlines: they depend on the
clock and the counter’s state. Decay and release also use piecewise
exponential divisions, so do not use the attack column as their duration.
An ADSR change during a note can encounter the rate counter’s behaviour,
including the known ADSR delay. [SID-4]

### Filter, volume and reads

| Address | Use |
|---|---|
| `$FD55` | Low cutoff: bits 0–2 only |
| `$FD56` | High cutoff: eight bits; `cutoff = (high << 3) | (low & 7)` |
| `$FD57` | Resonance in bits 7–4; voice 1/2/3 and external-input routing into the filter in bits 0/1/2/3 |
| `$FD58` | Volume in bits 3–0; low-pass bit 4, band-pass bit 5, high-pass bit 6; bit 7 excludes voice 3 from the direct path |
| `$FD59` | POTX read, dependent on emulated inputs/configuration |
| `$FD5A` | POTY read, under the same constraint |
| `$FD5B` | Voice-3 oscillator output read |
| `$FD5C` | Voice-3 envelope read |
| `$FD5D` | SID offset `$1D`, without a defined synthesis function |
| `$FD5E/$FD5F` | Outside the registered SIDcart window |

The 11-bit cutoff is not a universal linear conversion to hertz: the filter
and chip model matter. The external-input bit does not demonstrate that an
analogue input path has already been built in a physical cartridge. Zero
volume silences the output without necessarily stopping oscillators or the
music sequence. [SID-3, SID-5]

Synthesis registers are **writable, not ordinary readable RAM cells**. A CPU
read from a write-only register returns the emulated SID bus behaviour, not
a reliable copy of its programmed value. Keep a RAM shadow of your values;
use `STA`, not `INC/ASL`, on SID registers. The emulator also models the
additional writes of read-modify-write instructions.

Debugger peek is different: `sid_peek_chip()` returns the `siddata` array of
last writes and does not actually sample OSC3/ENV3. With sound disabled, CPU
reads have a software fallback: do not use them to demonstrate an active
oscillator or as a random source independent of audio configuration. [SID-6]

## 4.3 Clocks: C64, TED and the “native” setting

For a periodic waveform, with 16-bit frequency value `N`:

```text
note_frequency = N × SID_clock_frequency / 2^24
N = round(note_frequency × 2^24 / SID_clock_frequency)
```

With `-sidcartclock 0`, the runtime initializes the PAL SID at **985,248 Hz**
(NTSC: 1,022,730 Hz). The bridge converts VICE’s base clocks into the SID
domain using a rational ratio and a retained remainder, even when only part
of the audio buffer is consumed. This does not make C64 and TED CPU-code
timing identical. [SID-1, SID-7]

**Pay attention to the meaning of `-sidcartclock 1` in this build:** the code
passes the machine’s `cycles_per_sec` value to the SID, which is
**1,773,447 Hz** in PAL. The option’s “PLUS4/native clock” name does not mean
886 kHz here. That is instead `1,773,447 / 2 = 886,723.5 Hz`, the TED timer
tick rate and one possible slow physical-clock choice; it is not the value
passed to the SID by option 1 of the preserved runtime. Do not copy 886 kHz
note tables into that profile. [SID-1, SID-7]

For example, A4 at approximately 440 Hz in the C64 PAL profile uses
`N=7493=$1D45`, with a calculated actual frequency of about **440.029 Hz**.
The low byte is `$45`, the high byte `$1D`. At initialization of a program
that owns the SID, a triangle note on the first voice can be set up as follows:

```asm
        lda #0
        sta $fd44       ; GATE low, no selected waveform
        sta $fd57       ; no filter routing in this example
        lda #$09
        sta $fd45       ; attack 0, decay 9
        lda #$f4
        sta $fd46       ; sustain F, release 4
        lda #$45
        sta $fd40
        lda #$1d
        sta $fd41
        lda #$0f
        sta $fd58       ; maximum volume, direct paths
        lda #$11
        sta $fd44       ; triangle + rising GATE edge
        rts
; Release the note in a later tick:
rilascio:
        lda #$10
        sta $fd44       ; same waveform, GATE low
        rts
```

The other two voices must be initialized or managed by your own driver.
The sample does not allocate a timer or impose a duration: the game tick
must decide when to call `rilascio`. If a music IRQ writes to the same SID,
coordinate writes with that driver.

VICE’s audio-buffer size, for example `-soundbufsize 64`, changes host latency,
not the note formula or IRQ frequency. A C64 conversion that used CIA/NMI
must adapt its scheduler separately: the SID does not generate those
interrupts.

## 4.4 Modem registers and state

The modem is available at `$FDF0..$FDF7` when plus/64 is enabled. It exposes a
**128-byte RX FIFO**, a **128-byte TX FIFO**, and a **256-byte command buffer**:
**512 bytes in total**, all included in the **80 KiB = 64 KiB cartridge plus
16 KiB internal RAM**. It is not an ACIA and contains no CIA registers.
The current backend uses the host computer’s TCP sockets. [MOD-1]

The FIFOs are not private modem memory. In the native profile they alias
cartridge bank 3, offsets `$3E00..$3FFF`; in MainRAM they alias the internal
16 KiB at offsets `$0000..$01FF`, also accessible through the sprite port.
The program must reserve the region before using the modem and avoid
concurrent writes from sprites, audio or other owners. While the modem is
disconnected, with no call, queues or partial command pending, a program
that performs no modem I/O may lend the region to other resources. It must
return it before starting commands or connections.

| Address | CPU read | CPU write |
|---|---|---|
| `$FDF0` DATA | Removes one RX byte; returns zero if empty | Feeds the parser in command mode; queues one TX byte when connected |
| `$FDF1` STATUS | Status bits in the next table | Ignored |
| `$FDF2` CONTROL | Always zero | Bit 0 reset; otherwise bit 1 disconnect; bit 2 clears overrun |
| `$FDF3` BAUD | Always `$04`, descriptive “9600” value | Ignored: it does not regulate a real serial port |
| `$FDF4` RX COUNT | Queued RX bytes, 0–128 | Ignored |
| `$FDF5` TX COUNT | Queued TX bytes, 0–128; not free space | Ignored |
| `$FDF6` | Signature `$64` | Ignored |
| `$FDF7` | Shared-protocol version `$03` | Ignored |

| STATUS bit | Mask | Meaning when set |
|---:|---:|---|
| 0 | `$01` | RX contains at least one byte |
| 1 | `$02` | TX has room for at least one byte, even while disconnected |
| 2 | `$04` | Connected |
| 3 | `$08` | Connection in progress |
| 4 | `$10` | Latched overrun: a local write or response exceeded available space |
| 5 | `$20` | Neither connected nor dialing; offline state, not a latched event |
| 6–7 | `$C0` | Zero in the current version |

An RX zero byte is valid data. Test STATUS bit 0 before reading DATA, without
interpreting zero as “FIFO empty”. Reading STATUS clears no flag. A device
peek at DATA shows the next byte without consuming it; an ordinary BASIC
`PEEK` is a CPU read and consumes it. Counts describe bytes actually queued
in the 128-byte buffers; the previous private capacity of 8 KiB per queue
no longer exists. [MOD-1]

CONTROL is a set of actions, not stored state: `$01` resets; `$02` interrupts
the link and puts `OK` in RX; `$04` clears only overrun. If both bits 0 and 1
are present, reset takes precedence; bit 2 is still processed afterwards.
There is no IRQ enable. Disconnect clears TX but preserves RX; reset empties
both FIFOs and the partial command, clears overrun, disconnects, and restores
echo-off. Reset changes indices and device state: **it does not zero the
shared RAM bank**. [MOD-1]

## 4.5 AT commands actually implemented

Send **ASCII** bytes, ending the command with CR (`$0D`). LF is ignored.
The parser is case-insensitive for commands but preserves the host name.
Responses take the form `CR LF text CR LF`. No network connection is needed
to test `AT`. [MOD-2]

| Command | Result |
|---|---|
| `AT` | `OK` |
| `ATE0` / `ATE1` | Disables/enables local byte echo in command mode; `OK` |
| `ATZ` | Modem reset and `OK` |
| `ATH` | Disconnect and `OK` when the parser is in command mode |
| `ATDhost` / `ATDThost` | Attempts TCP connection to port 23 |
| `ATDhost:port` / `ATDThost:port` | Decimal port 1–65535; nonempty host, at most 219 bytes |

Immediate connection or completion at the next poll produces `CONNECT 9600`.
Failure or link loss produces `NO CARRIER`. Unsupported commands or invalid
syntax produce `ERROR`. Do not assume `ATH0`, `+++` escape, S registers,
numeric response mode or concatenated command sequences: they are not
implemented.

The command buffer holds at most 255 printable characters; one more
character causes `ERROR`, clears the length, and is discarded. Backspace
(`$08`) and DEL (`$7F`) remove one character when present. With echo enabled,
control characters are queued too, before processing.

**When connected, every byte written to DATA is outgoing traffic.** The
string `ATH` is not interpreted locally, and `+++` does not change modes.
To close a connection from the program, use CONTROL bit 1. The parser stays
active while dialing: the program can cancel using CONTROL or `ATH`.

## 4.6 Polling, Telnet and backend limits

`machine_vsync_hook()` calls `plus64vice_frame()`, which polls the modem once
per video update. Reading STATUS does not force a poll. The poll advances
a pending connection, sends a contiguous portion of TX, and receives only
into the free contiguous span of the RX queue: at most 128 bytes, often less
because of occupancy or ring wrapping. A full RX queue prevents a socket
read and therefore applies backpressure to the transport. The “9600” speed
is descriptive: UART baud rate, serial bits, RTS/CTS and electrical timing
are not simulated. Provide game timeouts, frequent RX draining and overrun
checks. [MOD-3]

Input always passes through minimal Telnet handling:

- `IAC IAC` (`$FF $FF`) delivers one `$FF` byte to the game.
- `WILL` and `DO` are refused with `DONT` and `WONT`; `WONT/DONT` are consumed.
- Subnegotiations are discarded up to `IAC SE`.
- Ordinary data become RX bytes: there is no ASCII/PETSCII conversion.

This is not completely transparent binary TCP transport. Outgoing code queues
application bytes without automatically doubling `$FF`; a protocol with a
Telnet peer must handle that escape deliberately. The modem contains no
TLS, service authentication or HTTP protocol.

The socket is nonblocking, but name resolution through `getaddrinfo()` is
synchronous: an ATD command with a problematic name can temporarily stop
the emulator UI. For reproducible tests, use a local test service and a
timeout; do not interpret a DNS pause as a game timer. [MOD-4]

### Two nonblocking primitives

The caller retains a byte to send and retries on a later tick when TX is
full. A single component of the game must own the modem.

```asm
; A contains the byte on entry. Carry clear if accepted, set to retry.
modem_prova_tx:
        pha
        lda $fdf1
        and #$02
        beq tx_piena
        pla
        sta $fdf0
        clc
        rts
tx_piena:
        pla
        sec
        rts

; Carry set if A contains valid data, including $00; clear if empty.
modem_prova_rx:
        lda $fdf1
        and #$01
        beq rx_vuota
        lda $fdf0
        sec
        rts
rx_vuota:
        clc
        rts
```

In command mode, “accepted” means passed to the parser, not sent over TCP.
In data mode it means queued: it does not confirm receipt by the peer.
After a group of sends, also check overrun, connection state and responses.
For a local parser test, send `$41 $54 $0D` and collect the response without
an infinite wait loop.

## 4.7 What the model proves and what remains hardware work

Current VSF checkpoints preserve local state, indices and all shared RAM80
bytes. Saving and loading are refused while the modem is connected or
dialing because the external TCP peer cannot be rewound. Loading does not
automatically reconnect that peer.

The model documents registers, shared FIFOs and host socket APIs. It contains
no cartridge MCU firmware, electrical serial modem, measured SID clock,
analogue power circuitry or additional interrupt circuit. A physical
cartridge must satisfy the same visible behaviour; those implementations
and their memory budget require their own design and tests. This source
audit does not perform remote connections, a new Windows listening test,
or physical qualification.

## Chapter references

The following paths are relative to `reference/vice/` in the manual package
and identify current source. Historical inventories and version-1.0 tests
do not replace the distribution’s RAM80 and format-17 reports.

- **SID-1:** `src/plus4/cart/plus4-sidcart.c`, SIDcart I/O decoder,
  `sidcart_sound_machine_init`, enable and clock resources;
  `src/plus4/plus64vice.c`, plus/64 integration and configuration.
- **SID-2:** `src/sid/sid-cmdline-options.c`, SID engine/model selection.
- **SID-3:** `src/resid/sid.cc`, register reads and writes;
  `src/resid/wave.cc`, `wave.h` and `voice.cc`, waveform control,
  synchronization and ring modulation.
- **SID-4:** `src/resid/envelope.cc`, ADSR counters, tables and writes.
- **SID-5:** `src/resid/filter.cc`, cutoff, resonance and mode registers.
- **SID-6:** `src/sid/sid.c` and `src/resid/sid.cc`, read/peek paths,
  bus values and `siddata`.
- **SID-7:** `src/plus4/cart/plus64_sid_clock_ratio.h`, rational ratio;
  `src/plus4/plus4.h`, `plus4.c`, `src/sound.c`, `src/sid/sid.c` and
  `src/sid/resid.cc`, audio clock constants and bridge.
- **MOD-1:** `src/plus4/plus64_modem.h`, `P64_RX_CAP`, `P64_TX_CAP`,
  `P64_CMD_CAP`, shared-storage views and API; `plus64_modem.c`,
  `p64_modem_init/reset`, `status`, `p64_modem_peek/read/store`.
- **MOD-2:** `src/plus4/plus64_modem.c`, `command` and
  `stream_from_device` functions.
- **MOD-3:** `src/plus4/plus64_modem.c`, `telnet_in` and `p64_modem_poll`;
  `plus64vice.c`, call to `p64_modem_poll` in the video path.
- **MOD-4:** `src/plus4/plus64_net.c`, `net_open`, `net_state`, `net_send`
  and `net_recv`.

# 5. Building a game for the platform

## A reproducible initial map

The native example uses a multicolour TED bitmap within the first 16 KiB.
The following layout is a software choice made by the examples, not new
cartridge address decoding:

| CPU area | Suggested use in the example |
| --- | --- |
| `$0000–$00FF` | Zero page: CPU ports and variables; explicitly reserve those belonging to the game |
| `$0100–$01FF` | 6502 stack; do not put sprites or tables here without checking depth |
| `$0200–$0FFF` | System area and workspace: do not consider it free while using the KERNAL |
| `$1001…` | PRG with BASIC stub and example program, ending before `$1800` |
| `$1800–$1BFF` | TED luminance attributes, 1,024 bytes |
| `$1C00–$1FFF` | TED chrominance attributes, 1,024 bytes |
| `$2000–$3F3F` | Bitmap, 8,000 bytes |
| `$3F40–$3FFF` | Remaining 192 bytes: usable only if not already reserved by the program |

Other games may choose a different layout. The program must check that code,
stack, loader, buffers and video do not overwrite one another. In the native
plus/64 profile the runtime enforces **16 KiB CPU/TED RAM on both C16 and
Plus/4**: additional internal Plus/4 RAM cannot be used implicitly. A high
address may alias lower RAM or an I/O/ROM window rather than free storage.
MainRAM is a distinct profile: it exposes the cartridge’s 64 KiB to CPU/TED
and leaves the internal 16 KiB as the sprite view. In both cases the total
remains **81,920 bytes**, with the aliases described in the memory chapter.

A PRG starts with two bytes containing its load address in low/high order.
A native PRG loaded at `$1001` cannot extend beyond `$3FFF` by assuming extra
internal RAM. Larger resources require a loading strategy into the SRAM
already available, not writes outside the verified native address space.

## Initialization sequence

1. Decide which system services to use and which variables the game owns.
2. Check `$FDEC=$64` and `$FDED=$05` before depending on RAM80 aliases.
   If using the modem, also check `$FDF6=$64`, `$FDF7=$03` and reserve its
   512 shared bytes.
3. Disable sprites while initially loading patterns.
4. Prepare the TED bitmap and attributes.
5. Set the upload pointer and load patterns into the sprite view.
6. Initialize only the required SID registers, with known volume and gate.
7. Write complete descriptors; publish the mask through FD90 last.
8. Start the loop with an explicit video rhythm.

Undocumented or reserved registers must not be used as new features. A value
that reads back correctly does not prove that the renderer or a circuit uses it.

## The main loop

A typical organization is:

```text
wait for the next frame
read input and calculate new button edges
update physics and rules once
resolve collisions and their consequences
prepare descriptors and animation advancement
update the required audio and HUD state
publish FD90
repeat
```

If the loop misses its raster appointment, the game may become slow or lose
parts of sprites. Measure the program during shots, explosions, score
redrawing and loading, not only while the main character is standing still.

The emulator may use Warp during autostart loading. This is a host feature,
not a cartridge clock or a method of game synchronization. Do not use it to
compensate for slow routines.

## TED video and coordinates

The active rectangle is 320×200 physical pixels. In a multicolour TED bitmap,
each bit pair represents two horizontal pixels: artwork therefore has 160
horizontal samples, while sprite coordinates remain 320 pixels wide. The
SDK’s 16×16 sprite is 16 physical pixels wide, not 32.

For TED cell `(cx,cy)`, with 40 columns and 25 rows, and internal row `dy`:

```text
cell = cy * 40 + cx
attributes: $1800 + cell and $1C00 + cell
bitmap byte: $2000 + cell * 8 + dy
```

The four multicolour pixel values have the following meanings:

| Pair | TED colour |
| --- | --- |
| `00` | Global background colour FF15 |
| `01` | Hue from the high chrominance nibble, luminance from bits 0–2 of the other attribute |
| `10` | Hue from the low chrominance nibble, luminance from bits 4–6 of the other attribute |
| `11` | Global colour FF16 |

To use 121 different colours in the same bitmap, choose different attributes
in different cells; the number of colours available in an individual cell
is not increased. Sprite palettes instead use the indexed plus/64 format
described in the video chapter.

## Input, operating system and interrupts

The SDK demonstrates the path actually verified for the keyboard and joystick 2.
Do not copy C64 CIA polling: the C16/Plus/4 uses other registers and a different
TED connection. The absence of a physical joystick on the host does not
prevent use of the keyset configured in VICE.

`SEI` disables IRQ, not NMI. A game that disables IRQs must manage input,
timers and audio progression itself: do not assume the KERNAL clock is still
running automatically. The documented cartridge provides no new NMI
equivalent to the C64’s CIA2.

KERNAL routines require their own variables and entry conditions. Do not call
LOAD, SAVE or system printing after overwriting that workspace without a
verified save/restore protocol. The initial example keeps its essential
resources in the program and uses normal D64 loading before entering its
autonomous loop.

## Collisions: drawing and rules are separate

FD91 reports overlaps between device sprites. It does not detect TED platforms
or walls, apply penalties, or decide game rules. A software policy is needed:
rectangles, masks, a collision map, or combinations of these.

With 16×16 artwork placed in a 24×21 record, the eight pixels on the right
and five rows below are transparent. Its visible rectangle can be 16×16;
it need not become 24×21 simply because the record has that size. For
pixel-perfect collision, read your own masks: a simple rectangle also
includes any holes within the silhouette.

The hardware latch uses the numbers of the eight slots. When multiplexing
several characters onto the same slots, a slot is not a character identity.
The software must know the raster band and test instant, or use software
collision detection.

## Resources and levels

The register-addressed SRAM is useful for storing rooms, bitmaps, tables and
compressed data. The CPU does not execute instructions through `$FDEA`. In
the native profile, executing a routine stored in the cartridge requires
copying it into an executable CPU area and checking its relocations. In
MainRAM, the cartridge is already exposed in CPU address space: code can run
at the corresponding CPU address, subject to ROM and I/O visibility, without
going through the data port.

The SRAM and sprite ports are **aliasing views**, not two additional pools.
In the native profile, the sprite port addresses cartridge bank 2: a write to
that bank through `$FDEA` also changes data visible to the sprite decoder.
In MainRAM, the SRAM port accesses the same 64 KiB exposed to the CPU, while
`$FD96` accesses the internal 16 KiB. A resource manager must therefore
record the owner of each range and coordinate loading, code, patterns, modem
and audio. Do not add the aliases as separate available memory.

FDEA autoincrement wraps at the bank boundary; it does not select the next
bank automatically. Separate resource blocks and descriptors so the loader
handles crossing `$3FFF` explicitly.

## Publishing a game

Distribute a PRG or D64, the required runtime profile, control instructions
and the build hash. State whether RAW, packed, raster updates, MainRAM or
extended formats are required. MainRAM is now a profile of the common RAM80
contract, not a way to add a second 64 KiB CPU block.

Use a working copy for writable files. For example, the Impossible Mission
port writes its high-score table into its D64; automatically replacing that
disk with a new image would lose those data. A record kept only in RAM lasts
until reset.

## Resource budgets and loading by phase

For each resource, record starting address, length, profile, aliases and the
phase during which it is live. The physical total is 65,536 + 16,384 bytes,
not 64 KiB plus a 16 KiB sprite cache plus further audio or modem RAM.
Compression reduces source data and transfers; a temporary decoder does not
authorize a second resident bitmap outside the budget. The same range may
be reused for loading, graphics or audio only after its previous owner is
finished and before those data are needed again.

Material descriptors, palette regions and luminance streams in the current
formats belong in that same map. In the software model the compositor reads
them from emulated RAM; the access path and cost of a physical implementation
require an explicit design, as explained in the video chapter.

## Checkpoints and disk data

The current runtime supports complete RAM80 VSF snapshots: they store all
81,920 bytes and local device state, including aliases, registers and the
video state required for continuation. The Plus/4 VSF 2.1 container, PLUS64
1.0 module, SRAM protocol `$05` and video revision 17 are separate version
numbers. A VSF can exceed 80 KiB because it also includes CPU, drives,
peripherals and serialized emulator structures; this is not extra memory
available to the game.

Incomplete older checkpoints cannot recover bytes that were never saved and
are refused when they must describe complete plus/64 state. For a
self-contained checkpoint, include disk images in the save options;
otherwise preserve the associated D64 files too. A game’s original SAVE
remains separate: in Impossible Mission it records the high-score table
and does not replace a VSF checkpoint. The modem must be disconnected and
have no pending call before saving or loading.

# 6. Debugging, tools and reuse of C64 code

## Keep the kinds of evidence separate

| Test | What it demonstrates |
| --- | --- |
| Python calculation | Data formats, addresses and transformations in the analysis program |
| 6502 simulation with peripheral stubs | Instruction execution and the contract of the stubs used |
| Actual C device modules | Register and renderer behaviour in the compiled functions |
| Native VICE | Interaction between guest CPU, TED and the model’s devices |
| Windows PE under Wine | Behaviour of that executable and the simulated host APIs |
| Native Windows | Execution on a real Windows system |
| Physical cartridge | Electrical and temporal behaviour measured on hardware |

A “PASS” line is meaningful only together with its version, inputs and scope.
A test using a prepared final state tests the ending; it does not demonstrate
a whole campaign won naturally. The SDK manifest lists tests actually run,
without promoting them to physical certification.

## A practical check for every new build

- Check that code and data remain within the common machine’s
  **65,536 + 16,384 bytes**, without double-counting aliases, caches,
  compressed sources and decoded buffers reused in different phases.
- Test first boot, reset and return to the title.
- Test boundaries: X255/256, X319, Y199 and data spanning an SRAM bank.
- Test an opaque sprite pixel 0 and transparent pixel 255 on the same background.
- Read the latch once, then check that it clears and records new events.
- Measure the rhythm during HUD updates, shots, collisions and scene changes.
- Check muting, note release and SID frequencies with the selected clock.
- Preserve the previous version and hashes of the executable and D64.

Do not automatically widen tolerances because a test fails: first distinguish
a program problem from observation or host configuration. For example,
missing audio output in a Wine test without an audio device does not prove
an error in SID registers.

## Monitor and captures

Use breakpoints at known functions, RAM captures and images of the VICE
canvas. For side-effecting registers, distinguish `read` from `peek`; the
monitor may deliberately avoid consuming FIFOs or latches. A CPU-read test
must execute a guest `LDA`.

Compare images with state from the same phase of the frame. If a sprite
changes descriptor halfway down the screen, a later RAM read does not by
itself reconstruct what has already been drawn in the upper lines. For
multiplexing, record the raster band, slot, pointer and published mask.

The diagnostic `@k` input used by some project tools must be interpreted
according to that tool’s contract or observer build: it is not a plus/64
register available to the program and must not be assumed to be a portable
command in a Windows distribution. Games read the emulated keyboard or
joystick, as in the SDK example.

## Why a C64 port is not a global address replacement

Data representing an address may occur as operands, pointer tables,
generated code or calculated values. A number equal to `$D400` inside a
bitmap is not thereby a SID write. Code may also depend on VIC-II, CIA,
ROMs, vectors or timing absent from the C16/Plus/4.

A useful procedure is:

1. Identify the input by hash and reconstruct its actual loading.
2. Disassemble from known entry points and follow control flow.
3. Mark indirect jumps and unresolved parts without guessing.
4. Separate hardware-independent logic from device accesses.
5. Define replacements for explicit sites and profiles, checking operands.
6. Preserve game behaviour and compare observable sequences.

The distributed toolkit includes `translate_core.py` for D64 inventory,
extraction and analysis, 6502 libraries and builders for known profiles.
The documented decoder covers the 151 official NMOS6502 opcodes; that is not
a promise that every game or undocumented opcode can be converted
automatically.

Patches for a known dump do not apply to a different copy simply because it
has the same name. The output of RAM analysis is not automatically a
bootable D64: loading, services, input, graphics, audio and game state must
be integrated and tested.

## A first learning path

Start with the SDK example; add a second sprite and a collision, then an
animation table in SRAM. Only then add loading, scrolling or multiplexing.
The manual and example describe current APIs; addresses or drivers of a
future physical implementation must be documented separately when they
are defined and verified.

## Snapshots, restoration and versions to check

A checkpoint test must compare all RAM80, not only the visible CPU window:
65,536 main bytes plus 16,384 internal bytes. First check immediate restore,
then continuation with the same inputs, preferably also in a fresh process
and on the other C16/Plus/4 model. Record the VSF container revision,
PLUS64 module, memory configuration and video features; a successful read
alone does not prove that the same profile was restored.

The current runtime uses Plus/4 VSF container 2.1 and PLUS64 module 1.0, with
SRAM protocol `$05`, modem `$03` and scenery revision 17. Legacy checkpoints
missing required RAM80 bytes are refused. A connected or dialing modem
prevents saving and loading: the test must not promise to rewind a remote
peer. For SID, distinguish digital state and register writes from identity
of analogue PCM or host resampling history.

## Final distribution identity

The final Windows executable without debug symbols is **6,617,154 bytes**
and has SHA256:

```text
08d3e87f84140fe13014213beb32bf7635de12b715769d995efc0658bf08ddfa
```

Removing debug symbols does not change the loaded code and data sections;
the distribution report preserves that comparison and provenance from the
complete build. The Impossible Mission REV8R D64 retains the code and data
of its qualified revision. Trials with pieces or a password already ready
are separate test states, not the normal game and not a natural win that
can certify the whole mission.

Linux C16/Plus/4 tests and Windows-executable tests through Wine remain
distinct from native Windows and physical hardware. Comparing RAM bytes
and registers does not itself qualify future bus arbitration, CPU/video
contention, compositor bandwidth or synchronization in a real cartridge.

# 7. Quick reference

A reminder for the documented runtime, PE `08d3e87f…` (6,617,154 bytes,
debug sections removed). Details, exceptions and source hashes are in
chapters 2–4 and the API JSON inventories. These tables describe available
software, not a certified physical cartridge. `R` = CPU read, `W` = CPU write.

## Profiles and general map

| Profile | Program contract |
|---|---|
| New native game | CPU/TED use the **internal 16 KiB**, enforced on Plus/4 too; **64 KiB cartridge RAM** through the port; sprite view is cartridge bank 2 |
| `-plus64mainram` | CPU, TED and SRAM port share **64 KiB cartridge RAM**; sprite port sees the separate **internal 16 KiB** |
| Current budget | **65,536 + 16,384 = 81,920 bytes**; no additional sprite/FIFO RAM |

In the native profile ordinary RAM addresses are masked with `$3FFF`;
upper quarters are aliases, including on a Plus/4 configured to 16 KiB by
plus/64. The sprite port and modem share the budget: reserve their bytes.
Changing profile requires disabled sprites, an idle modem and empty queues
and command buffer. These are runtime resources, not new guest registers.
**See chapter 2.**

| Range | Device or area |
|---|---|
| `$FD40..$FD5D` | SIDcart at its standard address; `$FD5E/$FD5F` are not SID |
| `$FD90..$FDCF` | Sprites, data port and eight descriptors |
| `$FDE8..$FDED` | SRAM port: bank, offset, data and signature |
| `$FDF0..$FDF7` | Polled modem |
| `$FF00..$FF1F` | TED: native timers, video, input and IRQs |
| `$FF3E/$FF3F` | ROM-enabled / underlying-RAM strobes; written value irrelevant |

`$FDxx/$FExx` remain I/O with ROM disabled. BASIC normally occupies
`$8000..$BFFF`; KERNAL/high ROM occupies `$C000..$FFFF`, with I/O exceptions.
Zero page, stack and vectors remain the program's responsibility. Do not
use `$0001` as a C64-style banking selector.

## SRAM: six registers and same-bank wrapping

| Register | R | W |
|---|---|---|
| `$FDE8` | Offset low | Set low, preserve high |
| `$FDE9` | Offset high, bits 6–7 zero | Set high using `value & $3F` |
| `$FDEA` | Data, then increment | Write data, then increment |
| `$FDEB` | Bank 0–3 | `value & 3`; preserve offset |
| `$FDEC` | `$64` | Ignored |
| `$FDED` | `$05` | Ignored |

`index = (bank << 14) | offset`. After DATA: `offset = (offset+1) & $3FFF`.
**The bank does not change** on crossing `$3FFF` to `$0000`. Select all four
banks explicitly to traverse 64 KiB.

A diagnostic peek does not increment; a CPU read, including BASIC `PEEK`,
does. The signature does not expose the MainRAM flag. Coordinate port use
with IRQ routines and avoid RMW instructions on DATA. **See chapter 2.**

## Sprites: slots, coordinates, palette and publication

| Register | Function |
|---|---|
| `$FD90` | Enable, one bit per slot; write it **last** |
| `$FD91` | Sprite collisions, one bit per slot; R clears all, W ignored |
| `$FD92` | Per-slot bit: 0 monochrome, 1 RAW8 in the ordinary profile |
| `$FD93/$FD94` | X / Y expansion ×2, one bit per slot |
| `$FD95` | **Reserved**; does not implement behind-TED priority |
| `$FD96` | Sprite-view RAM port, R/W with auto-increment |
| `$FD97/$FD98` | 16-bit data pointer low / high |
| `$FD99..$FD9C` | Light selectors, two nibbles per register |
| `$FD9D/$FD9E` | Main-RAM lighting/scenery list pointer |
| `$FD9F` | Bit 0 enable, bits 1/2 blanking, bit 3 presentation window |
| `$FDA0..$FDCF` | Eight descriptors, six bytes per slot |

For slot `s=0..7`, base `b=$FDA0+6*s`:

| Offset | Field |
|---:|---|
| 0 | X low |
| 1 | Y |
| 2 | X high: only bit 0 contributes |
| 3 | Local colour or extended-profile material/format selector |
| 4–5 | **Byte** pattern address in the view, low/high |

Origin `(0,0)` is at the top left of the **320×200** area. In ordinary RAW:
`X=low+256*(high&1)`, range 0–511; Y is 0–255. The border clips pixels:
X=511 and Y=255 do not mean −1. The `leftmcm` signed projections apply
only to the advanced packed profile. **See chapter 3.**

| Ordinary format | Data | Transparency |
|---|---:|---|
| Monochrome | 63 bytes, 24×21, three bytes per row, high bit at left | Bit 0 transparent; bit 1 uses descriptor colour |
| RAW8 | 504 bytes, 24×21, 24 bytes per row | `$FF` recommended; renderer discards every value 121–255 |

A visible 16×16 sprite still occupies a 24×21 slot: initialize padding and
holes to `$FF`. In RAW8, **index 0 is opaque black**, not transparency.
Indices 0–120 encode one black and 120 combinations:

```text
index 0 -> TED $00
index i from 1 to 120:
    L = (i-1) div 15
    H = (i-1) mod 15 + 1
    TED colour = 16*L + H
```

Examples: index 6 → TED `$06`, index 111 → `$76`, index 106 → `$71`.
The palette does not remove TED background-cell/video-mode limits.

Sprite-view RAM uses `pointer & $3FFF`, but the **port counter is 16-bit**:
after `$3FFF` it records `$4000`, which accesses offset 0 again. Only after
`$FFFF` do its registers return to zero. This differs from the SRAM port's
14-bit offset. Ordinary RAW/mono fetches also wrap within the 16 KiB view.

With `-plus64rastercollisions`, writing `$FD90` publishes descriptors and
patterns even midway through a frame; disable with zero before reusing
slots. Already drawn lines remain unchanged. The latch contains collisions
between opaque slot pixels, not collisions against TED: no hardware
wall/platform collision is supplied. Lower-numbered slots have visual
priority. Bits belong to **slots**, not to identities of multiplexed enemies.

### Extended formats and lighting

`Plus64MixedSprites` requires `Plus64PackedCache`. Aligned 1 KiB packed
records contain inverse source64 at `$200..$23F`, shift at `$240`, MCM at
`$241`, three inks at `$242..$244`, and valid marker `$A5` at `$245`. These
are views of shared bytes, not another 16 KiB. Pointer tag `$4000`, with
bit 15 zero, selects mixed RAW8 at the low-14-bit offset; all 504 bytes
must fit without wrapping.

Sparse HIRES uses descriptor colour `$F9`, source magic `$A7`, a mask and
colour rectangles. Where supported, a material uses `$80|colour` and
preserves the mask. Light selectors use low/high nibbles for even/odd
sprites: 0 historical; 1–8 N, NE, E, SE, S, SW, W, NW; 9 front; 10 per-ink
diagonal MCM. FA is an invisible MCM occlusion tag between virtual sprites,
not arbitrary priority behind TED characters. **See chapter 3 and FORMAT.**

## SID: notes, gate and actual addresses

Reproducible profile: `-sound -sidenginemodel 256 -sidcartaddress 0xFD40
-sidcartclock 0`. `256` = reSID 6581; `257` = reSID 8580. SID clock 0:
**985,248 Hz PAL**, 1,022,730 Hz NTSC. In the preserved runtime, clock 1
instead supplies **1,773,447 Hz PAL** to SID, not 886 kHz. **See chapter 4.**

| Voice base | `+0/+1` | `+2/+3` | `+4` | `+5` | `+6` |
|---|---|---|---|---|---|
| `$FD40`, `$FD47`, `$FD4E` | Frequency low/high | 12-bit pulse width | Control | A high / D low | S high / R low |

CONTROL: `$01` gate, `$02` sync, `$04` ring, `$08` test, `$10` triangle,
`$20` sawtooth, `$40` pulse, `$80` noise. Rearticulating a note requires a
0→1 gate edge; TEST does not reset the ADSR rate counter.

| Register | Use |
|---|---|
| `$FD55/$FD56` | Cutoff: `(high<<3) | (low&7)` |
| `$FD57` | Resonance high nibble; voice 1/2/3/external routing at bits 0–3 |
| `$FD58` | Volume 0–15; LP `$10`, BP `$20`, HP `$40`, voice 3 excluded from direct output `$80` |
| `$FD59/$FD5A` | POTX/POTY, reads depending on inputs/configuration |
| `$FD5B/$FD5C` | Voice-3 oscillator / envelope reads |
| `$FD5D` | Decoded offset with no defined synthesis function |
| `$FD5E/$FD5F` | **Not decoded as SID** |

`N=round(Hz*2^24/SIDclock)`: A4 PAL with clock 0 → `$1D45`; write low `$45`,
high `$1D`, approximately 440.029 Hz. Keep RAM shadows of write-only
registers; do not recover them through reads or RMW. SID debugger peek shows
last writes, not necessarily live OSC3/ENV3 values. The host audio buffer
changes latency, not note frequency.

## Modem: polling, FIFOs and commands

| Register | Read / write |
|---|---|
| `$FDF0` | R removes RX, zero if empty; W feeds AT while offline, then TX when connected |
| `$FDF1` | STATUS; W ignored |
| `$FDF2` | R zero; W bit 0 reset, otherwise bit 1 disconnect; bit 2 clears overrun |
| `$FDF3` | R `$04`, writes ignored: descriptive “9600”, not programmable baud |
| `$FDF4/$FDF5` | RX / TX pending bytes, 0–128 in the current model |
| `$FDF6/$FDF7` | Signature `$64` / protocol `$03` |

STATUS: `$01` RX ready, `$02` TX has room, `$04` connected, `$08` dialing,
`$10` latched overrun, `$20` offline. After reset: `$22`. RX/TX have
**128 bytes each**, with a 256-byte command buffer: **512 bytes total,
already inside the budget**. Network reception applies backpressure while
RX is full; CPU writes that cannot be accepted set overrun. Reading STATUS
does not clear flags. RX byte `$00` is valid: check `$01` first. Device
peek does not remove a byte; BASIC `PEEK` does.

Supported AT commands: `AT`, `ATE0`, `ATE1`, `ATZ`, `ATH`, `ATDhost[:port]`,
`ATDThost[:port]`, terminated by ASCII CR `$0D`. Default port 23; responses
`OK`, `ERROR`, `CONNECT 9600`, `NO CARRIER`, enclosed in CR/LF. When connected,
`ATH` and `+++` are data, not commands: close using `$FDF2=$02`.

The backend is host TCP with minimal incoming Telnet handling; it is not a
fully binary-transparent transport and has no TLS. It generates no IRQ/NMI.
Polling occurs in the video callback, not on reading STATUS. Use timeouts
and handle overrun. DNS resolution is synchronous. **See chapter 4.**

## TED, IRQs and reset: operational reminder

| Register | Native function |
|---|---|
| `$FF00/01`, `$FF02/03`, `$FF04/05` | Timers 1/2/3; W low stops, W high starts |
| `$FF06/$FF07` | TED video mode and control |
| `$FF08` | TED input sampling; not a C64 CIA |
| `$FF09` | IRQ flags; write bits to acknowledge |
| `$FF0A/$FF0B` | IRQ mask and raster comparison; `$FF0A` bit 0 = line bit 8 |
| `$FF12..$FF14` | Native video-memory selections/bases; respect shared bits |
| `$FF15..$FF19` | Video, auxiliary and border colours according to TED mode |
| `$FF1C/$FF1D` | Raster counter high/low |

IRQ: raster `$02`, T1 `$08`, T2 `$10`, T3 `$40`. Timers count at half the
base clock: **886,723.5 ticks/s PAL**. Initial zero means 65,536; T1 reloads
its configured value, T2/T3 reload 65,536 after the first underflow. Two-byte
reads are not atomic; use high/low/high if necessary. `SEI` masks IRQs: it
does not provide the equivalent of a CIA2 NMI.

| Action | Effect to remember |
|---|---|
| SRAM register reset | Bank/offset zero; preserves contents and MainRAM binding |
| Enabling plus/64 from disabled | Initializes views and clears cartridge RAM, preserving native internal RAM |
| Sprite reset | Clears registers and latch, preserves shared backing; initialize every image explicitly |
| Modem reset, `$FDF2=$01` | Disconnects, clears indices/command and overrun, preserves shared payload; echo disabled |
| Disconnect, `$FDF2=$02` | Discards TX, preserves RX and inserts `OK` |
| Audio initialization | Set gate, waveforms, ADSR and volume explicitly; do not read them from write-only registers |

For details see chapters 2–4; for complete programs and checks see chapters
5–6 and the SDK. Host C tests do not equal CPU 6502, VICE, native Windows or
physical-hardware tests.

## Snapshots and RAM80 ownership

VSF with plus/64 enabled: container 2.1, PLUS64 module 1.0. The 64 KiB is
in `PLUS4MEM`; the 16 KiB and device state are in `PLUS64`. Bytes 72–78
version extended formats; byte 79 is the scenery revision, currently 17.
Current readers accept 0, 1 and 3–17; withdrawn prototype 2 is refused.
Older readers may refuse new versions; there is no silent partial restore.
With a connected/dialing modem, save and load are refused.

Modem payload occupies cartridge bank 3 `$3E00..$3FFF` in native mode or
internal RAM `$0000..$01FF` in MainRAM. Reserve it before using the modem.
Impossible Mission lends it to speech only while the modem is idle. PC
video/snapshot copies are not guest RAM. The scenery compositor reads
emulated RAM directly: physical hardware/genlock needs a verified data
path, synchronization and contention policy, not assumptions implicit in
the API.

# 8. Programmable materials within the RAM80 budget

The complete `sdk/materials/material-example.asm` uses a generic HIRES mask
and121 selected highlights, switching between north, east and frontal
light. Its executable and D64 are under `sdk/materials/prebuilt/`.

```sh
python3 sdk/materials/build_material.py --xa /path/to/xa --out build-material
```

It loads at `$1001`, enters at `$1100`, and ends at `$1398` exclusive.
It reserves one1 KiB record in cartridge bank2, already within64 KiB. Zero
page, stack, code and TED bitmap remain within internal16 KiB. Tests observed
all121 colours and three lights over500 frames on each host. Running the
prebuilt D64 does not require Python.

The full record and layer specification is in [FORMATI_GRAFICI.md](FORMATI_GRAFICI.md),
and serialization in [SNAPSHOT_FORMAT.md](SNAPSHOT_FORMAT.md). Historical
format sections are superseded by later sections in the same specification;
the current implementation supports scenery17. In REV8R, data formerly
placed in unused font glyphs is copied to retired `$0600..$07FF` staging
pages before restoring all original room glyphs.

The compositor reads fonts and data from emulated RAM. That software access
does not establish free physical-cartridge access to TED RAM: publication,
arbitration, synchronization and hardware cost remain to be designed. FA
masks implement priority between virtual sprites, not arbitrary priority
behind TED characters; FD95 remains reserved.


# 9. Appendix: Impossible Mission REV8R accounting

The `MANIFEST.json` contains historical parent fields as well as current declarations. Use `ram80.active_memory_declarations`, the current speech layout and qualified delivery records rather than adding every inherited allocation.

| Audited internal-16-KiB reservation | Bytes |
|---|---:|
| First 49 compressed-voice segments | 10,986 |
| Union of protected sprite metadata/helper/backup ranges | 5,398 |
| **Disjoint union** | **16,384** |

The protected union includes sixteen 70-byte source/key/valid records (1,120 bytes), native-code backups and other phase-owned storage. It is a reservation map; some locations have different owners at different phases. There are no unlisted bytes in this particular internal-RAM reservation. The modem's first 512 bytes are already included in the voice segments, borrowed while idle.

Main-RAM compressed audio data totals 2,136 bytes: `$0A00..$0AFF` (256), `$EC98..$F1FF` (1,384), and `$FA10..$FBFF` (496). Its history occupies `$F200..$F7FF` (1,536). The player and tables use 3,181 bytes, with entry `$E026`. These are already inside the 64 KiB, as are game logic, screen planes, fonts, original sprites and decompression helpers.

The hero retains its 4,096-byte source-record reservation; its compressed payload is 2,121 bytes. Existing source padding also carries palette regions, helpers and scenery. The scenery allocation counter is 1,127 bytes including its streams and descriptors: the 393-byte shared room background and 55-byte stone stream must not be added again. The 320×200 3-bit expansion would be 24,000 bytes, but that expansion is not retained in guest RAM. Final-door/font preservation uses retired `$0600..$07FF` staging pages; all original room glyphs are restored.

The cold CORE expands in place to 62,720 bytes at `$0800..$FCFF`; the current stream is 48,101 bytes and its decoder 234 bytes. Transport and decoded images reuse memory at different phases. Adding both sizes as permanent allocations would double-count the same address space.

For scale, the earlier unstripped REV8R Windows build was 30,436,536 bytes; the final distribution executable with debug sections removed is 6,617,154 bytes. Its executable core sections are unchanged by stripping. The REV8R D64 is 174,848 bytes and a password-ready VSF 500,080 bytes. These are PC files, not RAM requirements of the game. The D64 carries secondary files loaded into reused phase-specific areas. The executable implements the emulator and contains PC code; it is not loaded into the emulated cartridge. The strict guest total remains **65,536 + 16,384 = 81,920 bytes**.
