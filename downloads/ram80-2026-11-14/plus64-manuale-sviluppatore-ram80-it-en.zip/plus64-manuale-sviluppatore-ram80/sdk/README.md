# SDK RAM80 corrente / Current RAM80 SDK

Il codice nativo usa16KiB CPU/TED su C16 e Plus/4; i dati sprite sono alias
del banco cartuccia2. Non esiste RAM sprite aggiuntiva. Firme SRAM64/05,
modem64/03. Native CPU/TED uses16KiB on both hosts; sprite data aliases
cartridge bank2, without additional sprite RAM.

Build: `python3 build.py --xa /path/to/xa --out build-new`.
Prebuilt: `prebuilt/DEMO_PLUS64.d64`, identical to the currently tested SDK.
The raw8 example runs without packed/mixed options; see the technical manual.
Material example, sources and independent build: `materials/README.md`.
The current source include names FD99..FD9F, light directions and protocols.
Proof summaries are under `evidence/`; they distinguish nativeLinux, Wine,
rendererC and assembly checks. Physical and nativeWindows tests are not claimed.
