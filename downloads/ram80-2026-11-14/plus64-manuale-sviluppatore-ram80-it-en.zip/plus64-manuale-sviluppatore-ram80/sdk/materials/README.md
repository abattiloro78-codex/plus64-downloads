# Current RAM80 programming SDK

This directory is a small source SDK for the maintained plus/64 VICE model.
It contains a preserved RAM80 baseline and a new, independent material example.
The model has exactly **64 KiB cartridge RAM plus 16 KiB internal RAM**, on
both C16 and Plus/4. Sprite storage is an alias of existing memory, not another
16 KiB pool. This SDK does not alter an emulator or a game.

## Contents and requirements

- `baseline/`: exact copy of the active `runtime/SDK_RAM80/source/` input files.
  Its SRAM protocol check is already version5. It draws all121 RAW8 colours,
  accepts keyboard/joystick movement, and demonstrates a SID tone.
- `include/plus64.inc`: baseline register names plus current optional graphics
  registers, direction selectors and protocol constants.
- `material-example.asm`: new generic ellipse mask,121 selectable highlights,
  and north/east/front illumination. No game artwork or game logic is included.
- `build_material.py`: Python3 standard library and **xa6502** assembler only.
- `prebuilt/MATERIAL.prg` and `.d64`: assembled sample, with build metadata.

Run the examples with the **current modified xplus4**, not stock VICE. Building
requires Python3 and xa6502; running prebuilt PRG/D64 files does not require
Python or an assembler. The frame synchronisation is PAL-specific.

## Build

Choose an output directory that does not yet exist:

```sh
python3 build_material.py --xa /path/to/xa --out build-material
python3 baseline/build.py --xa /path/to/xa --out build-baseline
```

The new example loads at `$1001`, enters at `$1100` through BASIC `SYS4352`,
and ends below `$1800`. The build verifies this bound and produces a standard
174848-byte D64. `build_material.py` generates the mask and palette tables;
there are no image-library dependencies.

## Run the material example

The material sample uses **native16K**, with the existing packed-cache and
mixed-format configuration enabled before sprite output. Do not add `mainram`.
For example, from a folder containing the current runtime:

```text
xplus4.exe -default -model c16 -ramsize 16 -plus64 -plus64packedcache -plus64leftmcm -plus64mixedsprites -plus64rastercollisions -directory . -kernal kernal-318004-05.bin -drive8type 1541 -trapdevice8 -busdevice8 -autostart C:\sdk\prebuilt\MATERIAL.d64
```

Replace the disk path as needed and quote paths containing spaces. `-model
plus4` uses the same software and16K native memory contract. Linux uses the
same options with its native `xplus4` binary. No manual SYS is needed when
using autostart.

The screen displays a TED palette background and an ellipse. Its selected
highlight cycles through compact colours0..120 every four PAL frames. Light
cycles through north, east and front every128 frames. Black0 is opaque, so it
is visible as a black silhouette over the palette. The output may use fewer
than eight luminance levels when a darker highlight is selected.

The baseline sample uses its original RAW8 profile and must run without the
packed-cache/mixed-format options. It demonstrates a different pixel format;
turning on the packed profile changes what an untagged FD92 slot means.

## Memory ownership

| CPU address | New material example |
| --- | --- |
| `$0080..$0087` | State and scratch pointers; IRQs are disabled. |
| `$0100..$01FF` | CPU stack. |
| `$03F0..$03F3` | Ready/error, selected colour, direction, frame counter. |
| `$1001..$10FF` | BASIC autostart prefix. |
| `$1100..$1397` | Current assembled code, new mask and palette tables. |
| `$1800..$1BFF` | TED luminance attributes. |
| `$1C00..$1FFF` | TED chrominance attributes. |
| `$2000..$3F3F` | TED bitmap,8000 bytes. |

The example reserves **cartridge bank2 offset `$0000..$03FF`** as one packed
sprite cache record. It uploads only `$0200..$0245` through FD96. In native
mode, the sprite port aliases cartridge bank2; SRAM access to that bank sees
the same bytes. The sample does not use the modem or its bank3 buffer area.
There is no separate sprite allocation outside the existing80 KiB.

In `mainram` mode, CPU/TED instead use the64 KiB cartridge and the sprite port
aliases the existing16 KiB internal memory. This example deliberately does
not switch profiles or implement a mainram loader.

`STATUS=$03F0` is1 after setup or `$FF` for an incompatible SRAM signature.
`$03F1` is the selected compact highlight0..120; `$03F2` is1,3 or9; `$03F3`
is the wrapping8-bit frame counter. The source owns those locations only
while running. It disables IRQs and makes no KERNAL or disk calls after entry.

## Minimal material mechanism

The existing six-byte slot0 descriptor at FDA0 is `x,y,xHigh,colour,ptrLo,ptrHi`.
This sample sets the pointer to zero, FD92 bit0 to zero (HIRES packed mask),
and the descriptor colour to `$80 | highlight`. The high bit requests the
existing computed material; the lower seven bits select colour0..120.

The inverse cache has the63 mask bytes at `pattern+$23F .. pattern+$201`,
source byte63 at `pattern+$200`, shift0 at `$240`, HIRES selector0 at `$241`,
three fallback ink bytes at `$242..$244`, and validity `$A5` at `$245`.
This example sets source byte63 to zero and the fallback inks to1. The
software writes the descriptor before FD90 enables output, and disables
output around multibyte descriptor updates.

FD99 low nibble selects slot0 light; its high nibble belongs to slot1. The
other pairs are FD9A for2/3, FD9B for4/5, and FD9C for6/7:

| Selector | Profile |
| --- | --- |
|0|Historical upper-left highlight at(6,5).|
|1..8|N,NE,E,SE,S,SW,W,NW.|
|9|Front at(12,10).|
|10|Per-ink diagonal lighting for packed multicolour masks.|
|11..15|Reserved; historical profile fallback.|

Ordinary HIRES mask front lighting uses the radial profile. The separate
front silhouette profile applies to sparse masks, which this minimal sample
does not use. A material affects colours, not mask occupancy or collisions.
Compact colours1..15 are hues1..15 at luminance0;16..30 are luminance1;
106..120 are luminance7. `0` is opaque black. The baseline RAW8 example uses
`255` for transparency; a zero pixel is not a transparency request.

FD9D/FD9E and FD9F name the existing optional linked layer list and its flags.
This sample leaves the list disabled. They are not additional RAM or a second
framebuffer. FD95 remains reserved.

## Validation and limits

See `VALIDATION.md`. The sample was assembled and run on native Linux C16 and
Plus/4. The actual maintained C renderer was checked for all363 combinations
of121 highlights and three directions, including opaque black and exact mask
occupancy. These checks do not establish physical hardware feasibility,
physical timing, native Windows execution or arbitrary program compatibility.
