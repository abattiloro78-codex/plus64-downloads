# 1. Come usare questo manuale

Questo manuale serve a scrivere nuovi giochi per il **modello software
plus/64** eseguito dal runtime VICE distribuito con il progetto. Descrive
gli indirizzi effettivamente decodificati, i formati realmente letti dal
renderer e le convenzioni verificate dagli esempi. Non presuppone l'accesso
a un repository online: esempi, costanti e riferimenti sono nel pacchetto.

**Edizione documentale 2.0 RAM80 — 14 novembre 2026. Progetto Meck.**
Il riferimento corrente è il runtime Windows `xplus4.exe` da 6.617.154 byte,
con SHA256 `08d3e87f84140fe13014213beb32bf7635de12b715769d995efc0658bf08ddfa`. La distribuzione finale ha le sezioni debug
rimosse; il codice eseguibile è identico alla build di riferimento verificata.
Il numero dell'edizione riguarda il manuale, non una nuova revisione elettrica
della cartuccia. La porta RAM corrente dichiara il protocollo `$05`; il formato
del modulo snapshot PLUS64 resta 1.0 e la versione scenery corrente è 17.

## Che cosa offre la piattaforma

Il C16 o Plus/4 continua a fornire CPU, TED, tastiera, joystick e KERNAL.
plus/64 aggiunge, nel modello emulato, SID, una porta per 64 KiB di SRAM,
otto descrittori sprite composti sopra il video TED e un modem a registri.
Gli sprite hanno una tavolozza di 121 colori; il TED mantiene la propria
tavolozza di 121 colori distinti. Ogni singola cella del bitmap TED rimane
soggetta ai limiti del suo modo video:121 non significa121 colori per cella.

Un solo `xplus4.exe` emula sia C16 sia Plus/4. Il nome del programma non
identifica una versione del gioco destinata soltanto al Plus/4. Lo stesso
programma può usare la stessa API e lo stesso budget di memoria sui due
ospiti. Il profilo nativo impone 16 KiB di RAM CPU anche sul Plus/4; il profilo
MainRAM impone 64 KiB di cartuccia come RAM CPU. La memoria complessiva
disponibile al programma è sempre **64+16 KiB, cioè 81.920 byte**.

## Due profili da distinguere

| Profilo | Impiego | Memoria osservabile |
| --- | --- | --- |
| Nativo, consigliato per iniziare | Nuovi giochi e SDK di questo manuale | Codice e TED nei 16 KiB interni; 64 KiB cartuccia tramite `$FDE8..$FDED`; la porta sprite vede il banco cartuccia 2 |
| MainRAM | Raccordo del motore C64 di Impossible Mission e programmi avanzati | CPU/TED e porta SRAM vedono gli stessi 64 KiB cartuccia; la porta sprite vede i 16 KiB interni distinti |

Il codice implementa due backing: `mem_ram[65536]` e `p64_aux_ram[16384]`.
Le viste SRAM, sprite e modem sono alias di questi byte, non pool aggiuntivi.
Nel profilo nativo il modem usa gli ultimi 512 byte del banco cartuccia 3;
in MainRAM usa i primi 512 byte della RAM interna. Ogni programma deve
riservare le aree condivise che utilizza. Non sommare una seconda SRAM,
RAM sprite privata o FIFO modem al budget: il totale resta 80 KiB.

Il cambio di profilo è un'impostazione del runtime, non un nuovo registro
CPU. Riordina in posto i cinque blocchi da 16 KiB preservandone i dati;
richiede sprite disabilitati e modem inattivo, con code e comando vuoti.
Il profilo software non dimostra un decoder fisico della cartuccia.

## Stato delle informazioni

| Etichetta | Significato |
| --- | --- |
| API corrente | Comportamento presente nei sorgenti del runtime di riferimento |
| Verificato in VICE | Istruzioni della CPU guest o pixel realmente prodotti nell'emulatore |
| Formato sperimentale | Funzione opt-in già presente, con opzioni e layout specifici |
| Questione hardware aperta | Non è una funzione da presumere disponibile su una cartuccia fisica |

La cartuccia qui descritta è **emulata dentro VICE**. I nuovi materiali e
scenari leggono direttamente le strutture RAM emulata tramite il codice
host: un circuito fisico deve ancora definire accesso ai dati, contesa e
sincronizzazione video. Un eventuale compositor/genlock esterno richiede
un progetto e verifiche propri, non impliciti in questi test. Non è una semplice
immagine ROM/CRT caricabile nel VICE ufficiale, né un circuito fisico
certificato. I test software non misurano alimentazione, contesa sul bus,
temporizzazioni elettriche o qualità del video analogico.

## Cosa occorre

- Il runtime Windows plus/64 già distribuito, per giocare o eseguire i PRG.
- Per compilare l'esempio: Python3 e assembler `xa`; vedere `sdk/README.md`.
- Per partire: familiarità con registri 6502, indirizzamento, stack e salti.
- Per usare i diagnostici VICE: ROM del sistema e un eseguibile con il
  supporto plus/64 corrispondente. L'SDK non contiene un nuovo emulatore.

I moduli aggiunti non emulano un Commodore64 completo. In particolare non
si devono presumere VIC-II, CIA, raster IRQ C64, sprite DMA C64 o un NMI
programmabile soltanto perché sono presenti SID e grafica aggiuntiva.

## Convenzioni di scrittura

Gli indirizzi con `$` sono esadecimali; `0x` è equivalente negli strumenti
Python/C. I valori binari sono indicati con `%`. Un byte vale0–255,
un KiB1024 byte. Le tabelle specificano separatamente lettura e scrittura.

Una lettura CPU di un registro non equivale sempre a guardarlo con il
monitor: il monitor può usare una funzione `peek` senza effetti collaterali.
Una normale `LDA` o `PEEK` BASIC è invece una lettura del programma e può
far avanzare un puntatore, consumare un byte del modem o azzerare un latch.

Le citazioni a file della cartella `reference` si riferiscono alle copie
congelate incluse nel pacchetto. I loro hash sono riportati nel manifest.
Le citazioni non richiedono un collegamento a repository privati.

## Avvio rapido

## Organizzazione della cartella

Estrarre il manuale e l'SDK conservando le sottocartelle. Per eseguire la
demo, usare il runtime già distribuito: non sono necessari i D64 dei giochi
né una loro partita salvata. Per compilare, dalla cartella del manuale:

```sh
python sdk/build.py --out build-demo
```

La destinazione deve essere nuova. `xa` deve essere nel PATH; se serve,
impostare la variabile `XA` al suo percorso. I dettagli e gli output effettivi
sono descritti nel README dell'SDK. Il materiale `sdk-current` aggiunge
un esempio dei materiali correnti senza sostituire il programma base. Il codice sorgente dell'esempio è
fornito integralmente, non è uno pseudoprogramma da completare.

## Profilo di esecuzione nativo

Le opzioni essenziali per lo sviluppo iniziale sono:

```text
-default -model c16 -ramsize 16
-plus64 -plus64rastercollisions
-sound -soundbufsize 64
-sidenginemodel 256 -sidcartaddress 0xFD40 -sidcartclock 0
```

`-plus64` abilita i dispositivi. `-plus64rastercollisions` abilita il
percorso per scanline e la pubblicazione immediata alla scrittura di FD90.
Non aggiunge un registro. Per l'altro ospite sostituire `-model c16` con
`-model plus4`, mantenendo il limite interno16 KiB.

Per questo esempio lasciare disattivati `plus64mainram`, `plus64packedcache`,
`plus64mixedsprites` e `plus64leftmcm`: appartengono al profilo avanzato. Usare `-default`
evita di ereditare accidentalmente le opzioni di un gioco precedente.

`-directory` deve indicare la cartella delle risorse del runtime; KERNAL,
BASIC, ROM 1541 e keymap devono essere quelli della distribuzione funzionante.
Per un D64, mantenere anche le opzioni di unità1541 e bus/trap del launcher
distribuito. Non cambiare clock SID per accelerare caricamenti o animazioni.

## Risultato atteso

La demo mostra grafica TED e uno sprite colorato trasparente, mosso dai
comandi documentati nell'SDK. Un comando attiva una nota SID. La pubblicazione
dei descrittori non cancella il bitmap. I diagnostici separati verificano
lettura/scrittura dei dispositivi: non vanno confusi con un gioco completo.

# 2. Memoria, spazio CPU e porte I/O

Per scrivere un gioco occorre scegliere un profilo di memoria e mantenerlo
su entrambi gli ospiti. Il contratto corrente offre **64 KiB cartuccia e
16 KiB interni, 81.920 byte complessivi**. Le due viste disponibili non
espongono 80 KiB lineari alla CPU e non aggiungono un pool sprite.

Questo capitolo descrive il runtime 2.0 RAM80, PE SHA256
`08d3e87f84140fe13014213beb32bf7635de12b715769d995efc0658bf08ddfa` (6.617.154 byte, sezioni debug rimosse).
`MEMORY_API.json` accompagna il riferimento corrente; eventuali inventari
storici con protocollo `$04` non descrivono la proprietà della memoria RAM80.
I nomi citati sono relativi ai sorgenti VICE forniti con il runtime.

## 2.1 I due profili disponibili

| Profilo | RAM del programma CPU/TED | Porta `$FDE8..$FDED` | Vista porta sprite e modem |
|---|---|---|---|
| `-plus64`, nativo | 16 KiB interni, imposti anche su Plus/4 | Quattro banchi cartuccia da 16 KiB | Sprite: banco cartuccia 2. Modem: banco 3, offset `$3E00..$3FFF` |
| `-plus64mainram` | 64 KiB cartuccia come RAM principale | Alias degli stessi 64 KiB | Sprite: 16 KiB interni. Modem: offset interni `$0000..$01FF` |

Nel primo profilo un programma come PRISM mantiene codice e bitmap sotto
`$4000` e trasferisce le risorse dalla cartuccia mediante la porta dati.
Cambiare banco SRAM non sposta codice CPU, stack, video TED o ROM. Scrivere
nel banco 2 modifica anche la vista letta dal circuito sprite: occorre
riservare esplicitamente gli intervalli usati.

Nel secondo profilo, usato da Impossible Mission, il setter
`plus64_set_main_ram()` seleziona `RamSize=64` e collega i quattro banchi
alla stessa `mem_ram` usata dal decoder CPU. I 16 KiB interni restano
separati e sono accessibili tramite la porta sprite `$FD96..$FD98`.
Disattivando MainRAM si torna al profilo CPU da 16 KiB. Il cambio ruota
in posto i cinque blocchi da 16 KiB, senza un buffer nascosto aggiuntivo;
preserva i contenuti cartuccia e interni. È rifiutato se ci sono sprite
abilitati, modem connesso/in chiamata, code RX/TX o comando parziale. [MEM-2]

**L'alias non è un'altra memoria da 64 KiB.** Con MainRAM una scrittura
alla porta che seleziona banco 0 e offset `$2345` cambia la stessa cella
`mem_ram[$2345]` usata dal decoder CPU. La porta accede anche alla RAM
sottostante ROM e I/O, perché usa direttamente il backing; non invia
comandi ai registri I/O presenti a quegli indirizzi CPU. [MEM-1, MEM-2]

Il modello è un contratto software corrente, non la dimostrazione di un
decoder elettrico della cartuccia. Le strutture del compositore host e le
copie temporanee di convalida snapshot non sono RAM accessibile al gioco.

## 2.2 C16 e Plus/4: un solo contratto software

Nel C16 con `RamSize=16`, il normale decoder RAM usa `indirizzo & $3FFF`:
quando non intervengono ROM o I/O, `$2000`, `$6000`, `$A000` e `$E000` sono
alias della stessa cella. Anche le basi RAM del TED vengono ricondotte ai
primi 16 KiB. Scrivere oltre `$3FFF` non crea memoria libera. [MEM-3]

Con plus/64 abilitato, il profilo nativo impone `RamSize=16` anche sul
Plus/4. Non basta scegliere il modello Plus/4 per ottenere altri 48 KiB.
I due ospiti verificano lo stesso contratto, non varianti del gioco con
capacità o regole diverse. Le espansioni RAM incompatibili sono rifiutate.

Con `-plus64mainram` entrambi usano la cartuccia da 64 KiB come RAM
principale. I 16 KiB interni distinti sono la vista della porta sprite,
non una seconda finestra lineare né un registro di banking inventato.
Configurare il modello e il profilo prima di avviare il programma e
controllare il protocollo `$05` prima di usare il contratto condiviso.

## 2.3 API SRAM: `$FDE8..$FDED`

La porta è registrata soltanto quando plus/64 è abilitato. Non ha specchi
aggiuntivi dichiarati. I sei indirizzi sono quelli della tabella seguente.
`R` indica lettura CPU, `W` scrittura CPU. [MEM-1, MEM-2]

| Indirizzo | Accesso | Significato |
|---|---|---|
| `$FDE8` | R/W | Byte basso dell'offset nel banco |
| `$FDE9` | R/W | Byte alto dell'offset; in scrittura valgono soltanto i bit 0–5; in lettura i bit 6–7 sono zero |
| `$FDEA` | R/W | Dato all'indice corrente; **ogni lettura CPU e ogni scrittura incrementa l'offset** |
| `$FDEB` | R/W | Banco 0–3; in scrittura `valore & 3`; cambiarlo conserva l'offset |
| `$FDEC` | R | Firma costante `$64`; le scritture non fanno nulla |
| `$FDED` | R | Versione protocollo costante `$05`; le scritture non fanno nulla |

La versione `$05` identifica il contratto condiviso 64+16 KiB; non è un
registro che riveli o cambi MainRAM. Il profilo resta un accordo fra runtime
e programma. La firma va verificata come coppia `$64,$05`.

Il calcolo esatto è:

```text
indice = (banco << 14) | (offset & $3FFF)
dopo DATA: offset = (offset + 1) & $3FFF
```

Dopo `$3FFF` si torna a `$0000` **nello stesso banco**. Non si passa al
banco successivo. Una copia di 64 KiB deve quindi selezionare esplicitamente
i quattro banchi. Scrivere il byte basso o alto dell'offset preserva l'altro
byte; selezionare un banco non azzera il puntatore.

Il callback interno `p64_memory_peek()` legge senza incrementare. Questo
**non** significa che `PEEK(65002)` in BASIC sia innocuo: BASIC esegue una
lettura CPU di `$FDEA`, e quindi incrementa. Il peek senza effetti collaterali
è quello del dispositivo usato dal debugger, quando il debugger lo richiede.

### Un esempio: 256 byte alla fine del banco 2

Esempio per il profilo nativo a porta SRAM, su una banca riservata dal gioco.
Scrive i valori 0–255 a offset `$3F00..$3FFF`; al termine il puntatore è
`$0000`, banco 2. Il blocco `PHP/SEI/PLP` evita che una routine IRQ che usa
la stessa porta cambi banco o puntatore durante il trasferimento.

```asm
        php
        sei
        lda #2
        sta $fdeb
        lda #0
        sta $fde8
        lda #$3f
        sta $fde9
        ldy #0
copia:  tya
        sta $fdea
        iny
        bne copia
        plp
        rts
```

Il codice non salva il puntatore precedente: la routine chiamante deve
definire se la porta è esclusiva oppure salvare e ripristinare banco e offset.
Non usare istruzioni read-modify-write come `INC $FDEA`: comportano accessi
ulteriori a una porta con autoincremento. Nel profilo `mainram` scegliere
anche un intervallo che non contenga codice o dati vivi, perché la porta è
un alias della memoria principale.

### Reset e conservazione

- L'inizializzazione `p64_memory_powerup()` azzera la struttura, inclusa la
  vista cartuccia e i registri di porta, preservando la RAM interna nativa.
  Viene chiamata quando si abilita plus/64 da disabilitato.
- Il reset del dispositivo esegue `p64_memory_reset_registers()`: banco e
  offset tornano a zero; il contenuto SRAM e il binding `mainram` restano.
- Il reset generale della macchina può comunque eseguire codice ROM che
  modifica la RAM nativa. La conservazione dei dati SRAM non garantisce
  quella dell'intero stato di un gioco. [MEM-1, MEM-2]

## 2.4 ROM, I/O e aree realmente utilizzabili

La CPU ha uno spazio di indirizzamento da 64 KiB anche quando il programma
dispone di viste bancate della memoria. Il numero di byte installati non elimina le
sovrapposizioni. Nel profilo nativo standard: [MEM-3, MEM-4]

| Area | Uso da considerare |
|---|---|
| `$0000/$0001` | Porta del processore ospite; non è il selettore ROM/I/O del C64 |
| `$0002..$00FF` | Zero page, condivisa con KERNAL/BASIC se si chiamano le ROM |
| `$0100..$01FF` | Stack CPU; non usarlo come buffer permanente |
| `$0200..$7FFF` | RAM nelle condizioni ordinarie, entro i limiti/alias del profilo |
| `$8000..$BFFF` | BASIC o ROM bassa selezionata quando ROM attive; RAM sottostante in lettura quando disattivate |
| `$C000..$FFFF` | KERNAL o ROM alta selezionata, con eccezioni I/O; RAM sottostante quando ROM disattivate |
| `$FD00..$FDFF`, `$FE00..$FEFF` | Decodifica I/O in entrambe le configurazioni ROM/RAM; include le porte plus/64 |
| `$FF00..$FF1F` | Registri TED, non RAM ordinaria |
| `$FF3E`, `$FF3F` | Strobe di selezione ROM/RAM; il valore scritto è irrilevante |

Una scrittura a `$FF3E` abilita la lettura delle ROM; una scrittura a
`$FF3F` seleziona la RAM sottostante. I registri I/O non spariscono.
`$FF20..$FFFF`, tranne i due strobe, seguono la configurazione prevista
dal decoder; ciò comprende i vettori CPU finali. Non nascondere il KERNAL e
poi eseguire una sua `JSR` o lasciare attivo un IRQ senza vettori e handler
validi in RAM. I normali store sotto le finestre ROM scrivono la RAM
sottostante; le aree I/O rimangono eccezioni. [MEM-3, MEM-4]

I fetch del TED hanno basi e selezioni proprie. La porta SRAM indipendente
non è una sorgente di fetch TED: prima di mostrare bitmap o caratteri
occorre copiarli nella RAM nativa prevista dalla modalità video. Il fatto
che il circuito sprite sovrapponga immagini al video non cambia questa regola.

## 2.5 Backing condivisi e buffer del compositore

Il codice mantiene esattamente due backing di payload:

| Backing/vista | Dimensione | Proprietà |
|---|---:|---|
| `mem_ram` | 65.536 byte | RAM CPU/TED interna da 16 KiB più tre banchi cartuccia nel profilo nativo; quattro banchi cartuccia nel profilo MainRAM |
| `p64_aux_ram` | 16.384 byte | Quarto banco cartuccia nel profilo nativo; RAM interna distinta nel profilo MainRAM |
| Vista sprite | 16.384 byte, già compresi sopra | Banco cartuccia 2 oppure RAM interna, secondo il profilo |
| Payload modem | 512 byte, già compresi sopra | RX128, TX128, comando256; offset secondo la tabella 2.1 |
| Overlay, alpha e riepiloghi raster | Buffer host | Nessun indirizzo guest e nessuna capacità RAM aggiuntiva per il gioco |

La somma dei backing è **81.920 byte**, non 96 KiB. Le due viste successive
non si sommano di nuovo. Anche i dati SID/audio residenti del programma
occupano questi stessi byte. Le dimensioni di eseguibili, dischi e snapshot
sono misure di file del PC, non della RAM disponibile al programma. [MEM-1, MEM-2, MEM-5]

Il reset del modem azzera indici e stato ma conserva i byte condivisi.
Quando il modem è usato il software deve riservare il suo payload. Impossible
Mission lo presta alle voci soltanto a modem inattivo; usare contemporaneamente
modem e quell'audio corromperebbe la proprietà dei dati.

Gli snapshot RAM80 salvano entrambi i backing: `PLUS4MEM` contiene i 64 KiB,
`PLUS64` i 16 KiB insieme ai registri e al video latched. Il contenitore VSF
è 2.1 con plus/64 attivo, il modulo PLUS64 è 1.0 e il formato scenery corrente
è 17: sono numeri distinti. Le dimensioni serializzate includono stato
periferiche e buffer host e non aumentano il budget guest. I vecchi snapshot
privi di stato RAM80 completo vengono rifiutati; collegamenti modem attivi
non sono ripristinabili e il salvataggio è rifiutato mentre connessi/in chiamata.

## 2.6 IRQ e timer: l'ospite rimane TED

plus/64 non aggiunge una CIA del C64. Non vi sono nuovi registri CIA a
`$DCxx/$DDxx`, né un NMI modem o SID. Per programmare interrupt utilizzare
le risorse native TED: [MEM-4, MEM-6]

| Registri | Funzione |
|---|---|
| `$FF00/$FF01` | Timer 1, byte basso/alto |
| `$FF02/$FF03` | Timer 2, byte basso/alto |
| `$FF04/$FF05` | Timer 3, byte basso/alto |
| `$FF09` | Flag IRQ: raster bit 1, timer 1 bit 3, timer 2 bit 4, timer 3 bit 6; bit 7 riassume l'IRQ abilitato attivo |
| `$FF0A` | Maschera IRQ nei medesimi bit; bit 0 contiene il bit alto della linea raster programmata |
| `$FF0B` | Byte basso della linea raster programmata |

Scrivere il byte basso di un timer lo ferma; scrivere quello alto lo avvia.
Il timer 1 si ricarica dal valore impostato; dopo il primo underflow i timer
2 e 3 proseguono con periodo 65.536. Il valore iniziale zero rappresenta
65.536. Il modello conta un tick ogni due clock base TED: PAL
`1.773.447 / 2 = 886.723,5 Hz`, non un generico ciclo istruzione 6502.
Le letture basso/alto separate non sono un latch atomico: se serve un
campione coerente, controllare il rollover, per esempio alto/basso/alto.

I flag TED si riconoscono scrivendo i bit da cancellare in `$FF09`; non
copiano la semantica dei flag CIA. Un IRQ TED resta mascherabile con `SEI`:
non sostituisce un NMI C64 che interrompeva anche con `I=1`. Driver audio o
loader C64 dipendenti da CIA/NMI richiedono un raccordo analizzato, non una
sostituzione indiscriminata di indirizzi.

## Riferimenti del capitolo

Gli inventari devono riferirsi alla stessa revisione dei sorgenti; i vecchi
numeri di riga dell'edizione 1.0 non sono riferimenti della versione corrente.

- **MEM-1:** `src/plus4/plus64_memory.c` e `.h`: `bind_views`, `p64_memory_bind_main_ram`, `p64_memory_read/write`, costanti dei backing.
- **MEM-2:** `src/plus4/plus64vice.c`: `plus64_set_enabled`, `plus64_set_main_ram`, `plus64vice_ram_size_allowed`, API snapshot.
- **MEM-3:** `src/plus4/plus4mem.c`: decoder RAM, profili nativo/MainRAM, blocco delle espansioni incompatibili.
- **MEM-4:** `src/plus4/ted-mem.c` e `plus4mem.c`: selezioni ROM/RAM e I/O.
- **MEM-5:** `src/plus4/plus64_sprite.h`, `plus64_modem.h` e relativo `.c`: viste condivise e payload modem.
- **MEM-6:** `src/plus4/ted-timer.c`, `ted-irq.c`, `ted-mem.c`: timer, IRQ e funzioni `ted09_store`, `ted0a_store`, `ted0b_store`.

# 3. Video TED e sprite plus/64

Questo capitolo specifica il video dell'implementazione plus/64 mantenuta: contratto RAM80, protocollo memoria `$05` e formati grafici estesi fino alla versione17. Le regole TED, i descrittori di base e gli esempi validi del manuale1.0 sono conservati; i vecchi pool indipendenti e i registri allora riservati sono aggiornati. Il capitolo non specifica una futura implementazione elettrica della cartuccia. L'eseguibile e gli hash delle fonti della consegna sono identificati dal suo manifest corrente.

Le citazioni indicano file delle fonti mantenute, ricostruibili offline nella directory `reference/vice/src/plus4` del pacchetto. I numeri di riga della vecchia edizione sono rimossi: controllare le funzioni nominate o i rami corrispondenti nel file corrente. Per gli estesi, il capitolo8 contiene anche il riferimento dettagliato dei formati; il codice mantenuto decide le combinazioni supportate. Nessuna delle strutture HOST del renderer aggiunge RAM indirizzabile al programma6502.

## Profilo da scegliere per un nuovo gioco

Per iniziare, usare il formato normale con RAM nativa limitata a 16 KiB, SRAM della cartuccia tramite la sua porta e sprite raw8bpp nella vista condivisa. Le opzioni relative al video possono essere:

```text
xplus4.exe -default -model c16 -ramsize 16 -plus64 -plus64rastercollisions
```

`-default` ripristina le risorse iniziali; nel modello qui descritto `Plus64MainRAM`, `Plus64PackedCache`, `Plus64LeftMCM`, `Plus64MixedSprites` e `Plus64RasterCollisions` partono da 0. L'ultima opzione abilita esplicitamente pubblicazione e collisioni per linea, mantenendo il formato raw. Le opzioni complete di disco, SID e input sono descritte negli altri capitoli. Non attivare `packedcache` o `leftmcm` soltanto perché il gioco usa più colori. (`plus64vice.c`)

Il percorso packed è un'estensione software per cache compatte, materiali e riuso di particolari cache C64. Non è necessario per un gioco nuovo e non è il formato originale0.94. Il suo funzionamento è documentato più avanti affinché i porting possano riprodurlo, senza attribuirlo a un dispositivo fisico già realizzato. (`plus64_sprite.h`; `plus64vice.c`)

## Configurare lo sfondo TED

Lo sfondo è configurato tramite i registri TED nativi, indipendenti da `$FD90..$FDCF`. Questa tabella riporta i campi applicati dal runtime; gli indirizzi di memoria risultanti rimangono soggetti al profilo RAM del capitolo 2.

| Registro | Campi utili per configurare il video |
| --- | --- |
| `$FF06` | Bit0–2: scroll verticale0..7; bit 3:0=24 righe,1=25 righe; bit 4: display enable; bit 5:0=testo,1=bitmap; bit 6: extended color mode. Bitmap multicolore: bit 5=1, bit 6=0 e `$FF07` bit 4=1. |
| `$FF07` | Bit0–2: scroll orizzontale0..7; **bit 3**:0=38 colonne,1=40 colonne; bit 4: multicolore. Nel testo normale il bit 7 seleziona0=128 glifi con reverse tramite bit 7 del codice carattere,1=256 glifi senza tale reverse automatico. Non è un bit di inversione globale dello sfondo. |
| `$FF12` | Bit3–5: base bitmap `($FF12 AND $38) << 10`, quindi passi di $2000. **Bit3 non abilita il bitmap:** seleziona il primo bit della sua base. Bit2:0=fetch bitmap/glifi da RAM,1=percorso ROM; nel secondo caso una base inferiore a $8000 usa il percorso open-space del runtime. Bit0–1: parte alta della frequenza della voce0 TED; preservarli quando si cambia solo il video. Bit6–7 vengono letti come1 e non selezionano la base. |
| `$FF13` | Base glifi `($FF13 AND maschera) << 8`: maschera `$FC` normalmente, `$F8` se `$FF06` bit 6 o `$FF07` bit 7 è attivo. Bit1:0=CPU fast mode consentito,1=modo lento; non è un bit dell'indirizzo glifi. Bit0 non è modificabile scrivendo `$FF13`: riflette la selezione ROM/RAM aggiornata dagli strobe `$FF3E/$FF3F` e partecipa ai fetch di matrice e attributi. Non cambia il selettore bitmap/glifi di `$FF12` bit 2. |
| `$FF14` | Base attributi `A = ($FF14 AND $F8) << 8`, allineata a $0800; seconda matrice a `A+$0400`. Nel bitmap dell'SDK sono rispettivamente luminanza e crominanza. I bit 0–2 non spostano queste basi. |
| `$FF15` | Colore globale di sfondo; nel bitmap multicolore è il valore della coppia `00`. |
| `$FF16` | Primo colore globale aggiuntivo; nel bitmap multicolore è il valore della coppia `11`. |
| `$FF17/$FF18` | Secondo/terzo colore globale aggiuntivo: usati dai modi testo pertinenti, non dalle coppie del bitmap multicolore. In extended text `$FF15..$FF18` sono i quattro sfondi selezionati dai due bit alti del codice carattere. |
| `$FF19` | Colore del bordo. Come per `$FF15..$FF18`, bit 0–3=tinta, bit 4–6=luminanza; il bit 7 scritto viene ignorato e in lettura vale1. Tinta0 produce nero, quindi i 128 codici non rappresentano128 colori distinti. |
| `$FF1C/$FF1D` | Contatore della linea corrente: `(($FF1C AND 1) << 8) OR $FF1D`; in `$FF1C` gli altri bit si leggono a 1. Non sono la coppia di confronto IRQ `$FF0A/$FF0B`. Il runtime permette anche di scriverli e riposizionare il contatore: nel normale polling usare solo letture. |

I bit della modalità derivano da `ted.c`; scroll, display e finestra da `ted-mem.c`; reverse del testo da `ted-draw.c`. Per CSEL conta il ramo effettivo `value & $08`, non il commento storico che lo chiama bit 4 a riga405. Basi e sorgenti: `ted.c`; scritture/letture condivise di `$FF12`: `ted-mem.c`, `ted-sound.c`. Selezione ROM e attributi: `ted-mem.c`. Colori e coppie: `ted-mem.c`, `ted-draw.c`; raster: `ted-mem.c`.

### Inizializzazione esatta dell'esempio SDK

La demo viene caricata normalmente dal KERNAL e poi usa queste scritture, in questo ordine (`demo.asm`):

```asm
        lda #$3b
        sta $ff06
        lda #$18
        sta $ff07
        lda $ff12
        and #$c3
        ora #$08
        sta $ff12
        lda #$18
        sta $ff14
        lda #0
        sta $ff15
        sta $ff16
        sta $ff19
```

Il risultato è bitmap multicolore,25 righe,40 colonne, scroll verticale3 e orizzontale0; base bitmap $2000, luminanza $1800, crominanza $1C00, sfondi globali e bordo neri. `$FF12` non riceve una costante universale: l'operazione preserva i due bit audio, azzera il selettore ROM e imposta i bit di base a $08; i bit 6–7 riletti a 1 vengono ignorati dal setter video. La demo non scrive `$FF13`, `$FF17` o `$FF18`: la base glifi non serve al suo bitmap e quei due colori aggiuntivi non vi sono usati. Non assumere che questa sequenza ripristini ogni stato TED di un programma precedente.

L'SDK inizializza1024 byte per ciascuna matrice con le tabelle della palette, poi riempie8000 byte di bitmap con `$55`, mostrando la coppia `01` in ogni campione; il colore viene quindi dagli attributi della cella (`demo.asm`; `ted-draw.c`). Il loop attende `$FF1D=240`, valore univoco nel frame PAL da 312 linee, senza scrivere il contatore (`demo.asm`). Per sincronizzazioni generiche sotto256 usare anche `$FF1C`, come spiegato nella sezione coordinate.

## Che cosa viene sovrapposto al TED

Il TED continua a produrre il proprio sfondo. Il runtime applica i pixel sprite alla fine dell'emulazione di ciascuna linea TED, nell'area logica320×200. I pixel trasparenti lasciano intatto il contenuto TED; un pixel sprite opaco sostituisce il colore di quel punto. Questo percorso non fornisce un framebuffer RGB né una priorità «dietro allo sfondo». (`ted.c`; `plus64_overlay.c`; `plus64_sprite.c`)

Gli otto slot condividono una **vista di 16384 byte della RAM esistente**, `sprite.ram`, accessibile dalla CPU tramite `$FD96`. In profilo nativo CPU/TED usano i 16 KiB interni e questa vista è un alias del banco 2 della cartuccia; l'accesso SRAM a quel banco vede gli stessi byte. In `mainram`, CPU/TED usano i 64 KiB della cartuccia e la porta sprite vede i 16 KiB interni. Il totale resta64+16 KiB: nessun pool sprite privato aggiuntivo. In profilo nativo non si possono usare altri48 KiB del Plus/4. Il TED non legge la porta sprite come una propria finestra video: il programma deve rispettare la mappa del capitolo2. (`plus64_memory.c`, `bind_views`, `p64_memory_sprite_ram`; `plus64_sprite.h`)

La struttura `overlay`, la maschera `alpha` e il riepilogo collisioni per 200 linee sono buffer HOST dell'emulatore, non nuove aree indirizzabili dal programma6502. Non assegnare loro indirizzi della cartuccia. (`plus64vice.c`)

### Palette dei pixel sprite

Gli indici validi sono 0..120. Per convertire un indice sprite `i` nel codice colore TED:

```text
i = 0:       TED = $00
1 <= i <=120:
    luminanza = (i - 1) div 15
    tinta     = (i - 1) mod 15 + 1
    TED       = luminanza * 16 + tinta
```

Sono120 combinazioni tinta/luminanza non nere più un nero. Non sono 121 valori RGB scelti dal programma. La conversione del runtime è quella sopra; resa RGB, filtro e monitor dipendono dal percorso video. (`plus64_overlay.c`)

Nel formato raw8bpp,0 è **nero opaco**, non trasparenza. `$FF` è la sentinella trasparente consigliata; il codice attuale scarta in realtà tutti i valori 121..255. Il nero opaco copre il TED e partecipa alle collisioni, mentre un pixel scartato non occupa la posizione. La maschera alpha permette di distinguerli. (`plus64_sprite.h`; `plus64_sprite.c`; `plus64_overlay.c`)

La disponibilità della palette sprite non elimina i limiti dei modi grafici nativi del TED: lo sfondo è ancora il segnale che il TED ha già renderizzato. Non esiste in questa API un registro «121 colori per ogni cella dello sfondo». (`ted.c`; `plus64_overlay.c`)

## Mappa dei registri CPU

Il decoder sprite copre soltanto `$FD90..$FDCF`. La colonna reset descrive `plus64_reset`: i registri e il latch vengono azzerati, **non il backing RAM dei pattern**. Le opzioni HOST del formato sopravvivono come configurazione e sono risorse distinte, non registri di questa tabella. (`plus64_sprite.h`; `plus64_sprite.c`; `plus64vice.c`)

| Indirizzo | Accesso e reset | Significato effettivo |
| --- | --- | --- |
| `$FD90` | R/W,0 | Enable: bit `s` abilita lo slot `s`, per `s=0..7`. Con il profilo per linea, ogni scrittura pubblica lo stato corrente, anche se il valore non cambia. |
| `$FD91` | Lettura con azzeramento,0; scritture ignorate | Latch delle collisioni fra sprite: un bit per slot coinvolto. |
| `$FD92` | R/W,0 | Bit `s`:0=monocromatico;1=raw8bpp nel formato normale, oppure packed MCM quando `packedcache` è attivo. |
| `$FD93` | R/W,0 | Bit `s`: raddoppio orizzontale dello slot `s`. |
| `$FD94` | R/W,0 | Bit `s`: raddoppio verticale dello slot `s`. |
| `$FD95` | R/W,0 | Riservato. Il byte viene conservato e riletto, ma non applica priorità rispetto allo sfondo. |
| `$FD96` | Porta dati R/W; puntatore iniziale0 | Legge o scrive un byte del backing condiviso e poi incrementa il puntatore `$FD98:$FD97`. Non è una normale cella di registro. |
| `$FD97` | R/W,0 | Byte basso del puntatore della porta dati. |
| `$FD98` | R/W,0 | Byte alto del puntatore della porta dati. Non è un selettore dei banchi SRAM esterni. |
| `$FD99..$FD9C` | R/W,0 | Con formati estesi: due selettori luce a 4 bit per byte, slot pari nel nibble basso; valori 0..10 descritti sotto. |
| `$FD9D/$FD9E` | R/W,0 | Puntatore little-endian alla lista di livelli/materiali nella RAM principale esistente, per il profilo `mainram` esteso. |
| `$FD9F` | R/W,0 | Bit0: livelli attivi; bit 1 o bit 2: mascheramento nero di presentazione; bit 3: finestra post-sprite dei nodi flag4. Gli altri bit non hanno qui una funzione assegnata. |
| `$FDA0..$FDCF` | R/W,0 | Otto descrittori da sei byte, elencati sotto. |

Riferimenti della tabella: accesso e auto-incremento `plus64_sprite.c`; enable, formato ed espansioni `plus64_sprite.c`; pubblicazione `$FD90` `plus64vice.c`. I commenti storici che chiamano `$FD92` «reserved» non descrivono il ramo effettivamente eseguito a `plus64_sprite.c`.

L'auto-incremento usa un contatore a 16 bit e aggiorna entrambi i registri. L'accesso fisico al pool usa `puntatore AND $3FFF`, quindi `$4000`, `$8000` e `$C000` sono alias di `$0000`, non altri banchi. Mantenere il puntatore nell'intervallo0..$3FFF evita di dipendere da tali alias. Un incremento da $FFFF riporta i due byte a 0. (`plus64_sprite.c`)

**Regola SDK:** scrivere0 nei campi inutilizzati e non usare i registri riservati come RAM di lavoro. Il loro readback attuale non assegna loro una funzione pubblica aggiuntiva. (`plus64_sprite.c`)

### Gli otto descrittori

Per lo slot `s`, il primo indirizzo è `$FDA0 + 6*s`. I campi sono indipendenti: non si tratta della disposizione dei registri VIC-II. (`plus64_sprite.c`)

| Slot | X basso | Y | X alto | Colore | Pattern basso | Pattern alto |
| --- | --- | --- | --- | --- | --- | --- |
| 0 | `$FDA0` | `$FDA1` | `$FDA2` | `$FDA3` | `$FDA4` | `$FDA5` |
| 1 | `$FDA6` | `$FDA7` | `$FDA8` | `$FDA9` | `$FDAA` | `$FDAB` |
| 2 | `$FDAC` | `$FDAD` | `$FDAE` | `$FDAF` | `$FDB0` | `$FDB1` |
| 3 | `$FDB2` | `$FDB3` | `$FDB4` | `$FDB5` | `$FDB6` | `$FDB7` |
| 4 | `$FDB8` | `$FDB9` | `$FDBA` | `$FDBB` | `$FDBC` | `$FDBD` |
| 5 | `$FDBE` | `$FDBF` | `$FDC0` | `$FDC1` | `$FDC2` | `$FDC3` |
| 6 | `$FDC4` | `$FDC5` | `$FDC6` | `$FDC7` | `$FDC8` | `$FDC9` |
| 7 | `$FDCA` | `$FDCB` | `$FDCC` | `$FDCD` | `$FDCE` | `$FDCF` |

| Campo | Interpretazione |
| --- | --- |
| X basso, X alto | `X = basso + 256*(alto AND 1)`. I bit 7..1 di X alto sono memorizzati ma ignorati dal renderer. |
| Y | Coordinata a 8 bit, normalmente senza segno:0..255. Le eccezioni signed sono esclusivamente quelle del profilo avanzato descritto sotto. |
| Colore | Nel modo monocromatico di base viene usato `colore AND $7F`; con materiali estesi il bit 7 ha la funzione descritta sotto. In raw8bpp/MCM il colore ordinario viene dai pixel o dalle chiavi della cache. |
| Pattern | Nel formato base, indirizzo **in byte** nel backing condiviso: `(alto*256+basso) AND $3FFF`. Non è un numero di sprite da moltiplicare per 64 o512. |

Il readback restituisce i byte scritti, anche quando alcuni bit sono ignorati nel disegno. Nel monocromatico usare solo indici colore0..120: i valori mascherati121..127 vengono convertiti in nero opaco dalla funzione palette, non in trasparenza. (`plus64_sprite.c`; `plus64_overlay.c`)

## Formati normali dei pattern

Con `packedcache=0` e `leftmcm=0` esistono questi due formati, selezionabili separatamente per ogni slot tramite `$FD92`. (`plus64_sprite.c`)

| `$FD92` bit dello slot | Dimensione visuale | Dati necessari | Interpretazione |
| --- | --- | --- | --- |
| 0 | 24×21 | 63 byte | Tre byte per riga, bit 7 a sinistra; bit uguale a 0=trasparente, uguale a 1=colore del descrittore. Nessun header. |
| 1 | 24×21 | 504 byte | Un indice palette per pixel,24 byte per riga,21 righe. Nessun header e nessun requisito di allineamento. |

Qui raw8bpp ha24 pixel indipendenti per riga: il nome MCM del bit **non dimezza** la risoluzione. Un record da 512 byte è una convenzione utile, non un requisito del decoder; gli ultimi8 byte non vengono letti per l'immagine. Anche il passo64 del monocromatico è soltanto una convenzione. (`plus64_sprite.c`)

Otto slot sono otto istanze, non un limite di otto immagini memorizzate: gli slot possono condividere un puntatore e il programma può cambiare puntatore per animare un oggetto. (`plus64_sprite.c`)

Il fetch normale continua circolarmente entro il backing16 KiB: un'immagine posta vicino a $3FFF legge i successivi byte dall'inizio del pool. Pianificare le allocazioni per non sovrapporre accidentalmente altri pattern. I formati packed hanno invece i controlli di allineamento descritti più avanti. (`plus64_sprite.c`)

Se il backing contiene0, in raw8bpp quei byte significano nero opaco; il reset del dispositivo non garantisce di ripulire una vista condivisa. Abilitare uno sprite raw senza averne inizializzato **tutti** i 504 byte può quindi produrre un rettangolo nero. Per un'immagine16×16 dentro uno slot 24×21, inizializzare a $FF le otto colonne a destra, le cinque righe inferiori e ogni foro trasparente. (`plus64_sprite.c`)

### Esempio in byte: tre pixel e il nero opaco

L'esempio assume formato normale, slot 0, nessuna espansione e porta dati disponibile in esclusiva. È una ricetta dei dati, non un nuovo programma da compilare. Disabilitare prima l'output scrivendo `$FD90=$00`. (`plus64_sprite.c`)

1. Impostare `$FD97=$00`, `$FD98=$00`; scrivere504 volte `$FF` in `$FD96`.
2. Reimpostare il puntatore a $0000; scrivere `$6F,$00` nella porta: offset 0 e1.
3. Impostare il puntatore a $0018; scrivere `$06`: è il primo pixel della seconda riga, perché il passo è24 byte.
4. Scrivere `$FD92=$01`, `$FD93=$00`, `$FD94=$00`, `$FD95=$00`.
5. Scrivere i sei byte sotto e infine `$FD90=$01`.

```text
Indirizzi: FDA0 FDA1 FDA2 FDA3 FDA4 FDA5
Valori:     A0   50   00   00   00   00
```

Il risultato atteso è: blu luminoso in(160,80), nero **opaco** in(161,80), blu scuro in(160,81). Gli altri501 pixel dello slot sono trasparenti e lasciano vedere il TED. Gli indici$6F=111 e$06=6 si convertono rispettivamente nei colori TED$76 e$06. (`plus64_sprite.c`; `plus64_overlay.c`)

## Coordinate, bordi e frequenza

L'origine è l'angolo superiore sinistro dell'area logica320×200: X0..319 e Y0..199. Non aggiungere automaticamente gli offset degli sprite VIC-II di un programma C64. Nel formato normale X è0..511 e Y0..255; le porzioni oltre il bordo destro o inferiore vengono tagliate. X511 non rappresenta−1, e Y255 non rappresenta−1. (`plus64_sprite.h`; `plus64_sprite.c`)

`$FD93` e `$FD94` replicano ogni pixel rispettivamente due volte in orizzontale e verticale:24×21 diventa48×21,24×42 o48×42. Il clipping si applica al risultato espanso. Il formato raw normale non offre coordinate negative a sinistra o in alto; un gioco può tenere una posizione logica esterna e pubblicare un pattern ritagliato aX0, oppure attendere l'ingresso nell'area visibile. Non esiste un ulteriore registro di offset negativo. (`plus64_sprite.c`)

Nel profilo PAL l'emulatore usa312 linee da 114clock TED, con 1773447clock al secondo:35568clock per fotogramma, circa 49,86 Hz, normalmente indicati come50 Hz. Non equivalgono a 35568 cicli di istruzioni6502 disponibili. (`plus4.h`; `ted-timing.h`; `ted-timing.c`)

Con la geometria PAL25 righe usata qui, la linea overlayY0 corrisponde al contatore TED4. `$FF1D` contiene il byte basso del contatore e `$FF1C` il bit 8; `$FF1D=4` da solo non distingue4 da 260. Controllare il bit 0 di `$FF1C` quando si sincronizza una pubblicazione. L'offset canvas PAL59 non va sommato a una coordinata del descrittore. (`tedtypes.h`; `ted-mem.c`; `ted.c`)

Il modo24 righe, lo scroll e il bordo del TED possono cambiare il contenuto o la finestra che si vede sotto l'overlay: non trasformano questi descrittori in registri VIC-II. Per un nuovo modo video verificare il riferimento geometrico del runtime prima di portare una vecchia formula di proiezione. (`tedtypes.h`; `ted.c`; `plus64_overlay.c`)

## Pubblicazione e animazione senza immagini parziali

Le scritture di descrittori, formato, espansioni e dati dei pattern aggiornano il modello, ma non costituiscono da sole una transazione di display. Nel profilo predefinito, senza `-plus64rastercollisions`, il frame hook prepara l'intero overlay una volta per fotogramma. Nel profilo per linea, **ogni scrittura a `$FD90`** ricostruisce l'overlay corrente; non serve cambiare il valore dell'enable. (`plus64vice.c`)

La sequenza consigliata è: inizializzare/uploadare i dati con output disabilitato, scrivere formato, espansioni e descrittori, quindi scrivere la maschera enable in `$FD90` **per ultima**. Dopo la pubblicazione, preparare il successivo stato prima della sua scadenza video. Le linee già disegnate non vengono retroattivamente cambiate. Scrivere0 a `$FD90` disabilita le linee successive, ma non cancella il latch collisioni. (`plus64vice.c`; `plus64_sprite.c`)

Il frame hook continua a ricampionare i registri anche nel profilo per linea. Non considerare `$FD90` una doppia banca hardware di descrittori: una preparazione incompleta che attraversa il campionamento di fine frame può essere vista dal frame hook. Pianificare upload e staging, oppure mantenere l'output disabilitato durante l'inizializzazione. (`plus64vice.c`)

Il multiplex riusa uno slot in fasce verticali diverse: pubblicare la fascia corrente, preparare i descrittori successivi mentre la fascia è renderizzata, poi pubblicarli dopo la sua ultima linea. Gli otto slot restano otto per una stessa linea; non sono diciotto sprite simultanei orizzontali. Anche con `SEI` il TED e la scansione proseguono: misurare il codice completo, includendo input, collisioni, HUD e audio, prima della scadenza della fascia. (`plus64_sprite.c`; `plus64vice.c`; `ted.c`)

Una schermata statica non basta per qualificare un multiplex. Confrontare diverse immagini del framebuffer durante movimento, spari ed esplosioni; verificare che i pixel di tutti gli oggetti vivi siano presenti. Controllare anche gli intervalli fra aggiornamenti, distinguendo uno spostamento della linea di ritorno da un fotogramma effettivamente saltato. Questa è una regola di collaudo SDK, non una nuova funzione del dispositivo.

## Collisioni: soltanto fra sprite

Un pixel opaco di uno slot sovrapposto a quello di un altro produce i bit di **entrambi** nel latch `$FD91`. In sovrapposizioni multiple si accumulano tutti i partecipanti. Fra maschere visibili normali lo slot con indice minore ha priorità visiva, ma gli altri partecipano comunque alla collisione; il colore non definisce una hitbox rettangolare. (`plus64_sprite.c`)

Esempio: `$FD91=$05` significa che gli slot 0 e2 hanno partecipato a collisioni dall'ultima lettura. Non identifica il punto, la coppia esatta fra più eventi o la direzione dell'urto. Una lettura CPU restituisce il byte e azzera l'intero latch; una scrittura non lo azzera. Una sovrapposizione ancora presente può generare nuovamente gli stessi bit alle linee o ai frame successivi. (`plus64_sprite.c`; `plus64vice.c`)

Non vengono campionati i pixel o le strutture logiche del TED per calcolare il latch: niente collisioni hardware contro pavimenti, muri, bitmap, caratteri o colori dello sfondo. Il gioco deve implementarle con le proprie mappe o geometrie. `$FD95` non aggiunge questa funzione e non esiste qui un interrupt sprite equivalente a quello VIC-II. (`plus64_sprite.h`; `plus64_sprite.c`; `plus64vice.c`)

| Profilo collisioni | Momento e dominio |
| --- | --- |
| Predefinito: `rastercollisions=0`, `leftmcm=0` | Confronto dell'intero overlay durante la preparazione del frame; dominio visibile X0..319, Y0..199. |
| `rastercollisions=0`, `leftmcm=1` | Stessa preparazione per frame, ma vengono considerate anche le posizioni X−24..−1; dominio X−24..319, Y0..199. |
| `rastercollisions=1`, `leftmcm=0` | La preparazione non alza il latch; ogni linea completata aggiunge il proprio riepilogo. Per le collisioni si considera anche X320..511, pur senza disegnare il bordo. |
| `rastercollisions=1`, `leftmcm=1` | Stessa temporizzazione, con dominio orizzontale−24..511; la visualizzazione resta X0..319. Y fuori0..199 non produce collisioni. |

Riferimenti: `plus64_sprite.c`; `plus64vice.c`. La risorsa per linea si può cambiare soltanto con `$FD90=0`; il cambio scarta la vecchia rappresentazione alpha, ma conserva il latch già pendente. (`plus64vice.c`)

Quando uno slot viene riutilizzato per un altro nemico, il bit continua a identificare lo **slot**, non l'identità dell'oggetto del gioco. Consumare e attribuire gli eventi nella fascia corretta oppure usare collisioni software sugli oggetti logici. Non interpretare un vecchio bit rimasto nel latch come un urto del nuovo assegnatario. (`plus64_sprite.c`; `plus64vice.c`)

## Formati packed: riferimento avanzato sperimentale

Le seguenti opzioni sono risorse HOST già implementate, non nuovi registri CPU. Non sostituire `$FD98` o i bit riservati con presunti selettori del formato. (`plus64vice.c`)

| packedcache | leftmcm | `$FD92` dello slot=0 | `$FD92` dello slot=1 |
| --- | --- | --- | --- |
| 0 | 0 | Monocromatico normale63 byte | Raw8bpp normale504 byte |
| 1 | 0 | Monocromatico normale63 byte | Packed MCM |
| 1 | 1 | Packed HIRES | Packed MCM |
| 0 | 1 | Configurazione rifiutata dal setter | Configurazione rifiutata dal setter |

La scelta è derivata da `plus64_sprite.c`; il vincolo su `leftmcm` è in `plus64vice.c`. Attivare `packedcache` **da solo non converte** i pattern monocromatici nel formato HIRES packed.

Ogni record packed occupa una posizione allineata a 1024 byte nel backing16 KiB: basi$0000,$0400,...,$3C00, per un massimo di 16 record. Il puntatore completo deve coincidere col suo valore mascherato a 14 bit: un alias$4000 non è accettato. Un record non valido viene saltato dal renderer, senza assegnare un nuovo registro di errore. (`plus64_sprite.c`)

| Offset dalla base | Dati consumati dal decoder |
| --- | --- |
| `$200` | Byte63 del blocco RAW64 inverso: non è un pixel né un registro. Nel formato base è ignorato dal disegno; negli estesi può selezionare materiale, orientamento sparse o maschera invisibile. |
| `$201..$23F` | I63 byte di immagine originali in ordine inverso: il byte logico `i` si legge a `base+$23F-i`, per `i=0..62`. |
| `$240` | MCM: deve essere0. HIRES packed: spostamento sorgente orizzontale0..23. |
| `$241` | Tipo esatto:1 per MCM,0 per HIRES packed. Non è una maschera di bit liberamente combinabili. |
| `$242` | Indice palette per la coppia MCM `11`. |
| `$243` | Indice palette per la coppia MCM `10`. |
| `$244` | Indice palette per la coppia MCM `01`. |
| `$245` | Marker di validità: deve essere **esattamente `$A5`**. |

Riferimenti: `plus64_sprite.h`; `plus64_sprite.c`. Gli altri byte del record non sono letti da questi rami del renderer; questo non li dichiara automaticamente liberi se il motore usa la stessa area per una cache o un backup.

Nel motore C64 riutilizzato, il byte63 ha anche una funzione di tag di orientamento del motore. L'orientamento del motore appartiene al chiamante; il bridge conserva il byte nella chiave. Il formato base non lo usa come immagine, mentre le estensioni sottostanti ne interpretano tag precisi. Non trasferire i suoi eventuali bit in `$FD95` o nel byte tipo `$241`. (`engine/reuse/native_sprite_cpu.py`; `plus64_sprite.c`)

Nel packed MCM ogni byte contiene quattro coppie di bit, dalla più significativa. La coppia0 è trasparente;1,2,3 scelgono rispettivamente `$244,$243,$242`. Ogni coppia occupa **due pixel orizzontali** del formato 24×21. Anche qui un indice chiave121..255 è scartato; l'indice0 rimane nero opaco. Nel formato base il colore del descrittore non sostituisce queste tre chiavi; i materiali estesi possono invece sostituirle o ombreggiarle senza cambiare la coppia0 trasparente. (`plus64_sprite.c`)

Nel packed HIRES si usano i bit dei63 byte inversi e il colore del descrittore. Il decoder legge `source_x = pixel_x + record[$240]`; oltre23 scarta il pixel. È uno spostamento logico della sorgente, senza ricircolo dei bit persi a destra. Non è un cambiamento della posizione X del descrittore. (`plus64_sprite.c`)

### Proiezioni negative del profilo leftmcm

Queste regole non si applicano al normale raw8bpp. Con `packedcache=1` e `leftmcm=1`:

- Packed MCM: Xgrezza488..511 diventa−24..−1, anche senza espansioneX.
- Packed HIRES: la stessa conversione X avviene **solo quando l'espansioneX è attiva**; HIRES non espanso non interpreta488..511 come negativi.
- Per entrambi i tipi, Ygrezza215..255 diventa−41..−1. I valori 206..214 non fanno parte della conversione e restano positivi.

Sono proiezioni condizionali del publisher esistente, non una modalità signed generale a 9/8 bit. Le coordinate positive, l'espansione e il clipping continuano ad applicarsi dopo queste conversioni. (`plus64_sprite.c`)

### Cambiare profilo senza cache incoerenti

Prima del cambio scrivere `$FD90=0`. Un cambio di `packedcache` è rifiutato con output abilitato e invalida il marker `$245` di tutti i 16 record, **in entrambe le direzioni**. Il solo cambio risorsa non converte i dati: ricostruire o ricaricare i pattern nel formato nuovo prima di abilitarli. (`plus64_sprite.c`; `plus64vice.c`)

`leftmcm` si abilita solo con `packedcache` già attivo e output disabilitato; non si può disabilitare `packedcache` finché `leftmcm` o `mixedsprites` sono attivi. Il cambio di `rastercollisions` richiede anch'esso output disabilitato. Per tornare al formato normale: disabilitare l'output, togliere `mixedsprites`, togliere `leftmcm`, togliere `packedcache`, caricare i pattern raw/mono, impostare i descrittori e pubblicare `$FD90` per ultimo. (`plus64vice.c`)

## Formati grafici estesi correnti

Queste funzioni si attivano esplicitamente con le risorse HOST, prima di abilitare gli sprite:

```text
-plus64packedcache -plus64leftmcm -plus64mixedsprites
```

`mixedsprites` richiede `packedcache`; `leftmcm` serve al percorso HIRES packed. Il cambio formato con output attivo viene rifiutato. L'estensione non aggiunge slot o banchi. I materiali sprite funzionano anche nel profilo nativo16 KiB; i livelli che leggono la RAM principale, descritti più sotto, richiedono `mainram`. Il decoder corrente è in `plus64_sprite.c`, `draw_masked_common`, con configurazione e snapshot in `plus64vice.c`.

### RAW8 misto e colore materiale

Con FD92 bit dello slot=1, un puntatore il cui bit 14 è1 e bit 15 è0 seleziona RAW8 misto: i 14 bit bassi indirizzano504 byte nello stesso backing. Per esempio `$4800` significa RAW8 all'offset `$0800`. L'intera immagine deve rientrare nel banco, senza wrap. Un puntatore non taggato conserva il significato packed MCM. Espansioni e collisioni restano ordinarie. Con `leftmcm` attivo il RAW8 misto applica anche le proiezioni del publisher: Xgrezza488..511 diventa−24..−1 e Ygrezza215..255 diventa−41..−1; queste eccezioni non si applicano al RAW8 normale con packedcache disattivo.

Per una maschera compatta valida, il bit 7 del **colore del descrittore** richiede un materiale e i 7 bit bassi scelgono il colore0..120. Nel packed MCM si può anche usare il **byte63 sorgente** `$80 | colore`, cioè tag `$80..$F8`. Il RAW8 misto bypassa questi materiali. Il nero0 resta opaco: è la maschera a decidere dove esiste il pixel.

Il colore scelto è il massimo di luminanza, non soltanto la tinta. Per `c>0`, tinta=`1+(c-1) mod15`, luminanza massima=`(c-1) div15`. Il profilo radiale calcola `L=max(0,7-((x-lx)^2+(y-ly)^2) div40)` e poi `L=L*luminanza_massima div7`, con divisione intera. Il risultato compatto è `15*L+tinta`; `c=0` dà nero. Non si memorizza una seconda immagine per le ombre.

### Otto direzioni, fronte e diagonale per inchiostro

FD99 controlla slot 0/1, FD9A slot 2/3, FD9B slot 4/5 e FD9C slot 6/7. Lo slot pari usa il nibble basso. Per esempio `$FD99=$30` dà luce est allo slot 1 e mantiene il profilo storico nello slot 0.

| Valore | Luce | Punto nella griglia24×21 |
| --- | --- | --- |
|0|Storica, alto-sinistra|(6,5)|
|1|N|(12,0)|
|2|NE|(23,0)|
|3|E|(23,10)|
|4|SE|(23,20)|
|5|S|(12,20)|
|6|SW|(0,20)|
|7|W|(0,10)|
|8|NW|(0,0)|
|9|Frontale|(12,10)|
|10|Diagonale per inchiostro MCM|Usa i limiti opachi del fotogramma.|
|11..15|Riservati|Ripiego sul profilo storico.|

Le direzioni sono relative allo schermo; un mirror della sorgente non inverte il punto luce selezionato. La modalità10 conserva i tre inchiostri MCM e modifica soltanto la loro luminanza: aggiunge `2-floor(5*((x-xmin)*dy+(y-ymin)*dx)/(2*dx*dy))`, saturando0..7, con `dx,dy` almeno 1. I limiti provengono dalle coppie opache della maschera corrente. RAW8 e HIRES non diventano MCM per effetto del selettore10.

### Maschere sparse con rettangoli di palette

Il colore descrittore `$F9`, su un record HIRES packed valido, seleziona un formato sparse. Non va confuso con il tag sorgente F9 del packed MCM. La rappresentazione **sorgente** ha magic `A7`, byte1=`S=3+4*N`, byte2=colore/materiale di base. Seguono `N` rettangoli da quattro byte: limiti little-endian a 20 bit `x0|(y0<<5)|(x1<<10)|(y1<<15)`, poi colore/materiale. I limiti sono inclusivi e devono stare entro 24×21; gli ultimi rettangoli hanno precedenza solo sui pixel già opachi.

A byte `S`, otto byte di occupazione indicano quali byte bitmap sono nonzero, nell'ordine inverso62..0, bit alto per primo; seguono i valori nonzero nello stesso ordine. Tutte le letture devono rientrare nei byte0..62. Il bit 7 del byte63 applica il mirror orizzontale alla maschera. Un record malformato non viene disegnato. La decodifica usa una maschera HOST transitoria di 63 byte, non una RAM ospite aggiuntiva.

Gli inchiostri0..120 sono solidi; bit 7 in un colore richiede il materiale sui 7 bit bassi. Con selettore9 e profilo frontale sparse, il rilievo segue le estremità del tratto opaco di ogni riga, invece del solo centro del rettangolo. Un normale bitmap senza magic A7 ma con selettore F9 usa l'inchiostro shared1 conservato nella cache. I rettangoli di palette non possono introdurre pixel nuovi o modificarne le collisioni.

### Maschere invisibili e priorità

Nel packed MCM, byte63 sorgente F9 significa **collision-only** dal profilo15: la maschera continua a partecipare alle collisioni ma non emette pixel e non occupa priorità visiva. Il tag FA, dal profilo16, è invece una **maschera occludente invisibile**: continua a reclamare la priorità originale dello slot, nascondendo gli sprite successivi nei pixel coperti e lasciando visibile la scena sottostante. Non disegna nero o un colore di trasparenza; i 63 byte della maschera e le collisioni restano invariati.

Per questi profili, l'alpha di visualizzazione contiene soltanto gli sprite visibili. I riepiloghi separati per linea conservano anche le collisioni delle maschere invisibili. Un chiamante differito deve usare il riepilogo collisioni previsto, non ricavare tutte le collisioni dall'alpha visivo. I tag F9/FA restano tag ordinari nei vecchi profili che non ne dichiarano il supporto.

## Livelli di colore, scena e interfacce native

Nel profilo `mainram` esteso, FD9D/FD9E puntano a descrittori nella **RAM principale già esistente**; FD9F bit 0 ne abilita l'interpretazione. Il renderer percorre al massimo32nodi per passaggio. Il campo `next` è little-endian; zero termina la lista. Il byte11 sceglie il tipo, e il resto dipende dal tipo: non si possono combinare liberamente flag diversi. Coordinate base x,y,w,h sono in celle8×8 e devono rientrare nel320×200.

| Tipo nel byte11 | Dimensione | Funzione |
| --- | --- | --- |
|0|12 byte|Ombreggiatura diagonale di rettangolo, con chiave sfondo.|
|1|20 byte|Stessa luce, limitata al foreground di caratteri attesi e bitmap/glifi correnti.|
|2|24 byte|Scena/materiali con stream condivisi di luminanza e selettore di glifi.|
|3|12 byte|Cornici e tasti dell'interfaccia da griglia compatta.|
|4|12 byte|Finestra post-sprite controllata da due coordinate RAM.|
|5|12 byte|Tinta tramite tavolozze compatte.|
|6|12 byte|Link condizionale generico.|
|7|20 byte|Tinta condizionale.|
|8|24 byte|Scena come tipo2, con protezione dei caratteri dell'interfaccia nativa.|

Questa tabella è un indice, non sostituisce i layout completi del capitolo8. Il formato dei nodi è software, non nuovi registri o un pool texture. Il programma deve riservarne i byte nel proprio budget e mantenerli validi per tutta la durata dei fetch.

Per il tipo0, i byte6..9 sono xmin,ymin,xmax,ymax locali in pixel; byte10 è la chiave compatta di sfondo. La luminanza TED dei pixel nonneri viene modificata dalla formula diagonale con saturazione0..7, preservando la tinta. Il tipo1 aggiunge quattro puntatori LE16: font, caratteri vivi, attributi vivi e caratteri attesi del riquadro. Si modifica soltanto il foreground del glifo corrispondente; attributo bit 3 seleziona coppie MCM, con coppia0 esclusa. Un carattere sostituito dall'interfaccia non viene reinterpretato come il vecchio oggetto.

Il tipo2 aggiunge due stream: sfondo e tile materiale. Gli stream sono concatenazioni di segmenti `[nextLE16,length8,payload]`; l'immagine comincia con larghezza e altezza LE16, poi bande `[ripetizioni,numero_token,token...]`. Ogni token contiene luminanza nei 3 bit alti e lunghezza meno1 nei 5 bit bassi. Il selettore software associa banchi/range di glifi ai materiali. Non si tratta di una bitmap RGB separata, né il renderer conosce indirizzi o classi di oggetti di un gioco specifico.

Il tipo8 condivide il layout24 byte del tipo2. Byte12 impacchetta banco sorgente richiesto nei bit 0..2 e ultimo glifo nativo nei bit 3..7; byte13 conserva il byte alto della base font allineata. Byte22 impacchetta inchiostro testo nel nibble alto e tinta di ripiego nel basso; byte23 è il glifo del bordo pieno. Il puntatore di controllo nei byte20/21 sceglie il banco da `(RAM[controllo]>>1)&7`; il byte a `controllo-3` è l'enable sprite della vista logica standard.

La protezione nativa si attiva quando banco e vista corrispondono e **almeno un byte dell'intero intervallo font dei glifi configurati è nonzero**. Il primo byte o il primo glifo possono quindi essere vuoti. Una cella con inchiostro corrispondente e glifo nell'intervallo conserva foreground e sfondo solidi originali; il glifo di bordo è protetto se adiacente, anche in diagonale, a una cella di testo corrispondente. Questo include lati e angoli del bordo di una cella. Con banco errato o sprite sorgente disabilitati, il proprietario protetto sopprime scena e luci degli oggetti; un proprietario condizionale attivo può selezionare un'altra catena. I controlli sono su dati selezionati dal programma, non su costanti di un particolare titolo.

Il tipo4 si applica solo con FD9F bit 3=1, dopo gli sprite. Byte6/7 e8/9 puntano rispettivamente ai limiti superiore e inferiore in coordinate pixel globali Y; byte10 è un **codice TED0..127**, non un indice compatto sprite. Nell'intersezione del rettangolo e della banda `[alto,basso)` il nodo sostituisce i pixel con quel codice. Durante questa finestra la protezione UI del tipo8 è sospesa, così una maschera di apertura/chiusura può restare sopra a una scena migliorata anche se la vista sorgente cambia temporaneamente. FD9F bit 1 o bit 2 richiedono invece nero sull'intera area di presentazione.

L'ordine effettivo per linea è: rendering TED, luce dei livelli, materiali/scena, sprite, finestra tipo4 e mascheramento nero di presentazione. Perciò la protezione del testo o il colore di sfondo non cancellano uno sprite già emesso. Le maschere FA possono invece occultare sprite con priorità inferiore secondo le regole descritte sopra. I livelli non scrivono la RAM sorgente né cambiano le collisioni.

### Versione serializzata e esempio corrente

Il contenitore PLUS64 conserva dimensione e backing del contratto RAM80. Nel suo header HOST, byte72 abilita i formati misti;73 la palette materiale completa;74 sparse;75 direzioni;76 rilievo frontale sparse;77 luci dei livelli;78 diagonale per inchiostro;79 versione della scena, attualmente17. Questi byte non sono registri 6502. Le sezioni storiche che li dichiaravano riservati appartengono ai vecchi profili; non vanno applicate al formato corrente. Il reader convalida combinazioni e CRC prima del ripristino; un vecchio eseguibile può rifiutare un formato nuovo.

L'esempio aggiornato `sdk-current/material-example.asm`, con include e builder forniti, mostra tutti i 121 colori di highlight e le direzioni1,3,9 nel profilo nativo16 KiB. Carica un'unica maschera nuova e generica nella vista del banco 2 e seleziona le ombre via descrittore, senza un'immagine per ogni colore. Il PRG è921 byte, con ingresso `$1100` e fine codice/dati `$1398`; usa video TED entro `$3F3F` e riserva un record cache1 KiB nel banco 2. Il suo README spiega costruzione, avvio e diagnostica.

Le verifiche conservate coprono due build identici,363 combinazioni colore/direzione del renderer C, e500fotogrammi del programma su ciascun ospite C16 e Plus/4. Sono prove software specifiche dell'esempio e delle fonti indicate, non collaudo di circuiti fisici o di qualsiasi programma futuro.

## Debugger e limiti del collaudo

Una lettura CPU di `$FD91` azzera il latch e una lettura CPU di `$FD96` incrementa il puntatore. Il callback diagnostico **peek** restituisce invece il latch o il byte corrente senza tali effetti. Una vista del debugger che usa peek non dimostra che il programma abbia consumato una collisione; confrontare sempre il tipo di accesso. (`plus64_sprite.c`; `plus64vice.c`)

I comandi del monitor e gli eventuali helper di iniezione tastiera dei banchi di prova sono strumenti HOST, non istruzioni6502 o registri della cartuccia. Non trasformare una sequenza observer in un requisito del programma o dell'avviatore di produzione; il programma deve usare le normali periferiche di input.

Le prove CPU 6502, le periferiche simulate, il runtime VICE normale, gli observer, Wine e una cartuccia fisica sono livelli distinti. Per il proprio gioco conservare almeno: hash di eseguibile e asset, opzioni effettive, stato degli slot, immagini reali in movimento e verifica del latch con le letture CPU previste. Un'immagine ricostruita direttamente dai descrittori finali non sostituisce il framebuffer per qualificare un multiplex: la funzione di disegno diretto legge uno stato corrente, mentre il percorso di visualizzazione applica pubblicazioni alle singole linee. (`plus64vice.c`)

# 4. SID e modem

Il SID produce audio; il modem espone un flusso a polling. Nessuno dei due
fornisce una CIA o un interrupt NMI al programma. Gli indirizzi e i clock
seguenti appartengono all’implementazione corrente RAM80, distribuita con
PE SHA256 `08d3e87f84140fe13014213beb32bf7635de12b715769d995efc0658bf08ddfa`
(6.617.154 byte, simboli di debug rimossi senza cambiare le sezioni di codice
e dati caricate). Gli inventari `SID_API.json` e `MODEM_API.json` del manuale
precedente restano evidenze storiche; per capacità e protocolli correnti
fanno fede i sorgenti e le indicazioni aggiornate di questo capitolo.

## 4.1 Attivare un SID con impostazioni riproducibili

Abilitare plus/64 attiva il SIDcart di VICE se non è già attivo, senza
sovrascrivere un SIDcart configurato dall'utente. Pertanto un launcher deve
specificare indirizzo, modello e clock, dopo `-default` e la scelta
dell'ospite. Per il profilo audio usato dai giochi distribuiti:

```text
-sound -sidenginemodel 256 -sidcartaddress 0xFD40 -sidcartclock 0
```

`256` seleziona reSID/MOS6581; `257` seleziona reSID/MOS8580. Non sono
registri che il gioco può cambiare scrivendo un byte. I due modelli hanno
differenze analogiche, di filtro e di comportamento dei campioni digitali:
sceglierne uno e collaudare il gioco con quello. [SID-1, SID-2]

### La finestra effettiva finisce a `$FD5D`

Il dispositivo VICE registra **`$FD40..$FD5D`**, con maschera interna `$1F`
e `IO_MIRROR_NONE`. `$FD5E` e `$FD5F` non sono decodificati come SID da questo
SIDcart. Non usare quegli indirizzi come specchi o come nuovi registri.
La notazione convenzionale «32 registri SID» non estende la finestra
effettivamente registrata. Esiste una configurazione alternativa a
`$FE80..$FE9D`, ma non è il profilo plus/64 adottato qui. [SID-1]

## 4.2 Mappa dei registri SID

Le tre voci hanno lo stesso schema di sette registri. `b` è la base della
voce: `$FD40`, `$FD47` oppure `$FD4E`. Gli offset indicati sono relativi a
questa base, non a `$D400` del C64. [SID-3]

| Registro | Voce 1 | Voce 2 | Voce 3 | Bit e uso |
|---|---|---|---|---|
| `b+0` | `$FD40` | `$FD47` | `$FD4E` | Frequenza, byte basso |
| `b+1` | `$FD41` | `$FD48` | `$FD4F` | Frequenza, byte alto |
| `b+2` | `$FD42` | `$FD49` | `$FD50` | Pulse width, bit 0–7 |
| `b+3` | `$FD43` | `$FD4A` | `$FD51` | Pulse width, bit 8–11 nei bit 0–3; gli altri bit non modificano la larghezza |
| `b+4` | `$FD44` | `$FD4B` | `$FD52` | Controllo forma d'onda e gate |
| `b+5` | `$FD45` | `$FD4C` | `$FD53` | Attack nei bit 7–4, decay nei bit 3–0 |
| `b+6` | `$FD46` | `$FD4D` | `$FD54` | Sustain nei bit 7–4, release nei bit 3–0 |

Il registro di controllo usa questi bit:

| Bit | Maschera | Funzione |
|---:|---:|---|
| 0 | `$01` | GATE: fronte 0→1 avvia l'attacco, fronte 1→0 avvia il rilascio |
| 1 | `$02` | SYNC dell'oscillatore rispetto alla voce sorgente |
| 2 | `$04` | Ring modulation per la componente triangolare |
| 3 | `$08` | TEST: controllo/reset dell'oscillatore; non è un reset generale ADSR |
| 4 | `$10` | Triangolare |
| 5 | `$20` | Dente di sega |
| 6 | `$40` | Impulso, con larghezza a 12 bit |
| 7 | `$80` | Rumore |

Più forme selezionate producono forme combinate proprie del SID, non una
somma arbitraria di generatori. SYNC e ring modulation usano il collegamento
circolare delle voci; richiedono una configurazione consapevole anche della
voce sorgente. Per una nota nuova, lasciare realmente basso GATE prima del
fronte alto: riscrivere `$11` quando GATE è già uno non genera un nuovo
attacco. Non aspettarsi che TEST azzeri il contatore dell'inviluppo. [SID-3]

### ADSR

Ogni parametro A/D/S/R è un nibble 0–15. Il sustain seleziona un livello
`nibble × $11`, da `$00` a `$FF`; non è una durata. Attack, decay e release
selezionano velocità dell'inviluppo. Il codice reSID conserva i confronti
del rate counter seguenti:

| Nibble | Valore di confronto reSID | Attacco nominale indicato nei commenti del modello |
|---:|---:|---:|
| 0 | 8 | 2 ms |
| 1 | 31 | 8 ms |
| 2 | 62 | 16 ms |
| 3 | 94 | 24 ms |
| 4 | 148 | 38 ms |
| 5 | 219 | 56 ms |
| 6 | 266 | 68 ms |
| 7 | 312 | 80 ms |
| 8 | 391 | 100 ms |
| 9 | 976 | 250 ms |
| A | 1953 | 500 ms |
| B | 3125 | 800 ms |
| C | 3906 | 1 s |
| D | 11719 | 3 s |
| E | 19531 | 5 s |
| F | 31250 | 8 s |

Questi tempi sono nominali, non scadenze esatte in millisecondi: dipendono
dal clock e dallo stato del contatore. Decay e release usano inoltre
divisioni esponenziali a tratti, quindi non adottare la colonna «attacco»
come loro durata. Un cambio ADSR durante una nota può incontrare il
comportamento del rate counter, incluso il noto ritardo ADSR. [SID-4]

### Filtro, volume e letture

| Indirizzo | Uso |
|---|---|
| `$FD55` | Cutoff basso: soltanto bit 0–2 |
| `$FD56` | Cutoff alto: otto bit; `cutoff = (alto << 3) | (basso & 7)` |
| `$FD57` | Risonanza bit 7–4; invio al filtro di voce 1/2/3 e ingresso esterno nei bit 0/1/2/3 |
| `$FD58` | Volume bit 3–0; low-pass bit 4, band-pass bit 5, high-pass bit 6; bit 7 esclude la voce 3 dal percorso diretto |
| `$FD59` | Lettura POTX, dipendente dagli ingressi/configurazione emulata |
| `$FD5A` | Lettura POTY, stesso vincolo |
| `$FD5B` | Lettura uscita oscillatore della voce 3 |
| `$FD5C` | Lettura inviluppo della voce 3 |
| `$FD5D` | Offset SID `$1D` senza funzione di sintesi definita |
| `$FD5E/$FD5F` | Fuori dalla finestra SIDcart registrata |

Il cutoff a 11 bit non corrisponde a una conversione lineare universale in
hertz: filtro e modello del chip contano. Il bit di ingresso esterno non
dimostra che una cartuccia fisica disponga già di un percorso analogico
realizzato. Volume zero silenzia l'uscita, senza fermare necessariamente gli
oscillatori o la sequenza musicale. [SID-3, SID-5]

I registri di sintesi sono **scrivibili, non normali celle RAM leggibili**.
Una lettura CPU di un registro write-only restituisce il comportamento del
bus SID emulato, non una copia affidabile del valore impostato. Conservare
un'ombra RAM dei propri valori; usare `STA`, non `INC/ASL` sui registri SID.
L'emulatore modella anche le scritture ulteriori delle istruzioni RMW.

Il peek del debugger è diverso: `sid_peek_chip()` restituisce l'array
`siddata` delle ultime scritture e non campiona realmente OSC3/ENV3. Con il
suono disabilitato, le letture CPU hanno un fallback software: non usarle
per dimostrare un oscillatore attivo o per una sorgente casuale indipendente
dalla configurazione audio. [SID-6]

## 4.3 Clock: C64, TED e impostazione «native»

Per una forma periodica, con valore di frequenza `N` a 16 bit:

```text
f_nota = N × f_clock_SID / 2^24
N = arrotonda(f_nota × 2^24 / f_clock_SID)
```

Con `-sidcartclock 0`, il runtime inizializza il SID PAL a **985.248 Hz**
(NTSC: 1.022.730 Hz). Il ponte converte i clock base VICE nel dominio SID
con rapporto razionale e resto conservato, anche quando il buffer audio
viene consumato solo in parte. Questo non rende identiche le temporizzazioni
del codice CPU C64 e TED. [SID-1, SID-7]

**Attenzione al significato di `-sidcartclock 1` in questa build:** il codice
passa al SID il valore `cycles_per_sec` della macchina, che in PAL è
**1.773.447 Hz**. Il nome «PLUS4/native clock» dell'opzione non indica qui
886 kHz. Quest'ultimo è il valore `1.773.447 / 2 = 886.723,5 Hz` dei tick dei
timer TED e di una possibile scelta di clock fisico lento; non è il valore
passato al SID dall'opzione 1 del runtime conservato. Non copiare tabelle
di note per 886 kHz su quel profilo. [SID-1, SID-7]

Esempio La4, circa 440 Hz, con il profilo C64 PAL: `N=7493=$1D45`, frequenza
effettiva calcolata circa **440,029 Hz**. Il byte basso è `$45`, quello alto
`$1D`. Una nota triangolare sulla prima voce, all'inizializzazione di un
programma che possiede il SID, può essere impostata così:

```asm
        lda #0
        sta $fd44       ; GATE basso, nessuna forma selezionata
        sta $fd57       ; nessun invio al filtro per questo esempio
        lda #$09
        sta $fd45       ; attacco 0, decay 9
        lda #$f4
        sta $fd46       ; sustain F, release 4
        lda #$45
        sta $fd40
        lda #$1d
        sta $fd41
        lda #$0f
        sta $fd58       ; volume massimo, percorsi diretti
        lda #$11
        sta $fd44       ; triangolare + fronte GATE alto
        rts
; In un tick successivo, per rilasciare la nota:
rilascio:
        lda #$10
        sta $fd44       ; stessa forma, GATE basso
        rts
```

Le altre due voci devono essere inizializzate o gestite dal proprio driver.
Il campione non assegna un timer e non impone una durata: il tick del gioco
deve decidere quando chiamare `rilascio`. Se un IRQ musicale scrive lo
stesso SID, coordinare le scritture con quel driver.

La dimensione del buffer audio VICE, per esempio `-soundbufsize 64`, cambia
la latenza host, non la formula delle note e non la frequenza degli IRQ.
Una conversione C64 che usava CIA/NMI deve adattare separatamente il proprio
scheduler: il SID non genera quegli interrupt.

## 4.4 Modem: registri e stato

Il modem è disponibile a `$FDF0..$FDF7` quando plus/64 è abilitato.
Espone una FIFO RX da **128 byte**, una FIFO TX da **128 byte** e un buffer
comandi da **256 byte**: **512 byte complessivi**, tutti compresi negli
**80 KiB = 64 KiB cartuccia + 16 KiB interni**. Non è una ACIA e non contiene
registri CIA. Il backend attuale usa socket TCP del computer host. [MOD-1]

Le FIFO non sono memoria privata del modem. Nel profilo nativo sono alias
del banco cartuccia 3, offset `$3E00..$3FFF`; nel profilo MainRAM sono alias
dei 16 KiB interni, offset `$0000..$01FF`, accessibili anche dalla porta sprite.
Il programma deve riservare l’area prima di usare il modem ed evitare
scritture concorrenti da parte di sprite, audio o altri utilizzatori. Quando
il modem è disconnesso, senza chiamata, code o comando parziale, un programma
che non esegue I/O modem può prestare l’area ad altre risorse. Deve però
restituirgliela prima di avviare comandi o connessioni.

| Indirizzo | Lettura CPU | Scrittura CPU |
|---|---|---|
| `$FDF0` DATA | Estrae un byte RX; se vuota restituisce zero | In modalità comandi alimenta il parser; connesso accoda un byte TX |
| `$FDF1` STATUS | Bit di stato della tabella seguente | Ignorata |
| `$FDF2` CONTROL | Sempre zero | Bit 0 reset; altrimenti bit 1 disconnessione; bit 2 cancella overrun |
| `$FDF3` BAUD | Sempre `$04`, valore descrittivo «9600» | Ignorata: non regola una seriale reale |
| `$FDF4` RX COUNT | Byte pendenti RX, 0–128 | Ignorata |
| `$FDF5` TX COUNT | Byte pendenti TX, 0–128; non è lo spazio libero | Ignorata |
| `$FDF6` | Firma `$64` | Ignorata |
| `$FDF7` | Versione protocollo condiviso `$03` | Ignorata |

| STATUS bit | Maschera | Significato quando è 1 |
|---:|---:|---|
| 0 | `$01` | RX contiene almeno un byte |
| 1 | `$02` | TX ha spazio per almeno un byte, anche quando non si è connessi |
| 2 | `$04` | Connesso |
| 3 | `$08` | Connessione in corso |
| 4 | `$10` | Overrun latched: una scrittura o risposta locale ha superato lo spazio disponibile |
| 5 | `$20` | Né connesso né in chiamata; stato offline, non un evento latched |
| 6–7 | `$C0` | Zero nella versione attuale |

Un byte RX zero è un dato valido. Controllare STATUS bit 0 prima di leggere
DATA, senza interpretare zero come «FIFO vuota». Leggere STATUS non cancella
alcun flag. Un peek del dispositivo su DATA mostra il prossimo byte senza
consumarlo; il normale `PEEK` BASIC è invece una lettura CPU e lo consuma.
I contatori descrivono i byte effettivamente accodati nei buffer da 128 byte;
non esiste la precedente capacità privata di 8 KiB per coda. [MOD-1]

CONTROL è un insieme di azioni, non uno stato memorizzato: `$01` fa reset;
`$02` interrompe il collegamento e inserisce `OK` in RX; `$04` cancella solo
l'overrun. Se sono presenti sia bit 0 sia bit 1, prevale il reset; bit 2 viene
poi gestito comunque. Non esiste un enable IRQ. La disconnessione svuota TX
ma conserva RX; il reset svuota entrambe le FIFO, il comando parziale e
l’overrun, disconnette e ripristina echo disattivato. Il reset modifica
indici e stato del dispositivo: **non azzera il banco di RAM condiviso**. [MOD-1]

## 4.5 Comandi AT effettivamente implementati

Inviare byte **ASCII**, terminando il comando con CR (`$0D`). LF viene
ignorato. Il parser è case-insensitive per i comandi, ma conserva il nome
host. Le risposte hanno forma `CR LF testo CR LF`. Non serve connettersi
a una rete per provare `AT`. [MOD-2]

| Comando | Risultato |
|---|---|
| `AT` | `OK` |
| `ATE0` / `ATE1` | Disattiva/attiva echo locale dei byte in modalità comandi; `OK` |
| `ATZ` | Reset del modem e `OK` |
| `ATH` | Disconnessione e `OK`, quando il parser è in modalità comandi |
| `ATDhost` / `ATDThost` | Tenta TCP verso porta 23 |
| `ATDhost:porta` / `ATDThost:porta` | Porta decimale 1–65535; host non vuoto, massimo 219 byte |

Connessione immediata o completata al poll successivo: `CONNECT 9600`.
Fallimento o perdita del collegamento: `NO CARRIER`. Comandi non supportati
o sintassi non ammessa: `ERROR`. Non assumere `ATH0`, escape `+++`, registri
S, modalità numerica delle risposte o sequenze di comandi concatenate:
non sono implementati.

Il buffer comando contiene al massimo 255 caratteri stampabili; un ulteriore
carattere causa `ERROR`, azzera la lunghezza e viene scartato. Backspace
(`$08`) e DEL (`$7F`) cancellano un carattere, se presente. Con echo attivo
anche i caratteri di controllo vengono accodati prima dell'elaborazione.

**Quando connesso, ogni byte scritto su DATA è traffico da trasmettere.**
La stringa `ATH` non viene interpretata localmente e `+++` non cambia
modalità. Per chiudere dal programma usare CONTROL bit 1. Durante la fase
di chiamata il parser resta attivo: il programma può interromperla tramite
CONTROL oppure `ATH`.

## 4.6 Polling, Telnet e limiti del backend

`machine_vsync_hook()` chiama `plus64vice_frame()`, che esegue il poll modem
una volta per aggiornamento video. La lettura di STATUS non forza il poll.
Il poll prova l'avanzamento della connessione, invia una porzione contigua
di TX e riceve soltanto nello spazio contiguo libero della coda RX: al massimo
128 byte, spesso meno per occupazione o avvolgimento del ring. Con RX piena
non legge dal socket e applica così backpressure al trasporto. La velocità
«9600» è descrittiva: non vengono simulati un baud rate UART, bit seriali,
RTS/CTS o tempi elettrici. Prevedere timeout del gioco, drain frequente di
RX e controllo dell'overrun. [MOD-3]

L'ingresso passa sempre attraverso una gestione Telnet minima:

- `IAC IAC` (`$FF $FF`) consegna un solo byte `$FF` al gioco.
- `WILL` e `DO` vengono rifiutati con `DONT` e `WONT`; `WONT/DONT` sono consumati.
- Le sottonegoziazioni vengono scartate fino a `IAC SE`.
- I dati ordinari sono byte in RX: non avviene conversione ASCII/PETSCII.

Non è un trasporto binario TCP totalmente trasparente. In uscita il codice
accoda i byte dell'applicazione senza raddoppiare automaticamente `$FF`;
un protocollo con peer Telnet deve gestire consapevolmente quell'escape.
Non vi sono TLS, autenticazione di servizio o protocollo HTTP nel modem.

Il socket è non bloccante, ma la risoluzione del nome con `getaddrinfo()`
è sincrona: una chiamata ATD con un nome problematico può fermare
temporaneamente l'interfaccia dell'emulatore. Per i collaudi riproducibili
usare un servizio di test locale e un timeout; non interpretare una pausa
DNS come un timer del gioco. [MOD-4]

### Due primitive non bloccanti

Il chiamante conserva il byte da inviare e riprova in un tick successivo
quando TX è piena. Un solo componente del gioco deve possedere il modem.

```asm
; Entrata A contiene il byte. Carry zero se consegnato, uno per riprovare.
modem_prova_tx:
        pha
        lda $fdf1
        and #$02
        beq tx_piena
        pla
        sta $fdf0
        clc
        rts
tx_piena:
        pla
        sec
        rts

; Carry uno se A contiene un byte valido, anche $00. Carry zero se vuoto.
modem_prova_rx:
        lda $fdf1
        and #$01
        beq rx_vuota
        lda $fdf0
        sec
        rts
rx_vuota:
        clc
        rts
```

In modalità comandi, «consegnato» significa passato al parser, non inviato
su TCP. In modalità dati significa accodato: non conferma che il peer lo
abbia ricevuto. Dopo un gruppo di invii controllare anche overrun, stato
connesso e risposte. Per una prova locale del parser inviare `$41 $54 $0D`
e raccogliere la risposta senza loop di attesa infinito.

## 4.7 Cosa prova il modello e cosa resta hardware

I checkpoint VSF correnti conservano stato locale, indici e tutti i byte RAM80
condivisi. Salvataggio e caricamento vengono rifiutati con modem connesso o
in chiamata, perché lo stato del peer TCP esterno non può essere riavvolto.
Un caricamento non riconnette automaticamente il peer.

Il modello documenta registri, FIFO condivise e API socket host. Non contiene un
firmware MCU della cartuccia, un modem seriale elettrico, un clock SID
misurato, alimentazioni analogiche o un circuito di interrupt aggiuntivo.
La cartuccia fisica deve rispettare il medesimo comportamento visibile;
quelle implementazioni e il relativo budget di memoria richiedono un
progetto e prove propri. Questo audit dei sorgenti non esegue connessioni
remote, un nuovo ascolto su Windows o un collaudo fisico.

## Riferimenti del capitolo

I percorsi seguenti sono relativi a `reference/vice/` nel pacchetto del
manuale e identificano i sorgenti correnti. Gli inventari storici e le prove
1.0 non sostituiscono i rapporti RAM80 e formato 17 della distribuzione.

- **SID-1:** `src/plus4/cart/plus4-sidcart.c`, decoder I/O SIDcart,
  `sidcart_sound_machine_init`, risorse di attivazione e clock;
  `src/plus4/plus64vice.c`, integrazione e configurazione plus/64.
- **SID-2:** `src/sid/sid-cmdline-options.c`, selezione engine/modello SID.
- **SID-3:** `src/resid/sid.cc`, letture e scritture dei registri;
  `src/resid/wave.cc`, `wave.h` e `voice.cc`, controllo delle forme d’onda,
  sincronizzazione e ring modulation.
- **SID-4:** `src/resid/envelope.cc`, contatori, tabelle e scritture ADSR.
- **SID-5:** `src/resid/filter.cc`, registri di cutoff, risonanza e modalità.
- **SID-6:** `src/sid/sid.c` e `src/resid/sid.cc`, percorsi read/peek,
  valori di bus e `siddata`.
- **SID-7:** `src/plus4/cart/plus64_sid_clock_ratio.h`, rapporto razionale;
  `src/plus4/plus4.h`, `plus4.c`, `src/sound.c`, `src/sid/sid.c` e
  `src/sid/resid.cc`, costanti e raccordo dei clock audio.
- **MOD-1:** `src/plus4/plus64_modem.h`, definizioni `P64_RX_CAP`, `P64_TX_CAP`,
  `P64_CMD_CAP`, viste sullo storage condiviso e API; `plus64_modem.c`,
  `p64_modem_init/reset`, `status`, `p64_modem_peek/read/store`.
- **MOD-2:** `src/plus4/plus64_modem.c`, funzioni `command` e
  `stream_from_device`.
- **MOD-3:** `src/plus4/plus64_modem.c`, `telnet_in` e `p64_modem_poll`;
  `plus64vice.c`, chiamata a `p64_modem_poll` nel percorso video.
- **MOD-4:** `src/plus4/plus64_net.c`, `net_open`, `net_state`, `net_send` e
  `net_recv`.

# 5. Costruire un gioco sulla piattaforma

## Una mappa iniziale riproducibile

L'esempio nativo impiega il bitmap TED multicolore nei primi 16 KiB. La
seguente disposizione è una scelta software degli esempi, non una nuova
decodifica della cartuccia:

| Area CPU | Uso consigliato nell'esempio |
| --- | --- |
| `$0000–$00FF` | Zero page: porti CPU e variabili; riservare esplicitamente quelle del gioco |
| `$0100–$01FF` | Stack6502; non depositare qui sprite o tabelle senza controllare la profondità |
| `$0200–$0FFF` | Area del sistema e workspace: non considerarla libera mentre si usa il KERNAL |
| `$1001…` | PRG con stub BASIC e programma dell'esempio, con limite prima di `$1800` |
| `$1800–$1BFF` | Attributi di luminanza TED,1024 byte |
| `$1C00–$1FFF` | Attributi di crominanza TED,1024 byte |
| `$2000–$3F3F` | Bitmap,8000 byte |
| `$3F40–$3FFF` |192 byte residui: utilizzabili solo se non già riservati dal proprio programma |

Altri giochi possono scegliere un layout diverso. Il programma deve
controllare che codice, stack, loader, buffer e video non si sovrascrivano.
Con il profilo plus/64 nativo il runtime impone **16 KiB CPU/TED sia al C16
sia al Plus/4**: non si può usare implicitamente la RAM interna aggiuntiva
del Plus/4. Un indirizzo alto può essere un alias della RAM bassa o una
finestra I/O/ROM, non spazio libero. Il profilo MainRAM è distinto: espone
i 64 KiB della cartuccia a CPU/TED e lascia i 16 KiB interni alla vista sprite.
In entrambi i casi il totale resta **81.920 byte**, con gli alias descritti
nel capitolo sulla memoria.

Un PRG contiene due byte iniziali con l'indirizzo di caricamento in ordine
low/high. Un PRG nativo caricato a `$1001` non può oltrepassare `$3FFF`
presumendo RAM interna aggiuntiva. Risorse più grandi richiedono una
strategia di caricamento nella SRAM già disponibile, non una scrittura
fuori dallo spazio nativo verificato.

## Sequenza di inizializzazione

1. Decidere quali servizi del sistema usare e quali variabili possiede il gioco.
2. Controllare `$FDEC=$64` e `$FDED=$05` prima di dipendere dagli alias RAM80.
   Se si usa il modem, verificare anche `$FDF6=$64`, `$FDF7=$03` e riservare
   i suoi 512 byte condivisi.
3. Disabilitare gli sprite durante il caricamento iniziale dei pattern.
4. Preparare bitmap e attributi TED.
5. Impostare puntatore di upload e caricare i pattern nella RAM sprite.
6. Inizializzare soltanto i registri SID necessari, con volume e gate noti.
7. Scrivere descrittori completi; pubblicare la maschera con FD90 per ultima.
8. Avviare il loop con un ritmo video esplicito.

I registri non documentati o riservati non devono essere usati come nuove
funzioni. Un valore che si rilegge correttamente non dimostra che il
renderer o un circuito lo utilizzi.

## Il loop principale

Un'organizzazione tipica è:

```text
attendi il prossimo fotogramma
leggi input e calcola i nuovi fronti dei pulsanti
aggiorna fisica e regole una sola volta
risolvi collisioni e conseguenze
prepara descrittori e avanzamento delle animazioni
aggiorna audio e HUD necessari
pubblica FD90
ripeti
```

Se il loop non raggiunge il proprio appuntamento raster, il gioco può
diventare lento o perdere parti degli sprite. Misurare il programma durante
colpi, esplosioni, ridisegno del punteggio e caricamenti, non soltanto quando
il protagonista è fermo.

L'emulatore può lavorare in Warp durante il caricamento automatico. Questa
è una funzione dell'ospite, non un clock della cartuccia e non un metodo
di sincronizzazione del gioco. Non usarla per compensare routine lente.

## Video TED e coordinate

Il rettangolo attivo è320×200 pixel fisici. Nel bitmap multicolore TED ogni
coppia di bit rappresenta due pixel orizzontali: il disegno ha quindi160
campioni orizzontali, mentre il sistema di coordinate sprite resta320.
Uno sprite16×16 del nostro SDK è16 pixel fisici di larghezza, non32.

Per la cella TED `(cx,cy)`, con 40 colonne e25 righe, e la riga interna `dy`:

```text
cell = cy * 40 + cx
attributi: $1800 + cell e $1C00 + cell
byte bitmap: $2000 + cell * 8 + dy
```

Il significato dei quattro valori di pixel multicolore è:

| Coppia | Colore TED |
| --- | --- |
| `00` | Colore di sfondo globaleFF15 |
| `01` | Hue dal nibble alto della crominanza, luminanza dai bit 0–2 dell'altro attributo |
| `10` | Hue dal nibble basso della crominanza, luminanza dai bit 4–6 dell'altro attributo |
| `11` | Colore globaleFF16 |

Per usare121 colori diversi nello stesso bitmap si scelgono attributi
diversi nelle celle; non si supera il numero di colori ammesso in una
singola cella. Le palette degli sprite usano invece il formato indicizzato
plus/64 descritto nel capitolo video.

## Input, sistema operativo e interrupt

L'SDK mostra il percorso effettivamente verificato per tastiera e joystick2.
Non copiare il polling CIA del C64: il C16/Plus/4 usa altri registri e
un diverso aggancio al TED. L'assenza di un joystick fisico nell'ospite
non impedisce l'uso del keyset configurato in VICE.

`SEI` disabilita IRQ, non NMI. Un gioco che disabilita gli IRQ deve curare
input, timer e avanzamento audio: l'orologio del KERNAL non va considerato
automaticamente in esecuzione. La cartuccia documentata non fornisce un
nuovo NMI equivalente a quello della CIA2 del C64.

Le routine KERNAL richiedono le proprie variabili e condizioni di ingresso.
Non chiamare LOAD, SAVE o stampa di sistema dopo averne sovrascritto lo
workspace, senza un protocollo di salvataggio e ripristino verificato.
L'esempio iniziale tiene le risorse essenziali nel programma e usa il
caricamento D64 normale, prima di entrare nel loop autonomo.

## Collisioni: disegno e regole sono due cose distinte

FD91 segnala sovrapposizioni fra sprite del dispositivo. Non rileva
piattaforme o muri TED, non applica penalità e non decide le regole del
gioco. Serve una politica software: rettangoli, maschere, collision map
oppure combinazioni delle tre.

Con artwork16×16 inserito in un record 24×21, gli otto pixel a destra e le
cinque righe sotto sono trasparenti. Il rettangolo visibile può essere16×16;
non deve diventare24×21 soltanto perché il record ha quella dimensione.
Se si vuole collisione pixel per pixel, leggere le proprie maschere: un
semplice rettangolo include anche eventuali fori interni della sagoma.

Il latch hardware usa i numeri degli otto slot. Quando si multiplexano
più personaggi sugli stessi slot, lo slot non è l'identità del personaggio.
Occorre conoscere la fascia e l'istante del test o usare collisioni software.

## Risorse e livelli

La SRAM a registri è adatta a conservare stanze, bitmap, tabelle e dati
compressi. La CPU non esegue istruzioni attraverso `$FDEA`. Nel profilo
nativo, per eseguire una routine conservata nella cartuccia occorre copiarla
in un’area CPU eseguibile e verificarne le rilocazioni. Nel profilo MainRAM
la cartuccia è già esposta nello spazio CPU: il codice si può eseguire al
corrispondente indirizzo CPU, rispettando la visibilità di ROM e I/O, senza
passare dalla porta dati.

Le porte SRAM e sprite sono **viste con alias**, non due pool aggiuntivi.
Nel profilo nativo la porta sprite indirizza il banco cartuccia 2: una
scrittura a quel banco tramite `$FDEA` modifica anche i dati visibili allo
sprite decoder. Nel profilo MainRAM la porta SRAM accede agli stessi
64 KiB esposti alla CPU, mentre `$FD96` accede ai 16 KiB interni. Un gestore
di risorse deve quindi registrare il proprietario di ogni intervallo e
coordinare caricamenti, codice, pattern, modem e audio. Non sommare gli
alias come memoria disponibile separata.

L'autoincremento FDEA si arresta sul confine del banco mediante wrap;
non seleziona automaticamente il banco successivo. Separare blocchi e
descrittori di risorsa in modo che il loader gestisca esplicitamente
l'attraversamento di `$3FFF`.

## Pubblicare un gioco

Distribuire PRG o D64, il profilo runtime richiesto, le istruzioni dei
comandi e l'hash della build. Indicare se servono formato raw, packed,
aggiornamento raster, MainRAM o formati estesi. MainRAM è ora un profilo
del contratto RAM80 comune, non un modo per aggiungere un secondo blocco
CPU da 64 KiB.

Per i file modificabili, usare una copia di lavoro. Per esempio il
porting di Impossible Mission scrive la classifica nel proprio D64:
sostituirlo automaticamente con una nuova immagine perderebbe quei dati.
Un record tenuto soltanto in RAM, invece, dura fino al reset.


## Budget delle risorse e caricamenti per fase

Per ogni risorsa registrare indirizzo iniziale, lunghezza, profilo, alias e
fase in cui è viva. Il totale fisico è 65.536 + 16.384 byte, non 64 KiB più
una cache sprite da 16 KiB più altre RAM audio o modem. La compressione
riduce dati sorgente e trasferimenti; un decoder temporaneo non autorizza
una seconda bitmap residente fuori dal budget. Uno stesso intervallo può
essere riutilizzato da loader, grafica o audio solo quando il proprietario
precedente ha terminato, e prima che i dati siano richiesti di nuovo.

I descrittori di materiale, le regioni di palette e gli stream di luminanza
dei formati correnti devono essere conteggiati nella stessa mappa. Nel
modello software il compositore li legge dalla RAM emulata; il costo e il
percorso di accesso di un’eventuale implementazione fisica richiedono un
progetto esplicito, come precisato nel capitolo video.

## Checkpoint e dati su disco

Il runtime corrente supporta snapshot VSF completi di RAM80: memorizza
tutti gli 81.920 byte e lo stato locale dei dispositivi, inclusi gli alias,
i registri e lo stato video necessario alla continuazione. Il contenitore
VSF Plus/4 2.1, il modulo PLUS64 1.0, il protocollo SRAM `$05` e la revisione
video 17 sono numeri distinti. Un file VSF può essere più grande di 80 KiB
perché include anche CPU, drive, periferiche e strutture serializzate
dell’emulatore; non è memoria aggiuntiva accessibile al gioco.

I vecchi checkpoint incompleti non possono recuperare byte mai salvati e
vengono rifiutati quando devono descrivere uno stato plus/64 completo.
Per un checkpoint autosufficiente, includere le immagini disco nelle
opzioni di salvataggio; altrimenti conservare anche i D64 associati. Il
SAVE originale di un gioco resta una funzione distinta: in Impossible
Mission registra la classifica e non sostituisce il checkpoint VSF. Il
modem deve essere disconnesso e senza chiamata pendente prima del salvataggio
o del caricamento.

# 6. Debug, strumenti e riuso di codice C64

## Le prove da tenere separate

| Prova | Cosa dimostra |
| --- | --- |
| Calcolo Python | Formati, indirizzi e trasformazioni dei dati nel programma di analisi |
| Simulazione6502 con periferiche stub | Esecuzione delle istruzioni e contratto degli stub usati |
| Moduli C reali del dispositivo | Comportamento di registri e renderer nelle funzioni compilate |
| VICE nativo | Interazione di CPU guest, TED e dispositivi del modello |
| PE Windows sotto Wine | Comportamento di quell'eseguibile e delle API ospiti simulate |
| Windows nativo | Esecuzione su un sistema Windows reale |
| Cartuccia fisica | Comportamento elettrico e temporale misurato su hardware |

Una riga «PASS» ha senso soltanto insieme a versione, input e ambito.
Un test con stato finale predisposto verifica il finale, non dimostra una
campagna intera vinta naturalmente. Il manifesto dell'SDK elenca le prove
effettivamente eseguite senza promuoverle a certificazione fisica.

## Un controllo pratico per ogni nuova build

- Verificare che codice e dati restino nei **65.536 + 16.384 byte** della
  macchina comune, senza contare due volte alias, cache, sorgenti compressi
  e buffer decodificati riutilizzati in fasi diverse.
- Provare primo avvio, reset e rientro al titolo.
- Provare i bordi: X255/256, X319, Y199 e dati a cavallo di un banco SRAM.
- Provare un pixel sprite0 opaco e uno 255 trasparente sullo stesso sfondo.
- Leggere il latch una volta, poi verificarne l'azzeramento e i nuovi eventi.
- Misurare il ritmo durante HUD, spari, collisioni e cambio scena.
- Verificare mute, rilascio delle note e frequenze SID con il clock scelto.
- Conservare la versione precedente e gli hash dell'eseguibile e del D64.

Non allargare automaticamente le tolleranze perché un test fallisce:
prima distinguere un problema del programma, dell'osservazione o della
configurazione dell'ospite. Per esempio un'uscita audio assente nel banco
Wine senza dispositivo sonoro non prova un errore dei registri SID.

## Monitor e acquisizioni

Usare breakpoint su funzioni note, acquisizioni RAM e immagini della canvas
VICE. Per i registri con effetti collaterali tenere conto del percorso
`read` rispetto a `peek`; il monitor può deliberatamente non consumare
FIFO o latch. Una prova della lettura CPU deve eseguire una `LDA` guest.

Le immagini vanno confrontate con lo stato della stessa fase del frame.
Se lo sprite cambia descrittore a metà schermo, una lettura RAM successiva
non ricostruisce da sola ciò che era già stato disegnato nelle righe alte.
Per il multiplex annotare fascia raster, slot, puntatore e maschera pubblicata.

L’input diagnostico `@k` usato da alcuni strumenti del progetto va letto
insieme al contratto di quello strumento o build osservatore: non è un
registro plus/64 disponibile al programma e non va assunto come comando
portabile di una distribuzione Windows. I giochi leggono
la tastiera o il joystick emulati, come nell'esempio SDK.

## Perché un porting C64 non è una sostituzione globale di indirizzi

I dati che rappresentano un indirizzo possono comparire come operandi,
tabelle di puntatori, codice generato o valori calcolati. Un numero uguale
a `$D400` dentro un bitmap non è per questo una scrittura SID.
Il codice può inoltre dipendere da VIC-II, CIA, ROM, vettori o temporizzazioni
non presenti sul C16/Plus/4.

Una procedura utile è:

1. Identificare con hash l'input e ricostruire il caricamento effettivo.
2. Disassemblare dagli ingressi noti e seguire il controllo di flusso.
3. Segnalare salti indiretti e parti non ancora risolte, senza indovinare.
4. Separare le logiche già indipendenti dall'hardware dagli accessi ai dispositivi.
5. Definire sostituzioni per siti e profili espliciti, verificando gli operandi.
6. Conservare il comportamento del gioco e confrontare le sequenze osservabili.

Il toolkit distribuito contiene `translate_core.py` per inventario D64,
estrazione e analisi, librerie6502 e builder per profili noti. Il decoder
documentato copre i 151 opcode ufficiali NMOS6502; non è la promessa che
qualsiasi gioco o opcode non documentato sia convertibile automaticamente.

Le patch disponibili per un dump noto non si applicano a una copia diversa
soltanto perché porta lo stesso nome. L'output di un'analisi RAM non è
automaticamente un D64 avviabile: loader, servizi, input, grafica, audio
e stato della partita devono essere integrati e collaudati.

## Primo percorso di apprendimento

Partire dall'esempio SDK; aggiungere un secondo sprite e una collisione,
poi una tabella di animazione nella SRAM. Solo dopo aggiungere caricamenti,
scroll o multiplex. Il manuale e l'esempio descrivono API correnti; gli
indirizzi o driver di una futura implementazione fisica andranno documentati
separatamente, quando definiti e verificati.


## Snapshot, ripristino e versioni da verificare

Un test di checkpoint deve confrontare tutta la RAM80, non soltanto la
finestra CPU visibile: 65.536 byte principali più 16.384 byte interni.
Verificare prima il ripristino immediato, poi la continuazione con gli
stessi input, preferibilmente anche in un nuovo processo e sull’altro
modello C16/Plus/4. Registrare revisione del contenitore VSF, modulo PLUS64,
configurazione di memoria e feature video; una lettura riuscita non basta
a provare che sia stato ripristinato lo stesso profilo.

Il runtime corrente usa contenitore Plus/4 VSF 2.1 e modulo PLUS64 1.0, con
protocollo SRAM `$05`, modem `$03` e revisione di scenario 17. I checkpoint
legacy privi dei byte RAM80 richiesti vengono rifiutati. Un modem connesso
o in chiamata impedisce salvataggio e caricamento: il test non deve
promettere di riavvolgere un peer remoto. Per il SID distinguere stato
digitale e scritture ai registri dall’identità del PCM analogico o della
storia del ricampionamento host.

## Identità della distribuzione finale

L’eseguibile Windows finale senza simboli di debug occupa **6.617.154 byte**
e ha SHA256:

```text
08d3e87f84140fe13014213beb32bf7635de12b715769d995efc0658bf08ddfa
```

La rimozione dei simboli di debug non cambia le sezioni caricate di codice
e dati; il rapporto di distribuzione conserva il confronto e la provenienza
dalla build completa. Il D64 Impossible Mission REV8R conserva codice e
dati della revisione qualificata. Le prove con pezzi o password già pronti
sono stati di test separati, non la partita normale e non una vittoria
naturale utilizzabile come certificazione di tutta la missione.

Le prove Linux C16/Plus/4 e quelle dell’eseguibile Windows tramite Wine
restano distinte da Windows nativo e dall’hardware fisico. Il controllo dei
byte RAM e dei registri non qualifica da solo il futuro arbitraggio del bus,
la contesa fra CPU e video, la banda del compositore o la sincronizzazione
di una cartuccia reale.

# 7. Riferimento rapido

Promemoria del runtime documentato, PE `08d3e87f…` (6.617.154 byte, debug rimosso). I dettagli, le eccezioni
e gli hash delle fonti sono nei capitoli 2–4 e negli inventari API JSON.
Le tabelle descrivono il software disponibile, non una cartuccia fisica già
certificata. `R` = lettura CPU, `W` = scrittura CPU.

## Profili e mappa generale

| Profilo | Contratto del programma |
|---|---|
| Nuovo gioco nativo | CPU/TED nei **16 KiB interni**, imposti anche su Plus/4; **64 KiB cartuccia** tramite porta; la vista sprite è il banco cartuccia 2 |
| `-plus64mainram` | CPU, TED e porta SRAM condividono i **64 KiB cartuccia**; la porta sprite vede i **16 KiB interni** distinti |
| Budget corrente | **65.536 + 16.384 = 81.920 byte**; nessuna RAM sprite/FIFO aggiuntiva |

Nel profilo nativo gli indirizzi RAM ordinari sono mascherati con `$3FFF`;
i quarti alti sono alias, anche sul Plus/4 configurato da plus/64 a 16 KiB.
La porta sprite e il modem condividono il budget: riservare i loro byte.
Il cambio di profilo richiede sprite disabilitati, modem inattivo e code/comando
vuoti. Sono risorse del runtime, non nuovi registri guest. **Vedi capitolo 2.**

| Range | Dispositivo o area |
|---|---|
| `$FD40..$FD5D` | SIDcart al suo indirizzo standard; `$FD5E/$FD5F` non sono SID |
| `$FD90..$FDCF` | Sprite, porta dati e otto descrittori |
| `$FDE8..$FDED` | Porta SRAM: banco, offset, dati e firma |
| `$FDF0..$FDF7` | Modem a polling |
| `$FF00..$FF1F` | TED: timer, video, input e IRQ nativi |
| `$FF3E/$FF3F` | Strobe ROM attive / RAM sottostante; valore scritto irrilevante |

`$FDxx/$FExx` rimangono I/O anche con ROM disattivate. BASIC occupa normalmente
`$8000..$BFFF`; KERNAL/ROM alta `$C000..$FFFF`, con eccezioni I/O. Zero page,
stack e vettori restano responsabilità del programma. Non usare `$0001`
come selettore di banking C64.

## SRAM: sei registri e un wrap nel banco

| Registro | R | W |
|---|---|---|
| `$FDE8` | Offset basso | Imposta basso, conserva alto |
| `$FDE9` | Offset alto, bit 6–7 zero | Imposta alto con `valore & $3F` |
| `$FDEA` | Dato, poi incremento | Scrive dato, poi incremento |
| `$FDEB` | Banco 0–3 | `valore & 3`; conserva offset |
| `$FDEC` | `$64` | Ignorata |
| `$FDED` | `$05` | Ignorata |

`indice = (banco << 14) | offset`. Dopo DATA: `offset = (offset+1) & $3FFF`.
**Il banco non cambia** passando da `$3FFF` a `$0000`. Per attraversare
64 KiB selezionare esplicitamente i quattro banchi.

Il peek diagnostico non incrementa; una lettura CPU, incluso `PEEK` BASIC,
incrementa. La firma non rivela il flag `mainram`. Coordinare la porta con
gli IRQ e non usare istruzioni RMW su DATA. **Vedi capitolo 2.**

## Sprite: slot, coordinate, palette e pubblicazione

| Registro | Funzione |
|---|---|
| `$FD90` | Enable, un bit per slot; scriverlo **per ultimo** |
| `$FD91` | Collisioni fra sprite, un bit per slot; R azzera tutto, W ignorata |
| `$FD92` | Bit per slot: 0 monocromatico, 1 raw8bpp nel profilo normale |
| `$FD93/$FD94` | Espansione X / Y ×2, un bit per slot |
| `$FD95` | **Riservato**, non realizza priorità dietro il TED |
| `$FD96` | Porta RAM sprite, R/W con autoincremento |
| `$FD97/$FD98` | Puntatore dati basso / alto a 16 bit |
| `$FD99..$FD9C` | Selettori luce, due nibble per registro |
| `$FD9D/$FD9E` | Puntatore lista illuminazione/scenery in RAM principale |
| `$FD9F` | bit 0 abilita, bit 1/2 oscuramento, bit 3 finestra di presentazione |
| `$FDA0..$FDCF` | Otto descrittori, sei byte per slot |

Per slot `s=0..7`, base `b=$FDA0+6*s`:

| Offset | Campo |
|---:|---|
| 0 | X basso |
| 1 | Y |
| 2 | X alto: soltanto bit 0 contribuisce |
| 3 | Colore locale o selettore materiale/formato nel profilo esteso |
| 4–5 | Indirizzo **in byte** del pattern nel pool, basso/alto |

Origine `(0,0)` in alto a sinistra dell'area **320×200**. In raw normale:
`X=basso+256*(alto&1)`, intervallo 0–511; Y 0–255. Il bordo taglia i pixel:
X=511 e Y=255 non significano −1. Le proiezioni signed di `leftmcm`
appartengono soltanto al profilo avanzato packed. **Vedi capitolo 3.**

| Formato normale | Dati | Trasparenza |
|---|---:|---|
| Monocromatico | 63 byte, 24×21, tre byte per riga, bit alto a sinistra | Bit 0 trasparente; bit 1 colore del descrittore |
| Raw8bpp | 504 byte, 24×21, 24 byte per riga | `$FF` consigliato; il renderer scarta tutti i valori 121–255 |

Uno sprite visibile 16×16 occupa ancora uno slot 24×21: inizializzare
padding e fori a `$FF`. In raw, **indice 0 = nero opaco**, non trasparenza.
Gli indici 0–120 rappresentano un nero e 120 combinazioni:

```text
indice 0 -> TED $00
indice i da 1 a 120:
    L = (i-1) div 15
    H = (i-1) mod 15 + 1
    colore TED = 16*L + H
```

Esempi: indice 6 → TED `$06`, indice 111 → `$76`, indice 106 → `$71`.
La palette non elimina i vincoli delle celle/modi video TED dello sfondo.

La RAM sprite usa `puntatore & $3FFF`, ma il **contatore della porta è a
16 bit**: dopo `$3FFF` registra `$4000`, che accede nuovamente all'offset 0;
solo dopo `$FFFF` i registri tornano a zero. Questo differisce dalla porta
SRAM a offset 14 bit. Anche il fetch raw/mono ricircola nel pool di 16 KiB.

Con `-plus64rastercollisions`, scrivere `$FD90` pubblica descrittori e
pattern anche a metà frame; disabilitare con zero prima di riutilizzare
gli slot. Le linee già disegnate non cambiano. Il latch contiene collisioni
fra pixel opachi degli slot, non contro il TED: nessuna collisione hardware
con muri o piattaforme. Lo slot più basso ha priorità visiva. I bit restano
legati agli **slot**, non alle identità dei nemici multiplexati.

### Formati estesi e luce

`Plus64MixedSprites` richiede `Plus64PackedCache`. Record packed allineati
da 1 KiB: sorgente64 inversa a `$200..$23F`, shift a `$240`, MCM a `$241`,
tre inchiostri a `$242..$244`, validità `$A5` a `$245`. Sono viste dei byte
condivisi, non altri 16 KiB. Il tag puntatore `$4000`, con bit 15 zero,
seleziona RAW8 misto all'offset basso14 bit; i 504 byte devono entrare senza wrap.

Sparse HIRES: colore descrittore `$F9`, magic sorgente `$A7`, maschera e
rettangoli cromatici. Un materiale usa `$80|colore` dove previsto e conserva
la maschera. Selettori nei nibble basso/alto per sprite pari/dispari:
0 storico; 1..8 N, NE, E, SE, S, SW, W, NW; 9 frontale; 10 diagonale MCM
per inchiostro. FA è un tag MCM di occlusione invisibile fra sprite virtuali,
non una priorità arbitraria dietro i caratteri TED. **Vedi capitolo 3 e FORMAT.**

## SID: note, gate e indirizzi effettivi

Profilo riproducibile: `-sound -sidenginemodel 256 -sidcartaddress 0xFD40
-sidcartclock 0`. `256` = reSID 6581; `257` = reSID 8580.
Clock SID 0: **985.248 Hz PAL**, 1.022.730 Hz NTSC. Nel runtime conservato
clock 1 passa invece **1.773.447 Hz PAL** al SID, non 886 kHz.
**Vedi capitolo 4.**

| Base voce | `+0/+1` | `+2/+3` | `+4` | `+5` | `+6` |
|---|---|---|---|---|---|
| `$FD40`, `$FD47`, `$FD4E` | Frequenza basso/alto | Pulse width 12 bit | Controllo | A alto / D basso | S alto / R basso |

CONTROL: `$01` gate, `$02` sync, `$04` ring, `$08` test, `$10` triangolare,
`$20` sega, `$40` impulso, `$80` rumore. Per riarticolare una nota serve
un fronte gate 0→1; TEST non azzera il rate counter ADSR.

| Registro | Uso |
|---|---|
| `$FD55/$FD56` | Cutoff: `(alto<<3) | (basso&7)` |
| `$FD57` | Risonanza alto nibble; routing voci 1/2/3/esterno nei bit 0–3 |
| `$FD58` | Volume 0–15; LP `$10`, BP `$20`, HP `$40`, voce 3 fuori dal diretto `$80` |
| `$FD59/$FD5A` | POTX/POTY, letture dipendenti dagli ingressi/configurazione |
| `$FD5B/$FD5C` | Letture oscillatore / inviluppo della voce 3 |
| `$FD5D` | Offset decodificato senza funzione di sintesi definita |
| `$FD5E/$FD5F` | **Non decodificati come SID** |

`N=round(Hz*2^24/clockSID)`: La4 PAL con clock 0 → `$1D45`, scrivere basso
`$45`, alto `$1D`, circa 440,029 Hz. Tenere un'ombra RAM dei registri
write-only; non recuperarli con letture o RMW. Il peek SID del debugger
mostra le ultime scritture, non necessariamente OSC3/ENV3 vivi.
Il buffer audio host modifica la latenza, non la frequenza delle note.

## Modem: polling, FIFO e comandi

| Registro | Lettura / scrittura |
|---|---|
| `$FDF0` | R estrae RX, zero se vuota; W alimenta AT finché non connesso, poi TX |
| `$FDF1` | STATUS; W ignorata |
| `$FDF2` | R zero; W bit 0 reset, altrimenti bit 1 disconnette; bit 2 cancella overrun |
| `$FDF3` | R `$04`, scrittura ignorata: «9600» descrittivo, non baud programmabile |
| `$FDF4/$FDF5` | Byte pendenti RX / TX, 0..128 nel modello corrente |
| `$FDF6/$FDF7` | Firma `$64` / protocollo `$03` |

STATUS: `$01` RX pronta, `$02` TX con spazio, `$04` connesso, `$08` chiamata
in corso, `$10` overrun latched, `$20` offline. Dopo reset: `$22`.
RX/TX hanno **128 byte ciascuna**, con comando da 256 byte: **512 byte
complessivi già nel budget**. In ricezione da rete il backend applica
backpressure quando RX è piena; scritture CPU non accettabili impostano overrun.
Leggere STATUS non cancella flag. Un byte RX `$00` è valido: controllare
prima `$01`. Il peek del dispositivo non estrae; `PEEK` BASIC estrae.

AT supportati: `AT`, `ATE0`, `ATE1`, `ATZ`, `ATH`, `ATDhost[:porta]`,
`ATDThost[:porta]`, terminati da CR ASCII `$0D`. Porta predefinita 23;
risposte `OK`, `ERROR`, `CONNECT 9600`, `NO CARRIER`, racchiuse in CR/LF.
Da connesso `ATH` e `+++` sono dati, non comandi: chiudere con `$FDF2=$02`.

Il backend è TCP host, con Telnet minimo in ingresso: non è un trasporto
binario completamente trasparente e non ha TLS. Non genera IRQ/NMI.
Il poll avviene nel callback video, non leggendo STATUS; usare timeout e
gestire l'overrun. La risoluzione DNS è sincrona. **Vedi capitolo 4.**

## TED, IRQ e reset: promemoria operativo

| Registro | Funzione nativa |
|---|---|
| `$FF00/01`, `$FF02/03`, `$FF04/05` | Timer 1/2/3; W basso ferma, W alto avvia |
| `$FF06/$FF07` | Modalità e controllo video TED |
| `$FF08` | Campionamento input TED; non è una CIA C64 |
| `$FF09` | Flag IRQ; scrivere i bit da riconoscere |
| `$FF0A/$FF0B` | Maschera IRQ e confronto raster; bit 0 di `$FF0A` = linea bit 8 |
| `$FF12..$FF14` | Selezioni/basi della memoria video nativa; rispettare i bit condivisi |
| `$FF15..$FF19` | Colori video, ausiliari e bordo secondo il modo TED |
| `$FF1C/$FF1D` | Contatore raster alto/basso |

IRQ: raster `$02`, T1 `$08`, T2 `$10`, T3 `$40`. I timer contano a metà del
clock base: **886.723,5 tick/s PAL**. Zero iniziale vale 65.536; T1 ricarica
il valore impostato, T2/T3 ricaricano 65.536 dopo il primo underflow.
Letture a due byte non atomiche; se necessario usare alto/basso/alto.
`SEI` maschera gli IRQ: non fornisce l'equivalente di un NMI CIA2.

| Azione | Effetto da ricordare |
|---|---|
| Reset registri SRAM | Banco/offset zero; conserva dati e binding `mainram` |
| Abilitazione plus/64 da disabilitato | Inizializza le viste e azzera la cartuccia, preservando la RAM interna nativa |
| Reset sprite | Azzera registri e latch, conserva il backing condiviso; inizializzare esplicitamente ogni immagine |
| Reset modem, `$FDF2=$01` | Disconnette, azzera indici/comando e overrun, conserva il payload condiviso; echo disattivato |
| Disconnessione, `$FDF2=$02` | Scarta TX, conserva RX e inserisce `OK` |
| Inizializzazione audio | Definire esplicitamente gate, forme, ADSR e volume; non leggerli da write-only |

Per i dettagli consultare i capitoli 2–4; per programmi completi e collaudi,
capitoli 5–6 e il kit SDK. Le prove C host non equivalgono a prove CPU 6502,
VICE, Windows reale o hardware fisico.

## Snapshot e proprietà RAM80

VSF con plus/64 attivo: contenitore 2.1, modulo PLUS64 1.0. I 64 KiB sono
in `PLUS4MEM`; i 16 KiB e lo stato dispositivo sono in `PLUS64`. Byte72..78
versionano i formati estesi; byte79 è la revisione scenery, corrente17.
I lettori correnti accettano 0,1,3..17; il prototipo2 è rifiutato. I vecchi
lettori possono rifiutare le nuove versioni; nessun caricamento parziale
silenzioso. Modem connesso/in chiamata: salvataggio e caricamento rifiutati.

Il payload modem è nel banco cartuccia3 `$3E00..$3FFF` in nativo o nella
RAM interna `$0000..$01FF` in MainRAM. Riservarlo prima di usare il modem;
Impossible Mission lo presta alle voci solo quando il modem è inattivo.
Le copie video/snapshot del PC non sono RAM guest. Il compositore scenery
legge la RAM emulata direttamente: per hardware fisico/genlock servono un
percorso dati, sincronizzazione e contesa verificati, non impliciti nell'API.

# 8. Materiali e shader programmabili nel budget RAM80

L'esempio completo `sdk/materials/material-example.asm` usa una maschera
HIRES generica e121 colori di evidenziazione; passa fra luce nord, est e
frontale. Eseguibile e D64 sono in `sdk/materials/prebuilt/`.

```sh
python3 sdk/materials/build_material.py --xa /path/to/xa --out build-material
```

Carica a `$1001`, entra a `$1100`, termina a `$1398` escluso. Riserva un
solo record da 1 KiB nel banco cartuccia2, già compreso nei 64 KiB. Zero page,
stack, codice e bitmap TED restano nei 16 KiB interni. Le prove hanno osservato
i 121 colori e le tre luci per 500 fotogrammi su ciascuno degli ospiti.
Non richiede Python per eseguire il D64 già costruito.

La specifica completa dei record e dei layer è in [FORMATI_GRAFICI.md](FORMATI_GRAFICI.md),
la serializzazione in [SNAPSHOT_FORMAT.md](SNAPSHOT_FORMAT.md). Le parti
storiche dei formati vanno lette con le sezioni successive della stessa
specifica: la revisione corrente supporta la scenery17. Nella REV8R i dati
del vecchio font inutilizzato sono copiati nelle pagine di staging ritirate
`$0600..$07FF` prima di ripristinare tutti i glifi della stanza.

Il compositore legge font e dati della RAM emulata. Questa possibilità
software non dimostra un accesso gratuito della cartuccia fisica alla RAM
TED: pubblicazione, arbitraggio, sincronismo e costo hardware restano da
progettare. Le maschere FA gestiscono la priorità fra sprite virtuali, non
una priorità arbitraria dietro i caratteri TED; FD95 rimane riservato.


# 9. Appendice: contabilità di Impossible Mission REV8R

Il `MANIFEST.json` conserva campi storici delle versioni precedenti oltre alle dichiarazioni correnti. Usare `ram80.active_memory_declarations`, la disposizione audio corrente e i rapporti di consegna qualificati, senza sommare ogni allocazione ereditata.

| Prenotazione verificata nei 16 KiB interni | Byte |
|---|---:|
| Primi 49 segmenti delle voci compresse | 10.986 |
| Unione degli intervalli protetti per metadati sprite/helper/backup | 5.398 |
| **Unione disgiunta** | **16.384** |

L’unione protetta comprende sedici record da 70 byte per sorgente/chiave/validità (1.120 byte), backup del codice nativo e altre aree assegnate per fase. È una mappa di prenotazione: alcune posizioni hanno proprietari diversi in fasi diverse. In questa specifica prenotazione della RAM interna non restano byte non elencati. I primi 512 byte del modem sono già compresi nei segmenti vocali, prestati mentre il modem è inattivo.

I dati audio compressi nella RAM principale sono in totale 2.136 byte: `$0A00..$0AFF` (256), `$EC98..$F1FF` (1.384) e `$FA10..$FBFF` (496). La history occupa `$F200..$F7FF` (1.536). Player e tabelle usano 3.181 byte, con ingresso `$E026`. Sono già compresi nei 64 KiB, come logica di gioco, piani dello schermo, font, sprite originali e helper di decompressione.

Il protagonista conserva la prenotazione da 4.096 byte per i record sorgente; il payload compresso è di 2.121 byte. Il riempimento disponibile nei record originali ospita anche regioni di palette, helper e scenari. Il contatore di allocazione degli scenari è 1.127 byte, comprendenti stream e descrittori: lo sfondo condiviso delle stanze da 393 byte e lo stream delle pietre da 55 byte non vanno sommati una seconda volta. L’espansione 320×200 a 3 bit richiederebbe 24.000 byte, ma non viene conservata nella RAM del programma. La preservazione della porta finale e del font usa le pagine di staging ormai ritirate `$0600..$07FF`; tutti i caratteri originali delle stanze sono ripristinati.

Il CORE di avvio si espande sul posto in 62.720 byte a `$0800..$FCFF`; lo stream corrente è di 48.101 byte e il decoder di 234 byte. Immagini di trasporto e decodificate riutilizzano la memoria in fasi diverse. Sommarne le dimensioni come allocazioni permanenti conterebbe due volte lo stesso spazio di indirizzamento.

Per confronto, l’eseguibile Windows REV8R con simboli di debug occupava 30.436.536 byte; la distribuzione finale senza quei simboli occupa 6.617.154 byte e conserva identiche le sezioni di codice e dati caricate. Il D64 occupa 174.848 byte e un VSF con password pronta 500.080 byte. Sono file del PC, non requisiti RAM del gioco. Il D64 contiene file secondari caricati in aree riutilizzate per fase. L’eseguibile realizza l’emulatore e contiene codice per il PC; non viene caricato nella cartuccia emulata. Il totale rigoroso resta **65.536 + 16.384 = 81.920 byte**.
