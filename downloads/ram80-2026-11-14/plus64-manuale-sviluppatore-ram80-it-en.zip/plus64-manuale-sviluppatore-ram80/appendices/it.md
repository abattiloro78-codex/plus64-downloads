# 8. Materiali e shader programmabili nel budget RAM80

L'esempio completo `sdk/materials/material-example.asm` usa una maschera
HIRES generica e121 colori di evidenziazione; passa fra luce nord, est e
frontale. Eseguibile e D64 sono in `sdk/materials/prebuilt/`.

```sh
python3 sdk/materials/build_material.py --xa /path/to/xa --out build-material
```

Carica a `$1001`, entra a `$1100`, termina a `$1398` escluso. Riserva un
solo record da1KiB nel banco cartuccia2, già compreso nei64KiB. Zero page,
stack, codice e bitmap TED restano nei16KiB interni. Le prove hanno osservato
i121 colori e le tre luci per500 fotogrammi su ciascuno degli ospiti.
Non richiede Python per eseguire il D64 già costruito.

La specifica completa dei record e dei layer è in [FORMATI_GRAFICI.md](FORMATI_GRAFICI.md),
la serializzazione in [SNAPSHOT_FORMAT.md](SNAPSHOT_FORMAT.md). Le parti
storiche dei formati vanno lette con le sezioni successive della stessa
specifica: la revisione corrente supporta la scenery17. Nella REV8R i dati
del vecchio font inutilizzato sono copiati nelle pagine di staging ritirate
`$0600..$07FF` prima di ripristinare tutti i glifi della stanza.

Il compositore legge font e dati della RAM emulata. Questa possibilità
software non dimostra un accesso gratuito della cartuccia fisica alla RAM
TED: pubblicazione, arbitraggio, sincronismo e costo hardware restano da
progettare. Le maschere FA gestiscono la priorità fra sprite virtuali, non
una priorità arbitraria dietro i caratteri TED; FD95 rimane riservato.


# 9. Appendice: contabilità di Impossible Mission REV8R

Il `MANIFEST.json` conserva campi storici delle versioni precedenti oltre alle dichiarazioni correnti. Usare `ram80.active_memory_declarations`, la disposizione audio corrente e i rapporti di consegna qualificati, senza sommare ogni allocazione ereditata.

| Prenotazione verificata nei 16 KiB interni | Byte |
|---|---:|
| Primi 49 segmenti delle voci compresse | 10.986 |
| Unione degli intervalli protetti per metadati sprite/helper/backup | 5.398 |
| **Unione disgiunta** | **16.384** |

L’unione protetta comprende sedici record da 70 byte per sorgente/chiave/validità (1.120 byte), backup del codice nativo e altre aree assegnate per fase. È una mappa di prenotazione: alcune posizioni hanno proprietari diversi in fasi diverse. In questa specifica prenotazione della RAM interna non restano byte non elencati. I primi 512 byte del modem sono già compresi nei segmenti vocali, prestati mentre il modem è inattivo.

I dati audio compressi nella RAM principale sono in totale 2.136 byte: `$0A00..$0AFF` (256), `$EC98..$F1FF` (1.384) e `$FA10..$FBFF` (496). La history occupa `$F200..$F7FF` (1.536). Player e tabelle usano 3.181 byte, con ingresso `$E026`. Sono già compresi nei 64 KiB, come logica di gioco, piani dello schermo, font, sprite originali e helper di decompressione.

Il protagonista conserva la prenotazione da 4.096 byte per i record sorgente; il payload compresso è di 2.121 byte. Il riempimento disponibile nei record originali ospita anche regioni di palette, helper e scenari. Il contatore di allocazione degli scenari è 1.127 byte, comprendenti stream e descrittori: lo sfondo condiviso delle stanze da 393 byte e lo stream delle pietre da 55 byte non vanno sommati una seconda volta. L’espansione 320×200 a 3 bit richiederebbe 24.000 byte, ma non viene conservata nella RAM del programma. La preservazione della porta finale e del font usa le pagine di staging ormai ritirate `$0600..$07FF`; tutti i caratteri originali delle stanze sono ripristinati.

Il CORE di avvio si espande sul posto in 62.720 byte a `$0800..$FCFF`; lo stream corrente è di 48.101 byte e il decoder di 234 byte. Immagini di trasporto e decodificate riutilizzano la memoria in fasi diverse. Sommarne le dimensioni come allocazioni permanenti conterebbe due volte lo stesso spazio di indirizzamento.

Per confronto, l’eseguibile Windows REV8R con simboli di debug occupava 30.436.536 byte; la distribuzione finale senza quei simboli occupa 6.617.154 byte e conserva identiche le sezioni di codice e dati caricate. Il D64 occupa 174.848 byte e un VSF con password pronta 500.080 byte. Sono file del PC, non requisiti RAM del gioco. Il D64 contiene file secondari caricati in aree riutilizzate per fase. L’eseguibile realizza l’emulatore e contiene codice per il PC; non viene caricato nella cartuccia emulata. Il totale rigoroso resta **65.536 + 16.384 = 81.920 byte**.
