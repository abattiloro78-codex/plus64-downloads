# 8. Programmable materials within the RAM80 budget

The complete `sdk/materials/material-example.asm` uses a generic HIRES mask
and121 selected highlights, switching between north, east and frontal
light. Its executable and D64 are under `sdk/materials/prebuilt/`.

```sh
python3 sdk/materials/build_material.py --xa /path/to/xa --out build-material
```

It loads at `$1001`, enters at `$1100`, and ends at `$1398` exclusive.
It reserves one1KiB record in cartridge bank2, already within64KiB. Zero
page, stack, code and TED bitmap remain within internal16KiB. Tests observed
all121 colours and three lights over500 frames on each host. Running the
prebuilt D64 does not require Python.

The full record and layer specification is in [FORMATI_GRAFICI.md](FORMATI_GRAFICI.md),
and serialization in [SNAPSHOT_FORMAT.md](SNAPSHOT_FORMAT.md). Historical
format sections are superseded by later sections in the same specification;
the current implementation supports scenery17. In REV8R, data formerly
placed in unused font glyphs is copied to retired `$0600..$07FF` staging
pages before restoring all original room glyphs.

The compositor reads fonts and data from emulated RAM. That software access
does not establish free physical-cartridge access to TED RAM: publication,
arbitration, synchronization and hardware cost remain to be designed. FA
masks implement priority between virtual sprites, not arbitrary priority
behind TED characters; FD95 remains reserved.


# 9. Appendix: Impossible Mission REV8R accounting

The `MANIFEST.json` contains historical parent fields as well as current declarations. Use `ram80.active_memory_declarations`, the current speech layout and qualified delivery records rather than adding every inherited allocation.

| Audited internal-16-KiB reservation | Bytes |
|---|---:|
| First 49 compressed-voice segments | 10,986 |
| Union of protected sprite metadata/helper/backup ranges | 5,398 |
| **Disjoint union** | **16,384** |

The protected union includes sixteen 70-byte source/key/valid records (1,120 bytes), native-code backups and other phase-owned storage. It is a reservation map; some locations have different owners at different phases. There are no unlisted bytes in this particular internal-RAM reservation. The modem's first 512 bytes are already included in the voice segments, borrowed while idle.

Main-RAM compressed audio data totals 2,136 bytes: `$0A00..$0AFF` (256), `$EC98..$F1FF` (1,384), and `$FA10..$FBFF` (496). Its history occupies `$F200..$F7FF` (1,536). The player and tables use 3,181 bytes, with entry `$E026`. These are already inside the 64 KiB, as are game logic, screen planes, fonts, original sprites and decompression helpers.

The hero retains its 4,096-byte source-record reservation; its compressed payload is 2,121 bytes. Existing source padding also carries palette regions, helpers and scenery. The scenery allocation counter is 1,127 bytes including its streams and descriptors: the 393-byte shared room background and 55-byte stone stream must not be added again. The 320×200 3-bit expansion would be 24,000 bytes, but that expansion is not retained in guest RAM. Final-door/font preservation uses retired `$0600..$07FF` staging pages; all original room glyphs are restored.

The cold CORE expands in place to 62,720 bytes at `$0800..$FCFF`; the current stream is 48,101 bytes and its decoder 234 bytes. Transport and decoded images reuse memory at different phases. Adding both sizes as permanent allocations would double-count the same address space.

For scale, the earlier unstripped REV8R Windows build was 30,436,536 bytes; the final distribution executable with debug sections removed is 6,617,154 bytes. Its executable core sections are unchanged by stripping. The REV8R D64 is 174,848 bytes and a password-ready VSF 500,080 bytes. These are PC files, not RAM requirements of the game. The D64 carries secondary files loaded into reused phase-specific areas. The executable implements the emulator and contains PC code; it is not loaded into the emulated cartridge. The strict guest total remains **65,536 + 16,384 = 81,920 bytes**.
