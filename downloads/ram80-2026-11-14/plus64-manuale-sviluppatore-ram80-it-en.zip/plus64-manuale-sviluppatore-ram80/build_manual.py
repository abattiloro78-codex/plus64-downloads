#!/usr/bin/env python3
"""Rebuild the complete bilingual manual from its packaged chapter sources."""
from pathlib import Path
import argparse,shutil,re,json,hashlib,importlib.util
HERE=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def build(out):
 out=out.resolve();assert out!=HERE and HERE not in out.parents,'Output must be outside the source package'
 shutil.copytree(HERE,out,ignore=shutil.ignore_patterns('*.pdf','*.html','SHA256SUMS.txt','__pycache__','*.pyc'))
 spec=importlib.util.spec_from_file_location('renderer',out/'manual_html_renderer.py');r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r);records=[]
 for lang in ['it','en']:
  r.LANG=lang;r.TITLE='Manuale sviluppatore plus/64 RAM80'if lang=='it'else'plus/64 RAM80 Developer Manual';r.QUICK='Riferimento rapido plus/64 RAM80'if lang=='it'else'plus/64 RAM80 Quick Reference';chunks=[]
  for i,p in enumerate(sorted((out/'chapters'/lang).glob('*.md')),1):
   t=re.sub(r'^# (?:[0-9]+\. )?',f'# {i}. ',p.read_text(),count=1)
   if i==1:t=t.replace('# Avvio rapido','## Avvio rapido').replace('# Quick start','## Quick start')
   chunks.append(t.strip())
  assert len(chunks)==7
  full=r.prose_spaces('\n\n'.join(chunks)+'\n\n'+(out/'appendices'/(lang+'.md')).read_text());name='Manuale_Sviluppatore_PLUS64_RAM80_IT'if lang=='it'else'PLUS64_RAM80_Developer_Manual_EN';quick='Riferimento_Rapido_PLUS64_RAM80_IT'if lang=='it'else'PLUS64_RAM80_Quick_Reference_EN';records.append(r.render(out,out,name,full,True));records.append(r.render(out,out,quick,chunks[6],False))
 proof=json.loads((out/'VALIDATION.json').read_text());proof['documentation']=records;proof['rebuilt_from_packaged_chapters']=True;(out/'VALIDATION.json').write_text(json.dumps(proof,indent=2)+'\n');(out/'SHA256SUMS.txt').write_text(''.join(sha(p)+'  '+str(p.relative_to(out))+'\n'for p in sorted(out.rglob('*'))if p.is_file()and p.name!='SHA256SUMS.txt'and '__pycache__'not in p.parts));print(json.dumps(records,indent=2))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);a=p.parse_args();build(a.out)
