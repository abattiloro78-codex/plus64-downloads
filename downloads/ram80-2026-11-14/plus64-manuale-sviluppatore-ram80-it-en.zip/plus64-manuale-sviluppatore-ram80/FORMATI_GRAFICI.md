# Extended sprite formats and compact-mask materials

This optional video-circuit extension adds no emulated payload RAM, CPU
registers or sprite slots. Storage remains the existing 64 KiB cartridge
plus 16 KiB host backing. The implementation is in the maintained VICE
source and the RAM80 snapshot source overlay. Physical circuitry is not
qualified by these emulator tests.

Enable `Plus64PackedCache` first, then `Plus64MixedSprites` (CLI:
`-plus64packedcache -plus64mixedsprites`). The extension defaults off.
Changing it while any sprite is enabled is rejected without side effects.
It survives device reset as configuration; registers reset normally.

## Mixed RAW8

With FD92's slot bit set, bit14 of the descriptor pattern pointer selects
RAW8; bit15 must be zero. The lower 14 bits address the same existing
16 KiB backing. For example, `$4800` selects RAW8 at backing offset `$0800`.
The full 504-byte image must fit without wrapping the bank. Indices 0..120
are opaque, including black0; larger values are transparent, as in the
existing RAW8 decoder. Coordinates, expansion, priority and collisions use
the ordinary compositor. Untagged slots retain packed-cache semantics.
When the extension is disabled, tagged packed pointers remain invalid.

## Eight-luminance mask material

For a valid packed multicolour record, the software-owned, non-displayed
RAW64 byte63 at record offset `$200` selects a full material colour:
`tag = $80 | colour`, with compact colour indices0..120. Therefore `$80..$F8`
are material tags; `$F9..$FF` and tags below `$80` are ordinary source tags.
Black0 remains opaque black. All64 source bytes remain part of the cache key.

The selected colour is the highlight, including its luminance. Shadows use
only lower luminances of the same hue. Index0 is black; indices1..15 are
hues1..15 at luminance0, indices16..30 at luminance1, and so on through
indices106..120 at luminance7. Examples: bright cyan108 uses tag`$EC`, bright
red107 uses`$EB`, bright blue111 uses`$EF`, blue3 uses81/tag`$D1`, and black
uses`$80`. In a user scale1=light to8=dark, TED luminance is`8-step`.

Alternatively, descriptor colour bit7 selects the material for a valid
compact mask; its lower seven bits select the same colour0..120. This also
supports HIRES masks. Tagged mixed RAW8 bypasses materials.

The profile has highlight origin (6,5) in the 24x21 sprite grid. For each
opaque pixel (x,y), luminance is:

```
max(0, 7 - ((x-6)*(x-6) + (y-5)*(y-5)) / 40)
```

Division is integer truncation. For selected colour`c > 0`, its maximum luminance is `(c-1)/15`, and
its hue is `1+(c-1)%15`. Scale the profile luminance by `maximum/7`, using
integer truncation, then output `15*luma+hue`. Colour0 outputs black.
The brightest selected colours retain all eight bands; darker selections
use fewer levels without exceeding the selected highlight colour.
The circuit computes this fixed material; it does not store an extra pixel
image or recognize game IDs, sprite IDs, game addresses or bitmap contents.
Every existing opacity, clipping, expansion and collision rule remains.
Different silhouettes need different visual evaluation of this fixed profile.

## Snapshots

PLUS64's existing fixed payload stores the configuration boolean in header
byte72, formerly reserved. Byte73 marks full-palette material semantics. CRC32 covers both. New readers accept old snapshots
with byte72 zero. First-generation material snapshots with byte72 one and
byte73 zero retain their old hue-only tags`$81..$8F` and full eight-level ramp;
their image is preserved. New full-palette snapshots use byte73 one. Old
readers reject these snapshots because they require
all reserved bytes to be zero. Corrupt booleans, palette-without-extension and extension-without-packed
configurations are rejected. Descriptors, source tags, latched colours,
alpha and collisions already have serialized storage, so no payload grows.

## Validation

```
python3 emulator/experimental/sprite-formats/tests/run.py --out qa/formats-new
```

This compiles the actual C decoder with ASan/UBSan and compares 256 supported
legacy configurations against the preserved pre-extension decoder. Additional
checks cover all121 RAW8 colours, opaque black, transparency, bank boundaries,
materials, clipping and collision invariance. The sphere integration's
`verify_game.py` adds actual cold VICE game A/B and fresh snapshot checks on
C16 and Plus/4. Neither suite is a physical-hardware test.

## Sparse mask and palette regions

A new version of the same opt-in extension accepts descriptor colour`F9`
for a valid HIRES packed record. Cache source byte0=`A7`, byte1=`S`,
byte2=base ink/material. `S=3+4*N`, where`N` is the number of inclusive
palette rectangles. Each four-byte rectangle stores bounds as the little-
endian20-bit value `x0|(y0<<5)|(x1<<10)|(y1<<15)`, followed by its ink.
Coordinates must satisfy `0<=x0<=x1<24`, `0<=y0<=y1<21`.

At source byte`S`, eight occupancy bytes identify nonzero bitmap bytes in
reverse bitmap order62..0, high bit first. The corresponding nonzero values
follow these eight bytes in the same order. Every read must fit bytes0..62;
malformed records draw nothing. Byte63's bit7 mirrors the logical source
horizontally. HIRES source shifting/clipping follows the existing rule.
Colours0..120 are solid; bit7 requests the existing luminance material using
the low seven bits. Later rectangles take precedence on opaque pixels only.
Neither the regions nor compression may introduce opacity. Rectangles,
colours, orientation and the base ink belong to software, with no game,
address, slot or silhouette recognition in the decoder.

An`F9`-selected ordinary bitmap without magic`A7` uses its cached shared1
colour as its solid ink. This permits software to reconstruct a bitmap for
ordinary bitwise effects while keeping its descriptor format selector.

The existing16KiB backing and inverse RAW64 metadata hold everything. The
63-byte temporary decoding mask in the host compositor is computation,
not extra CPU-addressable or snapshot payload memory. Hardware feasibility
and timing of this optional decoder remain unqualified.

PLUS64 header byte74 now versions sparse-format support. New extension
configuration enables it; old snapshots with74=0 retain their old behaviour.
Readers reject74>1 and sparse-without-full-palette. Bytes75..127 stay reserved.
Older executables reject the new reserved-byte value rather than loading a
snapshot with incompatible interpretation. Payload size remains unchanged.

## Eight selectable light directions plus front

With the extended formats enabled, existing registers`FD99..FD9C` select a
light direction per sprite, packed two slots per byte. The low nibble belongs
to the even slot; the high nibble to the following odd slot. Example:
`FD99=$30` gives slot1 east lighting and keeps slot0's historical highlight.

| Value | Direction | Highlight in the24x21 sprite grid |
|---|---|---|
|0|Historical profile|(6,5)|
|1|N|(12,0)|
|2|NE|(23,0)|
|3|E|(23,10)|
|4|SE|(23,20)|
|5|S|(12,20)|
|6|SW|(0,20)|
|7|W|(0,10)|
|8|NW|(0,0)|
|9|Front, from the viewer|(12,10)|

Values10..15 are reserved and retain the historical profile. Directions are
screen-relative: mirroring the source does not reverse a selected light.
The established radial luminance formula, selected highlight colour and
opacity remain unchanged. This is a colour profile, not a surface-normal or
3D lighting model. No new guest RAM, image upload or sprite slot is added;
these four registers already belonged to the existing64-byte register file.
Configuration reset sets selectors to0, preserving all previous pictures.
Snapshot header75 versions direction support; older snapshots ignore these
registers for materials. New snapshots require a reader supporting75=1.
Header bytes76..127 remain reserved.

The directions regression is in`tests/light-directions/test.c`: all121
colours, eight slots, sixteen selector values and every24x21pixel, with
ASan/UBSan, plus sparse mirroring and legacy behaviour. The reviewed game
art and launchers are not changed by implementing this platform feature.

### Mask-aware frontal material revision

For sparse masks, new snapshots with header76=1 use a frontal highlight
within each occupied row span. Thin spans retain the selected highlight;
wider spans shade their edges. This avoids darkening a face merely because
it lies away from a whole-record centre. Legacy snapshots keep the earlier
radial front9 profile. Header bytes77..127 remain reserved. No RGB palette
is invented: output remains the same121 TED colours.

### Mask material opacity

For a tagged compact-mask material, pair0 alone is transparent. Any nonzero
pair is opaque even if the old source-ink field contains an extended tag or
transparent marker: that ink is replaced by the selected material. Untagged
multicolour records retain their original ink/alpha behaviour. The sphere
regression in `tests/sphere-alpha` covers the formerly missing18 pixels.

## Diagonal character lighting (opt-in, snapshot header byte77)

With the mixed-format extension enabled, FD9D/FD9E point into existing main
RAM; FD9F bit0 enables a linked list of lighting rectangles. No additional
CPU-addressable storage or texture RAM is allocated. Rendering reads the
list directly, with at most32 nodes per scanline. Sprites are composited
AFTER this pass and retain their original pixels, alpha and collisions.

Base node (12 bytes): next pointer LE16; x,y,width,height in8px character
cells; local xmin,ymin,xmax,ymax; compact background key; flags. Coordinates
must fit320x200. Flags0 shades all nonblack pixels except the background
key. Flags1 uses a20-byte node, adding font-base LE16, live-character-base
LE16, live-attribute-base LE16 and expected-tile-character-base LE16. It
shades only matching glyph foreground pixels, with bit3 of the source
attribute selecting two-bit multicolour (pair0 transparent); otherwise
one-bit hires. This preserves opaque foregrounds matching the background
colour and excludes replaced characters such as search windows. Unknown
flags, invalid bounds or out-of-range reads never affect display pixels.

Hue is preserved. With dx=max(1,xmax-xmin),dy=max(1,ymax-ymin), local x,y
clamped to those bounds, the TED luminance is clamped0..7 after adding
2-floor(5*(x*dy+y*dx)/(2*dx*dy)). Thus equal-light bands are diagonal.
Black stays black. The optional VICE raster cache redraws the TED base
before lighting, preventing accumulation on static frames.

Snapshot PLUS64 header77 records the format version as a boolean dependent
on mixed formats; bytes78..127 remain zero. Descriptors and operands reside
in the existing64KiB main image and are already serialized. Old snapshots
restore with lighting disabled. Old readers reject the new nonzero flag.

## Per-ink diagonal MCM sprite lighting (snapshot header78)

Light-direction nibble10 is an opt-in diagonal profile for validated compact
MCM records. It retains all three original inks and pair0 transparency.
Black stays black; nonblack compact inks retain hue while luminance gets
2-floor(5*((x-xmin)*dy+(y-ymin)*dx)/(2*dx*dy)), clamped0..7. Bounds are
calculated from the original opaque source pairs per frame; dx/dy have a
minimum of1. Expansion replicates shaded source pixels. The light stays
in screen coordinates as the source robot head animation turns.

The effect runs before sprite priority/collision composition. It does not
modify source RAM, occupancy, collisions or texture upload grammar. RAW8,
HIRES and sparse sprites retain their existing behaviour. No guest storage
is added. The new flag fills existing host structure alignment padding.

Header78 is a boolean requiring mixed formats and light-directions support;
79..127 remain zero. Old snapshots restore78=0 and retain the historical
profile10 fallback. Old readers reject the new nonzero reserved flag.

## Streamed scenery (header79, scene nodes with flag2)

The extension adds no register or addressable RAM. A scene node in the
existing FD9D/E linked list is24 bytes: nextLE16; x,y,w,h in8px cells;
background streamLE16; material tile streamLE16; stone hue1..15; flag2;
source font-bank baseLE16; character baseLE16; attribute baseLE16;
selector tableLE16; source font-control pointerLE16; fallback hue1..15;
reserved0. The control is a VIC-compatible D018 shadow (character index
bits3..1), with its multicolour enable at control-2 bit4. The source bank
and planes are supplied by software; no game addresses are in the circuit.

Selector table: count<=16, then records font-index,first-glyph,last-glyph,
material-kind. Kind0 draws the background behind transparent font pixels;
kind1 draws the luminance tile, staggered on alternate tile rows; kind2
adds an upper-left bevel to opaque nonblack character pixels and puts the
background behind transparent ones; kind3 uses the background over the
whole selected character. Software supplies original glyph selections.

Both image streams are explicit guest-owned linked segments: nextLE16,
payload length8,payload bytes. Each image starts widthLE16,heightLE16,
limited320x200; then bands repeat8,token-count8,tokens. A token has a3-bit
luminance and a5-bit run length minus1. Runs exactly cover the image width;
bands exactly cover its height. Scenery stretches to the node rectangle;
the material tile repeats. Only transient host scanlines are decoded;
there is no persistent image pool or second guest copy. Segments are
bounded to64 per traversal and node lists to32; malformed reads fail safely.

Foreground character masking, room colours and the scene rectangle remain
software inputs. Sprites are composited afterwards. Nodes with flag2 are
ignored when scene support is off. Header79 is a boolean requiring mixed
formats and character lighting;80..127 remain zero. Old snapshots restore
79=0. Older readers reject the new nonzero reserved header flag.


### Scenery version3 vertical interiors and grooves

Header79 version3 adds material4, a vertical ramp with eight luminances
7 through0 across the software node rectangle, and material5, the same
ramp with a two-pixel dark groove and one-pixel lit lip at each selected
character's left edge. Hue follows the source foreground, with the node
fallback for black. Node byte23 bit0 skips unmatched characters, retaining
the earlier rendering. Other bits are reserved. Nodes and selectors remain
in the same guest RAM; there is no new pool or register. Version2 belonged
to a withdrawn prototype and is rejected to avoid ambiguous materials.


### Scenery version4 black panels and horizontal colour ramps

Material6 sets only selected characters to black. Materials7/8 ramp right/
left across the software rectangle, but only pixels whose hue matches node
byte10 or22. Other hues retain the previous rendering. Used with override-
only nodes, this changes a selected material without touching other scene
pixels. No new guest memory pool or register. Header79 accepts0,1,3,4;
older readers reject4. Existing material meanings remain unchanged.


### Scenery version5 character-width colour ramps

Materials9/10 use all eight luminances across one character width, directed
right/left. Hue filtering remains byte10/22, as for materials7/8. This lets
software shade narrow posts without scaling the ramp across a larger scene
rectangle. Header79 adds5, preserving0/1/3/4 and rejecting the withdrawn2.
No extra register, guest byte, or memory pool is required by the renderer.


### Scenery version6 raised UI rectangles

Linked node flag3 uses12 bytes: nextLE16, bounding x/y/w/h in cells,
layout-stream pointerLE16, grid count<=32, bevel width1..8 pixels,
two hue numbers packed in nibbles. Layout uses the existing bounded linked
segment reader; each record is x/y/w/h in cells, packed column/row counts, and packed X/Y steps. Counts are1..8, steps0..15, at most64 instances total. The two node hues select the native surfaces to shade.
Only matching nonblack native pixels are shaded. Top/left bevels are lit,
bottom/right bevels dark, with eight luminances across the face and rim.
Glyphs/icons, geometry, RAM and collision state are not rewritten. Older
readers reject header79=6. No extra RAM pool or register is introduced.


### Scenery version7 native icon protection

UI grid height bit7 protects pixels of the first node hue within that grid.
The height is bits6..0. Protected pixels are restored from the incoming
native TED scanline, before any UI frame layers, retaining their original
luminance and glyph detail. Other pixels keep the existing raised profile.
Only a transient host scanline is used; no guest byte or pool is added.
Header79 adds7; earlier supported versions retain their original behaviour.


### Scenery version8 symmetric corridor materials

Material5 follows the transparent edge of its supplied font row: trailing
clear bits mirror the groove and its lit lip. Material11 shades two wings
away from a central gap; node byte23 bits1..6 specify gap width in cells,
bit0 retains override-only semantics, bit7 remains reserved. The node
rectangle, material hues and font selections are software parameters.
Older materials keep their behaviour; header79 adds8 for fail-closed reads.
No extra guest storage or register is introduced.


### Scenery version9 world-anchored masonry and flat trim

Scene byte23 bit7 selects a row-counter pointer in bytes12..13. Its
containing 16KiB bank supplies the aligned font-bank base. When enabled, material1
samples both the tile row and its stagger in world Y (screen Y + 8 * counter).
The source counter, selected by software, therefore moves the wall texture
and freezes it when the counter stops. Other material layers remain fixed.
Material12 uses the same hue filter and central-gap parameters as11, but
renders one uniform midtone (luminance3, hue byte10). Header79 adds9.
One row-counter byte uses existing game padding. No additional RAM pool,
tile copy, register or CPU drawing loop is added.

For scenery version9, lighting register FD9F bits1 or2 request presentation
blanking of the 320x200 viewport after all background and sprite layers.
Collision accumulation remains active. Software holds this bit throughout
room construction and the original wipe, then marks completion with bit2. The next IRQ gate selects the completed
scene and replaces bit2 with the normal enable bit0.
The gate preserves blanking until the explicit completion hook. No image
copy, guest buffer, delay loop or change to the original room logic is used.


### Scenery version10 source-attached panels and local bevels

Material13 shades opaque source pixels with eight luminances within the
character row; clear pixels stay black. Byte22 optionally selects the hue
(zero selects the source ink hue); byte23 bits1..6 optionally exclude a
central gap in cells. Material14 preserves opaque native
pixels with a black transparent background. Materials15/16 locate the
contiguous vertical run of selected panel materials in source characters
and attributes. Byte10 is the attribute mask and byte22 the excluded value
(rendered black); byte23 bits1..6 supply the full panel height in cells.
This keeps illumination attached to moving, clipped panels. Material16
also retains the mirrored black groove and illuminated lip. These material
IDs and selectors are generic; no game glyph or CPU address is embedded
in the renderer. Header79 adds10, preserving version9 semantics.
No extra guest RAM pool, image copy or game drawing loop is introduced.

Materials17/18/20/21 are source-attached counterparts of the rectangular
and character-width horizontal ramps. Material19 supplies the two-wing
ramp. They derive coverage and the two shaded hues directly from supplied
multicolour font pixels (code1 uses byte22, code2 uses byte10), rather than
from a potentially older native framebuffer colour. This makes the same
material work with every shaft palette and avoids mixed update colours.

Material22 uses the same source mask, hue and central-gap fields as13,
with eight luminances increasing away from the gap toward the outer
edges of the supplied rectangle. This gives mirrored depth lighting for
floors leading from a central shaft to room entrances.

Material23 requires a dedicated single-selector node. It fills clear source
mask pixels from the shared bitmap at logical row byte22*8 + source row
within the character, stretched using the node height. Opaque pixels use
luminance7; byte10 supplies the surface hue. This preserves an approved
bitmap floor profile while attaching it to scrolling character geometry.
It reuses the existing scanline buffer and introduces no guest storage.

### Scenery version11 progressive presentation window

FD9F bit3 enables post-sprite window nodes (flag4). A12-byte node supplies
next16, x/y/w/h in character cells, top-source16, bottom-source16, native
TED colour and flag4. The two source bytes provide pixel Y bounds for a
central mask. Bounds outside the node rectangle are clipped; inverted or
empty bounds mask nothing. Collisions continue independently of visibility.
The game drives this generic mask from its original reveal bounds, so the
completed scene appears progressively instead of being enabled all at once.
The window descriptor and helpers reuse existing padding and retired
furniture-only helper bytes; no additional guest RAM pool is introduced.
For entry completion the game clears bit3 directly to the ordinary enable
bit, avoiding an additional full-black frame. Exit retains its separate
ready-blank flag until the following gate selects the corridor scene.

### Scenery version12 regular baseboard surface

Material24 retains the material23 floor profile except in the first three
source scanlines. In those scanlines it uses eight regular luminance steps
away from the central gap (byte23 bits1..6), with hue byte10. The central
cab area and the white walking surface keep the approved profile. The game
also links the presentation window to both scene lists and drives the same
original bounds during closing and reopening on entry and exit.

### Scenery format13: indexed colour materials and conditional owners

The existing81920 guest bytes remain the complete device memory. No new
CPU registers. Snapshot header79=13; readers through12 reject13. Older
versions0..12 remain accepted by this reader.

Flag5 is a12-byte indexed tint: nextLE16,x/y/w/h in character cells,
first-tableLE16,second-tableLE16,style,5. Tables contain compact colours0..120;
255 preserves a native pixel. Bit7 limits inputs to native hues0..7.
Normally two8-entry tables index native hue; bit6 instead selects two16-entry
tables by native luminance<5/>=5. Low three style bits select diagonal shade
depth0..7; bit5 selects frontal radial shading. A table colour with bit7 set
retains native luminance relative to white7 and caps shading at two steps,
useful for legible silver details and displays. Black native pixels remain
black. Tint runs before streamed scene materials and sprite composition.

Flag7 extends flag5 to20 bytes: bytes12/13 condition pointer,14 mask,
15/16 accepted masked values,17/18 second pointer,19 exact second value.
It draws only when both conditions hold. No addresses or colours are built
into the renderer.

Flag6 is a12-byte conditional link: fallbackLE16,targetLE16,conditionPtrLE16,
value,mask,ownerFlags,reserved0,reserved0,6. A matching condition chooses
target. ownerFlags bit0 replaces the preceding scene/light/window chain
with that target; this prevents stale game layers from touching an ending
owner. All walks are bounded to32 descriptors and checked RAM addresses.

### Scenery format14 protected native UI

Flag8 is a24-byte protected scene descriptor, sharing flag2's image streams,
source planes and selector. Its aligned font-low byte12 instead packs the
required source bank in bits0..2 and the final native-text glyph in bits3..7;
byte13 retains the aligned font base high byte. Byte22 packs native-text ink
in its high nibble and the existing fallback hue in its low nibble. Byte23
is an additional native UI glyph (for the solid horizontal border, included
only next to native text rows). Native UI protection
is active only when the source font first byte is nonzero.

A matching native text cell bypasses both furniture lighting and background
replacement; its original foreground and solid native background survive.
The source control pointer also names the standard logical view: control-3
is sprite enable. Wrong-bank or sprite-disabled owners suppress scene and
furniture effects, restoring original terminal/defeat backgrounds. An active
conditional ending owner takes precedence. The original transition window
mask remains independent of this UI protection. No CPU register, game
instruction or guest allocation is added. Snapshot byte79=14; older readers
reject14, while this reader retains versions0..13.

### Format15 collision only packed masks and transition protection

Packed MCM source tag63=F9 selects a collision-only mask. The inverse-cache
key retains the tag. All63 mask bytes, expansion, coordinates and collision
occupancy remain unchanged; the mask emits no pixels or visible priority.
Visible priority uses a separate transient host occupancy array. This adds
no guest RAM, device register, guest bitmap or guest instruction. Immediate
collision latching and the separate deferred scanline collision summaries
retain the full mask. Deferred callers using collision-only records must
use the separate scanline summary API: visual alpha contains visible sprites.

The host enables this interpretation in profile15 and restores the ordinary
reserved-tag interpretation for older snapshots. Snapshot byte79=15;
readers without profile15 reject it. Formats0..14 remain supported.

During a guest-selected flag4 window (FD9F bit3), flag8 native-UI suppression
and text-cell bypasses are suspended. Enhanced scenery stays visible behind
the original opening/closing mask even when source sprites are disabled.
Outside that window, the protected SEARCHING/terminal/defeat behavior remains.

The game marks its existing expanded collision stencil with F9. A linked
flag6 conditional and flag5 black palette cover only the bottom80 pixels
until the native HUD's first glyph is ready. These40 descriptor/palette bytes
reuse unused room-font slots; no6502 instruction or allocation is added.
The existing ending owner bypasses normal scene effects.

### Format16 hidden occluding masks

Packed MCM tagFA retains the original mask's sprite display priority while
emitting no image pixels. A lower-priority sprite covered by this mask is
hidden, revealing the scene already rendered underneath. Collision occupancy
is unchanged. TagF9 keeps the non-occluding behavior from profile15; FA stays
an ordinary reserved tag in profiles0..15. The host restores this distinction
from snapshot byte79. Invisible priority is a transient host bit alongside
visible occupancy; no guest RAM or source bitmap is added.

### Format17 framed masonry material

Scene material25 reuses material1's existing stone stream and staggering.
Byte23 bits1..6 select a centered gap in character cells. For valid gaps of
at least16 pixels, its interior is black, with two8-pixel vertical trim ramps
at the edges; byte22 supplies the trim hue, byte10 the masonry hue. Other
pixels use the existing tile. Scrolling retains flag2's counter semantics.

The lower-background scene descriptor and selector occupy29 bytes in an
explicit room-font lease, linked after the ending owner and computer tint.
Its bank1-only, matching-only material yields to the original bank3 HUD.
The shared stone stream, shaft and shaded rails continue through the lower
80 pixels until the apparatus covers them, as in the C64 arrangement.
The background adds no6502 instructions, allocations or image streams.
Snapshot byte79=17; older readers reject17 and this reader keeps0..16.

Reserve all original dynamic platform glyphs49..51, not just glyphs found
in static room initializers. In particular,4C..51 are the moving platforms'
half-step images and must retain their original font bytes. The game builder
checks every font lease against the original0DB4..0DBC platform glyph table.

Initial-pose publication uses36 bytes in3 instruction-aligned pieces in
other reserved font spans (5750,5738,5768), with2 inter-piece JMPs. Its
original LEFT flag is unchanged; the existing orientation adapter copies it
to the3 pose tags before initial C9B0 publication. A/X/Y/P/SP and ZP18/19
are preserved. The original warm font lease restores all3 pieces after the
ending's temporary ENDWAVE lease. There is no per-gameplay-frame CPU call.
